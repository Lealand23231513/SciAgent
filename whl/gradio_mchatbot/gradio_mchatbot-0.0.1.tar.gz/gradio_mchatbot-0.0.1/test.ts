// type FileMessage = {
// 	file: string;
// 	alt_text?: string;
// };
// type Equals<X, Y> = (<T>() => T extends X ? 1 : 2) extends <T>() => T extends Y ? 1 : 2 ? true : false;
// let s = {file:'s', b:'v'};

console.log(typeof 's')