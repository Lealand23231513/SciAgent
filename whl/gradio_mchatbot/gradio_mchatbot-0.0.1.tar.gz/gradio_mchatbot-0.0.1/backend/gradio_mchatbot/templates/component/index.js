var oc = Object.defineProperty;
var uc = (s, t, n) => t in s ? oc(s, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : s[t] = n;
var je = (s, t, n) => (uc(s, typeof t != "symbol" ? t + "" : t, n), n), cc = (s, t, n) => {
  if (!t.has(s))
    throw TypeError("Cannot " + n);
};
var La = (s, t, n) => {
  if (t.has(s))
    throw TypeError("Cannot add the same private member more than once");
  t instanceof WeakSet ? t.add(s) : t.set(s, n);
};
var An = (s, t, n) => (cc(s, t, "access private method"), n);
const hc = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Xl = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
hc.reduce(
  (s, { color: t, primary: n, secondary: i }) => ({
    ...s,
    [t]: {
      primary: Xl[t][n],
      secondary: Xl[t][i]
    }
  }),
  {}
);
function Zo(s) {
  let t, n = s[0], i = 1;
  for (; i < s.length; ) {
    const o = s[i], u = s[i + 1];
    if (i += 2, (o === "optionalAccess" || o === "optionalCall") && n == null)
      return;
    o === "access" || o === "optionalAccess" ? (t = n, n = u(n)) : (o === "call" || o === "optionalCall") && (n = u((...f) => n.call(t, ...f)), t = void 0);
  }
  return n;
}
class On extends Error {
  constructor(t) {
    super(t), this.name = "ShareError";
  }
}
async function Yl(s, t) {
  if (window.__gradio_space__ == null)
    throw new On("Must be on Spaces to share.");
  let n, i, o;
  if (t === "url") {
    const v = await fetch(s);
    n = await v.blob(), i = v.headers.get("content-type") || "", o = v.headers.get("content-disposition") || "";
  } else
    n = fc(s), i = s.split(";")[0].split(":")[1], o = "file" + i.split("/")[1];
  const u = new File([n], o, { type: i }), f = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: u,
    headers: {
      "Content-Type": u.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!f.ok) {
    if (Zo([f, "access", (v) => v.headers, "access", (v) => v.get, "call", (v) => v("content-type"), "optionalAccess", (v) => v.includes, "call", (v) => v("application/json")])) {
      const v = await f.json();
      throw new On(`Upload failed: ${v.error}`);
    }
    throw new On("Upload failed.");
  }
  return await f.text();
}
function fc(s) {
  for (var t = s.split(","), n = t[0].match(/:(.*?);/)[1], i = atob(t[1]), o = i.length, u = new Uint8Array(o); o--; )
    u[o] = i.charCodeAt(o);
  return new Blob([u], { type: n });
}
function mc(s) {
  s.addEventListener("click", t);
  async function t(n) {
    const i = n.composedPath(), [o] = i.filter(
      (u) => Zo([u, "optionalAccess", (f) => f.tagName]) === "BUTTON" && u.classList.contains("copy_code_button")
    );
    if (o) {
      let u = function(y) {
        y.style.opacity = "1", setTimeout(() => {
          y.style.opacity = "0";
        }, 2e3);
      };
      n.stopImmediatePropagation();
      const f = o.parentElement.innerText.trim(), g = Array.from(
        o.children
      )[1];
      await dc(f) && u(g);
    }
  }
  return {
    destroy() {
      s.removeEventListener("click", t);
    }
  };
}
async function dc(s) {
  let t = !1;
  if ("clipboard" in navigator)
    await navigator.clipboard.writeText(s), t = !0;
  else {
    const n = document.createElement("textarea");
    n.value = s, n.style.position = "absolute", n.style.left = "-999999px", document.body.prepend(n), n.select();
    try {
      document.execCommand("copy"), t = !0;
    } catch (i) {
      console.error(i), t = !1;
    } finally {
      n.remove();
    }
  }
  return t;
}
function xn(s) {
  let t, n = s[0], i = 1;
  for (; i < s.length; ) {
    const o = s[i], u = s[i + 1];
    if (i += 2, (o === "optionalAccess" || o === "optionalCall") && n == null)
      return;
    o === "access" || o === "optionalAccess" ? (t = n, n = u(n)) : (o === "call" || o === "optionalCall") && (n = u((...f) => n.call(t, ...f)), t = void 0);
  }
  return n;
}
const pc = async (s) => (await Promise.all(
  s.map(async (n) => await Promise.all(
    n.map(async (i, o) => {
      if (i === null)
        return "";
      let u = o === 0 ? "😃" : "🤖", f = "";
      if (typeof i == "string") {
        const g = {
          audio: /<audio.*?src="(\/file=.*?)"/g,
          video: /<video.*?src="(\/file=.*?)"/g,
          image: /<img.*?src="(\/file=.*?)".*?\/>|!\[.*?\]\((\/file=.*?)\)/g
        };
        f = i;
        for (let [v, y] of Object.entries(g)) {
          let D;
          for (; (D = y.exec(i)) !== null; ) {
            const B = D[1] || D[2], q = await Yl(B, "url");
            f = f.replace(B, q);
          }
        }
      } else {
        if (!xn([i, "optionalAccess", (v) => v.url]))
          return "";
        const g = await Yl(i.url, "url");
        xn([i, "access", (v) => v.mime_type, "optionalAccess", (v) => v.includes, "call", (v) => v("audio")]) ? f = `<audio controls src="${g}"></audio>` : xn([i, "access", (v) => v.mime_type, "optionalAccess", (v) => v.includes, "call", (v) => v("video")]) ? f = g : xn([i, "access", (v) => v.mime_type, "optionalAccess", (v) => v.includes, "call", (v) => v("image")]) && (f = `<img src="${g}" />`);
      }
      return `${u}: ${f}`;
    })
  ))
)).map(
  (n) => n.join(
    n[0] !== "" && n[1] !== "" ? `
` : ""
  )
).join(`
`);
var Zl = Object.prototype.hasOwnProperty;
function li(s, t) {
  var n, i;
  if (s === t)
    return !0;
  if (s && t && (n = s.constructor) === t.constructor) {
    if (n === Date)
      return s.getTime() === t.getTime();
    if (n === RegExp)
      return s.toString() === t.toString();
    if (n === Array) {
      if ((i = s.length) === t.length)
        for (; i-- && li(s[i], t[i]); )
          ;
      return i === -1;
    }
    if (!n || typeof s == "object") {
      i = 0;
      for (n in s)
        if (Zl.call(s, n) && ++i && !Zl.call(t, n) || !(n in t) || !li(s[n], t[n]))
          return !1;
      return Object.keys(t).length === i;
    }
  }
  return s !== s && t !== t;
}
const {
  SvelteComponent: gc,
  assign: vc,
  create_slot: bc,
  detach: yc,
  element: wc,
  get_all_dirty_from_scope: _c,
  get_slot_changes: kc,
  get_spread_update: Dc,
  init: Ac,
  insert: xc,
  safe_not_equal: Sc,
  set_dynamic_element_data: Kl,
  set_style: St,
  toggle_class: L0,
  transition_in: Ko,
  transition_out: Qo,
  update_slot_base: Ec
} = window.__gradio__svelte__internal;
function Fc(s) {
  let t, n, i;
  const o = (
    /*#slots*/
    s[18].default
  ), u = bc(
    o,
    s,
    /*$$scope*/
    s[17],
    null
  );
  let f = [
    { "data-testid": (
      /*test_id*/
      s[7]
    ) },
    { id: (
      /*elem_id*/
      s[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      s[3].join(" ") + " svelte-1t38q2d"
    }
  ], g = {};
  for (let v = 0; v < f.length; v += 1)
    g = vc(g, f[v]);
  return {
    c() {
      t = wc(
        /*tag*/
        s[14]
      ), u && u.c(), Kl(
        /*tag*/
        s[14]
      )(t, g), L0(
        t,
        "hidden",
        /*visible*/
        s[10] === !1
      ), L0(
        t,
        "padded",
        /*padding*/
        s[6]
      ), L0(
        t,
        "border_focus",
        /*border_mode*/
        s[5] === "focus"
      ), L0(t, "hide-container", !/*explicit_call*/
      s[8] && !/*container*/
      s[9]), St(
        t,
        "height",
        /*get_dimension*/
        s[15](
          /*height*/
          s[0]
        )
      ), St(t, "width", typeof /*width*/
      s[1] == "number" ? `calc(min(${/*width*/
      s[1]}px, 100%))` : (
        /*get_dimension*/
        s[15](
          /*width*/
          s[1]
        )
      )), St(
        t,
        "border-style",
        /*variant*/
        s[4]
      ), St(
        t,
        "overflow",
        /*allow_overflow*/
        s[11] ? "visible" : "hidden"
      ), St(
        t,
        "flex-grow",
        /*scale*/
        s[12]
      ), St(t, "min-width", `calc(min(${/*min_width*/
      s[13]}px, 100%))`), St(t, "border-width", "var(--block-border-width)");
    },
    m(v, y) {
      xc(v, t, y), u && u.m(t, null), i = !0;
    },
    p(v, y) {
      u && u.p && (!i || y & /*$$scope*/
      131072) && Ec(
        u,
        o,
        v,
        /*$$scope*/
        v[17],
        i ? kc(
          o,
          /*$$scope*/
          v[17],
          y,
          null
        ) : _c(
          /*$$scope*/
          v[17]
        ),
        null
      ), Kl(
        /*tag*/
        v[14]
      )(t, g = Dc(f, [
        (!i || y & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          v[7]
        ) },
        (!i || y & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          v[2]
        ) },
        (!i || y & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        v[3].join(" ") + " svelte-1t38q2d")) && { class: n }
      ])), L0(
        t,
        "hidden",
        /*visible*/
        v[10] === !1
      ), L0(
        t,
        "padded",
        /*padding*/
        v[6]
      ), L0(
        t,
        "border_focus",
        /*border_mode*/
        v[5] === "focus"
      ), L0(t, "hide-container", !/*explicit_call*/
      v[8] && !/*container*/
      v[9]), y & /*height*/
      1 && St(
        t,
        "height",
        /*get_dimension*/
        v[15](
          /*height*/
          v[0]
        )
      ), y & /*width*/
      2 && St(t, "width", typeof /*width*/
      v[1] == "number" ? `calc(min(${/*width*/
      v[1]}px, 100%))` : (
        /*get_dimension*/
        v[15](
          /*width*/
          v[1]
        )
      )), y & /*variant*/
      16 && St(
        t,
        "border-style",
        /*variant*/
        v[4]
      ), y & /*allow_overflow*/
      2048 && St(
        t,
        "overflow",
        /*allow_overflow*/
        v[11] ? "visible" : "hidden"
      ), y & /*scale*/
      4096 && St(
        t,
        "flex-grow",
        /*scale*/
        v[12]
      ), y & /*min_width*/
      8192 && St(t, "min-width", `calc(min(${/*min_width*/
      v[13]}px, 100%))`);
    },
    i(v) {
      i || (Ko(u, v), i = !0);
    },
    o(v) {
      Qo(u, v), i = !1;
    },
    d(v) {
      v && yc(t), u && u.d(v);
    }
  };
}
function Cc(s) {
  let t, n = (
    /*tag*/
    s[14] && Fc(s)
  );
  return {
    c() {
      n && n.c();
    },
    m(i, o) {
      n && n.m(i, o), t = !0;
    },
    p(i, [o]) {
      /*tag*/
      i[14] && n.p(i, o);
    },
    i(i) {
      t || (Ko(n, i), t = !0);
    },
    o(i) {
      Qo(n, i), t = !1;
    },
    d(i) {
      n && n.d(i);
    }
  };
}
function Tc(s, t, n) {
  let { $$slots: i = {}, $$scope: o } = t, { height: u = void 0 } = t, { width: f = void 0 } = t, { elem_id: g = "" } = t, { elem_classes: v = [] } = t, { variant: y = "solid" } = t, { border_mode: D = "base" } = t, { padding: B = !0 } = t, { type: q = "normal" } = t, { test_id: G = void 0 } = t, { explicit_call: K = !1 } = t, { container: $ = !0 } = t, { visible: X = !0 } = t, { allow_overflow: M = !0 } = t, { scale: z = null } = t, { min_width: F = 0 } = t, N = q === "fieldset" ? "fieldset" : "div";
  const O = (R) => {
    if (R !== void 0) {
      if (typeof R == "number")
        return R + "px";
      if (typeof R == "string")
        return R;
    }
  };
  return s.$$set = (R) => {
    "height" in R && n(0, u = R.height), "width" in R && n(1, f = R.width), "elem_id" in R && n(2, g = R.elem_id), "elem_classes" in R && n(3, v = R.elem_classes), "variant" in R && n(4, y = R.variant), "border_mode" in R && n(5, D = R.border_mode), "padding" in R && n(6, B = R.padding), "type" in R && n(16, q = R.type), "test_id" in R && n(7, G = R.test_id), "explicit_call" in R && n(8, K = R.explicit_call), "container" in R && n(9, $ = R.container), "visible" in R && n(10, X = R.visible), "allow_overflow" in R && n(11, M = R.allow_overflow), "scale" in R && n(12, z = R.scale), "min_width" in R && n(13, F = R.min_width), "$$scope" in R && n(17, o = R.$$scope);
  }, [
    u,
    f,
    g,
    v,
    y,
    D,
    B,
    G,
    K,
    $,
    X,
    M,
    z,
    F,
    N,
    O,
    q,
    o,
    i
  ];
}
class Bc extends gc {
  constructor(t) {
    super(), Ac(this, t, Tc, Cc, Sc, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: Mc,
  append: Ia,
  attr: Sn,
  create_component: zc,
  destroy_component: Nc,
  detach: Rc,
  element: Ql,
  init: Lc,
  insert: Ic,
  mount_component: Oc,
  safe_not_equal: qc,
  set_data: Pc,
  space: Hc,
  text: Uc,
  toggle_class: I0,
  transition_in: Gc,
  transition_out: Vc
} = window.__gradio__svelte__internal;
function Wc(s) {
  let t, n, i, o, u, f;
  return i = new /*Icon*/
  s[1]({}), {
    c() {
      t = Ql("label"), n = Ql("span"), zc(i.$$.fragment), o = Hc(), u = Uc(
        /*label*/
        s[0]
      ), Sn(n, "class", "svelte-9gxdi0"), Sn(t, "for", ""), Sn(t, "data-testid", "block-label"), Sn(t, "class", "svelte-9gxdi0"), I0(t, "hide", !/*show_label*/
      s[2]), I0(t, "sr-only", !/*show_label*/
      s[2]), I0(
        t,
        "float",
        /*float*/
        s[4]
      ), I0(
        t,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    m(g, v) {
      Ic(g, t, v), Ia(t, n), Oc(i, n, null), Ia(t, o), Ia(t, u), f = !0;
    },
    p(g, [v]) {
      (!f || v & /*label*/
      1) && Pc(
        u,
        /*label*/
        g[0]
      ), (!f || v & /*show_label*/
      4) && I0(t, "hide", !/*show_label*/
      g[2]), (!f || v & /*show_label*/
      4) && I0(t, "sr-only", !/*show_label*/
      g[2]), (!f || v & /*float*/
      16) && I0(
        t,
        "float",
        /*float*/
        g[4]
      ), (!f || v & /*disable*/
      8) && I0(
        t,
        "hide-label",
        /*disable*/
        g[3]
      );
    },
    i(g) {
      f || (Gc(i.$$.fragment, g), f = !0);
    },
    o(g) {
      Vc(i.$$.fragment, g), f = !1;
    },
    d(g) {
      g && Rc(t), Nc(i);
    }
  };
}
function jc(s, t, n) {
  let { label: i = null } = t, { Icon: o } = t, { show_label: u = !0 } = t, { disable: f = !1 } = t, { float: g = !0 } = t;
  return s.$$set = (v) => {
    "label" in v && n(0, i = v.label), "Icon" in v && n(1, o = v.Icon), "show_label" in v && n(2, u = v.show_label), "disable" in v && n(3, f = v.disable), "float" in v && n(4, g = v.float);
  }, [i, o, u, f, g];
}
class Xc extends Mc {
  constructor(t) {
    super(), Lc(this, t, jc, Wc, qc, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: Yc,
  append: si,
  attr: b0,
  bubble: Zc,
  create_component: Kc,
  destroy_component: Qc,
  detach: Jo,
  element: oi,
  init: Jc,
  insert: $o,
  listen: $c,
  mount_component: e4,
  safe_not_equal: t4,
  set_data: r4,
  set_style: En,
  space: n4,
  text: a4,
  toggle_class: Wt,
  transition_in: i4,
  transition_out: l4
} = window.__gradio__svelte__internal;
function Jl(s) {
  let t, n;
  return {
    c() {
      t = oi("span"), n = a4(
        /*label*/
        s[1]
      ), b0(t, "class", "svelte-lpi64a");
    },
    m(i, o) {
      $o(i, t, o), si(t, n);
    },
    p(i, o) {
      o & /*label*/
      2 && r4(
        n,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && Jo(t);
    }
  };
}
function s4(s) {
  let t, n, i, o, u, f, g, v = (
    /*show_label*/
    s[2] && Jl(s)
  );
  return o = new /*Icon*/
  s[0]({}), {
    c() {
      t = oi("button"), v && v.c(), n = n4(), i = oi("div"), Kc(o.$$.fragment), b0(i, "class", "svelte-lpi64a"), Wt(
        i,
        "small",
        /*size*/
        s[4] === "small"
      ), Wt(
        i,
        "large",
        /*size*/
        s[4] === "large"
      ), t.disabled = /*disabled*/
      s[7], b0(
        t,
        "aria-label",
        /*label*/
        s[1]
      ), b0(
        t,
        "aria-haspopup",
        /*hasPopup*/
        s[8]
      ), b0(
        t,
        "title",
        /*label*/
        s[1]
      ), b0(t, "class", "svelte-lpi64a"), Wt(
        t,
        "pending",
        /*pending*/
        s[3]
      ), Wt(
        t,
        "padded",
        /*padded*/
        s[5]
      ), Wt(
        t,
        "highlight",
        /*highlight*/
        s[6]
      ), Wt(
        t,
        "transparent",
        /*transparent*/
        s[9]
      ), En(t, "color", !/*disabled*/
      s[7] && /*_color*/
      s[11] ? (
        /*_color*/
        s[11]
      ) : "var(--block-label-text-color)"), En(t, "--bg-color", /*disabled*/
      s[7] ? "auto" : (
        /*background*/
        s[10]
      ));
    },
    m(y, D) {
      $o(y, t, D), v && v.m(t, null), si(t, n), si(t, i), e4(o, i, null), u = !0, f || (g = $c(
        t,
        "click",
        /*click_handler*/
        s[13]
      ), f = !0);
    },
    p(y, [D]) {
      /*show_label*/
      y[2] ? v ? v.p(y, D) : (v = Jl(y), v.c(), v.m(t, n)) : v && (v.d(1), v = null), (!u || D & /*size*/
      16) && Wt(
        i,
        "small",
        /*size*/
        y[4] === "small"
      ), (!u || D & /*size*/
      16) && Wt(
        i,
        "large",
        /*size*/
        y[4] === "large"
      ), (!u || D & /*disabled*/
      128) && (t.disabled = /*disabled*/
      y[7]), (!u || D & /*label*/
      2) && b0(
        t,
        "aria-label",
        /*label*/
        y[1]
      ), (!u || D & /*hasPopup*/
      256) && b0(
        t,
        "aria-haspopup",
        /*hasPopup*/
        y[8]
      ), (!u || D & /*label*/
      2) && b0(
        t,
        "title",
        /*label*/
        y[1]
      ), (!u || D & /*pending*/
      8) && Wt(
        t,
        "pending",
        /*pending*/
        y[3]
      ), (!u || D & /*padded*/
      32) && Wt(
        t,
        "padded",
        /*padded*/
        y[5]
      ), (!u || D & /*highlight*/
      64) && Wt(
        t,
        "highlight",
        /*highlight*/
        y[6]
      ), (!u || D & /*transparent*/
      512) && Wt(
        t,
        "transparent",
        /*transparent*/
        y[9]
      ), D & /*disabled, _color*/
      2176 && En(t, "color", !/*disabled*/
      y[7] && /*_color*/
      y[11] ? (
        /*_color*/
        y[11]
      ) : "var(--block-label-text-color)"), D & /*disabled, background*/
      1152 && En(t, "--bg-color", /*disabled*/
      y[7] ? "auto" : (
        /*background*/
        y[10]
      ));
    },
    i(y) {
      u || (i4(o.$$.fragment, y), u = !0);
    },
    o(y) {
      l4(o.$$.fragment, y), u = !1;
    },
    d(y) {
      y && Jo(t), v && v.d(), Qc(o), f = !1, g();
    }
  };
}
function o4(s, t, n) {
  let i, { Icon: o } = t, { label: u = "" } = t, { show_label: f = !1 } = t, { pending: g = !1 } = t, { size: v = "small" } = t, { padded: y = !0 } = t, { highlight: D = !1 } = t, { disabled: B = !1 } = t, { hasPopup: q = !1 } = t, { color: G = "var(--block-label-text-color)" } = t, { transparent: K = !1 } = t, { background: $ = "var(--background-fill-primary)" } = t;
  function X(M) {
    Zc.call(this, s, M);
  }
  return s.$$set = (M) => {
    "Icon" in M && n(0, o = M.Icon), "label" in M && n(1, u = M.label), "show_label" in M && n(2, f = M.show_label), "pending" in M && n(3, g = M.pending), "size" in M && n(4, v = M.size), "padded" in M && n(5, y = M.padded), "highlight" in M && n(6, D = M.highlight), "disabled" in M && n(7, B = M.disabled), "hasPopup" in M && n(8, q = M.hasPopup), "color" in M && n(12, G = M.color), "transparent" in M && n(9, K = M.transparent), "background" in M && n(10, $ = M.background);
  }, s.$$.update = () => {
    s.$$.dirty & /*highlight, color*/
    4160 && n(11, i = D ? "var(--color-accent)" : G);
  }, [
    o,
    u,
    f,
    g,
    v,
    y,
    D,
    B,
    q,
    K,
    $,
    i,
    G,
    X
  ];
}
class u4 extends Yc {
  constructor(t) {
    super(), Jc(this, t, o4, s4, t4, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: c4,
  append: $l,
  attr: Et,
  detach: h4,
  init: f4,
  insert: m4,
  noop: Oa,
  safe_not_equal: d4,
  svg_element: qa
} = window.__gradio__svelte__internal;
function p4(s) {
  let t, n, i;
  return {
    c() {
      t = qa("svg"), n = qa("path"), i = qa("path"), Et(n, "fill", "currentColor"), Et(n, "d", "M17.74 30L16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84Z"), Et(i, "fill", "currentColor"), Et(i, "d", "M8 10h16v2H8zm0 6h10v2H8z"), Et(t, "xmlns", "http://www.w3.org/2000/svg"), Et(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Et(t, "aria-hidden", "true"), Et(t, "role", "img"), Et(t, "class", "iconify iconify--carbon"), Et(t, "width", "100%"), Et(t, "height", "100%"), Et(t, "preserveAspectRatio", "xMidYMid meet"), Et(t, "viewBox", "0 0 32 32");
    },
    m(o, u) {
      m4(o, t, u), $l(t, n), $l(t, i);
    },
    p: Oa,
    i: Oa,
    o: Oa,
    d(o) {
      o && h4(t);
    }
  };
}
class g4 extends c4 {
  constructor(t) {
    super(), f4(this, t, null, p4, d4, {});
  }
}
const {
  SvelteComponent: v4,
  append: b4,
  attr: O0,
  detach: y4,
  init: w4,
  insert: _4,
  noop: Pa,
  safe_not_equal: k4,
  svg_element: es
} = window.__gradio__svelte__internal;
function D4(s) {
  let t, n;
  return {
    c() {
      t = es("svg"), n = es("polyline"), O0(n, "points", "20 6 9 17 4 12"), O0(t, "xmlns", "http://www.w3.org/2000/svg"), O0(t, "viewBox", "2 0 20 20"), O0(t, "fill", "none"), O0(t, "stroke", "currentColor"), O0(t, "stroke-width", "3"), O0(t, "stroke-linecap", "round"), O0(t, "stroke-linejoin", "round");
    },
    m(i, o) {
      _4(i, t, o), b4(t, n);
    },
    p: Pa,
    i: Pa,
    o: Pa,
    d(i) {
      i && y4(t);
    }
  };
}
class A4 extends v4 {
  constructor(t) {
    super(), w4(this, t, null, D4, k4, {});
  }
}
const {
  SvelteComponent: x4,
  append: S4,
  attr: Or,
  detach: E4,
  init: F4,
  insert: C4,
  noop: Ha,
  safe_not_equal: T4,
  svg_element: ts
} = window.__gradio__svelte__internal;
function B4(s) {
  let t, n;
  return {
    c() {
      t = ts("svg"), n = ts("path"), Or(n, "d", "M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z"), Or(n, "fill", "currentColor"), Or(t, "id", "icon"), Or(t, "xmlns", "http://www.w3.org/2000/svg"), Or(t, "viewBox", "0 0 32 32");
    },
    m(i, o) {
      C4(i, t, o), S4(t, n);
    },
    p: Ha,
    i: Ha,
    o: Ha,
    d(i) {
      i && E4(t);
    }
  };
}
class M4 extends x4 {
  constructor(t) {
    super(), F4(this, t, null, B4, T4, {});
  }
}
const {
  SvelteComponent: z4,
  append: rs,
  attr: Q0,
  detach: N4,
  init: R4,
  insert: L4,
  noop: Ua,
  safe_not_equal: I4,
  svg_element: Ga
} = window.__gradio__svelte__internal;
function O4(s) {
  let t, n, i;
  return {
    c() {
      t = Ga("svg"), n = Ga("path"), i = Ga("path"), Q0(n, "fill", "currentColor"), Q0(n, "d", "M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"), Q0(i, "fill", "currentColor"), Q0(i, "d", "M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"), Q0(t, "xmlns", "http://www.w3.org/2000/svg"), Q0(t, "viewBox", "0 0 33 33"), Q0(t, "color", "currentColor");
    },
    m(o, u) {
      L4(o, t, u), rs(t, n), rs(t, i);
    },
    p: Ua,
    i: Ua,
    o: Ua,
    d(o) {
      o && N4(t);
    }
  };
}
class q4 extends z4 {
  constructor(t) {
    super(), R4(this, t, null, O4, I4, {});
  }
}
const {
  SvelteComponent: P4,
  append: ns,
  attr: gt,
  detach: H4,
  init: U4,
  insert: G4,
  noop: as,
  safe_not_equal: V4,
  svg_element: Va
} = window.__gradio__svelte__internal;
function W4(s) {
  let t, n, i, o;
  return {
    c() {
      t = Va("svg"), n = Va("path"), i = Va("path"), gt(n, "stroke", "currentColor"), gt(n, "stroke-width", "1.5"), gt(n, "stroke-linecap", "round"), gt(n, "d", "M16.472 3.5H4.1a.6.6 0 0 0-.6.6v9.8a.6.6 0 0 0 .6.6h2.768a2 2 0 0 1 1.715.971l2.71 4.517a1.631 1.631 0 0 0 2.961-1.308l-1.022-3.408a.6.6 0 0 1 .574-.772h4.575a2 2 0 0 0 1.93-2.526l-1.91-7A2 2 0 0 0 16.473 3.5Z"), gt(i, "stroke", "currentColor"), gt(i, "stroke-width", "1.5"), gt(i, "stroke-linecap", "round"), gt(i, "stroke-linejoin", "round"), gt(i, "d", "M7 14.5v-11"), gt(t, "xmlns", "http://www.w3.org/2000/svg"), gt(t, "viewBox", "0 0 24 24"), gt(t, "fill", o = /*selected*/
      s[0] ? "currentColor" : "none"), gt(t, "stroke-width", "1.5"), gt(t, "color", "currentColor");
    },
    m(u, f) {
      G4(u, t, f), ns(t, n), ns(t, i);
    },
    p(u, [f]) {
      f & /*selected*/
      1 && o !== (o = /*selected*/
      u[0] ? "currentColor" : "none") && gt(t, "fill", o);
    },
    i: as,
    o: as,
    d(u) {
      u && H4(t);
    }
  };
}
function j4(s, t, n) {
  let { selected: i } = t;
  return s.$$set = (o) => {
    "selected" in o && n(0, i = o.selected);
  }, [i];
}
class X4 extends P4 {
  constructor(t) {
    super(), U4(this, t, j4, W4, V4, { selected: 0 });
  }
}
const {
  SvelteComponent: Y4,
  append: is,
  attr: vt,
  detach: Z4,
  init: K4,
  insert: Q4,
  noop: ls,
  safe_not_equal: J4,
  svg_element: Wa
} = window.__gradio__svelte__internal;
function $4(s) {
  let t, n, i, o;
  return {
    c() {
      t = Wa("svg"), n = Wa("path"), i = Wa("path"), vt(n, "stroke", "currentColor"), vt(n, "stroke-width", "1.5"), vt(n, "stroke-linecap", "round"), vt(n, "d", "M16.472 20H4.1a.6.6 0 0 1-.6-.6V9.6a.6.6 0 0 1 .6-.6h2.768a2 2 0 0 0 1.715-.971l2.71-4.517a1.631 1.631 0 0 1 2.961 1.308l-1.022 3.408a.6.6 0 0 0 .574.772h4.575a2 2 0 0 1 1.93 2.526l-1.91 7A2 2 0 0 1 16.473 20Z"), vt(i, "stroke", "currentColor"), vt(i, "stroke-width", "1.5"), vt(i, "stroke-linecap", "round"), vt(i, "stroke-linejoin", "round"), vt(i, "d", "M7 20V9"), vt(t, "xmlns", "http://www.w3.org/2000/svg"), vt(t, "viewBox", "0 0 24 24"), vt(t, "fill", o = /*selected*/
      s[0] ? "currentColor" : "none"), vt(t, "stroke-width", "1.5"), vt(t, "color", "currentColor");
    },
    m(u, f) {
      Q4(u, t, f), is(t, n), is(t, i);
    },
    p(u, [f]) {
      f & /*selected*/
      1 && o !== (o = /*selected*/
      u[0] ? "currentColor" : "none") && vt(t, "fill", o);
    },
    i: ls,
    o: ls,
    d(u) {
      u && Z4(t);
    }
  };
}
function eh(s, t, n) {
  let { selected: i } = t;
  return s.$$set = (o) => {
    "selected" in o && n(0, i = o.selected);
  }, [i];
}
class th extends Y4 {
  constructor(t) {
    super(), K4(this, t, eh, $4, J4, { selected: 0 });
  }
}
const {
  SvelteComponent: rh,
  create_component: nh,
  destroy_component: ah,
  init: ih,
  mount_component: lh,
  safe_not_equal: sh,
  transition_in: oh,
  transition_out: uh
} = window.__gradio__svelte__internal, { createEventDispatcher: ch } = window.__gradio__svelte__internal;
function hh(s) {
  let t, n;
  return t = new u4({
    props: {
      Icon: M4,
      label: (
        /*i18n*/
        s[2]("common.share")
      ),
      pending: (
        /*pending*/
        s[3]
      )
    }
  }), t.$on(
    "click",
    /*click_handler*/
    s[5]
  ), {
    c() {
      nh(t.$$.fragment);
    },
    m(i, o) {
      lh(t, i, o), n = !0;
    },
    p(i, [o]) {
      const u = {};
      o & /*i18n*/
      4 && (u.label = /*i18n*/
      i[2]("common.share")), o & /*pending*/
      8 && (u.pending = /*pending*/
      i[3]), t.$set(u);
    },
    i(i) {
      n || (oh(t.$$.fragment, i), n = !0);
    },
    o(i) {
      uh(t.$$.fragment, i), n = !1;
    },
    d(i) {
      ah(t, i);
    }
  };
}
function fh(s, t, n) {
  const i = ch();
  let { formatter: o } = t, { value: u } = t, { i18n: f } = t, g = !1;
  const v = async () => {
    try {
      n(3, g = !0);
      const y = await o(u);
      i("share", { description: y });
    } catch (y) {
      console.error(y);
      let D = y instanceof On ? y.message : "Share failed.";
      i("error", D);
    } finally {
      n(3, g = !1);
    }
  };
  return s.$$set = (y) => {
    "formatter" in y && n(0, o = y.formatter), "value" in y && n(1, u = y.value), "i18n" in y && n(2, f = y.i18n);
  }, [o, u, f, g, i, v];
}
class mh extends rh {
  constructor(t) {
    super(), ih(this, t, fh, hh, sh, { formatter: 0, value: 1, i18n: 2 });
  }
}
const { setContext: Xd, getContext: dh } = window.__gradio__svelte__internal, ph = "WORKER_PROXY_CONTEXT_KEY";
function gh() {
  return dh(ph);
}
function vh(s) {
  return s.host === window.location.host || s.host === "localhost:7860" || s.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  s.host === "lite.local";
}
function bh(s, t) {
  const n = t.toLowerCase();
  for (const [i, o] of Object.entries(s))
    if (i.toLowerCase() === n)
      return o;
}
function yh(s) {
  if (s == null)
    return !1;
  const t = new URL(s, window.location.href);
  return !(!vh(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
async function vi(s) {
  if (s == null || !yh(s))
    return s;
  const t = gh();
  if (t == null)
    return s;
  const i = new URL(s, window.location.href).pathname;
  return t.httpRequest({
    method: "GET",
    path: i,
    headers: {},
    query_string: ""
  }).then((o) => {
    if (o.status !== 200)
      throw new Error(`Failed to get file ${i} from the Wasm worker.`);
    const u = new Blob([o.body], {
      type: bh(o.headers, "content-type")
    });
    return URL.createObjectURL(u);
  });
}
const {
  SvelteComponent: wh,
  assign: ui,
  compute_rest_props: ss,
  detach: _h,
  element: kh,
  exclude_internal_props: Dh,
  get_spread_update: Ah,
  init: xh,
  insert: Sh,
  listen: ja,
  noop: os,
  run_all: Eh,
  safe_not_equal: Fh,
  set_attributes: us,
  src_url_equal: Ch
} = window.__gradio__svelte__internal, { createEventDispatcher: Th } = window.__gradio__svelte__internal;
function Bh(s) {
  let t, n, i, o, u = [
    {
      src: n = /*resolved_src*/
      s[0]
    },
    /*$$restProps*/
    s[2]
  ], f = {};
  for (let g = 0; g < u.length; g += 1)
    f = ui(f, u[g]);
  return {
    c() {
      t = kh("audio"), us(t, f);
    },
    m(g, v) {
      Sh(g, t, v), i || (o = [
        ja(
          t,
          "play",
          /*dispatch*/
          s[1].bind(null, "play")
        ),
        ja(
          t,
          "pause",
          /*dispatch*/
          s[1].bind(null, "pause")
        ),
        ja(
          t,
          "ended",
          /*dispatch*/
          s[1].bind(null, "ended")
        )
      ], i = !0);
    },
    p(g, [v]) {
      us(t, f = Ah(u, [
        v & /*resolved_src*/
        1 && !Ch(t.src, n = /*resolved_src*/
        g[0]) && { src: n },
        v & /*$$restProps*/
        4 && /*$$restProps*/
        g[2]
      ]));
    },
    i: os,
    o: os,
    d(g) {
      g && _h(t), i = !1, Eh(o);
    }
  };
}
function Mh(s, t, n) {
  const i = ["src"];
  let o = ss(t, i), { src: u = void 0 } = t, f, g;
  const v = Th();
  return s.$$set = (y) => {
    t = ui(ui({}, t), Dh(y)), n(2, o = ss(t, i)), "src" in y && n(3, u = y.src);
  }, s.$$.update = () => {
    if (s.$$.dirty & /*src, latest_src*/
    24) {
      n(0, f = u), n(4, g = u);
      const y = u;
      vi(y).then((D) => {
        g === y && n(0, f = D);
      });
    }
  }, [f, v, o, u, g];
}
class eu extends wh {
  constructor(t) {
    super(), xh(this, t, Mh, Bh, Fh, { src: 3 });
  }
}
const {
  SvelteComponent: zh,
  assign: ci,
  compute_rest_props: cs,
  detach: Nh,
  element: Rh,
  exclude_internal_props: Lh,
  get_spread_update: Ih,
  init: Oh,
  insert: qh,
  noop: hs,
  safe_not_equal: Ph,
  set_attributes: fs,
  src_url_equal: Hh,
  toggle_class: ms
} = window.__gradio__svelte__internal;
function Uh(s) {
  let t, n, i = [
    {
      src: n = /*resolved_src*/
      s[0]
    },
    /*$$restProps*/
    s[1]
  ], o = {};
  for (let u = 0; u < i.length; u += 1)
    o = ci(o, i[u]);
  return {
    c() {
      t = Rh("img"), fs(t, o), ms(t, "svelte-kxeri3", !0);
    },
    m(u, f) {
      qh(u, t, f);
    },
    p(u, [f]) {
      fs(t, o = Ih(i, [
        f & /*resolved_src*/
        1 && !Hh(t.src, n = /*resolved_src*/
        u[0]) && { src: n },
        f & /*$$restProps*/
        2 && /*$$restProps*/
        u[1]
      ])), ms(t, "svelte-kxeri3", !0);
    },
    i: hs,
    o: hs,
    d(u) {
      u && Nh(t);
    }
  };
}
function Gh(s, t, n) {
  const i = ["src"];
  let o = cs(t, i), { src: u = void 0 } = t, f, g;
  return s.$$set = (v) => {
    t = ci(ci({}, t), Lh(v)), n(1, o = cs(t, i)), "src" in v && n(2, u = v.src);
  }, s.$$.update = () => {
    if (s.$$.dirty & /*src, latest_src*/
    12) {
      n(0, f = u), n(3, g = u);
      const v = u;
      vi(v).then((y) => {
        g === v && n(0, f = y);
      });
    }
  }, [f, o, u, g];
}
class bi extends zh {
  constructor(t) {
    super(), Oh(this, t, Gh, Uh, Ph, { src: 2 });
  }
}
var ds;
(function(s) {
  s.LOAD = "LOAD", s.EXEC = "EXEC", s.WRITE_FILE = "WRITE_FILE", s.READ_FILE = "READ_FILE", s.DELETE_FILE = "DELETE_FILE", s.RENAME = "RENAME", s.CREATE_DIR = "CREATE_DIR", s.LIST_DIR = "LIST_DIR", s.DELETE_DIR = "DELETE_DIR", s.ERROR = "ERROR", s.DOWNLOAD = "DOWNLOAD", s.PROGRESS = "PROGRESS", s.LOG = "LOG", s.MOUNT = "MOUNT", s.UNMOUNT = "UNMOUNT";
})(ds || (ds = {}));
function Vh(s, { autoplay: t }) {
  async function n() {
    t && await s.play();
  }
  return s.addEventListener("loadeddata", n), {
    destroy() {
      s.removeEventListener("loadeddata", n);
    }
  };
}
const {
  SvelteComponent: Wh,
  action_destroyer: jh,
  add_render_callback: Xh,
  assign: ps,
  attr: q0,
  binding_callbacks: Yh,
  create_slot: Zh,
  detach: Xa,
  element: gs,
  exclude_internal_props: vs,
  get_all_dirty_from_scope: Kh,
  get_slot_changes: Qh,
  init: Jh,
  insert: Ya,
  is_function: $h,
  listen: Ft,
  raf: ef,
  run_all: tf,
  safe_not_equal: rf,
  space: nf,
  src_url_equal: bs,
  toggle_class: ys,
  transition_in: af,
  transition_out: lf,
  update_slot_base: sf
} = window.__gradio__svelte__internal, { createEventDispatcher: of } = window.__gradio__svelte__internal;
function uf(s) {
  let t, n, i, o, u, f = !1, g, v = !0, y, D, B, q;
  const G = (
    /*#slots*/
    s[16].default
  ), K = Zh(
    G,
    s,
    /*$$scope*/
    s[15],
    null
  );
  function $() {
    cancelAnimationFrame(g), i.paused || (g = ef($), f = !0), s[17].call(i);
  }
  return {
    c() {
      t = gs("div"), t.innerHTML = '<span class="load-wrap svelte-1pwzuub"><span class="loader svelte-1pwzuub"></span></span>', n = nf(), i = gs("video"), K && K.c(), q0(t, "class", "overlay svelte-1pwzuub"), ys(t, "hidden", !/*processingVideo*/
      s[9]), bs(i.src, o = /*resolved_src*/
      s[10]) || q0(i, "src", o), i.muted = /*muted*/
      s[4], i.playsInline = /*playsinline*/
      s[5], q0(
        i,
        "preload",
        /*preload*/
        s[6]
      ), i.autoplay = /*autoplay*/
      s[7], i.controls = /*controls*/
      s[8], q0(i, "data-testid", u = /*$$props*/
      s[12]["data-testid"]), q0(i, "crossorigin", "anonymous"), /*duration*/
      s[1] === void 0 && Xh(() => (
        /*video_durationchange_handler*/
        s[18].call(i)
      ));
    },
    m(X, M) {
      Ya(X, t, M), Ya(X, n, M), Ya(X, i, M), K && K.m(i, null), s[20](i), D = !0, B || (q = [
        Ft(
          i,
          "loadeddata",
          /*dispatch*/
          s[11].bind(null, "loadeddata")
        ),
        Ft(
          i,
          "click",
          /*dispatch*/
          s[11].bind(null, "click")
        ),
        Ft(
          i,
          "play",
          /*dispatch*/
          s[11].bind(null, "play")
        ),
        Ft(
          i,
          "pause",
          /*dispatch*/
          s[11].bind(null, "pause")
        ),
        Ft(
          i,
          "ended",
          /*dispatch*/
          s[11].bind(null, "ended")
        ),
        Ft(
          i,
          "mouseover",
          /*dispatch*/
          s[11].bind(null, "mouseover")
        ),
        Ft(
          i,
          "mouseout",
          /*dispatch*/
          s[11].bind(null, "mouseout")
        ),
        Ft(
          i,
          "focus",
          /*dispatch*/
          s[11].bind(null, "focus")
        ),
        Ft(
          i,
          "blur",
          /*dispatch*/
          s[11].bind(null, "blur")
        ),
        Ft(i, "timeupdate", $),
        Ft(
          i,
          "durationchange",
          /*video_durationchange_handler*/
          s[18]
        ),
        Ft(
          i,
          "play",
          /*video_play_pause_handler*/
          s[19]
        ),
        Ft(
          i,
          "pause",
          /*video_play_pause_handler*/
          s[19]
        ),
        jh(y = Vh.call(null, i, { autoplay: (
          /*autoplay*/
          s[7] ?? !1
        ) }))
      ], B = !0);
    },
    p(X, [M]) {
      (!D || M & /*processingVideo*/
      512) && ys(t, "hidden", !/*processingVideo*/
      X[9]), K && K.p && (!D || M & /*$$scope*/
      32768) && sf(
        K,
        G,
        X,
        /*$$scope*/
        X[15],
        D ? Qh(
          G,
          /*$$scope*/
          X[15],
          M,
          null
        ) : Kh(
          /*$$scope*/
          X[15]
        ),
        null
      ), (!D || M & /*resolved_src*/
      1024 && !bs(i.src, o = /*resolved_src*/
      X[10])) && q0(i, "src", o), (!D || M & /*muted*/
      16) && (i.muted = /*muted*/
      X[4]), (!D || M & /*playsinline*/
      32) && (i.playsInline = /*playsinline*/
      X[5]), (!D || M & /*preload*/
      64) && q0(
        i,
        "preload",
        /*preload*/
        X[6]
      ), (!D || M & /*autoplay*/
      128) && (i.autoplay = /*autoplay*/
      X[7]), (!D || M & /*controls*/
      256) && (i.controls = /*controls*/
      X[8]), (!D || M & /*$$props*/
      4096 && u !== (u = /*$$props*/
      X[12]["data-testid"])) && q0(i, "data-testid", u), !f && M & /*currentTime*/
      1 && !isNaN(
        /*currentTime*/
        X[0]
      ) && (i.currentTime = /*currentTime*/
      X[0]), f = !1, M & /*paused*/
      4 && v !== (v = /*paused*/
      X[2]) && i[v ? "pause" : "play"](), y && $h(y.update) && M & /*autoplay*/
      128 && y.update.call(null, { autoplay: (
        /*autoplay*/
        X[7] ?? !1
      ) });
    },
    i(X) {
      D || (af(K, X), D = !0);
    },
    o(X) {
      lf(K, X), D = !1;
    },
    d(X) {
      X && (Xa(t), Xa(n), Xa(i)), K && K.d(X), s[20](null), B = !1, tf(q);
    }
  };
}
function cf(s, t, n) {
  let { $$slots: i = {}, $$scope: o } = t, { src: u = void 0 } = t, { muted: f = void 0 } = t, { playsinline: g = void 0 } = t, { preload: v = void 0 } = t, { autoplay: y = void 0 } = t, { controls: D = void 0 } = t, { currentTime: B = void 0 } = t, { duration: q = void 0 } = t, { paused: G = void 0 } = t, { node: K = void 0 } = t, { processingVideo: $ = !1 } = t, X, M;
  const z = of();
  function F() {
    B = this.currentTime, n(0, B);
  }
  function N() {
    q = this.duration, n(1, q);
  }
  function O() {
    G = this.paused, n(2, G);
  }
  function R(U) {
    Yh[U ? "unshift" : "push"](() => {
      K = U, n(3, K);
    });
  }
  return s.$$set = (U) => {
    n(12, t = ps(ps({}, t), vs(U))), "src" in U && n(13, u = U.src), "muted" in U && n(4, f = U.muted), "playsinline" in U && n(5, g = U.playsinline), "preload" in U && n(6, v = U.preload), "autoplay" in U && n(7, y = U.autoplay), "controls" in U && n(8, D = U.controls), "currentTime" in U && n(0, B = U.currentTime), "duration" in U && n(1, q = U.duration), "paused" in U && n(2, G = U.paused), "node" in U && n(3, K = U.node), "processingVideo" in U && n(9, $ = U.processingVideo), "$$scope" in U && n(15, o = U.$$scope);
  }, s.$$.update = () => {
    if (s.$$.dirty & /*src, latest_src*/
    24576) {
      n(10, X = u), n(14, M = u);
      const U = u;
      vi(U).then((J) => {
        M === U && n(10, X = J);
      });
    }
  }, t = vs(t), [
    B,
    q,
    G,
    K,
    f,
    g,
    v,
    y,
    D,
    $,
    X,
    z,
    t,
    u,
    M,
    o,
    i,
    F,
    N,
    O,
    R
  ];
}
class tu extends Wh {
  constructor(t) {
    super(), Jh(this, t, cf, uf, rf, {
      src: 13,
      muted: 4,
      playsinline: 5,
      preload: 6,
      autoplay: 7,
      controls: 8,
      currentTime: 0,
      duration: 1,
      paused: 2,
      node: 3,
      processingVideo: 9
    });
  }
}
/*! @license DOMPurify 3.0.9 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.0.9/LICENSE */
const {
  entries: ru,
  setPrototypeOf: ws,
  isFrozen: hf,
  getPrototypeOf: ff,
  getOwnPropertyDescriptor: mf
} = Object;
let {
  freeze: bt,
  seal: e0,
  create: nu
} = Object, {
  apply: hi,
  construct: fi
} = typeof Reflect < "u" && Reflect;
bt || (bt = function(t) {
  return t;
});
e0 || (e0 = function(t) {
  return t;
});
hi || (hi = function(t, n, i) {
  return t.apply(n, i);
});
fi || (fi = function(t, n) {
  return new t(...n);
});
const Fn = zt(Array.prototype.forEach), _s = zt(Array.prototype.pop), qr = zt(Array.prototype.push), qn = zt(String.prototype.toLowerCase), Za = zt(String.prototype.toString), df = zt(String.prototype.match), Pr = zt(String.prototype.replace), pf = zt(String.prototype.indexOf), gf = zt(String.prototype.trim), $t = zt(Object.prototype.hasOwnProperty), Ct = zt(RegExp.prototype.test), Hr = vf(TypeError);
function zt(s) {
  return function(t) {
    for (var n = arguments.length, i = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++)
      i[o - 1] = arguments[o];
    return hi(s, t, i);
  };
}
function vf(s) {
  return function() {
    for (var t = arguments.length, n = new Array(t), i = 0; i < t; i++)
      n[i] = arguments[i];
    return fi(s, n);
  };
}
function De(s, t) {
  let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : qn;
  ws && ws(s, null);
  let i = t.length;
  for (; i--; ) {
    let o = t[i];
    if (typeof o == "string") {
      const u = n(o);
      u !== o && (hf(t) || (t[i] = u), o = u);
    }
    s[o] = !0;
  }
  return s;
}
function bf(s) {
  for (let t = 0; t < s.length; t++)
    $t(s, t) || (s[t] = null);
  return s;
}
function J0(s) {
  const t = nu(null);
  for (const [n, i] of ru(s))
    $t(s, n) && (Array.isArray(i) ? t[n] = bf(i) : i && typeof i == "object" && i.constructor === Object ? t[n] = J0(i) : t[n] = i);
  return t;
}
function Cn(s, t) {
  for (; s !== null; ) {
    const i = mf(s, t);
    if (i) {
      if (i.get)
        return zt(i.get);
      if (typeof i.value == "function")
        return zt(i.value);
    }
    s = ff(s);
  }
  function n() {
    return null;
  }
  return n;
}
const ks = bt(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Ka = bt(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Qa = bt(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), yf = bt(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Ja = bt(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), wf = bt(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Ds = bt(["#text"]), As = bt(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "xmlns", "slot"]), $a = bt(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), xs = bt(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), Tn = bt(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), _f = e0(/\{\{[\w\W]*|[\w\W]*\}\}/gm), kf = e0(/<%[\w\W]*|[\w\W]*%>/gm), Df = e0(/\${[\w\W]*}/gm), Af = e0(/^data-[\-\w.\u00B7-\uFFFF]/), xf = e0(/^aria-[\-\w]+$/), au = e0(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), Sf = e0(/^(?:\w+script|data):/i), Ef = e0(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), iu = e0(/^html$/i);
var Ss = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  MUSTACHE_EXPR: _f,
  ERB_EXPR: kf,
  TMPLIT_EXPR: Df,
  DATA_ATTR: Af,
  ARIA_ATTR: xf,
  IS_ALLOWED_URI: au,
  IS_SCRIPT_OR_DATA: Sf,
  ATTR_WHITESPACE: Ef,
  DOCTYPE_NAME: iu
});
const Ff = function() {
  return typeof window > "u" ? null : window;
}, Cf = function(t, n) {
  if (typeof t != "object" || typeof t.createPolicy != "function")
    return null;
  let i = null;
  const o = "data-tt-policy-suffix";
  n && n.hasAttribute(o) && (i = n.getAttribute(o));
  const u = "dompurify" + (i ? "#" + i : "");
  try {
    return t.createPolicy(u, {
      createHTML(f) {
        return f;
      },
      createScriptURL(f) {
        return f;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + u + " could not be created."), null;
  }
};
function lu() {
  let s = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Ff();
  const t = (he) => lu(he);
  if (t.version = "3.0.9", t.removed = [], !s || !s.document || s.document.nodeType !== 9)
    return t.isSupported = !1, t;
  let {
    document: n
  } = s;
  const i = n, o = i.currentScript, {
    DocumentFragment: u,
    HTMLTemplateElement: f,
    Node: g,
    Element: v,
    NodeFilter: y,
    NamedNodeMap: D = s.NamedNodeMap || s.MozNamedAttrMap,
    HTMLFormElement: B,
    DOMParser: q,
    trustedTypes: G
  } = s, K = v.prototype, $ = Cn(K, "cloneNode"), X = Cn(K, "nextSibling"), M = Cn(K, "childNodes"), z = Cn(K, "parentNode");
  if (typeof f == "function") {
    const he = n.createElement("template");
    he.content && he.content.ownerDocument && (n = he.content.ownerDocument);
  }
  let F, N = "";
  const {
    implementation: O,
    createNodeIterator: R,
    createDocumentFragment: U,
    getElementsByTagName: J
  } = n, {
    importNode: V
  } = i;
  let ee = {};
  t.isSupported = typeof ru == "function" && typeof z == "function" && O && O.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: fe,
    ERB_EXPR: xe,
    TMPLIT_EXPR: ve,
    DATA_ATTR: Se,
    ARIA_ATTR: Je,
    IS_SCRIPT_OR_DATA: ft,
    ATTR_WHITESPACE: ct
  } = Ss;
  let {
    IS_ALLOWED_URI: Ne
  } = Ss, Y = null;
  const Me = De({}, [...ks, ...Ka, ...Qa, ...Ja, ...Ds]);
  let re = null;
  const Ue = De({}, [...As, ...$a, ...xs, ...Tn]);
  let le = Object.seal(nu(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ke = null, yt = null, ht = !0, It = !0, ae = !1, nt = !0, Re = !1, tt = !1, G0 = !1, f0 = !1, _0 = !1, nr = !1, V0 = !1, Kr = !0, k0 = !1;
  const Ot = "user-content-";
  let D0 = !0, A0 = !1, x0 = {}, t0 = null;
  const ar = De({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Qr = null;
  const Jr = De({}, ["audio", "video", "img", "source", "image", "track"]);
  let ir = null;
  const xr = De({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), W0 = "http://www.w3.org/1998/Math/MathML", lr = "http://www.w3.org/2000/svg", At = "http://www.w3.org/1999/xhtml";
  let S0 = At, sr = !1, qe = null;
  const ne = De({}, [W0, lr, At], Za);
  let wt = null;
  const $r = ["application/xhtml+xml", "text/html"], en = "text/html";
  let $e = null, qt = null;
  const Sr = n.createElement("form"), tn = function(E) {
    return E instanceof RegExp || E instanceof Function;
  }, Er = function() {
    let E = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(qt && qt === E)) {
      if ((!E || typeof E != "object") && (E = {}), E = J0(E), wt = // eslint-disable-next-line unicorn/prefer-includes
      $r.indexOf(E.PARSER_MEDIA_TYPE) === -1 ? en : E.PARSER_MEDIA_TYPE, $e = wt === "application/xhtml+xml" ? Za : qn, Y = $t(E, "ALLOWED_TAGS") ? De({}, E.ALLOWED_TAGS, $e) : Me, re = $t(E, "ALLOWED_ATTR") ? De({}, E.ALLOWED_ATTR, $e) : Ue, qe = $t(E, "ALLOWED_NAMESPACES") ? De({}, E.ALLOWED_NAMESPACES, Za) : ne, ir = $t(E, "ADD_URI_SAFE_ATTR") ? De(
        J0(xr),
        // eslint-disable-line indent
        E.ADD_URI_SAFE_ATTR,
        // eslint-disable-line indent
        $e
        // eslint-disable-line indent
      ) : xr, Qr = $t(E, "ADD_DATA_URI_TAGS") ? De(
        J0(Jr),
        // eslint-disable-line indent
        E.ADD_DATA_URI_TAGS,
        // eslint-disable-line indent
        $e
        // eslint-disable-line indent
      ) : Jr, t0 = $t(E, "FORBID_CONTENTS") ? De({}, E.FORBID_CONTENTS, $e) : ar, Ke = $t(E, "FORBID_TAGS") ? De({}, E.FORBID_TAGS, $e) : {}, yt = $t(E, "FORBID_ATTR") ? De({}, E.FORBID_ATTR, $e) : {}, x0 = $t(E, "USE_PROFILES") ? E.USE_PROFILES : !1, ht = E.ALLOW_ARIA_ATTR !== !1, It = E.ALLOW_DATA_ATTR !== !1, ae = E.ALLOW_UNKNOWN_PROTOCOLS || !1, nt = E.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Re = E.SAFE_FOR_TEMPLATES || !1, tt = E.WHOLE_DOCUMENT || !1, _0 = E.RETURN_DOM || !1, nr = E.RETURN_DOM_FRAGMENT || !1, V0 = E.RETURN_TRUSTED_TYPE || !1, f0 = E.FORCE_BODY || !1, Kr = E.SANITIZE_DOM !== !1, k0 = E.SANITIZE_NAMED_PROPS || !1, D0 = E.KEEP_CONTENT !== !1, A0 = E.IN_PLACE || !1, Ne = E.ALLOWED_URI_REGEXP || au, S0 = E.NAMESPACE || At, le = E.CUSTOM_ELEMENT_HANDLING || {}, E.CUSTOM_ELEMENT_HANDLING && tn(E.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (le.tagNameCheck = E.CUSTOM_ELEMENT_HANDLING.tagNameCheck), E.CUSTOM_ELEMENT_HANDLING && tn(E.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (le.attributeNameCheck = E.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), E.CUSTOM_ELEMENT_HANDLING && typeof E.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (le.allowCustomizedBuiltInElements = E.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Re && (It = !1), nr && (_0 = !0), x0 && (Y = De({}, Ds), re = [], x0.html === !0 && (De(Y, ks), De(re, As)), x0.svg === !0 && (De(Y, Ka), De(re, $a), De(re, Tn)), x0.svgFilters === !0 && (De(Y, Qa), De(re, $a), De(re, Tn)), x0.mathMl === !0 && (De(Y, Ja), De(re, xs), De(re, Tn))), E.ADD_TAGS && (Y === Me && (Y = J0(Y)), De(Y, E.ADD_TAGS, $e)), E.ADD_ATTR && (re === Ue && (re = J0(re)), De(re, E.ADD_ATTR, $e)), E.ADD_URI_SAFE_ATTR && De(ir, E.ADD_URI_SAFE_ATTR, $e), E.FORBID_CONTENTS && (t0 === ar && (t0 = J0(t0)), De(t0, E.FORBID_CONTENTS, $e)), D0 && (Y["#text"] = !0), tt && De(Y, ["html", "head", "body"]), Y.table && (De(Y, ["tbody"]), delete Ke.tbody), E.TRUSTED_TYPES_POLICY) {
        if (typeof E.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Hr('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof E.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Hr('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        F = E.TRUSTED_TYPES_POLICY, N = F.createHTML("");
      } else
        F === void 0 && (F = Cf(G, o)), F !== null && typeof N == "string" && (N = F.createHTML(""));
      bt && bt(E), qt = E;
    }
  }, mt = De({}, ["mi", "mo", "mn", "ms", "mtext"]), Pt = De({}, ["foreignobject", "desc", "title", "annotation-xml"]), r0 = De({}, ["title", "style", "font", "a", "script"]), or = De({}, [...Ka, ...Qa, ...yf]), Fr = De({}, [...Ja, ...wf]), Qn = function(E) {
    let Z = z(E);
    (!Z || !Z.tagName) && (Z = {
      namespaceURI: S0,
      tagName: "template"
    });
    const se = qn(E.tagName), Be = qn(Z.tagName);
    return qe[E.namespaceURI] ? E.namespaceURI === lr ? Z.namespaceURI === At ? se === "svg" : Z.namespaceURI === W0 ? se === "svg" && (Be === "annotation-xml" || mt[Be]) : !!or[se] : E.namespaceURI === W0 ? Z.namespaceURI === At ? se === "math" : Z.namespaceURI === lr ? se === "math" && Pt[Be] : !!Fr[se] : E.namespaceURI === At ? Z.namespaceURI === lr && !Pt[Be] || Z.namespaceURI === W0 && !mt[Be] ? !1 : !Fr[se] && (r0[se] || !or[se]) : !!(wt === "application/xhtml+xml" && qe[E.namespaceURI]) : !1;
  }, m0 = function(E) {
    qr(t.removed, {
      element: E
    });
    try {
      E.parentNode.removeChild(E);
    } catch {
      E.remove();
    }
  }, Cr = function(E, Z) {
    try {
      qr(t.removed, {
        attribute: Z.getAttributeNode(E),
        from: Z
      });
    } catch {
      qr(t.removed, {
        attribute: null,
        from: Z
      });
    }
    if (Z.removeAttribute(E), E === "is" && !re[E])
      if (_0 || nr)
        try {
          m0(Z);
        } catch {
        }
      else
        try {
          Z.setAttribute(E, "");
        } catch {
        }
  }, j0 = function(E) {
    let Z = null, se = null;
    if (f0)
      E = "<remove></remove>" + E;
    else {
      const Ve = df(E, /^[\r\n\t ]+/);
      se = Ve && Ve[0];
    }
    wt === "application/xhtml+xml" && S0 === At && (E = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + E + "</body></html>");
    const Be = F ? F.createHTML(E) : E;
    if (S0 === At)
      try {
        Z = new q().parseFromString(Be, wt);
      } catch {
      }
    if (!Z || !Z.documentElement) {
      Z = O.createDocument(S0, "template", null);
      try {
        Z.documentElement.innerHTML = sr ? N : Be;
      } catch {
      }
    }
    const x = Z.body || Z.documentElement;
    return E && se && x.insertBefore(n.createTextNode(se), x.childNodes[0] || null), S0 === At ? J.call(Z, tt ? "html" : "body")[0] : tt ? Z.documentElement : x;
  }, Ge = function(E) {
    return R.call(
      E.ownerDocument || E,
      E,
      // eslint-disable-next-line no-bitwise
      y.SHOW_ELEMENT | y.SHOW_COMMENT | y.SHOW_TEXT,
      null
    );
  }, h = function(E) {
    return E instanceof B && (typeof E.nodeName != "string" || typeof E.textContent != "string" || typeof E.removeChild != "function" || !(E.attributes instanceof D) || typeof E.removeAttribute != "function" || typeof E.setAttribute != "function" || typeof E.namespaceURI != "string" || typeof E.insertBefore != "function" || typeof E.hasChildNodes != "function");
  }, p = function(E) {
    return typeof g == "function" && E instanceof g;
  }, j = function(E, Z, se) {
    ee[E] && Fn(ee[E], (Be) => {
      Be.call(t, Z, se, qt);
    });
  }, w = function(E) {
    let Z = null;
    if (j("beforeSanitizeElements", E, null), h(E))
      return m0(E), !0;
    const se = $e(E.nodeName);
    if (j("uponSanitizeElement", E, {
      tagName: se,
      allowedTags: Y
    }), E.hasChildNodes() && !p(E.firstElementChild) && Ct(/<[/\w]/g, E.innerHTML) && Ct(/<[/\w]/g, E.textContent))
      return m0(E), !0;
    if (!Y[se] || Ke[se]) {
      if (!Ke[se] && Pe(se) && (le.tagNameCheck instanceof RegExp && Ct(le.tagNameCheck, se) || le.tagNameCheck instanceof Function && le.tagNameCheck(se)))
        return !1;
      if (D0 && !t0[se]) {
        const Be = z(E) || E.parentNode, x = M(E) || E.childNodes;
        if (x && Be) {
          const Ve = x.length;
          for (let T = Ve - 1; T >= 0; --T)
            Be.insertBefore($(x[T], !0), X(E));
        }
      }
      return m0(E), !0;
    }
    return E instanceof v && !Qn(E) || (se === "noscript" || se === "noembed" || se === "noframes") && Ct(/<\/no(script|embed|frames)/i, E.innerHTML) ? (m0(E), !0) : (Re && E.nodeType === 3 && (Z = E.textContent, Fn([fe, xe, ve], (Be) => {
      Z = Pr(Z, Be, " ");
    }), E.textContent !== Z && (qr(t.removed, {
      element: E.cloneNode()
    }), E.textContent = Z)), j("afterSanitizeElements", E, null), !1);
  }, S = function(E, Z, se) {
    if (Kr && (Z === "id" || Z === "name") && (se in n || se in Sr))
      return !1;
    if (!(It && !yt[Z] && Ct(Se, Z))) {
      if (!(ht && Ct(Je, Z))) {
        if (!re[Z] || yt[Z]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(Pe(E) && (le.tagNameCheck instanceof RegExp && Ct(le.tagNameCheck, E) || le.tagNameCheck instanceof Function && le.tagNameCheck(E)) && (le.attributeNameCheck instanceof RegExp && Ct(le.attributeNameCheck, Z) || le.attributeNameCheck instanceof Function && le.attributeNameCheck(Z)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            Z === "is" && le.allowCustomizedBuiltInElements && (le.tagNameCheck instanceof RegExp && Ct(le.tagNameCheck, se) || le.tagNameCheck instanceof Function && le.tagNameCheck(se)))
          )
            return !1;
        } else if (!ir[Z]) {
          if (!Ct(Ne, Pr(se, ct, ""))) {
            if (!((Z === "src" || Z === "xlink:href" || Z === "href") && E !== "script" && pf(se, "data:") === 0 && Qr[E])) {
              if (!(ae && !Ct(ft, Pr(se, ct, "")))) {
                if (se)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, Pe = function(E) {
    return E !== "annotation-xml" && E.indexOf("-") > 0;
  }, ue = function(E) {
    j("beforeSanitizeAttributes", E, null);
    const {
      attributes: Z
    } = E;
    if (!Z)
      return;
    const se = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: re
    };
    let Be = Z.length;
    for (; Be--; ) {
      const x = Z[Be], {
        name: Ve,
        namespaceURI: T,
        value: n0
      } = x, E0 = $e(Ve);
      let it = Ve === "value" ? n0 : gf(n0);
      if (se.attrName = E0, se.attrValue = it, se.keepAttr = !0, se.forceKeepAttr = void 0, j("uponSanitizeAttribute", E, se), it = se.attrValue, se.forceKeepAttr || (Cr(Ve, E), !se.keepAttr))
        continue;
      if (!nt && Ct(/\/>/i, it)) {
        Cr(Ve, E);
        continue;
      }
      Re && Fn([fe, xe, ve], (Br) => {
        it = Pr(it, Br, " ");
      });
      const Tr = $e(E.nodeName);
      if (S(Tr, E0, it)) {
        if (k0 && (E0 === "id" || E0 === "name") && (Cr(Ve, E), it = Ot + it), F && typeof G == "object" && typeof G.getAttributeType == "function" && !T)
          switch (G.getAttributeType(Tr, E0)) {
            case "TrustedHTML": {
              it = F.createHTML(it);
              break;
            }
            case "TrustedScriptURL": {
              it = F.createScriptURL(it);
              break;
            }
          }
        try {
          T ? E.setAttributeNS(T, Ve, it) : E.setAttribute(Ve, it), _s(t.removed);
        } catch {
        }
      }
    }
    j("afterSanitizeAttributes", E, null);
  }, lt = function he(E) {
    let Z = null;
    const se = Ge(E);
    for (j("beforeSanitizeShadowDOM", E, null); Z = se.nextNode(); )
      j("uponSanitizeShadowNode", Z, null), !w(Z) && (Z.content instanceof u && he(Z.content), ue(Z));
    j("afterSanitizeShadowDOM", E, null);
  };
  return t.sanitize = function(he) {
    let E = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, Z = null, se = null, Be = null, x = null;
    if (sr = !he, sr && (he = "<!-->"), typeof he != "string" && !p(he))
      if (typeof he.toString == "function") {
        if (he = he.toString(), typeof he != "string")
          throw Hr("dirty is not a string, aborting");
      } else
        throw Hr("toString is not a function");
    if (!t.isSupported)
      return he;
    if (G0 || Er(E), t.removed = [], typeof he == "string" && (A0 = !1), A0) {
      if (he.nodeName) {
        const n0 = $e(he.nodeName);
        if (!Y[n0] || Ke[n0])
          throw Hr("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (he instanceof g)
      Z = j0("<!---->"), se = Z.ownerDocument.importNode(he, !0), se.nodeType === 1 && se.nodeName === "BODY" || se.nodeName === "HTML" ? Z = se : Z.appendChild(se);
    else {
      if (!_0 && !Re && !tt && // eslint-disable-next-line unicorn/prefer-includes
      he.indexOf("<") === -1)
        return F && V0 ? F.createHTML(he) : he;
      if (Z = j0(he), !Z)
        return _0 ? null : V0 ? N : "";
    }
    Z && f0 && m0(Z.firstChild);
    const Ve = Ge(A0 ? he : Z);
    for (; Be = Ve.nextNode(); )
      w(Be) || (Be.content instanceof u && lt(Be.content), ue(Be));
    if (A0)
      return he;
    if (_0) {
      if (nr)
        for (x = U.call(Z.ownerDocument); Z.firstChild; )
          x.appendChild(Z.firstChild);
      else
        x = Z;
      return (re.shadowroot || re.shadowrootmode) && (x = V.call(i, x, !0)), x;
    }
    let T = tt ? Z.outerHTML : Z.innerHTML;
    return tt && Y["!doctype"] && Z.ownerDocument && Z.ownerDocument.doctype && Z.ownerDocument.doctype.name && Ct(iu, Z.ownerDocument.doctype.name) && (T = "<!DOCTYPE " + Z.ownerDocument.doctype.name + `>
` + T), Re && Fn([fe, xe, ve], (n0) => {
      T = Pr(T, n0, " ");
    }), F && V0 ? F.createHTML(T) : T;
  }, t.setConfig = function() {
    let he = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Er(he), G0 = !0;
  }, t.clearConfig = function() {
    qt = null, G0 = !1;
  }, t.isValidAttribute = function(he, E, Z) {
    qt || Er({});
    const se = $e(he), Be = $e(E);
    return S(se, Be, Z);
  }, t.addHook = function(he, E) {
    typeof E == "function" && (ee[he] = ee[he] || [], qr(ee[he], E));
  }, t.removeHook = function(he) {
    if (ee[he])
      return _s(ee[he]);
  }, t.removeHooks = function(he) {
    ee[he] && (ee[he] = []);
  }, t.removeAllHooks = function() {
    ee = {};
  }, t;
}
var Es = lu(), Hn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function su(s) {
  return s && s.__esModule && Object.prototype.hasOwnProperty.call(s, "default") ? s.default : s;
}
var ou = { exports: {} }, ei = { exports: {} }, Fs;
function Tf() {
  return Fs || (Fs = 1, function(s, t) {
    (function(i, o) {
      s.exports = o();
    })(typeof self < "u" ? self : Hn, function() {
      return (
        /******/
        function() {
          var n = {};
          (function() {
            n.d = function(m, e) {
              for (var r in e)
                n.o(e, r) && !n.o(m, r) && Object.defineProperty(m, r, { enumerable: !0, get: e[r] });
            };
          })(), function() {
            n.o = function(m, e) {
              return Object.prototype.hasOwnProperty.call(m, e);
            };
          }();
          var i = {};
          n.d(i, {
            default: function() {
              return (
                /* binding */
                ac
              );
            }
          });
          var o = (
            // Error start position based on passed-in Token or ParseNode.
            // Length of affected text based on passed-in Token or ParseNode.
            // The underlying error message without any context added.
            function m(e, r) {
              this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
              var a = "KaTeX parse error: " + e, l, c, d = r && r.loc;
              if (d && d.start <= d.end) {
                var b = d.lexer.input;
                l = d.start, c = d.end, l === b.length ? a += " at end of input: " : a += " at position " + (l + 1) + ": ";
                var _ = b.slice(l, c).replace(/[^]/g, "$&̲"), A;
                l > 15 ? A = "…" + b.slice(l - 15, l) : A = b.slice(0, l);
                var C;
                c + 15 < b.length ? C = b.slice(c, c + 15) + "…" : C = b.slice(c), a += A + _ + C;
              }
              var L = new Error(a);
              return L.name = "ParseError", L.__proto__ = m.prototype, L.position = l, l != null && c != null && (L.length = c - l), L.rawMessage = e, L;
            }
          );
          o.prototype.__proto__ = Error.prototype;
          var u = o, f = function(e, r) {
            return e.indexOf(r) !== -1;
          }, g = function(e, r) {
            return e === void 0 ? r : e;
          }, v = /([A-Z])/g, y = function(e) {
            return e.replace(v, "-$1").toLowerCase();
          }, D = {
            "&": "&amp;",
            ">": "&gt;",
            "<": "&lt;",
            '"': "&quot;",
            "'": "&#x27;"
          }, B = /[&><"']/g;
          function q(m) {
            return String(m).replace(B, function(e) {
              return D[e];
            });
          }
          var G = function m(e) {
            return e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? m(e.body[0]) : e : e.type === "font" ? m(e.body) : e;
          }, K = function(e) {
            var r = G(e);
            return r.type === "mathord" || r.type === "textord" || r.type === "atom";
          }, $ = function(e) {
            if (!e)
              throw new Error("Expected non-null, but got " + String(e));
            return e;
          }, X = function(e) {
            var r = /^\s*([^\\/#]*?)(?::|&#0*58|&#x0*3a)/i.exec(e);
            return r != null ? r[1] : "_relative";
          }, M = {
            contains: f,
            deflt: g,
            escape: q,
            hyphenate: y,
            getBaseElem: G,
            isCharacterBox: K,
            protocolFromUrl: X
          }, z = {
            displayMode: {
              type: "boolean",
              description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
              cli: "-d, --display-mode"
            },
            output: {
              type: {
                enum: ["htmlAndMathml", "html", "mathml"]
              },
              description: "Determines the markup language of the output.",
              cli: "-F, --format <type>"
            },
            leqno: {
              type: "boolean",
              description: "Render display math in leqno style (left-justified tags)."
            },
            fleqn: {
              type: "boolean",
              description: "Render display math flush left."
            },
            throwOnError: {
              type: "boolean",
              default: !0,
              cli: "-t, --no-throw-on-error",
              cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
            },
            errorColor: {
              type: "string",
              default: "#cc0000",
              cli: "-c, --error-color <color>",
              cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
              cliProcessor: function(e) {
                return "#" + e;
              }
            },
            macros: {
              type: "object",
              cli: "-m, --macro <def>",
              cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
              cliDefault: [],
              cliProcessor: function(e, r) {
                return r.push(e), r;
              }
            },
            minRuleThickness: {
              type: "number",
              description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
              processor: function(e) {
                return Math.max(0, e);
              },
              cli: "--min-rule-thickness <size>",
              cliProcessor: parseFloat
            },
            colorIsTextColor: {
              type: "boolean",
              description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
              cli: "-b, --color-is-text-color"
            },
            strict: {
              type: [{
                enum: ["warn", "ignore", "error"]
              }, "boolean", "function"],
              description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
              cli: "-S, --strict",
              cliDefault: !1
            },
            trust: {
              type: ["boolean", "function"],
              description: "Trust the input, enabling all HTML features such as \\url.",
              cli: "-T, --trust"
            },
            maxSize: {
              type: "number",
              default: 1 / 0,
              description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
              processor: function(e) {
                return Math.max(0, e);
              },
              cli: "-s, --max-size <n>",
              cliProcessor: parseInt
            },
            maxExpand: {
              type: "number",
              default: 1e3,
              description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
              processor: function(e) {
                return Math.max(0, e);
              },
              cli: "-e, --max-expand <n>",
              cliProcessor: function(e) {
                return e === "Infinity" ? 1 / 0 : parseInt(e);
              }
            },
            globalGroup: {
              type: "boolean",
              cli: !1
            }
          };
          function F(m) {
            if (m.default)
              return m.default;
            var e = m.type, r = Array.isArray(e) ? e[0] : e;
            if (typeof r != "string")
              return r.enum[0];
            switch (r) {
              case "boolean":
                return !1;
              case "string":
                return "";
              case "number":
                return 0;
              case "object":
                return {};
            }
          }
          var N = /* @__PURE__ */ function() {
            function m(r) {
              this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, r = r || {};
              for (var a in z)
                if (z.hasOwnProperty(a)) {
                  var l = z[a];
                  this[a] = r[a] !== void 0 ? l.processor ? l.processor(r[a]) : r[a] : F(l);
                }
            }
            var e = m.prototype;
            return e.reportNonstrict = function(a, l, c) {
              var d = this.strict;
              if (typeof d == "function" && (d = d(a, l, c)), !(!d || d === "ignore")) {
                if (d === !0 || d === "error")
                  throw new u("LaTeX-incompatible input and strict mode is set to 'error': " + (l + " [" + a + "]"), c);
                d === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (l + " [" + a + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + d + "': " + l + " [" + a + "]"));
              }
            }, e.useStrictBehavior = function(a, l, c) {
              var d = this.strict;
              if (typeof d == "function")
                try {
                  d = d(a, l, c);
                } catch {
                  d = "error";
                }
              return !d || d === "ignore" ? !1 : d === !0 || d === "error" ? !0 : d === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (l + " [" + a + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + d + "': " + l + " [" + a + "]")), !1);
            }, e.isTrusted = function(a) {
              a.url && !a.protocol && (a.protocol = M.protocolFromUrl(a.url));
              var l = typeof this.trust == "function" ? this.trust(a) : this.trust;
              return !!l;
            }, m;
          }(), O = /* @__PURE__ */ function() {
            function m(r, a, l) {
              this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = r, this.size = a, this.cramped = l;
            }
            var e = m.prototype;
            return e.sup = function() {
              return Se[Je[this.id]];
            }, e.sub = function() {
              return Se[ft[this.id]];
            }, e.fracNum = function() {
              return Se[ct[this.id]];
            }, e.fracDen = function() {
              return Se[Ne[this.id]];
            }, e.cramp = function() {
              return Se[Y[this.id]];
            }, e.text = function() {
              return Se[Me[this.id]];
            }, e.isTight = function() {
              return this.size >= 2;
            }, m;
          }(), R = 0, U = 1, J = 2, V = 3, ee = 4, fe = 5, xe = 6, ve = 7, Se = [new O(R, 0, !1), new O(U, 0, !0), new O(J, 1, !1), new O(V, 1, !0), new O(ee, 2, !1), new O(fe, 2, !0), new O(xe, 3, !1), new O(ve, 3, !0)], Je = [ee, fe, ee, fe, xe, ve, xe, ve], ft = [fe, fe, fe, fe, ve, ve, ve, ve], ct = [J, V, ee, fe, xe, ve, xe, ve], Ne = [V, V, fe, fe, ve, ve, ve, ve], Y = [U, U, V, V, fe, fe, ve, ve], Me = [R, U, J, V, J, V, J, V], re = {
            DISPLAY: Se[R],
            TEXT: Se[J],
            SCRIPT: Se[ee],
            SCRIPTSCRIPT: Se[xe]
          }, Ue = [{
            // Latin characters beyond the Latin-1 characters we have metrics for.
            // Needed for Czech, Hungarian and Turkish text, for example.
            name: "latin",
            blocks: [
              [256, 591],
              // Latin Extended-A and Latin Extended-B
              [768, 879]
              // Combining Diacritical marks
            ]
          }, {
            // The Cyrillic script used by Russian and related languages.
            // A Cyrillic subset used to be supported as explicitly defined
            // symbols in symbols.js
            name: "cyrillic",
            blocks: [[1024, 1279]]
          }, {
            // Armenian
            name: "armenian",
            blocks: [[1328, 1423]]
          }, {
            // The Brahmic scripts of South and Southeast Asia
            // Devanagari (0900–097F)
            // Bengali (0980–09FF)
            // Gurmukhi (0A00–0A7F)
            // Gujarati (0A80–0AFF)
            // Oriya (0B00–0B7F)
            // Tamil (0B80–0BFF)
            // Telugu (0C00–0C7F)
            // Kannada (0C80–0CFF)
            // Malayalam (0D00–0D7F)
            // Sinhala (0D80–0DFF)
            // Thai (0E00–0E7F)
            // Lao (0E80–0EFF)
            // Tibetan (0F00–0FFF)
            // Myanmar (1000–109F)
            name: "brahmic",
            blocks: [[2304, 4255]]
          }, {
            name: "georgian",
            blocks: [[4256, 4351]]
          }, {
            // Chinese and Japanese.
            // The "k" in cjk is for Korean, but we've separated Korean out
            name: "cjk",
            blocks: [
              [12288, 12543],
              // CJK symbols and punctuation, Hiragana, Katakana
              [19968, 40879],
              // CJK ideograms
              [65280, 65376]
              // Fullwidth punctuation
              // TODO: add halfwidth Katakana and Romanji glyphs
            ]
          }, {
            // Korean
            name: "hangul",
            blocks: [[44032, 55215]]
          }];
          function le(m) {
            for (var e = 0; e < Ue.length; e++)
              for (var r = Ue[e], a = 0; a < r.blocks.length; a++) {
                var l = r.blocks[a];
                if (m >= l[0] && m <= l[1])
                  return r.name;
              }
            return null;
          }
          var Ke = [];
          Ue.forEach(function(m) {
            return m.blocks.forEach(function(e) {
              return Ke.push.apply(Ke, e);
            });
          });
          function yt(m) {
            for (var e = 0; e < Ke.length; e += 2)
              if (m >= Ke[e] && m <= Ke[e + 1])
                return !0;
            return !1;
          }
          var ht = 80, It = function(e, r) {
            return "M95," + (622 + e + r) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + r + "h400000v" + (40 + e) + "h-400000z";
          }, ae = function(e, r) {
            return "M263," + (601 + e + r) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + r + "h400000v" + (40 + e) + "h-400000z";
          }, nt = function(e, r) {
            return "M983 " + (10 + e + r) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + r + "h400000v" + (40 + e) + "h-400000z";
          }, Re = function(e, r) {
            return "M424," + (2398 + e + r) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + r + `
h400000v` + (40 + e) + "h-400000z";
          }, tt = function(e, r) {
            return "M473," + (2713 + e + r) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + r + "h400000v" + (40 + e) + "H1017.7z";
          }, G0 = function(e) {
            var r = e / 2;
            return "M400000 " + e + " H0 L" + r + " 0 l65 45 L145 " + (e - 80) + " H400000z";
          }, f0 = function(e, r, a) {
            var l = a - 54 - r - e;
            return "M702 " + (e + r) + "H400000" + (40 + e) + `
H742v` + l + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + r + "H400000v" + (40 + e) + "H742z";
          }, _0 = function(e, r, a) {
            r = 1e3 * r;
            var l = "";
            switch (e) {
              case "sqrtMain":
                l = It(r, ht);
                break;
              case "sqrtSize1":
                l = ae(r, ht);
                break;
              case "sqrtSize2":
                l = nt(r, ht);
                break;
              case "sqrtSize3":
                l = Re(r, ht);
                break;
              case "sqrtSize4":
                l = tt(r, ht);
                break;
              case "sqrtTall":
                l = f0(r, ht, a);
            }
            return l;
          }, nr = function(e, r) {
            switch (e) {
              case "⎜":
                return "M291 0 H417 V" + r + " H291z M291 0 H417 V" + r + " H291z";
              case "∣":
                return "M145 0 H188 V" + r + " H145z M145 0 H188 V" + r + " H145z";
              case "∥":
                return "M145 0 H188 V" + r + " H145z M145 0 H188 V" + r + " H145z" + ("M367 0 H410 V" + r + " H367z M367 0 H410 V" + r + " H367z");
              case "⎟":
                return "M457 0 H583 V" + r + " H457z M457 0 H583 V" + r + " H457z";
              case "⎢":
                return "M319 0 H403 V" + r + " H319z M319 0 H403 V" + r + " H319z";
              case "⎥":
                return "M263 0 H347 V" + r + " H263z M263 0 H347 V" + r + " H263z";
              case "⎪":
                return "M384 0 H504 V" + r + " H384z M384 0 H504 V" + r + " H384z";
              case "⏐":
                return "M312 0 H355 V" + r + " H312z M312 0 H355 V" + r + " H312z";
              case "‖":
                return "M257 0 H300 V" + r + " H257z M257 0 H300 V" + r + " H257z" + ("M478 0 H521 V" + r + " H478z M478 0 H521 V" + r + " H478z");
              default:
                return "";
            }
          }, V0 = {
            // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
            doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
            // doublerightarrow is from glyph U+21D2 in font KaTeX Main
            doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
            // leftarrow is from glyph U+2190 in font KaTeX Main
            leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
            // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
            leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
            leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
            // overgroup is from the MnSymbol package (public domain)
            leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
            leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
            // Harpoons are from glyph U+21BD in font KaTeX Main
            leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
            leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
            leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
            leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
            // hook is from glyph U+21A9 in font KaTeX Main
            lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
            leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
            leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
            // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
            leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
            longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
            midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
            midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
            oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
            oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
            oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
            oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
            rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
            rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
            rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
            rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
            rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
            rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
            rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
            rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
            rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
            righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
            rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
            rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
            // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
            twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
            twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
            // tilde1 is a modified version of a glyph from the MnSymbol package
            tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
            // ditto tilde2, tilde3, & tilde4
            tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
            tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
            tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
            // vec is from glyph U+20D7 in font KaTeX Main
            vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
            // widehat1 is a modified version of a glyph from the MnSymbol package
            widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
            // ditto widehat2, widehat3, & widehat4
            widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
            widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
            widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
            // widecheck paths are all inverted versions of widehat
            widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
            widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
            widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
            widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
            // The next ten paths support reaction arrows from the mhchem package.
            // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
            // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
            baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
            // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
            rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
            // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
            // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
            baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
            rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
            shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
            shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
          }, Kr = function(e, r) {
            switch (e) {
              case "lbrack":
                return "M403 1759 V84 H666 V0 H319 V1759 v" + r + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + r + " v1759 h84z";
              case "rbrack":
                return "M347 1759 V0 H0 V84 H263 V1759 v" + r + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + r + " v1759 h84z";
              case "vert":
                return "M145 15 v585 v" + r + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -r + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + r + " v585 h43z";
              case "doublevert":
                return "M145 15 v585 v" + r + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -r + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + r + ` v585 h43z
M367 15 v585 v` + r + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -r + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + r + " v585 h43z";
              case "lfloor":
                return "M319 602 V0 H403 V602 v" + r + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + r + " v1715 H319z";
              case "rfloor":
                return "M319 602 V0 H403 V602 v" + r + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + r + " v1715 H319z";
              case "lceil":
                return "M403 1759 V84 H666 V0 H319 V1759 v" + r + ` v602 h84z
M403 1759 V0 H319 V1759 v` + r + " v602 h84z";
              case "rceil":
                return "M347 1759 V0 H0 V84 H263 V1759 v" + r + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + r + " v602 h84z";
              case "lparen":
                return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (r + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (r + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
              case "rparen":
                return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (r + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (r + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
              default:
                throw new Error("Unknown stretchy delimiter.");
            }
          }, k0 = /* @__PURE__ */ function() {
            function m(r) {
              this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = r, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
            }
            var e = m.prototype;
            return e.hasClass = function(a) {
              return M.contains(this.classes, a);
            }, e.toNode = function() {
              for (var a = document.createDocumentFragment(), l = 0; l < this.children.length; l++)
                a.appendChild(this.children[l].toNode());
              return a;
            }, e.toMarkup = function() {
              for (var a = "", l = 0; l < this.children.length; l++)
                a += this.children[l].toMarkup();
              return a;
            }, e.toText = function() {
              var a = function(c) {
                return c.toText();
              };
              return this.children.map(a).join("");
            }, m;
          }(), Ot = {
            "AMS-Regular": {
              32: [0, 0, 0, 0, 0.25],
              65: [0, 0.68889, 0, 0, 0.72222],
              66: [0, 0.68889, 0, 0, 0.66667],
              67: [0, 0.68889, 0, 0, 0.72222],
              68: [0, 0.68889, 0, 0, 0.72222],
              69: [0, 0.68889, 0, 0, 0.66667],
              70: [0, 0.68889, 0, 0, 0.61111],
              71: [0, 0.68889, 0, 0, 0.77778],
              72: [0, 0.68889, 0, 0, 0.77778],
              73: [0, 0.68889, 0, 0, 0.38889],
              74: [0.16667, 0.68889, 0, 0, 0.5],
              75: [0, 0.68889, 0, 0, 0.77778],
              76: [0, 0.68889, 0, 0, 0.66667],
              77: [0, 0.68889, 0, 0, 0.94445],
              78: [0, 0.68889, 0, 0, 0.72222],
              79: [0.16667, 0.68889, 0, 0, 0.77778],
              80: [0, 0.68889, 0, 0, 0.61111],
              81: [0.16667, 0.68889, 0, 0, 0.77778],
              82: [0, 0.68889, 0, 0, 0.72222],
              83: [0, 0.68889, 0, 0, 0.55556],
              84: [0, 0.68889, 0, 0, 0.66667],
              85: [0, 0.68889, 0, 0, 0.72222],
              86: [0, 0.68889, 0, 0, 0.72222],
              87: [0, 0.68889, 0, 0, 1],
              88: [0, 0.68889, 0, 0, 0.72222],
              89: [0, 0.68889, 0, 0, 0.72222],
              90: [0, 0.68889, 0, 0, 0.66667],
              107: [0, 0.68889, 0, 0, 0.55556],
              160: [0, 0, 0, 0, 0.25],
              165: [0, 0.675, 0.025, 0, 0.75],
              174: [0.15559, 0.69224, 0, 0, 0.94666],
              240: [0, 0.68889, 0, 0, 0.55556],
              295: [0, 0.68889, 0, 0, 0.54028],
              710: [0, 0.825, 0, 0, 2.33334],
              732: [0, 0.9, 0, 0, 2.33334],
              770: [0, 0.825, 0, 0, 2.33334],
              771: [0, 0.9, 0, 0, 2.33334],
              989: [0.08167, 0.58167, 0, 0, 0.77778],
              1008: [0, 0.43056, 0.04028, 0, 0.66667],
              8245: [0, 0.54986, 0, 0, 0.275],
              8463: [0, 0.68889, 0, 0, 0.54028],
              8487: [0, 0.68889, 0, 0, 0.72222],
              8498: [0, 0.68889, 0, 0, 0.55556],
              8502: [0, 0.68889, 0, 0, 0.66667],
              8503: [0, 0.68889, 0, 0, 0.44445],
              8504: [0, 0.68889, 0, 0, 0.66667],
              8513: [0, 0.68889, 0, 0, 0.63889],
              8592: [-0.03598, 0.46402, 0, 0, 0.5],
              8594: [-0.03598, 0.46402, 0, 0, 0.5],
              8602: [-0.13313, 0.36687, 0, 0, 1],
              8603: [-0.13313, 0.36687, 0, 0, 1],
              8606: [0.01354, 0.52239, 0, 0, 1],
              8608: [0.01354, 0.52239, 0, 0, 1],
              8610: [0.01354, 0.52239, 0, 0, 1.11111],
              8611: [0.01354, 0.52239, 0, 0, 1.11111],
              8619: [0, 0.54986, 0, 0, 1],
              8620: [0, 0.54986, 0, 0, 1],
              8621: [-0.13313, 0.37788, 0, 0, 1.38889],
              8622: [-0.13313, 0.36687, 0, 0, 1],
              8624: [0, 0.69224, 0, 0, 0.5],
              8625: [0, 0.69224, 0, 0, 0.5],
              8630: [0, 0.43056, 0, 0, 1],
              8631: [0, 0.43056, 0, 0, 1],
              8634: [0.08198, 0.58198, 0, 0, 0.77778],
              8635: [0.08198, 0.58198, 0, 0, 0.77778],
              8638: [0.19444, 0.69224, 0, 0, 0.41667],
              8639: [0.19444, 0.69224, 0, 0, 0.41667],
              8642: [0.19444, 0.69224, 0, 0, 0.41667],
              8643: [0.19444, 0.69224, 0, 0, 0.41667],
              8644: [0.1808, 0.675, 0, 0, 1],
              8646: [0.1808, 0.675, 0, 0, 1],
              8647: [0.1808, 0.675, 0, 0, 1],
              8648: [0.19444, 0.69224, 0, 0, 0.83334],
              8649: [0.1808, 0.675, 0, 0, 1],
              8650: [0.19444, 0.69224, 0, 0, 0.83334],
              8651: [0.01354, 0.52239, 0, 0, 1],
              8652: [0.01354, 0.52239, 0, 0, 1],
              8653: [-0.13313, 0.36687, 0, 0, 1],
              8654: [-0.13313, 0.36687, 0, 0, 1],
              8655: [-0.13313, 0.36687, 0, 0, 1],
              8666: [0.13667, 0.63667, 0, 0, 1],
              8667: [0.13667, 0.63667, 0, 0, 1],
              8669: [-0.13313, 0.37788, 0, 0, 1],
              8672: [-0.064, 0.437, 0, 0, 1.334],
              8674: [-0.064, 0.437, 0, 0, 1.334],
              8705: [0, 0.825, 0, 0, 0.5],
              8708: [0, 0.68889, 0, 0, 0.55556],
              8709: [0.08167, 0.58167, 0, 0, 0.77778],
              8717: [0, 0.43056, 0, 0, 0.42917],
              8722: [-0.03598, 0.46402, 0, 0, 0.5],
              8724: [0.08198, 0.69224, 0, 0, 0.77778],
              8726: [0.08167, 0.58167, 0, 0, 0.77778],
              8733: [0, 0.69224, 0, 0, 0.77778],
              8736: [0, 0.69224, 0, 0, 0.72222],
              8737: [0, 0.69224, 0, 0, 0.72222],
              8738: [0.03517, 0.52239, 0, 0, 0.72222],
              8739: [0.08167, 0.58167, 0, 0, 0.22222],
              8740: [0.25142, 0.74111, 0, 0, 0.27778],
              8741: [0.08167, 0.58167, 0, 0, 0.38889],
              8742: [0.25142, 0.74111, 0, 0, 0.5],
              8756: [0, 0.69224, 0, 0, 0.66667],
              8757: [0, 0.69224, 0, 0, 0.66667],
              8764: [-0.13313, 0.36687, 0, 0, 0.77778],
              8765: [-0.13313, 0.37788, 0, 0, 0.77778],
              8769: [-0.13313, 0.36687, 0, 0, 0.77778],
              8770: [-0.03625, 0.46375, 0, 0, 0.77778],
              8774: [0.30274, 0.79383, 0, 0, 0.77778],
              8776: [-0.01688, 0.48312, 0, 0, 0.77778],
              8778: [0.08167, 0.58167, 0, 0, 0.77778],
              8782: [0.06062, 0.54986, 0, 0, 0.77778],
              8783: [0.06062, 0.54986, 0, 0, 0.77778],
              8785: [0.08198, 0.58198, 0, 0, 0.77778],
              8786: [0.08198, 0.58198, 0, 0, 0.77778],
              8787: [0.08198, 0.58198, 0, 0, 0.77778],
              8790: [0, 0.69224, 0, 0, 0.77778],
              8791: [0.22958, 0.72958, 0, 0, 0.77778],
              8796: [0.08198, 0.91667, 0, 0, 0.77778],
              8806: [0.25583, 0.75583, 0, 0, 0.77778],
              8807: [0.25583, 0.75583, 0, 0, 0.77778],
              8808: [0.25142, 0.75726, 0, 0, 0.77778],
              8809: [0.25142, 0.75726, 0, 0, 0.77778],
              8812: [0.25583, 0.75583, 0, 0, 0.5],
              8814: [0.20576, 0.70576, 0, 0, 0.77778],
              8815: [0.20576, 0.70576, 0, 0, 0.77778],
              8816: [0.30274, 0.79383, 0, 0, 0.77778],
              8817: [0.30274, 0.79383, 0, 0, 0.77778],
              8818: [0.22958, 0.72958, 0, 0, 0.77778],
              8819: [0.22958, 0.72958, 0, 0, 0.77778],
              8822: [0.1808, 0.675, 0, 0, 0.77778],
              8823: [0.1808, 0.675, 0, 0, 0.77778],
              8828: [0.13667, 0.63667, 0, 0, 0.77778],
              8829: [0.13667, 0.63667, 0, 0, 0.77778],
              8830: [0.22958, 0.72958, 0, 0, 0.77778],
              8831: [0.22958, 0.72958, 0, 0, 0.77778],
              8832: [0.20576, 0.70576, 0, 0, 0.77778],
              8833: [0.20576, 0.70576, 0, 0, 0.77778],
              8840: [0.30274, 0.79383, 0, 0, 0.77778],
              8841: [0.30274, 0.79383, 0, 0, 0.77778],
              8842: [0.13597, 0.63597, 0, 0, 0.77778],
              8843: [0.13597, 0.63597, 0, 0, 0.77778],
              8847: [0.03517, 0.54986, 0, 0, 0.77778],
              8848: [0.03517, 0.54986, 0, 0, 0.77778],
              8858: [0.08198, 0.58198, 0, 0, 0.77778],
              8859: [0.08198, 0.58198, 0, 0, 0.77778],
              8861: [0.08198, 0.58198, 0, 0, 0.77778],
              8862: [0, 0.675, 0, 0, 0.77778],
              8863: [0, 0.675, 0, 0, 0.77778],
              8864: [0, 0.675, 0, 0, 0.77778],
              8865: [0, 0.675, 0, 0, 0.77778],
              8872: [0, 0.69224, 0, 0, 0.61111],
              8873: [0, 0.69224, 0, 0, 0.72222],
              8874: [0, 0.69224, 0, 0, 0.88889],
              8876: [0, 0.68889, 0, 0, 0.61111],
              8877: [0, 0.68889, 0, 0, 0.61111],
              8878: [0, 0.68889, 0, 0, 0.72222],
              8879: [0, 0.68889, 0, 0, 0.72222],
              8882: [0.03517, 0.54986, 0, 0, 0.77778],
              8883: [0.03517, 0.54986, 0, 0, 0.77778],
              8884: [0.13667, 0.63667, 0, 0, 0.77778],
              8885: [0.13667, 0.63667, 0, 0, 0.77778],
              8888: [0, 0.54986, 0, 0, 1.11111],
              8890: [0.19444, 0.43056, 0, 0, 0.55556],
              8891: [0.19444, 0.69224, 0, 0, 0.61111],
              8892: [0.19444, 0.69224, 0, 0, 0.61111],
              8901: [0, 0.54986, 0, 0, 0.27778],
              8903: [0.08167, 0.58167, 0, 0, 0.77778],
              8905: [0.08167, 0.58167, 0, 0, 0.77778],
              8906: [0.08167, 0.58167, 0, 0, 0.77778],
              8907: [0, 0.69224, 0, 0, 0.77778],
              8908: [0, 0.69224, 0, 0, 0.77778],
              8909: [-0.03598, 0.46402, 0, 0, 0.77778],
              8910: [0, 0.54986, 0, 0, 0.76042],
              8911: [0, 0.54986, 0, 0, 0.76042],
              8912: [0.03517, 0.54986, 0, 0, 0.77778],
              8913: [0.03517, 0.54986, 0, 0, 0.77778],
              8914: [0, 0.54986, 0, 0, 0.66667],
              8915: [0, 0.54986, 0, 0, 0.66667],
              8916: [0, 0.69224, 0, 0, 0.66667],
              8918: [0.0391, 0.5391, 0, 0, 0.77778],
              8919: [0.0391, 0.5391, 0, 0, 0.77778],
              8920: [0.03517, 0.54986, 0, 0, 1.33334],
              8921: [0.03517, 0.54986, 0, 0, 1.33334],
              8922: [0.38569, 0.88569, 0, 0, 0.77778],
              8923: [0.38569, 0.88569, 0, 0, 0.77778],
              8926: [0.13667, 0.63667, 0, 0, 0.77778],
              8927: [0.13667, 0.63667, 0, 0, 0.77778],
              8928: [0.30274, 0.79383, 0, 0, 0.77778],
              8929: [0.30274, 0.79383, 0, 0, 0.77778],
              8934: [0.23222, 0.74111, 0, 0, 0.77778],
              8935: [0.23222, 0.74111, 0, 0, 0.77778],
              8936: [0.23222, 0.74111, 0, 0, 0.77778],
              8937: [0.23222, 0.74111, 0, 0, 0.77778],
              8938: [0.20576, 0.70576, 0, 0, 0.77778],
              8939: [0.20576, 0.70576, 0, 0, 0.77778],
              8940: [0.30274, 0.79383, 0, 0, 0.77778],
              8941: [0.30274, 0.79383, 0, 0, 0.77778],
              8994: [0.19444, 0.69224, 0, 0, 0.77778],
              8995: [0.19444, 0.69224, 0, 0, 0.77778],
              9416: [0.15559, 0.69224, 0, 0, 0.90222],
              9484: [0, 0.69224, 0, 0, 0.5],
              9488: [0, 0.69224, 0, 0, 0.5],
              9492: [0, 0.37788, 0, 0, 0.5],
              9496: [0, 0.37788, 0, 0, 0.5],
              9585: [0.19444, 0.68889, 0, 0, 0.88889],
              9586: [0.19444, 0.74111, 0, 0, 0.88889],
              9632: [0, 0.675, 0, 0, 0.77778],
              9633: [0, 0.675, 0, 0, 0.77778],
              9650: [0, 0.54986, 0, 0, 0.72222],
              9651: [0, 0.54986, 0, 0, 0.72222],
              9654: [0.03517, 0.54986, 0, 0, 0.77778],
              9660: [0, 0.54986, 0, 0, 0.72222],
              9661: [0, 0.54986, 0, 0, 0.72222],
              9664: [0.03517, 0.54986, 0, 0, 0.77778],
              9674: [0.11111, 0.69224, 0, 0, 0.66667],
              9733: [0.19444, 0.69224, 0, 0, 0.94445],
              10003: [0, 0.69224, 0, 0, 0.83334],
              10016: [0, 0.69224, 0, 0, 0.83334],
              10731: [0.11111, 0.69224, 0, 0, 0.66667],
              10846: [0.19444, 0.75583, 0, 0, 0.61111],
              10877: [0.13667, 0.63667, 0, 0, 0.77778],
              10878: [0.13667, 0.63667, 0, 0, 0.77778],
              10885: [0.25583, 0.75583, 0, 0, 0.77778],
              10886: [0.25583, 0.75583, 0, 0, 0.77778],
              10887: [0.13597, 0.63597, 0, 0, 0.77778],
              10888: [0.13597, 0.63597, 0, 0, 0.77778],
              10889: [0.26167, 0.75726, 0, 0, 0.77778],
              10890: [0.26167, 0.75726, 0, 0, 0.77778],
              10891: [0.48256, 0.98256, 0, 0, 0.77778],
              10892: [0.48256, 0.98256, 0, 0, 0.77778],
              10901: [0.13667, 0.63667, 0, 0, 0.77778],
              10902: [0.13667, 0.63667, 0, 0, 0.77778],
              10933: [0.25142, 0.75726, 0, 0, 0.77778],
              10934: [0.25142, 0.75726, 0, 0, 0.77778],
              10935: [0.26167, 0.75726, 0, 0, 0.77778],
              10936: [0.26167, 0.75726, 0, 0, 0.77778],
              10937: [0.26167, 0.75726, 0, 0, 0.77778],
              10938: [0.26167, 0.75726, 0, 0, 0.77778],
              10949: [0.25583, 0.75583, 0, 0, 0.77778],
              10950: [0.25583, 0.75583, 0, 0, 0.77778],
              10955: [0.28481, 0.79383, 0, 0, 0.77778],
              10956: [0.28481, 0.79383, 0, 0, 0.77778],
              57350: [0.08167, 0.58167, 0, 0, 0.22222],
              57351: [0.08167, 0.58167, 0, 0, 0.38889],
              57352: [0.08167, 0.58167, 0, 0, 0.77778],
              57353: [0, 0.43056, 0.04028, 0, 0.66667],
              57356: [0.25142, 0.75726, 0, 0, 0.77778],
              57357: [0.25142, 0.75726, 0, 0, 0.77778],
              57358: [0.41951, 0.91951, 0, 0, 0.77778],
              57359: [0.30274, 0.79383, 0, 0, 0.77778],
              57360: [0.30274, 0.79383, 0, 0, 0.77778],
              57361: [0.41951, 0.91951, 0, 0, 0.77778],
              57366: [0.25142, 0.75726, 0, 0, 0.77778],
              57367: [0.25142, 0.75726, 0, 0, 0.77778],
              57368: [0.25142, 0.75726, 0, 0, 0.77778],
              57369: [0.25142, 0.75726, 0, 0, 0.77778],
              57370: [0.13597, 0.63597, 0, 0, 0.77778],
              57371: [0.13597, 0.63597, 0, 0, 0.77778]
            },
            "Caligraphic-Regular": {
              32: [0, 0, 0, 0, 0.25],
              65: [0, 0.68333, 0, 0.19445, 0.79847],
              66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
              67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
              68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
              69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
              70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
              71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
              72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
              73: [0, 0.68333, 0.07382, 0, 0.54452],
              74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
              75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
              76: [0, 0.68333, 0, 0.13889, 0.68972],
              77: [0, 0.68333, 0, 0.13889, 1.2009],
              78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
              79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
              80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
              81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
              82: [0, 0.68333, 0, 0.08334, 0.8475],
              83: [0, 0.68333, 0.075, 0.13889, 0.60556],
              84: [0, 0.68333, 0.25417, 0, 0.54464],
              85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
              86: [0, 0.68333, 0.08222, 0, 0.61278],
              87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
              88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
              89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
              90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
              160: [0, 0, 0, 0, 0.25]
            },
            "Fraktur-Regular": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69141, 0, 0, 0.29574],
              34: [0, 0.69141, 0, 0, 0.21471],
              38: [0, 0.69141, 0, 0, 0.73786],
              39: [0, 0.69141, 0, 0, 0.21201],
              40: [0.24982, 0.74947, 0, 0, 0.38865],
              41: [0.24982, 0.74947, 0, 0, 0.38865],
              42: [0, 0.62119, 0, 0, 0.27764],
              43: [0.08319, 0.58283, 0, 0, 0.75623],
              44: [0, 0.10803, 0, 0, 0.27764],
              45: [0.08319, 0.58283, 0, 0, 0.75623],
              46: [0, 0.10803, 0, 0, 0.27764],
              47: [0.24982, 0.74947, 0, 0, 0.50181],
              48: [0, 0.47534, 0, 0, 0.50181],
              49: [0, 0.47534, 0, 0, 0.50181],
              50: [0, 0.47534, 0, 0, 0.50181],
              51: [0.18906, 0.47534, 0, 0, 0.50181],
              52: [0.18906, 0.47534, 0, 0, 0.50181],
              53: [0.18906, 0.47534, 0, 0, 0.50181],
              54: [0, 0.69141, 0, 0, 0.50181],
              55: [0.18906, 0.47534, 0, 0, 0.50181],
              56: [0, 0.69141, 0, 0, 0.50181],
              57: [0.18906, 0.47534, 0, 0, 0.50181],
              58: [0, 0.47534, 0, 0, 0.21606],
              59: [0.12604, 0.47534, 0, 0, 0.21606],
              61: [-0.13099, 0.36866, 0, 0, 0.75623],
              63: [0, 0.69141, 0, 0, 0.36245],
              65: [0, 0.69141, 0, 0, 0.7176],
              66: [0, 0.69141, 0, 0, 0.88397],
              67: [0, 0.69141, 0, 0, 0.61254],
              68: [0, 0.69141, 0, 0, 0.83158],
              69: [0, 0.69141, 0, 0, 0.66278],
              70: [0.12604, 0.69141, 0, 0, 0.61119],
              71: [0, 0.69141, 0, 0, 0.78539],
              72: [0.06302, 0.69141, 0, 0, 0.7203],
              73: [0, 0.69141, 0, 0, 0.55448],
              74: [0.12604, 0.69141, 0, 0, 0.55231],
              75: [0, 0.69141, 0, 0, 0.66845],
              76: [0, 0.69141, 0, 0, 0.66602],
              77: [0, 0.69141, 0, 0, 1.04953],
              78: [0, 0.69141, 0, 0, 0.83212],
              79: [0, 0.69141, 0, 0, 0.82699],
              80: [0.18906, 0.69141, 0, 0, 0.82753],
              81: [0.03781, 0.69141, 0, 0, 0.82699],
              82: [0, 0.69141, 0, 0, 0.82807],
              83: [0, 0.69141, 0, 0, 0.82861],
              84: [0, 0.69141, 0, 0, 0.66899],
              85: [0, 0.69141, 0, 0, 0.64576],
              86: [0, 0.69141, 0, 0, 0.83131],
              87: [0, 0.69141, 0, 0, 1.04602],
              88: [0, 0.69141, 0, 0, 0.71922],
              89: [0.18906, 0.69141, 0, 0, 0.83293],
              90: [0.12604, 0.69141, 0, 0, 0.60201],
              91: [0.24982, 0.74947, 0, 0, 0.27764],
              93: [0.24982, 0.74947, 0, 0, 0.27764],
              94: [0, 0.69141, 0, 0, 0.49965],
              97: [0, 0.47534, 0, 0, 0.50046],
              98: [0, 0.69141, 0, 0, 0.51315],
              99: [0, 0.47534, 0, 0, 0.38946],
              100: [0, 0.62119, 0, 0, 0.49857],
              101: [0, 0.47534, 0, 0, 0.40053],
              102: [0.18906, 0.69141, 0, 0, 0.32626],
              103: [0.18906, 0.47534, 0, 0, 0.5037],
              104: [0.18906, 0.69141, 0, 0, 0.52126],
              105: [0, 0.69141, 0, 0, 0.27899],
              106: [0, 0.69141, 0, 0, 0.28088],
              107: [0, 0.69141, 0, 0, 0.38946],
              108: [0, 0.69141, 0, 0, 0.27953],
              109: [0, 0.47534, 0, 0, 0.76676],
              110: [0, 0.47534, 0, 0, 0.52666],
              111: [0, 0.47534, 0, 0, 0.48885],
              112: [0.18906, 0.52396, 0, 0, 0.50046],
              113: [0.18906, 0.47534, 0, 0, 0.48912],
              114: [0, 0.47534, 0, 0, 0.38919],
              115: [0, 0.47534, 0, 0, 0.44266],
              116: [0, 0.62119, 0, 0, 0.33301],
              117: [0, 0.47534, 0, 0, 0.5172],
              118: [0, 0.52396, 0, 0, 0.5118],
              119: [0, 0.52396, 0, 0, 0.77351],
              120: [0.18906, 0.47534, 0, 0, 0.38865],
              121: [0.18906, 0.47534, 0, 0, 0.49884],
              122: [0.18906, 0.47534, 0, 0, 0.39054],
              160: [0, 0, 0, 0, 0.25],
              8216: [0, 0.69141, 0, 0, 0.21471],
              8217: [0, 0.69141, 0, 0, 0.21471],
              58112: [0, 0.62119, 0, 0, 0.49749],
              58113: [0, 0.62119, 0, 0, 0.4983],
              58114: [0.18906, 0.69141, 0, 0, 0.33328],
              58115: [0.18906, 0.69141, 0, 0, 0.32923],
              58116: [0.18906, 0.47534, 0, 0, 0.50343],
              58117: [0, 0.69141, 0, 0, 0.33301],
              58118: [0, 0.62119, 0, 0, 0.33409],
              58119: [0, 0.47534, 0, 0, 0.50073]
            },
            "Main-Bold": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.35],
              34: [0, 0.69444, 0, 0, 0.60278],
              35: [0.19444, 0.69444, 0, 0, 0.95833],
              36: [0.05556, 0.75, 0, 0, 0.575],
              37: [0.05556, 0.75, 0, 0, 0.95833],
              38: [0, 0.69444, 0, 0, 0.89444],
              39: [0, 0.69444, 0, 0, 0.31944],
              40: [0.25, 0.75, 0, 0, 0.44722],
              41: [0.25, 0.75, 0, 0, 0.44722],
              42: [0, 0.75, 0, 0, 0.575],
              43: [0.13333, 0.63333, 0, 0, 0.89444],
              44: [0.19444, 0.15556, 0, 0, 0.31944],
              45: [0, 0.44444, 0, 0, 0.38333],
              46: [0, 0.15556, 0, 0, 0.31944],
              47: [0.25, 0.75, 0, 0, 0.575],
              48: [0, 0.64444, 0, 0, 0.575],
              49: [0, 0.64444, 0, 0, 0.575],
              50: [0, 0.64444, 0, 0, 0.575],
              51: [0, 0.64444, 0, 0, 0.575],
              52: [0, 0.64444, 0, 0, 0.575],
              53: [0, 0.64444, 0, 0, 0.575],
              54: [0, 0.64444, 0, 0, 0.575],
              55: [0, 0.64444, 0, 0, 0.575],
              56: [0, 0.64444, 0, 0, 0.575],
              57: [0, 0.64444, 0, 0, 0.575],
              58: [0, 0.44444, 0, 0, 0.31944],
              59: [0.19444, 0.44444, 0, 0, 0.31944],
              60: [0.08556, 0.58556, 0, 0, 0.89444],
              61: [-0.10889, 0.39111, 0, 0, 0.89444],
              62: [0.08556, 0.58556, 0, 0, 0.89444],
              63: [0, 0.69444, 0, 0, 0.54305],
              64: [0, 0.69444, 0, 0, 0.89444],
              65: [0, 0.68611, 0, 0, 0.86944],
              66: [0, 0.68611, 0, 0, 0.81805],
              67: [0, 0.68611, 0, 0, 0.83055],
              68: [0, 0.68611, 0, 0, 0.88194],
              69: [0, 0.68611, 0, 0, 0.75555],
              70: [0, 0.68611, 0, 0, 0.72361],
              71: [0, 0.68611, 0, 0, 0.90416],
              72: [0, 0.68611, 0, 0, 0.9],
              73: [0, 0.68611, 0, 0, 0.43611],
              74: [0, 0.68611, 0, 0, 0.59444],
              75: [0, 0.68611, 0, 0, 0.90138],
              76: [0, 0.68611, 0, 0, 0.69166],
              77: [0, 0.68611, 0, 0, 1.09166],
              78: [0, 0.68611, 0, 0, 0.9],
              79: [0, 0.68611, 0, 0, 0.86388],
              80: [0, 0.68611, 0, 0, 0.78611],
              81: [0.19444, 0.68611, 0, 0, 0.86388],
              82: [0, 0.68611, 0, 0, 0.8625],
              83: [0, 0.68611, 0, 0, 0.63889],
              84: [0, 0.68611, 0, 0, 0.8],
              85: [0, 0.68611, 0, 0, 0.88472],
              86: [0, 0.68611, 0.01597, 0, 0.86944],
              87: [0, 0.68611, 0.01597, 0, 1.18888],
              88: [0, 0.68611, 0, 0, 0.86944],
              89: [0, 0.68611, 0.02875, 0, 0.86944],
              90: [0, 0.68611, 0, 0, 0.70277],
              91: [0.25, 0.75, 0, 0, 0.31944],
              92: [0.25, 0.75, 0, 0, 0.575],
              93: [0.25, 0.75, 0, 0, 0.31944],
              94: [0, 0.69444, 0, 0, 0.575],
              95: [0.31, 0.13444, 0.03194, 0, 0.575],
              97: [0, 0.44444, 0, 0, 0.55902],
              98: [0, 0.69444, 0, 0, 0.63889],
              99: [0, 0.44444, 0, 0, 0.51111],
              100: [0, 0.69444, 0, 0, 0.63889],
              101: [0, 0.44444, 0, 0, 0.52708],
              102: [0, 0.69444, 0.10903, 0, 0.35139],
              103: [0.19444, 0.44444, 0.01597, 0, 0.575],
              104: [0, 0.69444, 0, 0, 0.63889],
              105: [0, 0.69444, 0, 0, 0.31944],
              106: [0.19444, 0.69444, 0, 0, 0.35139],
              107: [0, 0.69444, 0, 0, 0.60694],
              108: [0, 0.69444, 0, 0, 0.31944],
              109: [0, 0.44444, 0, 0, 0.95833],
              110: [0, 0.44444, 0, 0, 0.63889],
              111: [0, 0.44444, 0, 0, 0.575],
              112: [0.19444, 0.44444, 0, 0, 0.63889],
              113: [0.19444, 0.44444, 0, 0, 0.60694],
              114: [0, 0.44444, 0, 0, 0.47361],
              115: [0, 0.44444, 0, 0, 0.45361],
              116: [0, 0.63492, 0, 0, 0.44722],
              117: [0, 0.44444, 0, 0, 0.63889],
              118: [0, 0.44444, 0.01597, 0, 0.60694],
              119: [0, 0.44444, 0.01597, 0, 0.83055],
              120: [0, 0.44444, 0, 0, 0.60694],
              121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
              122: [0, 0.44444, 0, 0, 0.51111],
              123: [0.25, 0.75, 0, 0, 0.575],
              124: [0.25, 0.75, 0, 0, 0.31944],
              125: [0.25, 0.75, 0, 0, 0.575],
              126: [0.35, 0.34444, 0, 0, 0.575],
              160: [0, 0, 0, 0, 0.25],
              163: [0, 0.69444, 0, 0, 0.86853],
              168: [0, 0.69444, 0, 0, 0.575],
              172: [0, 0.44444, 0, 0, 0.76666],
              176: [0, 0.69444, 0, 0, 0.86944],
              177: [0.13333, 0.63333, 0, 0, 0.89444],
              184: [0.17014, 0, 0, 0, 0.51111],
              198: [0, 0.68611, 0, 0, 1.04166],
              215: [0.13333, 0.63333, 0, 0, 0.89444],
              216: [0.04861, 0.73472, 0, 0, 0.89444],
              223: [0, 0.69444, 0, 0, 0.59722],
              230: [0, 0.44444, 0, 0, 0.83055],
              247: [0.13333, 0.63333, 0, 0, 0.89444],
              248: [0.09722, 0.54167, 0, 0, 0.575],
              305: [0, 0.44444, 0, 0, 0.31944],
              338: [0, 0.68611, 0, 0, 1.16944],
              339: [0, 0.44444, 0, 0, 0.89444],
              567: [0.19444, 0.44444, 0, 0, 0.35139],
              710: [0, 0.69444, 0, 0, 0.575],
              711: [0, 0.63194, 0, 0, 0.575],
              713: [0, 0.59611, 0, 0, 0.575],
              714: [0, 0.69444, 0, 0, 0.575],
              715: [0, 0.69444, 0, 0, 0.575],
              728: [0, 0.69444, 0, 0, 0.575],
              729: [0, 0.69444, 0, 0, 0.31944],
              730: [0, 0.69444, 0, 0, 0.86944],
              732: [0, 0.69444, 0, 0, 0.575],
              733: [0, 0.69444, 0, 0, 0.575],
              915: [0, 0.68611, 0, 0, 0.69166],
              916: [0, 0.68611, 0, 0, 0.95833],
              920: [0, 0.68611, 0, 0, 0.89444],
              923: [0, 0.68611, 0, 0, 0.80555],
              926: [0, 0.68611, 0, 0, 0.76666],
              928: [0, 0.68611, 0, 0, 0.9],
              931: [0, 0.68611, 0, 0, 0.83055],
              933: [0, 0.68611, 0, 0, 0.89444],
              934: [0, 0.68611, 0, 0, 0.83055],
              936: [0, 0.68611, 0, 0, 0.89444],
              937: [0, 0.68611, 0, 0, 0.83055],
              8211: [0, 0.44444, 0.03194, 0, 0.575],
              8212: [0, 0.44444, 0.03194, 0, 1.14999],
              8216: [0, 0.69444, 0, 0, 0.31944],
              8217: [0, 0.69444, 0, 0, 0.31944],
              8220: [0, 0.69444, 0, 0, 0.60278],
              8221: [0, 0.69444, 0, 0, 0.60278],
              8224: [0.19444, 0.69444, 0, 0, 0.51111],
              8225: [0.19444, 0.69444, 0, 0, 0.51111],
              8242: [0, 0.55556, 0, 0, 0.34444],
              8407: [0, 0.72444, 0.15486, 0, 0.575],
              8463: [0, 0.69444, 0, 0, 0.66759],
              8465: [0, 0.69444, 0, 0, 0.83055],
              8467: [0, 0.69444, 0, 0, 0.47361],
              8472: [0.19444, 0.44444, 0, 0, 0.74027],
              8476: [0, 0.69444, 0, 0, 0.83055],
              8501: [0, 0.69444, 0, 0, 0.70277],
              8592: [-0.10889, 0.39111, 0, 0, 1.14999],
              8593: [0.19444, 0.69444, 0, 0, 0.575],
              8594: [-0.10889, 0.39111, 0, 0, 1.14999],
              8595: [0.19444, 0.69444, 0, 0, 0.575],
              8596: [-0.10889, 0.39111, 0, 0, 1.14999],
              8597: [0.25, 0.75, 0, 0, 0.575],
              8598: [0.19444, 0.69444, 0, 0, 1.14999],
              8599: [0.19444, 0.69444, 0, 0, 1.14999],
              8600: [0.19444, 0.69444, 0, 0, 1.14999],
              8601: [0.19444, 0.69444, 0, 0, 1.14999],
              8636: [-0.10889, 0.39111, 0, 0, 1.14999],
              8637: [-0.10889, 0.39111, 0, 0, 1.14999],
              8640: [-0.10889, 0.39111, 0, 0, 1.14999],
              8641: [-0.10889, 0.39111, 0, 0, 1.14999],
              8656: [-0.10889, 0.39111, 0, 0, 1.14999],
              8657: [0.19444, 0.69444, 0, 0, 0.70277],
              8658: [-0.10889, 0.39111, 0, 0, 1.14999],
              8659: [0.19444, 0.69444, 0, 0, 0.70277],
              8660: [-0.10889, 0.39111, 0, 0, 1.14999],
              8661: [0.25, 0.75, 0, 0, 0.70277],
              8704: [0, 0.69444, 0, 0, 0.63889],
              8706: [0, 0.69444, 0.06389, 0, 0.62847],
              8707: [0, 0.69444, 0, 0, 0.63889],
              8709: [0.05556, 0.75, 0, 0, 0.575],
              8711: [0, 0.68611, 0, 0, 0.95833],
              8712: [0.08556, 0.58556, 0, 0, 0.76666],
              8715: [0.08556, 0.58556, 0, 0, 0.76666],
              8722: [0.13333, 0.63333, 0, 0, 0.89444],
              8723: [0.13333, 0.63333, 0, 0, 0.89444],
              8725: [0.25, 0.75, 0, 0, 0.575],
              8726: [0.25, 0.75, 0, 0, 0.575],
              8727: [-0.02778, 0.47222, 0, 0, 0.575],
              8728: [-0.02639, 0.47361, 0, 0, 0.575],
              8729: [-0.02639, 0.47361, 0, 0, 0.575],
              8730: [0.18, 0.82, 0, 0, 0.95833],
              8733: [0, 0.44444, 0, 0, 0.89444],
              8734: [0, 0.44444, 0, 0, 1.14999],
              8736: [0, 0.69224, 0, 0, 0.72222],
              8739: [0.25, 0.75, 0, 0, 0.31944],
              8741: [0.25, 0.75, 0, 0, 0.575],
              8743: [0, 0.55556, 0, 0, 0.76666],
              8744: [0, 0.55556, 0, 0, 0.76666],
              8745: [0, 0.55556, 0, 0, 0.76666],
              8746: [0, 0.55556, 0, 0, 0.76666],
              8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
              8764: [-0.10889, 0.39111, 0, 0, 0.89444],
              8768: [0.19444, 0.69444, 0, 0, 0.31944],
              8771: [222e-5, 0.50222, 0, 0, 0.89444],
              8773: [0.027, 0.638, 0, 0, 0.894],
              8776: [0.02444, 0.52444, 0, 0, 0.89444],
              8781: [222e-5, 0.50222, 0, 0, 0.89444],
              8801: [222e-5, 0.50222, 0, 0, 0.89444],
              8804: [0.19667, 0.69667, 0, 0, 0.89444],
              8805: [0.19667, 0.69667, 0, 0, 0.89444],
              8810: [0.08556, 0.58556, 0, 0, 1.14999],
              8811: [0.08556, 0.58556, 0, 0, 1.14999],
              8826: [0.08556, 0.58556, 0, 0, 0.89444],
              8827: [0.08556, 0.58556, 0, 0, 0.89444],
              8834: [0.08556, 0.58556, 0, 0, 0.89444],
              8835: [0.08556, 0.58556, 0, 0, 0.89444],
              8838: [0.19667, 0.69667, 0, 0, 0.89444],
              8839: [0.19667, 0.69667, 0, 0, 0.89444],
              8846: [0, 0.55556, 0, 0, 0.76666],
              8849: [0.19667, 0.69667, 0, 0, 0.89444],
              8850: [0.19667, 0.69667, 0, 0, 0.89444],
              8851: [0, 0.55556, 0, 0, 0.76666],
              8852: [0, 0.55556, 0, 0, 0.76666],
              8853: [0.13333, 0.63333, 0, 0, 0.89444],
              8854: [0.13333, 0.63333, 0, 0, 0.89444],
              8855: [0.13333, 0.63333, 0, 0, 0.89444],
              8856: [0.13333, 0.63333, 0, 0, 0.89444],
              8857: [0.13333, 0.63333, 0, 0, 0.89444],
              8866: [0, 0.69444, 0, 0, 0.70277],
              8867: [0, 0.69444, 0, 0, 0.70277],
              8868: [0, 0.69444, 0, 0, 0.89444],
              8869: [0, 0.69444, 0, 0, 0.89444],
              8900: [-0.02639, 0.47361, 0, 0, 0.575],
              8901: [-0.02639, 0.47361, 0, 0, 0.31944],
              8902: [-0.02778, 0.47222, 0, 0, 0.575],
              8968: [0.25, 0.75, 0, 0, 0.51111],
              8969: [0.25, 0.75, 0, 0, 0.51111],
              8970: [0.25, 0.75, 0, 0, 0.51111],
              8971: [0.25, 0.75, 0, 0, 0.51111],
              8994: [-0.13889, 0.36111, 0, 0, 1.14999],
              8995: [-0.13889, 0.36111, 0, 0, 1.14999],
              9651: [0.19444, 0.69444, 0, 0, 1.02222],
              9657: [-0.02778, 0.47222, 0, 0, 0.575],
              9661: [0.19444, 0.69444, 0, 0, 1.02222],
              9667: [-0.02778, 0.47222, 0, 0, 0.575],
              9711: [0.19444, 0.69444, 0, 0, 1.14999],
              9824: [0.12963, 0.69444, 0, 0, 0.89444],
              9825: [0.12963, 0.69444, 0, 0, 0.89444],
              9826: [0.12963, 0.69444, 0, 0, 0.89444],
              9827: [0.12963, 0.69444, 0, 0, 0.89444],
              9837: [0, 0.75, 0, 0, 0.44722],
              9838: [0.19444, 0.69444, 0, 0, 0.44722],
              9839: [0.19444, 0.69444, 0, 0, 0.44722],
              10216: [0.25, 0.75, 0, 0, 0.44722],
              10217: [0.25, 0.75, 0, 0, 0.44722],
              10815: [0, 0.68611, 0, 0, 0.9],
              10927: [0.19667, 0.69667, 0, 0, 0.89444],
              10928: [0.19667, 0.69667, 0, 0, 0.89444],
              57376: [0.19444, 0.69444, 0, 0, 0]
            },
            "Main-BoldItalic": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0.11417, 0, 0.38611],
              34: [0, 0.69444, 0.07939, 0, 0.62055],
              35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
              37: [0.05556, 0.75, 0.12861, 0, 0.94444],
              38: [0, 0.69444, 0.08528, 0, 0.88555],
              39: [0, 0.69444, 0.12945, 0, 0.35555],
              40: [0.25, 0.75, 0.15806, 0, 0.47333],
              41: [0.25, 0.75, 0.03306, 0, 0.47333],
              42: [0, 0.75, 0.14333, 0, 0.59111],
              43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
              44: [0.19444, 0.14722, 0, 0, 0.35555],
              45: [0, 0.44444, 0.02611, 0, 0.41444],
              46: [0, 0.14722, 0, 0, 0.35555],
              47: [0.25, 0.75, 0.15806, 0, 0.59111],
              48: [0, 0.64444, 0.13167, 0, 0.59111],
              49: [0, 0.64444, 0.13167, 0, 0.59111],
              50: [0, 0.64444, 0.13167, 0, 0.59111],
              51: [0, 0.64444, 0.13167, 0, 0.59111],
              52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
              53: [0, 0.64444, 0.13167, 0, 0.59111],
              54: [0, 0.64444, 0.13167, 0, 0.59111],
              55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
              56: [0, 0.64444, 0.13167, 0, 0.59111],
              57: [0, 0.64444, 0.13167, 0, 0.59111],
              58: [0, 0.44444, 0.06695, 0, 0.35555],
              59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
              61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
              63: [0, 0.69444, 0.11472, 0, 0.59111],
              64: [0, 0.69444, 0.09208, 0, 0.88555],
              65: [0, 0.68611, 0, 0, 0.86555],
              66: [0, 0.68611, 0.0992, 0, 0.81666],
              67: [0, 0.68611, 0.14208, 0, 0.82666],
              68: [0, 0.68611, 0.09062, 0, 0.87555],
              69: [0, 0.68611, 0.11431, 0, 0.75666],
              70: [0, 0.68611, 0.12903, 0, 0.72722],
              71: [0, 0.68611, 0.07347, 0, 0.89527],
              72: [0, 0.68611, 0.17208, 0, 0.8961],
              73: [0, 0.68611, 0.15681, 0, 0.47166],
              74: [0, 0.68611, 0.145, 0, 0.61055],
              75: [0, 0.68611, 0.14208, 0, 0.89499],
              76: [0, 0.68611, 0, 0, 0.69777],
              77: [0, 0.68611, 0.17208, 0, 1.07277],
              78: [0, 0.68611, 0.17208, 0, 0.8961],
              79: [0, 0.68611, 0.09062, 0, 0.85499],
              80: [0, 0.68611, 0.0992, 0, 0.78721],
              81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
              82: [0, 0.68611, 0.02559, 0, 0.85944],
              83: [0, 0.68611, 0.11264, 0, 0.64999],
              84: [0, 0.68611, 0.12903, 0, 0.7961],
              85: [0, 0.68611, 0.17208, 0, 0.88083],
              86: [0, 0.68611, 0.18625, 0, 0.86555],
              87: [0, 0.68611, 0.18625, 0, 1.15999],
              88: [0, 0.68611, 0.15681, 0, 0.86555],
              89: [0, 0.68611, 0.19803, 0, 0.86555],
              90: [0, 0.68611, 0.14208, 0, 0.70888],
              91: [0.25, 0.75, 0.1875, 0, 0.35611],
              93: [0.25, 0.75, 0.09972, 0, 0.35611],
              94: [0, 0.69444, 0.06709, 0, 0.59111],
              95: [0.31, 0.13444, 0.09811, 0, 0.59111],
              97: [0, 0.44444, 0.09426, 0, 0.59111],
              98: [0, 0.69444, 0.07861, 0, 0.53222],
              99: [0, 0.44444, 0.05222, 0, 0.53222],
              100: [0, 0.69444, 0.10861, 0, 0.59111],
              101: [0, 0.44444, 0.085, 0, 0.53222],
              102: [0.19444, 0.69444, 0.21778, 0, 0.4],
              103: [0.19444, 0.44444, 0.105, 0, 0.53222],
              104: [0, 0.69444, 0.09426, 0, 0.59111],
              105: [0, 0.69326, 0.11387, 0, 0.35555],
              106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
              107: [0, 0.69444, 0.11111, 0, 0.53222],
              108: [0, 0.69444, 0.10861, 0, 0.29666],
              109: [0, 0.44444, 0.09426, 0, 0.94444],
              110: [0, 0.44444, 0.09426, 0, 0.64999],
              111: [0, 0.44444, 0.07861, 0, 0.59111],
              112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
              113: [0.19444, 0.44444, 0.105, 0, 0.53222],
              114: [0, 0.44444, 0.11111, 0, 0.50167],
              115: [0, 0.44444, 0.08167, 0, 0.48694],
              116: [0, 0.63492, 0.09639, 0, 0.385],
              117: [0, 0.44444, 0.09426, 0, 0.62055],
              118: [0, 0.44444, 0.11111, 0, 0.53222],
              119: [0, 0.44444, 0.11111, 0, 0.76777],
              120: [0, 0.44444, 0.12583, 0, 0.56055],
              121: [0.19444, 0.44444, 0.105, 0, 0.56166],
              122: [0, 0.44444, 0.13889, 0, 0.49055],
              126: [0.35, 0.34444, 0.11472, 0, 0.59111],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.69444, 0.11473, 0, 0.59111],
              176: [0, 0.69444, 0, 0, 0.94888],
              184: [0.17014, 0, 0, 0, 0.53222],
              198: [0, 0.68611, 0.11431, 0, 1.02277],
              216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
              223: [0.19444, 0.69444, 0.09736, 0, 0.665],
              230: [0, 0.44444, 0.085, 0, 0.82666],
              248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
              305: [0, 0.44444, 0.09426, 0, 0.35555],
              338: [0, 0.68611, 0.11431, 0, 1.14054],
              339: [0, 0.44444, 0.085, 0, 0.82666],
              567: [0.19444, 0.44444, 0.04611, 0, 0.385],
              710: [0, 0.69444, 0.06709, 0, 0.59111],
              711: [0, 0.63194, 0.08271, 0, 0.59111],
              713: [0, 0.59444, 0.10444, 0, 0.59111],
              714: [0, 0.69444, 0.08528, 0, 0.59111],
              715: [0, 0.69444, 0, 0, 0.59111],
              728: [0, 0.69444, 0.10333, 0, 0.59111],
              729: [0, 0.69444, 0.12945, 0, 0.35555],
              730: [0, 0.69444, 0, 0, 0.94888],
              732: [0, 0.69444, 0.11472, 0, 0.59111],
              733: [0, 0.69444, 0.11472, 0, 0.59111],
              915: [0, 0.68611, 0.12903, 0, 0.69777],
              916: [0, 0.68611, 0, 0, 0.94444],
              920: [0, 0.68611, 0.09062, 0, 0.88555],
              923: [0, 0.68611, 0, 0, 0.80666],
              926: [0, 0.68611, 0.15092, 0, 0.76777],
              928: [0, 0.68611, 0.17208, 0, 0.8961],
              931: [0, 0.68611, 0.11431, 0, 0.82666],
              933: [0, 0.68611, 0.10778, 0, 0.88555],
              934: [0, 0.68611, 0.05632, 0, 0.82666],
              936: [0, 0.68611, 0.10778, 0, 0.88555],
              937: [0, 0.68611, 0.0992, 0, 0.82666],
              8211: [0, 0.44444, 0.09811, 0, 0.59111],
              8212: [0, 0.44444, 0.09811, 0, 1.18221],
              8216: [0, 0.69444, 0.12945, 0, 0.35555],
              8217: [0, 0.69444, 0.12945, 0, 0.35555],
              8220: [0, 0.69444, 0.16772, 0, 0.62055],
              8221: [0, 0.69444, 0.07939, 0, 0.62055]
            },
            "Main-Italic": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0.12417, 0, 0.30667],
              34: [0, 0.69444, 0.06961, 0, 0.51444],
              35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
              37: [0.05556, 0.75, 0.13639, 0, 0.81777],
              38: [0, 0.69444, 0.09694, 0, 0.76666],
              39: [0, 0.69444, 0.12417, 0, 0.30667],
              40: [0.25, 0.75, 0.16194, 0, 0.40889],
              41: [0.25, 0.75, 0.03694, 0, 0.40889],
              42: [0, 0.75, 0.14917, 0, 0.51111],
              43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
              44: [0.19444, 0.10556, 0, 0, 0.30667],
              45: [0, 0.43056, 0.02826, 0, 0.35778],
              46: [0, 0.10556, 0, 0, 0.30667],
              47: [0.25, 0.75, 0.16194, 0, 0.51111],
              48: [0, 0.64444, 0.13556, 0, 0.51111],
              49: [0, 0.64444, 0.13556, 0, 0.51111],
              50: [0, 0.64444, 0.13556, 0, 0.51111],
              51: [0, 0.64444, 0.13556, 0, 0.51111],
              52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
              53: [0, 0.64444, 0.13556, 0, 0.51111],
              54: [0, 0.64444, 0.13556, 0, 0.51111],
              55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
              56: [0, 0.64444, 0.13556, 0, 0.51111],
              57: [0, 0.64444, 0.13556, 0, 0.51111],
              58: [0, 0.43056, 0.0582, 0, 0.30667],
              59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
              61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
              63: [0, 0.69444, 0.1225, 0, 0.51111],
              64: [0, 0.69444, 0.09597, 0, 0.76666],
              65: [0, 0.68333, 0, 0, 0.74333],
              66: [0, 0.68333, 0.10257, 0, 0.70389],
              67: [0, 0.68333, 0.14528, 0, 0.71555],
              68: [0, 0.68333, 0.09403, 0, 0.755],
              69: [0, 0.68333, 0.12028, 0, 0.67833],
              70: [0, 0.68333, 0.13305, 0, 0.65277],
              71: [0, 0.68333, 0.08722, 0, 0.77361],
              72: [0, 0.68333, 0.16389, 0, 0.74333],
              73: [0, 0.68333, 0.15806, 0, 0.38555],
              74: [0, 0.68333, 0.14028, 0, 0.525],
              75: [0, 0.68333, 0.14528, 0, 0.76888],
              76: [0, 0.68333, 0, 0, 0.62722],
              77: [0, 0.68333, 0.16389, 0, 0.89666],
              78: [0, 0.68333, 0.16389, 0, 0.74333],
              79: [0, 0.68333, 0.09403, 0, 0.76666],
              80: [0, 0.68333, 0.10257, 0, 0.67833],
              81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
              82: [0, 0.68333, 0.03868, 0, 0.72944],
              83: [0, 0.68333, 0.11972, 0, 0.56222],
              84: [0, 0.68333, 0.13305, 0, 0.71555],
              85: [0, 0.68333, 0.16389, 0, 0.74333],
              86: [0, 0.68333, 0.18361, 0, 0.74333],
              87: [0, 0.68333, 0.18361, 0, 0.99888],
              88: [0, 0.68333, 0.15806, 0, 0.74333],
              89: [0, 0.68333, 0.19383, 0, 0.74333],
              90: [0, 0.68333, 0.14528, 0, 0.61333],
              91: [0.25, 0.75, 0.1875, 0, 0.30667],
              93: [0.25, 0.75, 0.10528, 0, 0.30667],
              94: [0, 0.69444, 0.06646, 0, 0.51111],
              95: [0.31, 0.12056, 0.09208, 0, 0.51111],
              97: [0, 0.43056, 0.07671, 0, 0.51111],
              98: [0, 0.69444, 0.06312, 0, 0.46],
              99: [0, 0.43056, 0.05653, 0, 0.46],
              100: [0, 0.69444, 0.10333, 0, 0.51111],
              101: [0, 0.43056, 0.07514, 0, 0.46],
              102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
              103: [0.19444, 0.43056, 0.08847, 0, 0.46],
              104: [0, 0.69444, 0.07671, 0, 0.51111],
              105: [0, 0.65536, 0.1019, 0, 0.30667],
              106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
              107: [0, 0.69444, 0.10764, 0, 0.46],
              108: [0, 0.69444, 0.10333, 0, 0.25555],
              109: [0, 0.43056, 0.07671, 0, 0.81777],
              110: [0, 0.43056, 0.07671, 0, 0.56222],
              111: [0, 0.43056, 0.06312, 0, 0.51111],
              112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
              113: [0.19444, 0.43056, 0.08847, 0, 0.46],
              114: [0, 0.43056, 0.10764, 0, 0.42166],
              115: [0, 0.43056, 0.08208, 0, 0.40889],
              116: [0, 0.61508, 0.09486, 0, 0.33222],
              117: [0, 0.43056, 0.07671, 0, 0.53666],
              118: [0, 0.43056, 0.10764, 0, 0.46],
              119: [0, 0.43056, 0.10764, 0, 0.66444],
              120: [0, 0.43056, 0.12042, 0, 0.46389],
              121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
              122: [0, 0.43056, 0.12292, 0, 0.40889],
              126: [0.35, 0.31786, 0.11585, 0, 0.51111],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.66786, 0.10474, 0, 0.51111],
              176: [0, 0.69444, 0, 0, 0.83129],
              184: [0.17014, 0, 0, 0, 0.46],
              198: [0, 0.68333, 0.12028, 0, 0.88277],
              216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
              223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
              230: [0, 0.43056, 0.07514, 0, 0.71555],
              248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
              338: [0, 0.68333, 0.12028, 0, 0.98499],
              339: [0, 0.43056, 0.07514, 0, 0.71555],
              710: [0, 0.69444, 0.06646, 0, 0.51111],
              711: [0, 0.62847, 0.08295, 0, 0.51111],
              713: [0, 0.56167, 0.10333, 0, 0.51111],
              714: [0, 0.69444, 0.09694, 0, 0.51111],
              715: [0, 0.69444, 0, 0, 0.51111],
              728: [0, 0.69444, 0.10806, 0, 0.51111],
              729: [0, 0.66786, 0.11752, 0, 0.30667],
              730: [0, 0.69444, 0, 0, 0.83129],
              732: [0, 0.66786, 0.11585, 0, 0.51111],
              733: [0, 0.69444, 0.1225, 0, 0.51111],
              915: [0, 0.68333, 0.13305, 0, 0.62722],
              916: [0, 0.68333, 0, 0, 0.81777],
              920: [0, 0.68333, 0.09403, 0, 0.76666],
              923: [0, 0.68333, 0, 0, 0.69222],
              926: [0, 0.68333, 0.15294, 0, 0.66444],
              928: [0, 0.68333, 0.16389, 0, 0.74333],
              931: [0, 0.68333, 0.12028, 0, 0.71555],
              933: [0, 0.68333, 0.11111, 0, 0.76666],
              934: [0, 0.68333, 0.05986, 0, 0.71555],
              936: [0, 0.68333, 0.11111, 0, 0.76666],
              937: [0, 0.68333, 0.10257, 0, 0.71555],
              8211: [0, 0.43056, 0.09208, 0, 0.51111],
              8212: [0, 0.43056, 0.09208, 0, 1.02222],
              8216: [0, 0.69444, 0.12417, 0, 0.30667],
              8217: [0, 0.69444, 0.12417, 0, 0.30667],
              8220: [0, 0.69444, 0.1685, 0, 0.51444],
              8221: [0, 0.69444, 0.06961, 0, 0.51444],
              8463: [0, 0.68889, 0, 0, 0.54028]
            },
            "Main-Regular": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.27778],
              34: [0, 0.69444, 0, 0, 0.5],
              35: [0.19444, 0.69444, 0, 0, 0.83334],
              36: [0.05556, 0.75, 0, 0, 0.5],
              37: [0.05556, 0.75, 0, 0, 0.83334],
              38: [0, 0.69444, 0, 0, 0.77778],
              39: [0, 0.69444, 0, 0, 0.27778],
              40: [0.25, 0.75, 0, 0, 0.38889],
              41: [0.25, 0.75, 0, 0, 0.38889],
              42: [0, 0.75, 0, 0, 0.5],
              43: [0.08333, 0.58333, 0, 0, 0.77778],
              44: [0.19444, 0.10556, 0, 0, 0.27778],
              45: [0, 0.43056, 0, 0, 0.33333],
              46: [0, 0.10556, 0, 0, 0.27778],
              47: [0.25, 0.75, 0, 0, 0.5],
              48: [0, 0.64444, 0, 0, 0.5],
              49: [0, 0.64444, 0, 0, 0.5],
              50: [0, 0.64444, 0, 0, 0.5],
              51: [0, 0.64444, 0, 0, 0.5],
              52: [0, 0.64444, 0, 0, 0.5],
              53: [0, 0.64444, 0, 0, 0.5],
              54: [0, 0.64444, 0, 0, 0.5],
              55: [0, 0.64444, 0, 0, 0.5],
              56: [0, 0.64444, 0, 0, 0.5],
              57: [0, 0.64444, 0, 0, 0.5],
              58: [0, 0.43056, 0, 0, 0.27778],
              59: [0.19444, 0.43056, 0, 0, 0.27778],
              60: [0.0391, 0.5391, 0, 0, 0.77778],
              61: [-0.13313, 0.36687, 0, 0, 0.77778],
              62: [0.0391, 0.5391, 0, 0, 0.77778],
              63: [0, 0.69444, 0, 0, 0.47222],
              64: [0, 0.69444, 0, 0, 0.77778],
              65: [0, 0.68333, 0, 0, 0.75],
              66: [0, 0.68333, 0, 0, 0.70834],
              67: [0, 0.68333, 0, 0, 0.72222],
              68: [0, 0.68333, 0, 0, 0.76389],
              69: [0, 0.68333, 0, 0, 0.68056],
              70: [0, 0.68333, 0, 0, 0.65278],
              71: [0, 0.68333, 0, 0, 0.78472],
              72: [0, 0.68333, 0, 0, 0.75],
              73: [0, 0.68333, 0, 0, 0.36111],
              74: [0, 0.68333, 0, 0, 0.51389],
              75: [0, 0.68333, 0, 0, 0.77778],
              76: [0, 0.68333, 0, 0, 0.625],
              77: [0, 0.68333, 0, 0, 0.91667],
              78: [0, 0.68333, 0, 0, 0.75],
              79: [0, 0.68333, 0, 0, 0.77778],
              80: [0, 0.68333, 0, 0, 0.68056],
              81: [0.19444, 0.68333, 0, 0, 0.77778],
              82: [0, 0.68333, 0, 0, 0.73611],
              83: [0, 0.68333, 0, 0, 0.55556],
              84: [0, 0.68333, 0, 0, 0.72222],
              85: [0, 0.68333, 0, 0, 0.75],
              86: [0, 0.68333, 0.01389, 0, 0.75],
              87: [0, 0.68333, 0.01389, 0, 1.02778],
              88: [0, 0.68333, 0, 0, 0.75],
              89: [0, 0.68333, 0.025, 0, 0.75],
              90: [0, 0.68333, 0, 0, 0.61111],
              91: [0.25, 0.75, 0, 0, 0.27778],
              92: [0.25, 0.75, 0, 0, 0.5],
              93: [0.25, 0.75, 0, 0, 0.27778],
              94: [0, 0.69444, 0, 0, 0.5],
              95: [0.31, 0.12056, 0.02778, 0, 0.5],
              97: [0, 0.43056, 0, 0, 0.5],
              98: [0, 0.69444, 0, 0, 0.55556],
              99: [0, 0.43056, 0, 0, 0.44445],
              100: [0, 0.69444, 0, 0, 0.55556],
              101: [0, 0.43056, 0, 0, 0.44445],
              102: [0, 0.69444, 0.07778, 0, 0.30556],
              103: [0.19444, 0.43056, 0.01389, 0, 0.5],
              104: [0, 0.69444, 0, 0, 0.55556],
              105: [0, 0.66786, 0, 0, 0.27778],
              106: [0.19444, 0.66786, 0, 0, 0.30556],
              107: [0, 0.69444, 0, 0, 0.52778],
              108: [0, 0.69444, 0, 0, 0.27778],
              109: [0, 0.43056, 0, 0, 0.83334],
              110: [0, 0.43056, 0, 0, 0.55556],
              111: [0, 0.43056, 0, 0, 0.5],
              112: [0.19444, 0.43056, 0, 0, 0.55556],
              113: [0.19444, 0.43056, 0, 0, 0.52778],
              114: [0, 0.43056, 0, 0, 0.39167],
              115: [0, 0.43056, 0, 0, 0.39445],
              116: [0, 0.61508, 0, 0, 0.38889],
              117: [0, 0.43056, 0, 0, 0.55556],
              118: [0, 0.43056, 0.01389, 0, 0.52778],
              119: [0, 0.43056, 0.01389, 0, 0.72222],
              120: [0, 0.43056, 0, 0, 0.52778],
              121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
              122: [0, 0.43056, 0, 0, 0.44445],
              123: [0.25, 0.75, 0, 0, 0.5],
              124: [0.25, 0.75, 0, 0, 0.27778],
              125: [0.25, 0.75, 0, 0, 0.5],
              126: [0.35, 0.31786, 0, 0, 0.5],
              160: [0, 0, 0, 0, 0.25],
              163: [0, 0.69444, 0, 0, 0.76909],
              167: [0.19444, 0.69444, 0, 0, 0.44445],
              168: [0, 0.66786, 0, 0, 0.5],
              172: [0, 0.43056, 0, 0, 0.66667],
              176: [0, 0.69444, 0, 0, 0.75],
              177: [0.08333, 0.58333, 0, 0, 0.77778],
              182: [0.19444, 0.69444, 0, 0, 0.61111],
              184: [0.17014, 0, 0, 0, 0.44445],
              198: [0, 0.68333, 0, 0, 0.90278],
              215: [0.08333, 0.58333, 0, 0, 0.77778],
              216: [0.04861, 0.73194, 0, 0, 0.77778],
              223: [0, 0.69444, 0, 0, 0.5],
              230: [0, 0.43056, 0, 0, 0.72222],
              247: [0.08333, 0.58333, 0, 0, 0.77778],
              248: [0.09722, 0.52778, 0, 0, 0.5],
              305: [0, 0.43056, 0, 0, 0.27778],
              338: [0, 0.68333, 0, 0, 1.01389],
              339: [0, 0.43056, 0, 0, 0.77778],
              567: [0.19444, 0.43056, 0, 0, 0.30556],
              710: [0, 0.69444, 0, 0, 0.5],
              711: [0, 0.62847, 0, 0, 0.5],
              713: [0, 0.56778, 0, 0, 0.5],
              714: [0, 0.69444, 0, 0, 0.5],
              715: [0, 0.69444, 0, 0, 0.5],
              728: [0, 0.69444, 0, 0, 0.5],
              729: [0, 0.66786, 0, 0, 0.27778],
              730: [0, 0.69444, 0, 0, 0.75],
              732: [0, 0.66786, 0, 0, 0.5],
              733: [0, 0.69444, 0, 0, 0.5],
              915: [0, 0.68333, 0, 0, 0.625],
              916: [0, 0.68333, 0, 0, 0.83334],
              920: [0, 0.68333, 0, 0, 0.77778],
              923: [0, 0.68333, 0, 0, 0.69445],
              926: [0, 0.68333, 0, 0, 0.66667],
              928: [0, 0.68333, 0, 0, 0.75],
              931: [0, 0.68333, 0, 0, 0.72222],
              933: [0, 0.68333, 0, 0, 0.77778],
              934: [0, 0.68333, 0, 0, 0.72222],
              936: [0, 0.68333, 0, 0, 0.77778],
              937: [0, 0.68333, 0, 0, 0.72222],
              8211: [0, 0.43056, 0.02778, 0, 0.5],
              8212: [0, 0.43056, 0.02778, 0, 1],
              8216: [0, 0.69444, 0, 0, 0.27778],
              8217: [0, 0.69444, 0, 0, 0.27778],
              8220: [0, 0.69444, 0, 0, 0.5],
              8221: [0, 0.69444, 0, 0, 0.5],
              8224: [0.19444, 0.69444, 0, 0, 0.44445],
              8225: [0.19444, 0.69444, 0, 0, 0.44445],
              8230: [0, 0.123, 0, 0, 1.172],
              8242: [0, 0.55556, 0, 0, 0.275],
              8407: [0, 0.71444, 0.15382, 0, 0.5],
              8463: [0, 0.68889, 0, 0, 0.54028],
              8465: [0, 0.69444, 0, 0, 0.72222],
              8467: [0, 0.69444, 0, 0.11111, 0.41667],
              8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
              8476: [0, 0.69444, 0, 0, 0.72222],
              8501: [0, 0.69444, 0, 0, 0.61111],
              8592: [-0.13313, 0.36687, 0, 0, 1],
              8593: [0.19444, 0.69444, 0, 0, 0.5],
              8594: [-0.13313, 0.36687, 0, 0, 1],
              8595: [0.19444, 0.69444, 0, 0, 0.5],
              8596: [-0.13313, 0.36687, 0, 0, 1],
              8597: [0.25, 0.75, 0, 0, 0.5],
              8598: [0.19444, 0.69444, 0, 0, 1],
              8599: [0.19444, 0.69444, 0, 0, 1],
              8600: [0.19444, 0.69444, 0, 0, 1],
              8601: [0.19444, 0.69444, 0, 0, 1],
              8614: [0.011, 0.511, 0, 0, 1],
              8617: [0.011, 0.511, 0, 0, 1.126],
              8618: [0.011, 0.511, 0, 0, 1.126],
              8636: [-0.13313, 0.36687, 0, 0, 1],
              8637: [-0.13313, 0.36687, 0, 0, 1],
              8640: [-0.13313, 0.36687, 0, 0, 1],
              8641: [-0.13313, 0.36687, 0, 0, 1],
              8652: [0.011, 0.671, 0, 0, 1],
              8656: [-0.13313, 0.36687, 0, 0, 1],
              8657: [0.19444, 0.69444, 0, 0, 0.61111],
              8658: [-0.13313, 0.36687, 0, 0, 1],
              8659: [0.19444, 0.69444, 0, 0, 0.61111],
              8660: [-0.13313, 0.36687, 0, 0, 1],
              8661: [0.25, 0.75, 0, 0, 0.61111],
              8704: [0, 0.69444, 0, 0, 0.55556],
              8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
              8707: [0, 0.69444, 0, 0, 0.55556],
              8709: [0.05556, 0.75, 0, 0, 0.5],
              8711: [0, 0.68333, 0, 0, 0.83334],
              8712: [0.0391, 0.5391, 0, 0, 0.66667],
              8715: [0.0391, 0.5391, 0, 0, 0.66667],
              8722: [0.08333, 0.58333, 0, 0, 0.77778],
              8723: [0.08333, 0.58333, 0, 0, 0.77778],
              8725: [0.25, 0.75, 0, 0, 0.5],
              8726: [0.25, 0.75, 0, 0, 0.5],
              8727: [-0.03472, 0.46528, 0, 0, 0.5],
              8728: [-0.05555, 0.44445, 0, 0, 0.5],
              8729: [-0.05555, 0.44445, 0, 0, 0.5],
              8730: [0.2, 0.8, 0, 0, 0.83334],
              8733: [0, 0.43056, 0, 0, 0.77778],
              8734: [0, 0.43056, 0, 0, 1],
              8736: [0, 0.69224, 0, 0, 0.72222],
              8739: [0.25, 0.75, 0, 0, 0.27778],
              8741: [0.25, 0.75, 0, 0, 0.5],
              8743: [0, 0.55556, 0, 0, 0.66667],
              8744: [0, 0.55556, 0, 0, 0.66667],
              8745: [0, 0.55556, 0, 0, 0.66667],
              8746: [0, 0.55556, 0, 0, 0.66667],
              8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
              8764: [-0.13313, 0.36687, 0, 0, 0.77778],
              8768: [0.19444, 0.69444, 0, 0, 0.27778],
              8771: [-0.03625, 0.46375, 0, 0, 0.77778],
              8773: [-0.022, 0.589, 0, 0, 0.778],
              8776: [-0.01688, 0.48312, 0, 0, 0.77778],
              8781: [-0.03625, 0.46375, 0, 0, 0.77778],
              8784: [-0.133, 0.673, 0, 0, 0.778],
              8801: [-0.03625, 0.46375, 0, 0, 0.77778],
              8804: [0.13597, 0.63597, 0, 0, 0.77778],
              8805: [0.13597, 0.63597, 0, 0, 0.77778],
              8810: [0.0391, 0.5391, 0, 0, 1],
              8811: [0.0391, 0.5391, 0, 0, 1],
              8826: [0.0391, 0.5391, 0, 0, 0.77778],
              8827: [0.0391, 0.5391, 0, 0, 0.77778],
              8834: [0.0391, 0.5391, 0, 0, 0.77778],
              8835: [0.0391, 0.5391, 0, 0, 0.77778],
              8838: [0.13597, 0.63597, 0, 0, 0.77778],
              8839: [0.13597, 0.63597, 0, 0, 0.77778],
              8846: [0, 0.55556, 0, 0, 0.66667],
              8849: [0.13597, 0.63597, 0, 0, 0.77778],
              8850: [0.13597, 0.63597, 0, 0, 0.77778],
              8851: [0, 0.55556, 0, 0, 0.66667],
              8852: [0, 0.55556, 0, 0, 0.66667],
              8853: [0.08333, 0.58333, 0, 0, 0.77778],
              8854: [0.08333, 0.58333, 0, 0, 0.77778],
              8855: [0.08333, 0.58333, 0, 0, 0.77778],
              8856: [0.08333, 0.58333, 0, 0, 0.77778],
              8857: [0.08333, 0.58333, 0, 0, 0.77778],
              8866: [0, 0.69444, 0, 0, 0.61111],
              8867: [0, 0.69444, 0, 0, 0.61111],
              8868: [0, 0.69444, 0, 0, 0.77778],
              8869: [0, 0.69444, 0, 0, 0.77778],
              8872: [0.249, 0.75, 0, 0, 0.867],
              8900: [-0.05555, 0.44445, 0, 0, 0.5],
              8901: [-0.05555, 0.44445, 0, 0, 0.27778],
              8902: [-0.03472, 0.46528, 0, 0, 0.5],
              8904: [5e-3, 0.505, 0, 0, 0.9],
              8942: [0.03, 0.903, 0, 0, 0.278],
              8943: [-0.19, 0.313, 0, 0, 1.172],
              8945: [-0.1, 0.823, 0, 0, 1.282],
              8968: [0.25, 0.75, 0, 0, 0.44445],
              8969: [0.25, 0.75, 0, 0, 0.44445],
              8970: [0.25, 0.75, 0, 0, 0.44445],
              8971: [0.25, 0.75, 0, 0, 0.44445],
              8994: [-0.14236, 0.35764, 0, 0, 1],
              8995: [-0.14236, 0.35764, 0, 0, 1],
              9136: [0.244, 0.744, 0, 0, 0.412],
              9137: [0.244, 0.745, 0, 0, 0.412],
              9651: [0.19444, 0.69444, 0, 0, 0.88889],
              9657: [-0.03472, 0.46528, 0, 0, 0.5],
              9661: [0.19444, 0.69444, 0, 0, 0.88889],
              9667: [-0.03472, 0.46528, 0, 0, 0.5],
              9711: [0.19444, 0.69444, 0, 0, 1],
              9824: [0.12963, 0.69444, 0, 0, 0.77778],
              9825: [0.12963, 0.69444, 0, 0, 0.77778],
              9826: [0.12963, 0.69444, 0, 0, 0.77778],
              9827: [0.12963, 0.69444, 0, 0, 0.77778],
              9837: [0, 0.75, 0, 0, 0.38889],
              9838: [0.19444, 0.69444, 0, 0, 0.38889],
              9839: [0.19444, 0.69444, 0, 0, 0.38889],
              10216: [0.25, 0.75, 0, 0, 0.38889],
              10217: [0.25, 0.75, 0, 0, 0.38889],
              10222: [0.244, 0.744, 0, 0, 0.412],
              10223: [0.244, 0.745, 0, 0, 0.412],
              10229: [0.011, 0.511, 0, 0, 1.609],
              10230: [0.011, 0.511, 0, 0, 1.638],
              10231: [0.011, 0.511, 0, 0, 1.859],
              10232: [0.024, 0.525, 0, 0, 1.609],
              10233: [0.024, 0.525, 0, 0, 1.638],
              10234: [0.024, 0.525, 0, 0, 1.858],
              10236: [0.011, 0.511, 0, 0, 1.638],
              10815: [0, 0.68333, 0, 0, 0.75],
              10927: [0.13597, 0.63597, 0, 0, 0.77778],
              10928: [0.13597, 0.63597, 0, 0, 0.77778],
              57376: [0.19444, 0.69444, 0, 0, 0]
            },
            "Math-BoldItalic": {
              32: [0, 0, 0, 0, 0.25],
              48: [0, 0.44444, 0, 0, 0.575],
              49: [0, 0.44444, 0, 0, 0.575],
              50: [0, 0.44444, 0, 0, 0.575],
              51: [0.19444, 0.44444, 0, 0, 0.575],
              52: [0.19444, 0.44444, 0, 0, 0.575],
              53: [0.19444, 0.44444, 0, 0, 0.575],
              54: [0, 0.64444, 0, 0, 0.575],
              55: [0.19444, 0.44444, 0, 0, 0.575],
              56: [0, 0.64444, 0, 0, 0.575],
              57: [0.19444, 0.44444, 0, 0, 0.575],
              65: [0, 0.68611, 0, 0, 0.86944],
              66: [0, 0.68611, 0.04835, 0, 0.8664],
              67: [0, 0.68611, 0.06979, 0, 0.81694],
              68: [0, 0.68611, 0.03194, 0, 0.93812],
              69: [0, 0.68611, 0.05451, 0, 0.81007],
              70: [0, 0.68611, 0.15972, 0, 0.68889],
              71: [0, 0.68611, 0, 0, 0.88673],
              72: [0, 0.68611, 0.08229, 0, 0.98229],
              73: [0, 0.68611, 0.07778, 0, 0.51111],
              74: [0, 0.68611, 0.10069, 0, 0.63125],
              75: [0, 0.68611, 0.06979, 0, 0.97118],
              76: [0, 0.68611, 0, 0, 0.75555],
              77: [0, 0.68611, 0.11424, 0, 1.14201],
              78: [0, 0.68611, 0.11424, 0, 0.95034],
              79: [0, 0.68611, 0.03194, 0, 0.83666],
              80: [0, 0.68611, 0.15972, 0, 0.72309],
              81: [0.19444, 0.68611, 0, 0, 0.86861],
              82: [0, 0.68611, 421e-5, 0, 0.87235],
              83: [0, 0.68611, 0.05382, 0, 0.69271],
              84: [0, 0.68611, 0.15972, 0, 0.63663],
              85: [0, 0.68611, 0.11424, 0, 0.80027],
              86: [0, 0.68611, 0.25555, 0, 0.67778],
              87: [0, 0.68611, 0.15972, 0, 1.09305],
              88: [0, 0.68611, 0.07778, 0, 0.94722],
              89: [0, 0.68611, 0.25555, 0, 0.67458],
              90: [0, 0.68611, 0.06979, 0, 0.77257],
              97: [0, 0.44444, 0, 0, 0.63287],
              98: [0, 0.69444, 0, 0, 0.52083],
              99: [0, 0.44444, 0, 0, 0.51342],
              100: [0, 0.69444, 0, 0, 0.60972],
              101: [0, 0.44444, 0, 0, 0.55361],
              102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
              103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
              104: [0, 0.69444, 0, 0, 0.66759],
              105: [0, 0.69326, 0, 0, 0.4048],
              106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
              107: [0, 0.69444, 0.01852, 0, 0.6037],
              108: [0, 0.69444, 88e-4, 0, 0.34815],
              109: [0, 0.44444, 0, 0, 1.0324],
              110: [0, 0.44444, 0, 0, 0.71296],
              111: [0, 0.44444, 0, 0, 0.58472],
              112: [0.19444, 0.44444, 0, 0, 0.60092],
              113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
              114: [0, 0.44444, 0.03194, 0, 0.5287],
              115: [0, 0.44444, 0, 0, 0.53125],
              116: [0, 0.63492, 0, 0, 0.41528],
              117: [0, 0.44444, 0, 0, 0.68102],
              118: [0, 0.44444, 0.03704, 0, 0.56666],
              119: [0, 0.44444, 0.02778, 0, 0.83148],
              120: [0, 0.44444, 0, 0, 0.65903],
              121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
              122: [0, 0.44444, 0.04213, 0, 0.55509],
              160: [0, 0, 0, 0, 0.25],
              915: [0, 0.68611, 0.15972, 0, 0.65694],
              916: [0, 0.68611, 0, 0, 0.95833],
              920: [0, 0.68611, 0.03194, 0, 0.86722],
              923: [0, 0.68611, 0, 0, 0.80555],
              926: [0, 0.68611, 0.07458, 0, 0.84125],
              928: [0, 0.68611, 0.08229, 0, 0.98229],
              931: [0, 0.68611, 0.05451, 0, 0.88507],
              933: [0, 0.68611, 0.15972, 0, 0.67083],
              934: [0, 0.68611, 0, 0, 0.76666],
              936: [0, 0.68611, 0.11653, 0, 0.71402],
              937: [0, 0.68611, 0.04835, 0, 0.8789],
              945: [0, 0.44444, 0, 0, 0.76064],
              946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
              947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
              948: [0, 0.69444, 0.03819, 0, 0.52222],
              949: [0, 0.44444, 0, 0, 0.52882],
              950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
              951: [0.19444, 0.44444, 0.03704, 0, 0.6],
              952: [0, 0.69444, 0.03194, 0, 0.5618],
              953: [0, 0.44444, 0, 0, 0.41204],
              954: [0, 0.44444, 0, 0, 0.66759],
              955: [0, 0.69444, 0, 0, 0.67083],
              956: [0.19444, 0.44444, 0, 0, 0.70787],
              957: [0, 0.44444, 0.06898, 0, 0.57685],
              958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
              959: [0, 0.44444, 0, 0, 0.58472],
              960: [0, 0.44444, 0.03704, 0, 0.68241],
              961: [0.19444, 0.44444, 0, 0, 0.6118],
              962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
              963: [0, 0.44444, 0.03704, 0, 0.68588],
              964: [0, 0.44444, 0.13472, 0, 0.52083],
              965: [0, 0.44444, 0.03704, 0, 0.63055],
              966: [0.19444, 0.44444, 0, 0, 0.74722],
              967: [0.19444, 0.44444, 0, 0, 0.71805],
              968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
              969: [0, 0.44444, 0.03704, 0, 0.71782],
              977: [0, 0.69444, 0, 0, 0.69155],
              981: [0.19444, 0.69444, 0, 0, 0.7125],
              982: [0, 0.44444, 0.03194, 0, 0.975],
              1009: [0.19444, 0.44444, 0, 0, 0.6118],
              1013: [0, 0.44444, 0, 0, 0.48333],
              57649: [0, 0.44444, 0, 0, 0.39352],
              57911: [0.19444, 0.44444, 0, 0, 0.43889]
            },
            "Math-Italic": {
              32: [0, 0, 0, 0, 0.25],
              48: [0, 0.43056, 0, 0, 0.5],
              49: [0, 0.43056, 0, 0, 0.5],
              50: [0, 0.43056, 0, 0, 0.5],
              51: [0.19444, 0.43056, 0, 0, 0.5],
              52: [0.19444, 0.43056, 0, 0, 0.5],
              53: [0.19444, 0.43056, 0, 0, 0.5],
              54: [0, 0.64444, 0, 0, 0.5],
              55: [0.19444, 0.43056, 0, 0, 0.5],
              56: [0, 0.64444, 0, 0, 0.5],
              57: [0.19444, 0.43056, 0, 0, 0.5],
              65: [0, 0.68333, 0, 0.13889, 0.75],
              66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
              67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
              68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
              69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
              70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
              71: [0, 0.68333, 0, 0.08334, 0.78625],
              72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
              73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
              74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
              75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
              76: [0, 0.68333, 0, 0.02778, 0.68056],
              77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
              78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
              79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
              80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
              81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
              82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
              83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
              84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
              85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
              86: [0, 0.68333, 0.22222, 0, 0.58333],
              87: [0, 0.68333, 0.13889, 0, 0.94445],
              88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
              89: [0, 0.68333, 0.22222, 0, 0.58056],
              90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
              97: [0, 0.43056, 0, 0, 0.52859],
              98: [0, 0.69444, 0, 0, 0.42917],
              99: [0, 0.43056, 0, 0.05556, 0.43276],
              100: [0, 0.69444, 0, 0.16667, 0.52049],
              101: [0, 0.43056, 0, 0.05556, 0.46563],
              102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
              103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
              104: [0, 0.69444, 0, 0, 0.57616],
              105: [0, 0.65952, 0, 0, 0.34451],
              106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
              107: [0, 0.69444, 0.03148, 0, 0.5206],
              108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
              109: [0, 0.43056, 0, 0, 0.87801],
              110: [0, 0.43056, 0, 0, 0.60023],
              111: [0, 0.43056, 0, 0.05556, 0.48472],
              112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
              113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
              114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
              115: [0, 0.43056, 0, 0.05556, 0.46875],
              116: [0, 0.61508, 0, 0.08334, 0.36111],
              117: [0, 0.43056, 0, 0.02778, 0.57246],
              118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
              119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
              120: [0, 0.43056, 0, 0.02778, 0.57153],
              121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
              122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
              160: [0, 0, 0, 0, 0.25],
              915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
              916: [0, 0.68333, 0, 0.16667, 0.83334],
              920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
              923: [0, 0.68333, 0, 0.16667, 0.69445],
              926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
              928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
              931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
              933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
              934: [0, 0.68333, 0, 0.08334, 0.66667],
              936: [0, 0.68333, 0.11, 0.05556, 0.61222],
              937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
              945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
              946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
              947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
              948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
              949: [0, 0.43056, 0, 0.08334, 0.46632],
              950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
              951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
              952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
              953: [0, 0.43056, 0, 0.05556, 0.35394],
              954: [0, 0.43056, 0, 0, 0.57616],
              955: [0, 0.69444, 0, 0, 0.58334],
              956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
              957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
              958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
              959: [0, 0.43056, 0, 0.05556, 0.48472],
              960: [0, 0.43056, 0.03588, 0, 0.57003],
              961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
              962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
              963: [0, 0.43056, 0.03588, 0, 0.57141],
              964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
              965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
              966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
              967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
              968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
              969: [0, 0.43056, 0.03588, 0, 0.62245],
              977: [0, 0.69444, 0, 0.08334, 0.59144],
              981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
              982: [0, 0.43056, 0.02778, 0, 0.82813],
              1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
              1013: [0, 0.43056, 0, 0.05556, 0.4059],
              57649: [0, 0.43056, 0, 0.02778, 0.32246],
              57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
            },
            "SansSerif-Bold": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.36667],
              34: [0, 0.69444, 0, 0, 0.55834],
              35: [0.19444, 0.69444, 0, 0, 0.91667],
              36: [0.05556, 0.75, 0, 0, 0.55],
              37: [0.05556, 0.75, 0, 0, 1.02912],
              38: [0, 0.69444, 0, 0, 0.83056],
              39: [0, 0.69444, 0, 0, 0.30556],
              40: [0.25, 0.75, 0, 0, 0.42778],
              41: [0.25, 0.75, 0, 0, 0.42778],
              42: [0, 0.75, 0, 0, 0.55],
              43: [0.11667, 0.61667, 0, 0, 0.85556],
              44: [0.10556, 0.13056, 0, 0, 0.30556],
              45: [0, 0.45833, 0, 0, 0.36667],
              46: [0, 0.13056, 0, 0, 0.30556],
              47: [0.25, 0.75, 0, 0, 0.55],
              48: [0, 0.69444, 0, 0, 0.55],
              49: [0, 0.69444, 0, 0, 0.55],
              50: [0, 0.69444, 0, 0, 0.55],
              51: [0, 0.69444, 0, 0, 0.55],
              52: [0, 0.69444, 0, 0, 0.55],
              53: [0, 0.69444, 0, 0, 0.55],
              54: [0, 0.69444, 0, 0, 0.55],
              55: [0, 0.69444, 0, 0, 0.55],
              56: [0, 0.69444, 0, 0, 0.55],
              57: [0, 0.69444, 0, 0, 0.55],
              58: [0, 0.45833, 0, 0, 0.30556],
              59: [0.10556, 0.45833, 0, 0, 0.30556],
              61: [-0.09375, 0.40625, 0, 0, 0.85556],
              63: [0, 0.69444, 0, 0, 0.51945],
              64: [0, 0.69444, 0, 0, 0.73334],
              65: [0, 0.69444, 0, 0, 0.73334],
              66: [0, 0.69444, 0, 0, 0.73334],
              67: [0, 0.69444, 0, 0, 0.70278],
              68: [0, 0.69444, 0, 0, 0.79445],
              69: [0, 0.69444, 0, 0, 0.64167],
              70: [0, 0.69444, 0, 0, 0.61111],
              71: [0, 0.69444, 0, 0, 0.73334],
              72: [0, 0.69444, 0, 0, 0.79445],
              73: [0, 0.69444, 0, 0, 0.33056],
              74: [0, 0.69444, 0, 0, 0.51945],
              75: [0, 0.69444, 0, 0, 0.76389],
              76: [0, 0.69444, 0, 0, 0.58056],
              77: [0, 0.69444, 0, 0, 0.97778],
              78: [0, 0.69444, 0, 0, 0.79445],
              79: [0, 0.69444, 0, 0, 0.79445],
              80: [0, 0.69444, 0, 0, 0.70278],
              81: [0.10556, 0.69444, 0, 0, 0.79445],
              82: [0, 0.69444, 0, 0, 0.70278],
              83: [0, 0.69444, 0, 0, 0.61111],
              84: [0, 0.69444, 0, 0, 0.73334],
              85: [0, 0.69444, 0, 0, 0.76389],
              86: [0, 0.69444, 0.01528, 0, 0.73334],
              87: [0, 0.69444, 0.01528, 0, 1.03889],
              88: [0, 0.69444, 0, 0, 0.73334],
              89: [0, 0.69444, 0.0275, 0, 0.73334],
              90: [0, 0.69444, 0, 0, 0.67223],
              91: [0.25, 0.75, 0, 0, 0.34306],
              93: [0.25, 0.75, 0, 0, 0.34306],
              94: [0, 0.69444, 0, 0, 0.55],
              95: [0.35, 0.10833, 0.03056, 0, 0.55],
              97: [0, 0.45833, 0, 0, 0.525],
              98: [0, 0.69444, 0, 0, 0.56111],
              99: [0, 0.45833, 0, 0, 0.48889],
              100: [0, 0.69444, 0, 0, 0.56111],
              101: [0, 0.45833, 0, 0, 0.51111],
              102: [0, 0.69444, 0.07639, 0, 0.33611],
              103: [0.19444, 0.45833, 0.01528, 0, 0.55],
              104: [0, 0.69444, 0, 0, 0.56111],
              105: [0, 0.69444, 0, 0, 0.25556],
              106: [0.19444, 0.69444, 0, 0, 0.28611],
              107: [0, 0.69444, 0, 0, 0.53056],
              108: [0, 0.69444, 0, 0, 0.25556],
              109: [0, 0.45833, 0, 0, 0.86667],
              110: [0, 0.45833, 0, 0, 0.56111],
              111: [0, 0.45833, 0, 0, 0.55],
              112: [0.19444, 0.45833, 0, 0, 0.56111],
              113: [0.19444, 0.45833, 0, 0, 0.56111],
              114: [0, 0.45833, 0.01528, 0, 0.37222],
              115: [0, 0.45833, 0, 0, 0.42167],
              116: [0, 0.58929, 0, 0, 0.40417],
              117: [0, 0.45833, 0, 0, 0.56111],
              118: [0, 0.45833, 0.01528, 0, 0.5],
              119: [0, 0.45833, 0.01528, 0, 0.74445],
              120: [0, 0.45833, 0, 0, 0.5],
              121: [0.19444, 0.45833, 0.01528, 0, 0.5],
              122: [0, 0.45833, 0, 0, 0.47639],
              126: [0.35, 0.34444, 0, 0, 0.55],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.69444, 0, 0, 0.55],
              176: [0, 0.69444, 0, 0, 0.73334],
              180: [0, 0.69444, 0, 0, 0.55],
              184: [0.17014, 0, 0, 0, 0.48889],
              305: [0, 0.45833, 0, 0, 0.25556],
              567: [0.19444, 0.45833, 0, 0, 0.28611],
              710: [0, 0.69444, 0, 0, 0.55],
              711: [0, 0.63542, 0, 0, 0.55],
              713: [0, 0.63778, 0, 0, 0.55],
              728: [0, 0.69444, 0, 0, 0.55],
              729: [0, 0.69444, 0, 0, 0.30556],
              730: [0, 0.69444, 0, 0, 0.73334],
              732: [0, 0.69444, 0, 0, 0.55],
              733: [0, 0.69444, 0, 0, 0.55],
              915: [0, 0.69444, 0, 0, 0.58056],
              916: [0, 0.69444, 0, 0, 0.91667],
              920: [0, 0.69444, 0, 0, 0.85556],
              923: [0, 0.69444, 0, 0, 0.67223],
              926: [0, 0.69444, 0, 0, 0.73334],
              928: [0, 0.69444, 0, 0, 0.79445],
              931: [0, 0.69444, 0, 0, 0.79445],
              933: [0, 0.69444, 0, 0, 0.85556],
              934: [0, 0.69444, 0, 0, 0.79445],
              936: [0, 0.69444, 0, 0, 0.85556],
              937: [0, 0.69444, 0, 0, 0.79445],
              8211: [0, 0.45833, 0.03056, 0, 0.55],
              8212: [0, 0.45833, 0.03056, 0, 1.10001],
              8216: [0, 0.69444, 0, 0, 0.30556],
              8217: [0, 0.69444, 0, 0, 0.30556],
              8220: [0, 0.69444, 0, 0, 0.55834],
              8221: [0, 0.69444, 0, 0, 0.55834]
            },
            "SansSerif-Italic": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0.05733, 0, 0.31945],
              34: [0, 0.69444, 316e-5, 0, 0.5],
              35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
              36: [0.05556, 0.75, 0.11156, 0, 0.5],
              37: [0.05556, 0.75, 0.03126, 0, 0.83334],
              38: [0, 0.69444, 0.03058, 0, 0.75834],
              39: [0, 0.69444, 0.07816, 0, 0.27778],
              40: [0.25, 0.75, 0.13164, 0, 0.38889],
              41: [0.25, 0.75, 0.02536, 0, 0.38889],
              42: [0, 0.75, 0.11775, 0, 0.5],
              43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
              44: [0.125, 0.08333, 0, 0, 0.27778],
              45: [0, 0.44444, 0.01946, 0, 0.33333],
              46: [0, 0.08333, 0, 0, 0.27778],
              47: [0.25, 0.75, 0.13164, 0, 0.5],
              48: [0, 0.65556, 0.11156, 0, 0.5],
              49: [0, 0.65556, 0.11156, 0, 0.5],
              50: [0, 0.65556, 0.11156, 0, 0.5],
              51: [0, 0.65556, 0.11156, 0, 0.5],
              52: [0, 0.65556, 0.11156, 0, 0.5],
              53: [0, 0.65556, 0.11156, 0, 0.5],
              54: [0, 0.65556, 0.11156, 0, 0.5],
              55: [0, 0.65556, 0.11156, 0, 0.5],
              56: [0, 0.65556, 0.11156, 0, 0.5],
              57: [0, 0.65556, 0.11156, 0, 0.5],
              58: [0, 0.44444, 0.02502, 0, 0.27778],
              59: [0.125, 0.44444, 0.02502, 0, 0.27778],
              61: [-0.13, 0.37, 0.05087, 0, 0.77778],
              63: [0, 0.69444, 0.11809, 0, 0.47222],
              64: [0, 0.69444, 0.07555, 0, 0.66667],
              65: [0, 0.69444, 0, 0, 0.66667],
              66: [0, 0.69444, 0.08293, 0, 0.66667],
              67: [0, 0.69444, 0.11983, 0, 0.63889],
              68: [0, 0.69444, 0.07555, 0, 0.72223],
              69: [0, 0.69444, 0.11983, 0, 0.59722],
              70: [0, 0.69444, 0.13372, 0, 0.56945],
              71: [0, 0.69444, 0.11983, 0, 0.66667],
              72: [0, 0.69444, 0.08094, 0, 0.70834],
              73: [0, 0.69444, 0.13372, 0, 0.27778],
              74: [0, 0.69444, 0.08094, 0, 0.47222],
              75: [0, 0.69444, 0.11983, 0, 0.69445],
              76: [0, 0.69444, 0, 0, 0.54167],
              77: [0, 0.69444, 0.08094, 0, 0.875],
              78: [0, 0.69444, 0.08094, 0, 0.70834],
              79: [0, 0.69444, 0.07555, 0, 0.73611],
              80: [0, 0.69444, 0.08293, 0, 0.63889],
              81: [0.125, 0.69444, 0.07555, 0, 0.73611],
              82: [0, 0.69444, 0.08293, 0, 0.64584],
              83: [0, 0.69444, 0.09205, 0, 0.55556],
              84: [0, 0.69444, 0.13372, 0, 0.68056],
              85: [0, 0.69444, 0.08094, 0, 0.6875],
              86: [0, 0.69444, 0.1615, 0, 0.66667],
              87: [0, 0.69444, 0.1615, 0, 0.94445],
              88: [0, 0.69444, 0.13372, 0, 0.66667],
              89: [0, 0.69444, 0.17261, 0, 0.66667],
              90: [0, 0.69444, 0.11983, 0, 0.61111],
              91: [0.25, 0.75, 0.15942, 0, 0.28889],
              93: [0.25, 0.75, 0.08719, 0, 0.28889],
              94: [0, 0.69444, 0.0799, 0, 0.5],
              95: [0.35, 0.09444, 0.08616, 0, 0.5],
              97: [0, 0.44444, 981e-5, 0, 0.48056],
              98: [0, 0.69444, 0.03057, 0, 0.51667],
              99: [0, 0.44444, 0.08336, 0, 0.44445],
              100: [0, 0.69444, 0.09483, 0, 0.51667],
              101: [0, 0.44444, 0.06778, 0, 0.44445],
              102: [0, 0.69444, 0.21705, 0, 0.30556],
              103: [0.19444, 0.44444, 0.10836, 0, 0.5],
              104: [0, 0.69444, 0.01778, 0, 0.51667],
              105: [0, 0.67937, 0.09718, 0, 0.23889],
              106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
              107: [0, 0.69444, 0.08336, 0, 0.48889],
              108: [0, 0.69444, 0.09483, 0, 0.23889],
              109: [0, 0.44444, 0.01778, 0, 0.79445],
              110: [0, 0.44444, 0.01778, 0, 0.51667],
              111: [0, 0.44444, 0.06613, 0, 0.5],
              112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
              113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
              114: [0, 0.44444, 0.10836, 0, 0.34167],
              115: [0, 0.44444, 0.0778, 0, 0.38333],
              116: [0, 0.57143, 0.07225, 0, 0.36111],
              117: [0, 0.44444, 0.04169, 0, 0.51667],
              118: [0, 0.44444, 0.10836, 0, 0.46111],
              119: [0, 0.44444, 0.10836, 0, 0.68334],
              120: [0, 0.44444, 0.09169, 0, 0.46111],
              121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
              122: [0, 0.44444, 0.08752, 0, 0.43472],
              126: [0.35, 0.32659, 0.08826, 0, 0.5],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.67937, 0.06385, 0, 0.5],
              176: [0, 0.69444, 0, 0, 0.73752],
              184: [0.17014, 0, 0, 0, 0.44445],
              305: [0, 0.44444, 0.04169, 0, 0.23889],
              567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
              710: [0, 0.69444, 0.0799, 0, 0.5],
              711: [0, 0.63194, 0.08432, 0, 0.5],
              713: [0, 0.60889, 0.08776, 0, 0.5],
              714: [0, 0.69444, 0.09205, 0, 0.5],
              715: [0, 0.69444, 0, 0, 0.5],
              728: [0, 0.69444, 0.09483, 0, 0.5],
              729: [0, 0.67937, 0.07774, 0, 0.27778],
              730: [0, 0.69444, 0, 0, 0.73752],
              732: [0, 0.67659, 0.08826, 0, 0.5],
              733: [0, 0.69444, 0.09205, 0, 0.5],
              915: [0, 0.69444, 0.13372, 0, 0.54167],
              916: [0, 0.69444, 0, 0, 0.83334],
              920: [0, 0.69444, 0.07555, 0, 0.77778],
              923: [0, 0.69444, 0, 0, 0.61111],
              926: [0, 0.69444, 0.12816, 0, 0.66667],
              928: [0, 0.69444, 0.08094, 0, 0.70834],
              931: [0, 0.69444, 0.11983, 0, 0.72222],
              933: [0, 0.69444, 0.09031, 0, 0.77778],
              934: [0, 0.69444, 0.04603, 0, 0.72222],
              936: [0, 0.69444, 0.09031, 0, 0.77778],
              937: [0, 0.69444, 0.08293, 0, 0.72222],
              8211: [0, 0.44444, 0.08616, 0, 0.5],
              8212: [0, 0.44444, 0.08616, 0, 1],
              8216: [0, 0.69444, 0.07816, 0, 0.27778],
              8217: [0, 0.69444, 0.07816, 0, 0.27778],
              8220: [0, 0.69444, 0.14205, 0, 0.5],
              8221: [0, 0.69444, 316e-5, 0, 0.5]
            },
            "SansSerif-Regular": {
              32: [0, 0, 0, 0, 0.25],
              33: [0, 0.69444, 0, 0, 0.31945],
              34: [0, 0.69444, 0, 0, 0.5],
              35: [0.19444, 0.69444, 0, 0, 0.83334],
              36: [0.05556, 0.75, 0, 0, 0.5],
              37: [0.05556, 0.75, 0, 0, 0.83334],
              38: [0, 0.69444, 0, 0, 0.75834],
              39: [0, 0.69444, 0, 0, 0.27778],
              40: [0.25, 0.75, 0, 0, 0.38889],
              41: [0.25, 0.75, 0, 0, 0.38889],
              42: [0, 0.75, 0, 0, 0.5],
              43: [0.08333, 0.58333, 0, 0, 0.77778],
              44: [0.125, 0.08333, 0, 0, 0.27778],
              45: [0, 0.44444, 0, 0, 0.33333],
              46: [0, 0.08333, 0, 0, 0.27778],
              47: [0.25, 0.75, 0, 0, 0.5],
              48: [0, 0.65556, 0, 0, 0.5],
              49: [0, 0.65556, 0, 0, 0.5],
              50: [0, 0.65556, 0, 0, 0.5],
              51: [0, 0.65556, 0, 0, 0.5],
              52: [0, 0.65556, 0, 0, 0.5],
              53: [0, 0.65556, 0, 0, 0.5],
              54: [0, 0.65556, 0, 0, 0.5],
              55: [0, 0.65556, 0, 0, 0.5],
              56: [0, 0.65556, 0, 0, 0.5],
              57: [0, 0.65556, 0, 0, 0.5],
              58: [0, 0.44444, 0, 0, 0.27778],
              59: [0.125, 0.44444, 0, 0, 0.27778],
              61: [-0.13, 0.37, 0, 0, 0.77778],
              63: [0, 0.69444, 0, 0, 0.47222],
              64: [0, 0.69444, 0, 0, 0.66667],
              65: [0, 0.69444, 0, 0, 0.66667],
              66: [0, 0.69444, 0, 0, 0.66667],
              67: [0, 0.69444, 0, 0, 0.63889],
              68: [0, 0.69444, 0, 0, 0.72223],
              69: [0, 0.69444, 0, 0, 0.59722],
              70: [0, 0.69444, 0, 0, 0.56945],
              71: [0, 0.69444, 0, 0, 0.66667],
              72: [0, 0.69444, 0, 0, 0.70834],
              73: [0, 0.69444, 0, 0, 0.27778],
              74: [0, 0.69444, 0, 0, 0.47222],
              75: [0, 0.69444, 0, 0, 0.69445],
              76: [0, 0.69444, 0, 0, 0.54167],
              77: [0, 0.69444, 0, 0, 0.875],
              78: [0, 0.69444, 0, 0, 0.70834],
              79: [0, 0.69444, 0, 0, 0.73611],
              80: [0, 0.69444, 0, 0, 0.63889],
              81: [0.125, 0.69444, 0, 0, 0.73611],
              82: [0, 0.69444, 0, 0, 0.64584],
              83: [0, 0.69444, 0, 0, 0.55556],
              84: [0, 0.69444, 0, 0, 0.68056],
              85: [0, 0.69444, 0, 0, 0.6875],
              86: [0, 0.69444, 0.01389, 0, 0.66667],
              87: [0, 0.69444, 0.01389, 0, 0.94445],
              88: [0, 0.69444, 0, 0, 0.66667],
              89: [0, 0.69444, 0.025, 0, 0.66667],
              90: [0, 0.69444, 0, 0, 0.61111],
              91: [0.25, 0.75, 0, 0, 0.28889],
              93: [0.25, 0.75, 0, 0, 0.28889],
              94: [0, 0.69444, 0, 0, 0.5],
              95: [0.35, 0.09444, 0.02778, 0, 0.5],
              97: [0, 0.44444, 0, 0, 0.48056],
              98: [0, 0.69444, 0, 0, 0.51667],
              99: [0, 0.44444, 0, 0, 0.44445],
              100: [0, 0.69444, 0, 0, 0.51667],
              101: [0, 0.44444, 0, 0, 0.44445],
              102: [0, 0.69444, 0.06944, 0, 0.30556],
              103: [0.19444, 0.44444, 0.01389, 0, 0.5],
              104: [0, 0.69444, 0, 0, 0.51667],
              105: [0, 0.67937, 0, 0, 0.23889],
              106: [0.19444, 0.67937, 0, 0, 0.26667],
              107: [0, 0.69444, 0, 0, 0.48889],
              108: [0, 0.69444, 0, 0, 0.23889],
              109: [0, 0.44444, 0, 0, 0.79445],
              110: [0, 0.44444, 0, 0, 0.51667],
              111: [0, 0.44444, 0, 0, 0.5],
              112: [0.19444, 0.44444, 0, 0, 0.51667],
              113: [0.19444, 0.44444, 0, 0, 0.51667],
              114: [0, 0.44444, 0.01389, 0, 0.34167],
              115: [0, 0.44444, 0, 0, 0.38333],
              116: [0, 0.57143, 0, 0, 0.36111],
              117: [0, 0.44444, 0, 0, 0.51667],
              118: [0, 0.44444, 0.01389, 0, 0.46111],
              119: [0, 0.44444, 0.01389, 0, 0.68334],
              120: [0, 0.44444, 0, 0, 0.46111],
              121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
              122: [0, 0.44444, 0, 0, 0.43472],
              126: [0.35, 0.32659, 0, 0, 0.5],
              160: [0, 0, 0, 0, 0.25],
              168: [0, 0.67937, 0, 0, 0.5],
              176: [0, 0.69444, 0, 0, 0.66667],
              184: [0.17014, 0, 0, 0, 0.44445],
              305: [0, 0.44444, 0, 0, 0.23889],
              567: [0.19444, 0.44444, 0, 0, 0.26667],
              710: [0, 0.69444, 0, 0, 0.5],
              711: [0, 0.63194, 0, 0, 0.5],
              713: [0, 0.60889, 0, 0, 0.5],
              714: [0, 0.69444, 0, 0, 0.5],
              715: [0, 0.69444, 0, 0, 0.5],
              728: [0, 0.69444, 0, 0, 0.5],
              729: [0, 0.67937, 0, 0, 0.27778],
              730: [0, 0.69444, 0, 0, 0.66667],
              732: [0, 0.67659, 0, 0, 0.5],
              733: [0, 0.69444, 0, 0, 0.5],
              915: [0, 0.69444, 0, 0, 0.54167],
              916: [0, 0.69444, 0, 0, 0.83334],
              920: [0, 0.69444, 0, 0, 0.77778],
              923: [0, 0.69444, 0, 0, 0.61111],
              926: [0, 0.69444, 0, 0, 0.66667],
              928: [0, 0.69444, 0, 0, 0.70834],
              931: [0, 0.69444, 0, 0, 0.72222],
              933: [0, 0.69444, 0, 0, 0.77778],
              934: [0, 0.69444, 0, 0, 0.72222],
              936: [0, 0.69444, 0, 0, 0.77778],
              937: [0, 0.69444, 0, 0, 0.72222],
              8211: [0, 0.44444, 0.02778, 0, 0.5],
              8212: [0, 0.44444, 0.02778, 0, 1],
              8216: [0, 0.69444, 0, 0, 0.27778],
              8217: [0, 0.69444, 0, 0, 0.27778],
              8220: [0, 0.69444, 0, 0, 0.5],
              8221: [0, 0.69444, 0, 0, 0.5]
            },
            "Script-Regular": {
              32: [0, 0, 0, 0, 0.25],
              65: [0, 0.7, 0.22925, 0, 0.80253],
              66: [0, 0.7, 0.04087, 0, 0.90757],
              67: [0, 0.7, 0.1689, 0, 0.66619],
              68: [0, 0.7, 0.09371, 0, 0.77443],
              69: [0, 0.7, 0.18583, 0, 0.56162],
              70: [0, 0.7, 0.13634, 0, 0.89544],
              71: [0, 0.7, 0.17322, 0, 0.60961],
              72: [0, 0.7, 0.29694, 0, 0.96919],
              73: [0, 0.7, 0.19189, 0, 0.80907],
              74: [0.27778, 0.7, 0.19189, 0, 1.05159],
              75: [0, 0.7, 0.31259, 0, 0.91364],
              76: [0, 0.7, 0.19189, 0, 0.87373],
              77: [0, 0.7, 0.15981, 0, 1.08031],
              78: [0, 0.7, 0.3525, 0, 0.9015],
              79: [0, 0.7, 0.08078, 0, 0.73787],
              80: [0, 0.7, 0.08078, 0, 1.01262],
              81: [0, 0.7, 0.03305, 0, 0.88282],
              82: [0, 0.7, 0.06259, 0, 0.85],
              83: [0, 0.7, 0.19189, 0, 0.86767],
              84: [0, 0.7, 0.29087, 0, 0.74697],
              85: [0, 0.7, 0.25815, 0, 0.79996],
              86: [0, 0.7, 0.27523, 0, 0.62204],
              87: [0, 0.7, 0.27523, 0, 0.80532],
              88: [0, 0.7, 0.26006, 0, 0.94445],
              89: [0, 0.7, 0.2939, 0, 0.70961],
              90: [0, 0.7, 0.24037, 0, 0.8212],
              160: [0, 0, 0, 0, 0.25]
            },
            "Size1-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [0.35001, 0.85, 0, 0, 0.45834],
              41: [0.35001, 0.85, 0, 0, 0.45834],
              47: [0.35001, 0.85, 0, 0, 0.57778],
              91: [0.35001, 0.85, 0, 0, 0.41667],
              92: [0.35001, 0.85, 0, 0, 0.57778],
              93: [0.35001, 0.85, 0, 0, 0.41667],
              123: [0.35001, 0.85, 0, 0, 0.58334],
              125: [0.35001, 0.85, 0, 0, 0.58334],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.72222, 0, 0, 0.55556],
              732: [0, 0.72222, 0, 0, 0.55556],
              770: [0, 0.72222, 0, 0, 0.55556],
              771: [0, 0.72222, 0, 0, 0.55556],
              8214: [-99e-5, 0.601, 0, 0, 0.77778],
              8593: [1e-5, 0.6, 0, 0, 0.66667],
              8595: [1e-5, 0.6, 0, 0, 0.66667],
              8657: [1e-5, 0.6, 0, 0, 0.77778],
              8659: [1e-5, 0.6, 0, 0, 0.77778],
              8719: [0.25001, 0.75, 0, 0, 0.94445],
              8720: [0.25001, 0.75, 0, 0, 0.94445],
              8721: [0.25001, 0.75, 0, 0, 1.05556],
              8730: [0.35001, 0.85, 0, 0, 1],
              8739: [-599e-5, 0.606, 0, 0, 0.33333],
              8741: [-599e-5, 0.606, 0, 0, 0.55556],
              8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
              8748: [0.306, 0.805, 0.19445, 0, 0.47222],
              8749: [0.306, 0.805, 0.19445, 0, 0.47222],
              8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
              8896: [0.25001, 0.75, 0, 0, 0.83334],
              8897: [0.25001, 0.75, 0, 0, 0.83334],
              8898: [0.25001, 0.75, 0, 0, 0.83334],
              8899: [0.25001, 0.75, 0, 0, 0.83334],
              8968: [0.35001, 0.85, 0, 0, 0.47222],
              8969: [0.35001, 0.85, 0, 0, 0.47222],
              8970: [0.35001, 0.85, 0, 0, 0.47222],
              8971: [0.35001, 0.85, 0, 0, 0.47222],
              9168: [-99e-5, 0.601, 0, 0, 0.66667],
              10216: [0.35001, 0.85, 0, 0, 0.47222],
              10217: [0.35001, 0.85, 0, 0, 0.47222],
              10752: [0.25001, 0.75, 0, 0, 1.11111],
              10753: [0.25001, 0.75, 0, 0, 1.11111],
              10754: [0.25001, 0.75, 0, 0, 1.11111],
              10756: [0.25001, 0.75, 0, 0, 0.83334],
              10758: [0.25001, 0.75, 0, 0, 0.83334]
            },
            "Size2-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [0.65002, 1.15, 0, 0, 0.59722],
              41: [0.65002, 1.15, 0, 0, 0.59722],
              47: [0.65002, 1.15, 0, 0, 0.81111],
              91: [0.65002, 1.15, 0, 0, 0.47222],
              92: [0.65002, 1.15, 0, 0, 0.81111],
              93: [0.65002, 1.15, 0, 0, 0.47222],
              123: [0.65002, 1.15, 0, 0, 0.66667],
              125: [0.65002, 1.15, 0, 0, 0.66667],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.75, 0, 0, 1],
              732: [0, 0.75, 0, 0, 1],
              770: [0, 0.75, 0, 0, 1],
              771: [0, 0.75, 0, 0, 1],
              8719: [0.55001, 1.05, 0, 0, 1.27778],
              8720: [0.55001, 1.05, 0, 0, 1.27778],
              8721: [0.55001, 1.05, 0, 0, 1.44445],
              8730: [0.65002, 1.15, 0, 0, 1],
              8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
              8748: [0.862, 1.36, 0.44445, 0, 0.55556],
              8749: [0.862, 1.36, 0.44445, 0, 0.55556],
              8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
              8896: [0.55001, 1.05, 0, 0, 1.11111],
              8897: [0.55001, 1.05, 0, 0, 1.11111],
              8898: [0.55001, 1.05, 0, 0, 1.11111],
              8899: [0.55001, 1.05, 0, 0, 1.11111],
              8968: [0.65002, 1.15, 0, 0, 0.52778],
              8969: [0.65002, 1.15, 0, 0, 0.52778],
              8970: [0.65002, 1.15, 0, 0, 0.52778],
              8971: [0.65002, 1.15, 0, 0, 0.52778],
              10216: [0.65002, 1.15, 0, 0, 0.61111],
              10217: [0.65002, 1.15, 0, 0, 0.61111],
              10752: [0.55001, 1.05, 0, 0, 1.51112],
              10753: [0.55001, 1.05, 0, 0, 1.51112],
              10754: [0.55001, 1.05, 0, 0, 1.51112],
              10756: [0.55001, 1.05, 0, 0, 1.11111],
              10758: [0.55001, 1.05, 0, 0, 1.11111]
            },
            "Size3-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [0.95003, 1.45, 0, 0, 0.73611],
              41: [0.95003, 1.45, 0, 0, 0.73611],
              47: [0.95003, 1.45, 0, 0, 1.04445],
              91: [0.95003, 1.45, 0, 0, 0.52778],
              92: [0.95003, 1.45, 0, 0, 1.04445],
              93: [0.95003, 1.45, 0, 0, 0.52778],
              123: [0.95003, 1.45, 0, 0, 0.75],
              125: [0.95003, 1.45, 0, 0, 0.75],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.75, 0, 0, 1.44445],
              732: [0, 0.75, 0, 0, 1.44445],
              770: [0, 0.75, 0, 0, 1.44445],
              771: [0, 0.75, 0, 0, 1.44445],
              8730: [0.95003, 1.45, 0, 0, 1],
              8968: [0.95003, 1.45, 0, 0, 0.58334],
              8969: [0.95003, 1.45, 0, 0, 0.58334],
              8970: [0.95003, 1.45, 0, 0, 0.58334],
              8971: [0.95003, 1.45, 0, 0, 0.58334],
              10216: [0.95003, 1.45, 0, 0, 0.75],
              10217: [0.95003, 1.45, 0, 0, 0.75]
            },
            "Size4-Regular": {
              32: [0, 0, 0, 0, 0.25],
              40: [1.25003, 1.75, 0, 0, 0.79167],
              41: [1.25003, 1.75, 0, 0, 0.79167],
              47: [1.25003, 1.75, 0, 0, 1.27778],
              91: [1.25003, 1.75, 0, 0, 0.58334],
              92: [1.25003, 1.75, 0, 0, 1.27778],
              93: [1.25003, 1.75, 0, 0, 0.58334],
              123: [1.25003, 1.75, 0, 0, 0.80556],
              125: [1.25003, 1.75, 0, 0, 0.80556],
              160: [0, 0, 0, 0, 0.25],
              710: [0, 0.825, 0, 0, 1.8889],
              732: [0, 0.825, 0, 0, 1.8889],
              770: [0, 0.825, 0, 0, 1.8889],
              771: [0, 0.825, 0, 0, 1.8889],
              8730: [1.25003, 1.75, 0, 0, 1],
              8968: [1.25003, 1.75, 0, 0, 0.63889],
              8969: [1.25003, 1.75, 0, 0, 0.63889],
              8970: [1.25003, 1.75, 0, 0, 0.63889],
              8971: [1.25003, 1.75, 0, 0, 0.63889],
              9115: [0.64502, 1.155, 0, 0, 0.875],
              9116: [1e-5, 0.6, 0, 0, 0.875],
              9117: [0.64502, 1.155, 0, 0, 0.875],
              9118: [0.64502, 1.155, 0, 0, 0.875],
              9119: [1e-5, 0.6, 0, 0, 0.875],
              9120: [0.64502, 1.155, 0, 0, 0.875],
              9121: [0.64502, 1.155, 0, 0, 0.66667],
              9122: [-99e-5, 0.601, 0, 0, 0.66667],
              9123: [0.64502, 1.155, 0, 0, 0.66667],
              9124: [0.64502, 1.155, 0, 0, 0.66667],
              9125: [-99e-5, 0.601, 0, 0, 0.66667],
              9126: [0.64502, 1.155, 0, 0, 0.66667],
              9127: [1e-5, 0.9, 0, 0, 0.88889],
              9128: [0.65002, 1.15, 0, 0, 0.88889],
              9129: [0.90001, 0, 0, 0, 0.88889],
              9130: [0, 0.3, 0, 0, 0.88889],
              9131: [1e-5, 0.9, 0, 0, 0.88889],
              9132: [0.65002, 1.15, 0, 0, 0.88889],
              9133: [0.90001, 0, 0, 0, 0.88889],
              9143: [0.88502, 0.915, 0, 0, 1.05556],
              10216: [1.25003, 1.75, 0, 0, 0.80556],
              10217: [1.25003, 1.75, 0, 0, 0.80556],
              57344: [-499e-5, 0.605, 0, 0, 1.05556],
              57345: [-499e-5, 0.605, 0, 0, 1.05556],
              57680: [0, 0.12, 0, 0, 0.45],
              57681: [0, 0.12, 0, 0, 0.45],
              57682: [0, 0.12, 0, 0, 0.45],
              57683: [0, 0.12, 0, 0, 0.45]
            },
            "Typewriter-Regular": {
              32: [0, 0, 0, 0, 0.525],
              33: [0, 0.61111, 0, 0, 0.525],
              34: [0, 0.61111, 0, 0, 0.525],
              35: [0, 0.61111, 0, 0, 0.525],
              36: [0.08333, 0.69444, 0, 0, 0.525],
              37: [0.08333, 0.69444, 0, 0, 0.525],
              38: [0, 0.61111, 0, 0, 0.525],
              39: [0, 0.61111, 0, 0, 0.525],
              40: [0.08333, 0.69444, 0, 0, 0.525],
              41: [0.08333, 0.69444, 0, 0, 0.525],
              42: [0, 0.52083, 0, 0, 0.525],
              43: [-0.08056, 0.53055, 0, 0, 0.525],
              44: [0.13889, 0.125, 0, 0, 0.525],
              45: [-0.08056, 0.53055, 0, 0, 0.525],
              46: [0, 0.125, 0, 0, 0.525],
              47: [0.08333, 0.69444, 0, 0, 0.525],
              48: [0, 0.61111, 0, 0, 0.525],
              49: [0, 0.61111, 0, 0, 0.525],
              50: [0, 0.61111, 0, 0, 0.525],
              51: [0, 0.61111, 0, 0, 0.525],
              52: [0, 0.61111, 0, 0, 0.525],
              53: [0, 0.61111, 0, 0, 0.525],
              54: [0, 0.61111, 0, 0, 0.525],
              55: [0, 0.61111, 0, 0, 0.525],
              56: [0, 0.61111, 0, 0, 0.525],
              57: [0, 0.61111, 0, 0, 0.525],
              58: [0, 0.43056, 0, 0, 0.525],
              59: [0.13889, 0.43056, 0, 0, 0.525],
              60: [-0.05556, 0.55556, 0, 0, 0.525],
              61: [-0.19549, 0.41562, 0, 0, 0.525],
              62: [-0.05556, 0.55556, 0, 0, 0.525],
              63: [0, 0.61111, 0, 0, 0.525],
              64: [0, 0.61111, 0, 0, 0.525],
              65: [0, 0.61111, 0, 0, 0.525],
              66: [0, 0.61111, 0, 0, 0.525],
              67: [0, 0.61111, 0, 0, 0.525],
              68: [0, 0.61111, 0, 0, 0.525],
              69: [0, 0.61111, 0, 0, 0.525],
              70: [0, 0.61111, 0, 0, 0.525],
              71: [0, 0.61111, 0, 0, 0.525],
              72: [0, 0.61111, 0, 0, 0.525],
              73: [0, 0.61111, 0, 0, 0.525],
              74: [0, 0.61111, 0, 0, 0.525],
              75: [0, 0.61111, 0, 0, 0.525],
              76: [0, 0.61111, 0, 0, 0.525],
              77: [0, 0.61111, 0, 0, 0.525],
              78: [0, 0.61111, 0, 0, 0.525],
              79: [0, 0.61111, 0, 0, 0.525],
              80: [0, 0.61111, 0, 0, 0.525],
              81: [0.13889, 0.61111, 0, 0, 0.525],
              82: [0, 0.61111, 0, 0, 0.525],
              83: [0, 0.61111, 0, 0, 0.525],
              84: [0, 0.61111, 0, 0, 0.525],
              85: [0, 0.61111, 0, 0, 0.525],
              86: [0, 0.61111, 0, 0, 0.525],
              87: [0, 0.61111, 0, 0, 0.525],
              88: [0, 0.61111, 0, 0, 0.525],
              89: [0, 0.61111, 0, 0, 0.525],
              90: [0, 0.61111, 0, 0, 0.525],
              91: [0.08333, 0.69444, 0, 0, 0.525],
              92: [0.08333, 0.69444, 0, 0, 0.525],
              93: [0.08333, 0.69444, 0, 0, 0.525],
              94: [0, 0.61111, 0, 0, 0.525],
              95: [0.09514, 0, 0, 0, 0.525],
              96: [0, 0.61111, 0, 0, 0.525],
              97: [0, 0.43056, 0, 0, 0.525],
              98: [0, 0.61111, 0, 0, 0.525],
              99: [0, 0.43056, 0, 0, 0.525],
              100: [0, 0.61111, 0, 0, 0.525],
              101: [0, 0.43056, 0, 0, 0.525],
              102: [0, 0.61111, 0, 0, 0.525],
              103: [0.22222, 0.43056, 0, 0, 0.525],
              104: [0, 0.61111, 0, 0, 0.525],
              105: [0, 0.61111, 0, 0, 0.525],
              106: [0.22222, 0.61111, 0, 0, 0.525],
              107: [0, 0.61111, 0, 0, 0.525],
              108: [0, 0.61111, 0, 0, 0.525],
              109: [0, 0.43056, 0, 0, 0.525],
              110: [0, 0.43056, 0, 0, 0.525],
              111: [0, 0.43056, 0, 0, 0.525],
              112: [0.22222, 0.43056, 0, 0, 0.525],
              113: [0.22222, 0.43056, 0, 0, 0.525],
              114: [0, 0.43056, 0, 0, 0.525],
              115: [0, 0.43056, 0, 0, 0.525],
              116: [0, 0.55358, 0, 0, 0.525],
              117: [0, 0.43056, 0, 0, 0.525],
              118: [0, 0.43056, 0, 0, 0.525],
              119: [0, 0.43056, 0, 0, 0.525],
              120: [0, 0.43056, 0, 0, 0.525],
              121: [0.22222, 0.43056, 0, 0, 0.525],
              122: [0, 0.43056, 0, 0, 0.525],
              123: [0.08333, 0.69444, 0, 0, 0.525],
              124: [0.08333, 0.69444, 0, 0, 0.525],
              125: [0.08333, 0.69444, 0, 0, 0.525],
              126: [0, 0.61111, 0, 0, 0.525],
              127: [0, 0.61111, 0, 0, 0.525],
              160: [0, 0, 0, 0, 0.525],
              176: [0, 0.61111, 0, 0, 0.525],
              184: [0.19445, 0, 0, 0, 0.525],
              305: [0, 0.43056, 0, 0, 0.525],
              567: [0.22222, 0.43056, 0, 0, 0.525],
              711: [0, 0.56597, 0, 0, 0.525],
              713: [0, 0.56555, 0, 0, 0.525],
              714: [0, 0.61111, 0, 0, 0.525],
              715: [0, 0.61111, 0, 0, 0.525],
              728: [0, 0.61111, 0, 0, 0.525],
              730: [0, 0.61111, 0, 0, 0.525],
              770: [0, 0.61111, 0, 0, 0.525],
              771: [0, 0.61111, 0, 0, 0.525],
              776: [0, 0.61111, 0, 0, 0.525],
              915: [0, 0.61111, 0, 0, 0.525],
              916: [0, 0.61111, 0, 0, 0.525],
              920: [0, 0.61111, 0, 0, 0.525],
              923: [0, 0.61111, 0, 0, 0.525],
              926: [0, 0.61111, 0, 0, 0.525],
              928: [0, 0.61111, 0, 0, 0.525],
              931: [0, 0.61111, 0, 0, 0.525],
              933: [0, 0.61111, 0, 0, 0.525],
              934: [0, 0.61111, 0, 0, 0.525],
              936: [0, 0.61111, 0, 0, 0.525],
              937: [0, 0.61111, 0, 0, 0.525],
              8216: [0, 0.61111, 0, 0, 0.525],
              8217: [0, 0.61111, 0, 0, 0.525],
              8242: [0, 0.61111, 0, 0, 0.525],
              9251: [0.11111, 0.21944, 0, 0, 0.525]
            }
          }, D0 = {
            slant: [0.25, 0.25, 0.25],
            // sigma1
            space: [0, 0, 0],
            // sigma2
            stretch: [0, 0, 0],
            // sigma3
            shrink: [0, 0, 0],
            // sigma4
            xHeight: [0.431, 0.431, 0.431],
            // sigma5
            quad: [1, 1.171, 1.472],
            // sigma6
            extraSpace: [0, 0, 0],
            // sigma7
            num1: [0.677, 0.732, 0.925],
            // sigma8
            num2: [0.394, 0.384, 0.387],
            // sigma9
            num3: [0.444, 0.471, 0.504],
            // sigma10
            denom1: [0.686, 0.752, 1.025],
            // sigma11
            denom2: [0.345, 0.344, 0.532],
            // sigma12
            sup1: [0.413, 0.503, 0.504],
            // sigma13
            sup2: [0.363, 0.431, 0.404],
            // sigma14
            sup3: [0.289, 0.286, 0.294],
            // sigma15
            sub1: [0.15, 0.143, 0.2],
            // sigma16
            sub2: [0.247, 0.286, 0.4],
            // sigma17
            supDrop: [0.386, 0.353, 0.494],
            // sigma18
            subDrop: [0.05, 0.071, 0.1],
            // sigma19
            delim1: [2.39, 1.7, 1.98],
            // sigma20
            delim2: [1.01, 1.157, 1.42],
            // sigma21
            axisHeight: [0.25, 0.25, 0.25],
            // sigma22
            // These font metrics are extracted from TeX by using tftopl on cmex10.tfm;
            // they correspond to the font parameters of the extension fonts (family 3).
            // See the TeXbook, page 441. In AMSTeX, the extension fonts scale; to
            // match cmex7, we'd use cmex7.tfm values for script and scriptscript
            // values.
            defaultRuleThickness: [0.04, 0.049, 0.049],
            // xi8; cmex7: 0.049
            bigOpSpacing1: [0.111, 0.111, 0.111],
            // xi9
            bigOpSpacing2: [0.166, 0.166, 0.166],
            // xi10
            bigOpSpacing3: [0.2, 0.2, 0.2],
            // xi11
            bigOpSpacing4: [0.6, 0.611, 0.611],
            // xi12; cmex7: 0.611
            bigOpSpacing5: [0.1, 0.143, 0.143],
            // xi13; cmex7: 0.143
            // The \sqrt rule width is taken from the height of the surd character.
            // Since we use the same font at all sizes, this thickness doesn't scale.
            sqrtRuleThickness: [0.04, 0.04, 0.04],
            // This value determines how large a pt is, for metrics which are defined
            // in terms of pts.
            // This value is also used in katex.less; if you change it make sure the
            // values match.
            ptPerEm: [10, 10, 10],
            // The space between adjacent `|` columns in an array definition. From
            // `\showthe\doublerulesep` in LaTeX. Equals 2.0 / ptPerEm.
            doubleRuleSep: [0.2, 0.2, 0.2],
            // The width of separator lines in {array} environments. From
            // `\showthe\arrayrulewidth` in LaTeX. Equals 0.4 / ptPerEm.
            arrayRuleWidth: [0.04, 0.04, 0.04],
            // Two values from LaTeX source2e:
            fboxsep: [0.3, 0.3, 0.3],
            //        3 pt / ptPerEm
            fboxrule: [0.04, 0.04, 0.04]
            // 0.4 pt / ptPerEm
          }, A0 = {
            // Latin-1
            Å: "A",
            Ð: "D",
            Þ: "o",
            å: "a",
            ð: "d",
            þ: "o",
            // Cyrillic
            А: "A",
            Б: "B",
            В: "B",
            Г: "F",
            Д: "A",
            Е: "E",
            Ж: "K",
            З: "3",
            И: "N",
            Й: "N",
            К: "K",
            Л: "N",
            М: "M",
            Н: "H",
            О: "O",
            П: "N",
            Р: "P",
            С: "C",
            Т: "T",
            У: "y",
            Ф: "O",
            Х: "X",
            Ц: "U",
            Ч: "h",
            Ш: "W",
            Щ: "W",
            Ъ: "B",
            Ы: "X",
            Ь: "B",
            Э: "3",
            Ю: "X",
            Я: "R",
            а: "a",
            б: "b",
            в: "a",
            г: "r",
            д: "y",
            е: "e",
            ж: "m",
            з: "e",
            и: "n",
            й: "n",
            к: "n",
            л: "n",
            м: "m",
            н: "n",
            о: "o",
            п: "n",
            р: "p",
            с: "c",
            т: "o",
            у: "y",
            ф: "b",
            х: "x",
            ц: "n",
            ч: "n",
            ш: "w",
            щ: "w",
            ъ: "a",
            ы: "m",
            ь: "a",
            э: "e",
            ю: "m",
            я: "r"
          };
          function x0(m, e) {
            Ot[m] = e;
          }
          function t0(m, e, r) {
            if (!Ot[e])
              throw new Error("Font metrics not found for font: " + e + ".");
            var a = m.charCodeAt(0), l = Ot[e][a];
            if (!l && m[0] in A0 && (a = A0[m[0]].charCodeAt(0), l = Ot[e][a]), !l && r === "text" && yt(a) && (l = Ot[e][77]), l)
              return {
                depth: l[0],
                height: l[1],
                italic: l[2],
                skew: l[3],
                width: l[4]
              };
          }
          var ar = {};
          function Qr(m) {
            var e;
            if (m >= 5 ? e = 0 : m >= 3 ? e = 1 : e = 2, !ar[e]) {
              var r = ar[e] = {
                cssEmPerMu: D0.quad[e] / 18
              };
              for (var a in D0)
                D0.hasOwnProperty(a) && (r[a] = D0[a][e]);
            }
            return ar[e];
          }
          var Jr = [
            // Each element contains [textsize, scriptsize, scriptscriptsize].
            // The size mappings are taken from TeX with \normalsize=10pt.
            [1, 1, 1],
            // size1: [5, 5, 5]              \tiny
            [2, 1, 1],
            // size2: [6, 5, 5]
            [3, 1, 1],
            // size3: [7, 5, 5]              \scriptsize
            [4, 2, 1],
            // size4: [8, 6, 5]              \footnotesize
            [5, 2, 1],
            // size5: [9, 6, 5]              \small
            [6, 3, 1],
            // size6: [10, 7, 5]             \normalsize
            [7, 4, 2],
            // size7: [12, 8, 6]             \large
            [8, 6, 3],
            // size8: [14.4, 10, 7]          \Large
            [9, 7, 6],
            // size9: [17.28, 12, 10]        \LARGE
            [10, 8, 7],
            // size10: [20.74, 14.4, 12]     \huge
            [11, 10, 9]
            // size11: [24.88, 20.74, 17.28] \HUGE
          ], ir = [
            // fontMetrics.js:getGlobalMetrics also uses size indexes, so if
            // you change size indexes, change that function.
            0.5,
            0.6,
            0.7,
            0.8,
            0.9,
            1,
            1.2,
            1.44,
            1.728,
            2.074,
            2.488
          ], xr = function(e, r) {
            return r.size < 2 ? e : Jr[e - 1][r.size - 1];
          }, W0 = /* @__PURE__ */ function() {
            function m(r) {
              this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = r.style, this.color = r.color, this.size = r.size || m.BASESIZE, this.textSize = r.textSize || this.size, this.phantom = !!r.phantom, this.font = r.font || "", this.fontFamily = r.fontFamily || "", this.fontWeight = r.fontWeight || "", this.fontShape = r.fontShape || "", this.sizeMultiplier = ir[this.size - 1], this.maxSize = r.maxSize, this.minRuleThickness = r.minRuleThickness, this._fontMetrics = void 0;
            }
            var e = m.prototype;
            return e.extend = function(a) {
              var l = {
                style: this.style,
                size: this.size,
                textSize: this.textSize,
                color: this.color,
                phantom: this.phantom,
                font: this.font,
                fontFamily: this.fontFamily,
                fontWeight: this.fontWeight,
                fontShape: this.fontShape,
                maxSize: this.maxSize,
                minRuleThickness: this.minRuleThickness
              };
              for (var c in a)
                a.hasOwnProperty(c) && (l[c] = a[c]);
              return new m(l);
            }, e.havingStyle = function(a) {
              return this.style === a ? this : this.extend({
                style: a,
                size: xr(this.textSize, a)
              });
            }, e.havingCrampedStyle = function() {
              return this.havingStyle(this.style.cramp());
            }, e.havingSize = function(a) {
              return this.size === a && this.textSize === a ? this : this.extend({
                style: this.style.text(),
                size: a,
                textSize: a,
                sizeMultiplier: ir[a - 1]
              });
            }, e.havingBaseStyle = function(a) {
              a = a || this.style.text();
              var l = xr(m.BASESIZE, a);
              return this.size === l && this.textSize === m.BASESIZE && this.style === a ? this : this.extend({
                style: a,
                size: l
              });
            }, e.havingBaseSizing = function() {
              var a;
              switch (this.style.id) {
                case 4:
                case 5:
                  a = 3;
                  break;
                case 6:
                case 7:
                  a = 1;
                  break;
                default:
                  a = 6;
              }
              return this.extend({
                style: this.style.text(),
                size: a
              });
            }, e.withColor = function(a) {
              return this.extend({
                color: a
              });
            }, e.withPhantom = function() {
              return this.extend({
                phantom: !0
              });
            }, e.withFont = function(a) {
              return this.extend({
                font: a
              });
            }, e.withTextFontFamily = function(a) {
              return this.extend({
                fontFamily: a,
                font: ""
              });
            }, e.withTextFontWeight = function(a) {
              return this.extend({
                fontWeight: a,
                font: ""
              });
            }, e.withTextFontShape = function(a) {
              return this.extend({
                fontShape: a,
                font: ""
              });
            }, e.sizingClasses = function(a) {
              return a.size !== this.size ? ["sizing", "reset-size" + a.size, "size" + this.size] : [];
            }, e.baseSizingClasses = function() {
              return this.size !== m.BASESIZE ? ["sizing", "reset-size" + this.size, "size" + m.BASESIZE] : [];
            }, e.fontMetrics = function() {
              return this._fontMetrics || (this._fontMetrics = Qr(this.size)), this._fontMetrics;
            }, e.getColor = function() {
              return this.phantom ? "transparent" : this.color;
            }, m;
          }();
          W0.BASESIZE = 6;
          var lr = W0, At = {
            // https://en.wikibooks.org/wiki/LaTeX/Lengths and
            // https://tex.stackexchange.com/a/8263
            pt: 1,
            // TeX point
            mm: 7227 / 2540,
            // millimeter
            cm: 7227 / 254,
            // centimeter
            in: 72.27,
            // inch
            bp: 803 / 800,
            // big (PostScript) points
            pc: 12,
            // pica
            dd: 1238 / 1157,
            // didot
            cc: 14856 / 1157,
            // cicero (12 didot)
            nd: 685 / 642,
            // new didot
            nc: 1370 / 107,
            // new cicero (12 new didot)
            sp: 1 / 65536,
            // scaled point (TeX's internal smallest unit)
            // https://tex.stackexchange.com/a/41371
            px: 803 / 800
            // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
          }, S0 = {
            ex: !0,
            em: !0,
            mu: !0
          }, sr = function(e) {
            return typeof e != "string" && (e = e.unit), e in At || e in S0 || e === "ex";
          }, qe = function(e, r) {
            var a;
            if (e.unit in At)
              a = At[e.unit] / r.fontMetrics().ptPerEm / r.sizeMultiplier;
            else if (e.unit === "mu")
              a = r.fontMetrics().cssEmPerMu;
            else {
              var l;
              if (r.style.isTight() ? l = r.havingStyle(r.style.text()) : l = r, e.unit === "ex")
                a = l.fontMetrics().xHeight;
              else if (e.unit === "em")
                a = l.fontMetrics().quad;
              else
                throw new u("Invalid unit: '" + e.unit + "'");
              l !== r && (a *= l.sizeMultiplier / r.sizeMultiplier);
            }
            return Math.min(e.number * a, r.maxSize);
          }, ne = function(e) {
            return +e.toFixed(4) + "em";
          }, wt = function(e) {
            return e.filter(function(r) {
              return r;
            }).join(" ");
          }, $r = function(e, r, a) {
            if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = a || {}, r) {
              r.style.isTight() && this.classes.push("mtight");
              var l = r.getColor();
              l && (this.style.color = l);
            }
          }, en = function(e) {
            var r = document.createElement(e);
            r.className = wt(this.classes);
            for (var a in this.style)
              this.style.hasOwnProperty(a) && (r.style[a] = this.style[a]);
            for (var l in this.attributes)
              this.attributes.hasOwnProperty(l) && r.setAttribute(l, this.attributes[l]);
            for (var c = 0; c < this.children.length; c++)
              r.appendChild(this.children[c].toNode());
            return r;
          }, $e = function(e) {
            var r = "<" + e;
            this.classes.length && (r += ' class="' + M.escape(wt(this.classes)) + '"');
            var a = "";
            for (var l in this.style)
              this.style.hasOwnProperty(l) && (a += M.hyphenate(l) + ":" + this.style[l] + ";");
            a && (r += ' style="' + M.escape(a) + '"');
            for (var c in this.attributes)
              this.attributes.hasOwnProperty(c) && (r += " " + c + '="' + M.escape(this.attributes[c]) + '"');
            r += ">";
            for (var d = 0; d < this.children.length; d++)
              r += this.children[d].toMarkup();
            return r += "</" + e + ">", r;
          }, qt = /* @__PURE__ */ function() {
            function m(r, a, l, c) {
              this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, $r.call(this, r, l, c), this.children = a || [];
            }
            var e = m.prototype;
            return e.setAttribute = function(a, l) {
              this.attributes[a] = l;
            }, e.hasClass = function(a) {
              return M.contains(this.classes, a);
            }, e.toNode = function() {
              return en.call(this, "span");
            }, e.toMarkup = function() {
              return $e.call(this, "span");
            }, m;
          }(), Sr = /* @__PURE__ */ function() {
            function m(r, a, l, c) {
              this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, $r.call(this, a, c), this.children = l || [], this.setAttribute("href", r);
            }
            var e = m.prototype;
            return e.setAttribute = function(a, l) {
              this.attributes[a] = l;
            }, e.hasClass = function(a) {
              return M.contains(this.classes, a);
            }, e.toNode = function() {
              return en.call(this, "a");
            }, e.toMarkup = function() {
              return $e.call(this, "a");
            }, m;
          }(), tn = /* @__PURE__ */ function() {
            function m(r, a, l) {
              this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = a, this.src = r, this.classes = ["mord"], this.style = l;
            }
            var e = m.prototype;
            return e.hasClass = function(a) {
              return M.contains(this.classes, a);
            }, e.toNode = function() {
              var a = document.createElement("img");
              a.src = this.src, a.alt = this.alt, a.className = "mord";
              for (var l in this.style)
                this.style.hasOwnProperty(l) && (a.style[l] = this.style[l]);
              return a;
            }, e.toMarkup = function() {
              var a = "<img  src='" + this.src + " 'alt='" + this.alt + "' ", l = "";
              for (var c in this.style)
                this.style.hasOwnProperty(c) && (l += M.hyphenate(c) + ":" + this.style[c] + ";");
              return l && (a += ' style="' + M.escape(l) + '"'), a += "'/>", a;
            }, m;
          }(), Er = {
            î: "ı̂",
            ï: "ı̈",
            í: "ı́",
            // 'ī': '\u0131\u0304', // enable when we add Extended Latin
            ì: "ı̀"
          }, mt = /* @__PURE__ */ function() {
            function m(r, a, l, c, d, b, _, A) {
              this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = r, this.height = a || 0, this.depth = l || 0, this.italic = c || 0, this.skew = d || 0, this.width = b || 0, this.classes = _ || [], this.style = A || {}, this.maxFontSize = 0;
              var C = le(this.text.charCodeAt(0));
              C && this.classes.push(C + "_fallback"), /[îïíì]/.test(this.text) && (this.text = Er[this.text]);
            }
            var e = m.prototype;
            return e.hasClass = function(a) {
              return M.contains(this.classes, a);
            }, e.toNode = function() {
              var a = document.createTextNode(this.text), l = null;
              this.italic > 0 && (l = document.createElement("span"), l.style.marginRight = ne(this.italic)), this.classes.length > 0 && (l = l || document.createElement("span"), l.className = wt(this.classes));
              for (var c in this.style)
                this.style.hasOwnProperty(c) && (l = l || document.createElement("span"), l.style[c] = this.style[c]);
              return l ? (l.appendChild(a), l) : a;
            }, e.toMarkup = function() {
              var a = !1, l = "<span";
              this.classes.length && (a = !0, l += ' class="', l += M.escape(wt(this.classes)), l += '"');
              var c = "";
              this.italic > 0 && (c += "margin-right:" + this.italic + "em;");
              for (var d in this.style)
                this.style.hasOwnProperty(d) && (c += M.hyphenate(d) + ":" + this.style[d] + ";");
              c && (a = !0, l += ' style="' + M.escape(c) + '"');
              var b = M.escape(this.text);
              return a ? (l += ">", l += b, l += "</span>", l) : b;
            }, m;
          }(), Pt = /* @__PURE__ */ function() {
            function m(r, a) {
              this.children = void 0, this.attributes = void 0, this.children = r || [], this.attributes = a || {};
            }
            var e = m.prototype;
            return e.toNode = function() {
              var a = "http://www.w3.org/2000/svg", l = document.createElementNS(a, "svg");
              for (var c in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, c) && l.setAttribute(c, this.attributes[c]);
              for (var d = 0; d < this.children.length; d++)
                l.appendChild(this.children[d].toNode());
              return l;
            }, e.toMarkup = function() {
              var a = '<svg xmlns="http://www.w3.org/2000/svg"';
              for (var l in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, l) && (a += " " + l + "='" + this.attributes[l] + "'");
              a += ">";
              for (var c = 0; c < this.children.length; c++)
                a += this.children[c].toMarkup();
              return a += "</svg>", a;
            }, m;
          }(), r0 = /* @__PURE__ */ function() {
            function m(r, a) {
              this.pathName = void 0, this.alternate = void 0, this.pathName = r, this.alternate = a;
            }
            var e = m.prototype;
            return e.toNode = function() {
              var a = "http://www.w3.org/2000/svg", l = document.createElementNS(a, "path");
              return this.alternate ? l.setAttribute("d", this.alternate) : l.setAttribute("d", V0[this.pathName]), l;
            }, e.toMarkup = function() {
              return this.alternate ? "<path d='" + this.alternate + "'/>" : "<path d='" + V0[this.pathName] + "'/>";
            }, m;
          }(), or = /* @__PURE__ */ function() {
            function m(r) {
              this.attributes = void 0, this.attributes = r || {};
            }
            var e = m.prototype;
            return e.toNode = function() {
              var a = "http://www.w3.org/2000/svg", l = document.createElementNS(a, "line");
              for (var c in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, c) && l.setAttribute(c, this.attributes[c]);
              return l;
            }, e.toMarkup = function() {
              var a = "<line";
              for (var l in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, l) && (a += " " + l + "='" + this.attributes[l] + "'");
              return a += "/>", a;
            }, m;
          }();
          function Fr(m) {
            if (m instanceof mt)
              return m;
            throw new Error("Expected symbolNode but got " + String(m) + ".");
          }
          function Qn(m) {
            if (m instanceof qt)
              return m;
            throw new Error("Expected span<HtmlDomNode> but got " + String(m) + ".");
          }
          var m0 = {
            bin: 1,
            close: 1,
            inner: 1,
            open: 1,
            punct: 1,
            rel: 1
          }, Cr = {
            "accent-token": 1,
            mathord: 1,
            "op-token": 1,
            spacing: 1,
            textord: 1
          }, j0 = {
            math: {},
            text: {}
          }, Ge = j0;
          function h(m, e, r, a, l, c) {
            j0[m][l] = {
              font: e,
              group: r,
              replace: a
            }, c && a && (j0[m][a] = j0[m][l]);
          }
          var p = "math", j = "text", w = "main", S = "ams", Pe = "accent-token", ue = "bin", lt = "close", he = "inner", E = "mathord", Z = "op-token", se = "open", Be = "punct", x = "rel", Ve = "spacing", T = "textord";
          h(p, w, x, "≡", "\\equiv", !0), h(p, w, x, "≺", "\\prec", !0), h(p, w, x, "≻", "\\succ", !0), h(p, w, x, "∼", "\\sim", !0), h(p, w, x, "⊥", "\\perp"), h(p, w, x, "⪯", "\\preceq", !0), h(p, w, x, "⪰", "\\succeq", !0), h(p, w, x, "≃", "\\simeq", !0), h(p, w, x, "∣", "\\mid", !0), h(p, w, x, "≪", "\\ll", !0), h(p, w, x, "≫", "\\gg", !0), h(p, w, x, "≍", "\\asymp", !0), h(p, w, x, "∥", "\\parallel"), h(p, w, x, "⋈", "\\bowtie", !0), h(p, w, x, "⌣", "\\smile", !0), h(p, w, x, "⊑", "\\sqsubseteq", !0), h(p, w, x, "⊒", "\\sqsupseteq", !0), h(p, w, x, "≐", "\\doteq", !0), h(p, w, x, "⌢", "\\frown", !0), h(p, w, x, "∋", "\\ni", !0), h(p, w, x, "∝", "\\propto", !0), h(p, w, x, "⊢", "\\vdash", !0), h(p, w, x, "⊣", "\\dashv", !0), h(p, w, x, "∋", "\\owns"), h(p, w, Be, ".", "\\ldotp"), h(p, w, Be, "⋅", "\\cdotp"), h(p, w, T, "#", "\\#"), h(j, w, T, "#", "\\#"), h(p, w, T, "&", "\\&"), h(j, w, T, "&", "\\&"), h(p, w, T, "ℵ", "\\aleph", !0), h(p, w, T, "∀", "\\forall", !0), h(p, w, T, "ℏ", "\\hbar", !0), h(p, w, T, "∃", "\\exists", !0), h(p, w, T, "∇", "\\nabla", !0), h(p, w, T, "♭", "\\flat", !0), h(p, w, T, "ℓ", "\\ell", !0), h(p, w, T, "♮", "\\natural", !0), h(p, w, T, "♣", "\\clubsuit", !0), h(p, w, T, "℘", "\\wp", !0), h(p, w, T, "♯", "\\sharp", !0), h(p, w, T, "♢", "\\diamondsuit", !0), h(p, w, T, "ℜ", "\\Re", !0), h(p, w, T, "♡", "\\heartsuit", !0), h(p, w, T, "ℑ", "\\Im", !0), h(p, w, T, "♠", "\\spadesuit", !0), h(p, w, T, "§", "\\S", !0), h(j, w, T, "§", "\\S"), h(p, w, T, "¶", "\\P", !0), h(j, w, T, "¶", "\\P"), h(p, w, T, "†", "\\dag"), h(j, w, T, "†", "\\dag"), h(j, w, T, "†", "\\textdagger"), h(p, w, T, "‡", "\\ddag"), h(j, w, T, "‡", "\\ddag"), h(j, w, T, "‡", "\\textdaggerdbl"), h(p, w, lt, "⎱", "\\rmoustache", !0), h(p, w, se, "⎰", "\\lmoustache", !0), h(p, w, lt, "⟯", "\\rgroup", !0), h(p, w, se, "⟮", "\\lgroup", !0), h(p, w, ue, "∓", "\\mp", !0), h(p, w, ue, "⊖", "\\ominus", !0), h(p, w, ue, "⊎", "\\uplus", !0), h(p, w, ue, "⊓", "\\sqcap", !0), h(p, w, ue, "∗", "\\ast"), h(p, w, ue, "⊔", "\\sqcup", !0), h(p, w, ue, "◯", "\\bigcirc", !0), h(p, w, ue, "∙", "\\bullet", !0), h(p, w, ue, "‡", "\\ddagger"), h(p, w, ue, "≀", "\\wr", !0), h(p, w, ue, "⨿", "\\amalg"), h(p, w, ue, "&", "\\And"), h(p, w, x, "⟵", "\\longleftarrow", !0), h(p, w, x, "⇐", "\\Leftarrow", !0), h(p, w, x, "⟸", "\\Longleftarrow", !0), h(p, w, x, "⟶", "\\longrightarrow", !0), h(p, w, x, "⇒", "\\Rightarrow", !0), h(p, w, x, "⟹", "\\Longrightarrow", !0), h(p, w, x, "↔", "\\leftrightarrow", !0), h(p, w, x, "⟷", "\\longleftrightarrow", !0), h(p, w, x, "⇔", "\\Leftrightarrow", !0), h(p, w, x, "⟺", "\\Longleftrightarrow", !0), h(p, w, x, "↦", "\\mapsto", !0), h(p, w, x, "⟼", "\\longmapsto", !0), h(p, w, x, "↗", "\\nearrow", !0), h(p, w, x, "↩", "\\hookleftarrow", !0), h(p, w, x, "↪", "\\hookrightarrow", !0), h(p, w, x, "↘", "\\searrow", !0), h(p, w, x, "↼", "\\leftharpoonup", !0), h(p, w, x, "⇀", "\\rightharpoonup", !0), h(p, w, x, "↙", "\\swarrow", !0), h(p, w, x, "↽", "\\leftharpoondown", !0), h(p, w, x, "⇁", "\\rightharpoondown", !0), h(p, w, x, "↖", "\\nwarrow", !0), h(p, w, x, "⇌", "\\rightleftharpoons", !0), h(p, S, x, "≮", "\\nless", !0), h(p, S, x, "", "\\@nleqslant"), h(p, S, x, "", "\\@nleqq"), h(p, S, x, "⪇", "\\lneq", !0), h(p, S, x, "≨", "\\lneqq", !0), h(p, S, x, "", "\\@lvertneqq"), h(p, S, x, "⋦", "\\lnsim", !0), h(p, S, x, "⪉", "\\lnapprox", !0), h(p, S, x, "⊀", "\\nprec", !0), h(p, S, x, "⋠", "\\npreceq", !0), h(p, S, x, "⋨", "\\precnsim", !0), h(p, S, x, "⪹", "\\precnapprox", !0), h(p, S, x, "≁", "\\nsim", !0), h(p, S, x, "", "\\@nshortmid"), h(p, S, x, "∤", "\\nmid", !0), h(p, S, x, "⊬", "\\nvdash", !0), h(p, S, x, "⊭", "\\nvDash", !0), h(p, S, x, "⋪", "\\ntriangleleft"), h(p, S, x, "⋬", "\\ntrianglelefteq", !0), h(p, S, x, "⊊", "\\subsetneq", !0), h(p, S, x, "", "\\@varsubsetneq"), h(p, S, x, "⫋", "\\subsetneqq", !0), h(p, S, x, "", "\\@varsubsetneqq"), h(p, S, x, "≯", "\\ngtr", !0), h(p, S, x, "", "\\@ngeqslant"), h(p, S, x, "", "\\@ngeqq"), h(p, S, x, "⪈", "\\gneq", !0), h(p, S, x, "≩", "\\gneqq", !0), h(p, S, x, "", "\\@gvertneqq"), h(p, S, x, "⋧", "\\gnsim", !0), h(p, S, x, "⪊", "\\gnapprox", !0), h(p, S, x, "⊁", "\\nsucc", !0), h(p, S, x, "⋡", "\\nsucceq", !0), h(p, S, x, "⋩", "\\succnsim", !0), h(p, S, x, "⪺", "\\succnapprox", !0), h(p, S, x, "≆", "\\ncong", !0), h(p, S, x, "", "\\@nshortparallel"), h(p, S, x, "∦", "\\nparallel", !0), h(p, S, x, "⊯", "\\nVDash", !0), h(p, S, x, "⋫", "\\ntriangleright"), h(p, S, x, "⋭", "\\ntrianglerighteq", !0), h(p, S, x, "", "\\@nsupseteqq"), h(p, S, x, "⊋", "\\supsetneq", !0), h(p, S, x, "", "\\@varsupsetneq"), h(p, S, x, "⫌", "\\supsetneqq", !0), h(p, S, x, "", "\\@varsupsetneqq"), h(p, S, x, "⊮", "\\nVdash", !0), h(p, S, x, "⪵", "\\precneqq", !0), h(p, S, x, "⪶", "\\succneqq", !0), h(p, S, x, "", "\\@nsubseteqq"), h(p, S, ue, "⊴", "\\unlhd"), h(p, S, ue, "⊵", "\\unrhd"), h(p, S, x, "↚", "\\nleftarrow", !0), h(p, S, x, "↛", "\\nrightarrow", !0), h(p, S, x, "⇍", "\\nLeftarrow", !0), h(p, S, x, "⇏", "\\nRightarrow", !0), h(p, S, x, "↮", "\\nleftrightarrow", !0), h(p, S, x, "⇎", "\\nLeftrightarrow", !0), h(p, S, x, "△", "\\vartriangle"), h(p, S, T, "ℏ", "\\hslash"), h(p, S, T, "▽", "\\triangledown"), h(p, S, T, "◊", "\\lozenge"), h(p, S, T, "Ⓢ", "\\circledS"), h(p, S, T, "®", "\\circledR"), h(j, S, T, "®", "\\circledR"), h(p, S, T, "∡", "\\measuredangle", !0), h(p, S, T, "∄", "\\nexists"), h(p, S, T, "℧", "\\mho"), h(p, S, T, "Ⅎ", "\\Finv", !0), h(p, S, T, "⅁", "\\Game", !0), h(p, S, T, "‵", "\\backprime"), h(p, S, T, "▲", "\\blacktriangle"), h(p, S, T, "▼", "\\blacktriangledown"), h(p, S, T, "■", "\\blacksquare"), h(p, S, T, "⧫", "\\blacklozenge"), h(p, S, T, "★", "\\bigstar"), h(p, S, T, "∢", "\\sphericalangle", !0), h(p, S, T, "∁", "\\complement", !0), h(p, S, T, "ð", "\\eth", !0), h(j, w, T, "ð", "ð"), h(p, S, T, "╱", "\\diagup"), h(p, S, T, "╲", "\\diagdown"), h(p, S, T, "□", "\\square"), h(p, S, T, "□", "\\Box"), h(p, S, T, "◊", "\\Diamond"), h(p, S, T, "¥", "\\yen", !0), h(j, S, T, "¥", "\\yen", !0), h(p, S, T, "✓", "\\checkmark", !0), h(j, S, T, "✓", "\\checkmark"), h(p, S, T, "ℶ", "\\beth", !0), h(p, S, T, "ℸ", "\\daleth", !0), h(p, S, T, "ℷ", "\\gimel", !0), h(p, S, T, "ϝ", "\\digamma", !0), h(p, S, T, "ϰ", "\\varkappa"), h(p, S, se, "┌", "\\@ulcorner", !0), h(p, S, lt, "┐", "\\@urcorner", !0), h(p, S, se, "└", "\\@llcorner", !0), h(p, S, lt, "┘", "\\@lrcorner", !0), h(p, S, x, "≦", "\\leqq", !0), h(p, S, x, "⩽", "\\leqslant", !0), h(p, S, x, "⪕", "\\eqslantless", !0), h(p, S, x, "≲", "\\lesssim", !0), h(p, S, x, "⪅", "\\lessapprox", !0), h(p, S, x, "≊", "\\approxeq", !0), h(p, S, ue, "⋖", "\\lessdot"), h(p, S, x, "⋘", "\\lll", !0), h(p, S, x, "≶", "\\lessgtr", !0), h(p, S, x, "⋚", "\\lesseqgtr", !0), h(p, S, x, "⪋", "\\lesseqqgtr", !0), h(p, S, x, "≑", "\\doteqdot"), h(p, S, x, "≓", "\\risingdotseq", !0), h(p, S, x, "≒", "\\fallingdotseq", !0), h(p, S, x, "∽", "\\backsim", !0), h(p, S, x, "⋍", "\\backsimeq", !0), h(p, S, x, "⫅", "\\subseteqq", !0), h(p, S, x, "⋐", "\\Subset", !0), h(p, S, x, "⊏", "\\sqsubset", !0), h(p, S, x, "≼", "\\preccurlyeq", !0), h(p, S, x, "⋞", "\\curlyeqprec", !0), h(p, S, x, "≾", "\\precsim", !0), h(p, S, x, "⪷", "\\precapprox", !0), h(p, S, x, "⊲", "\\vartriangleleft"), h(p, S, x, "⊴", "\\trianglelefteq"), h(p, S, x, "⊨", "\\vDash", !0), h(p, S, x, "⊪", "\\Vvdash", !0), h(p, S, x, "⌣", "\\smallsmile"), h(p, S, x, "⌢", "\\smallfrown"), h(p, S, x, "≏", "\\bumpeq", !0), h(p, S, x, "≎", "\\Bumpeq", !0), h(p, S, x, "≧", "\\geqq", !0), h(p, S, x, "⩾", "\\geqslant", !0), h(p, S, x, "⪖", "\\eqslantgtr", !0), h(p, S, x, "≳", "\\gtrsim", !0), h(p, S, x, "⪆", "\\gtrapprox", !0), h(p, S, ue, "⋗", "\\gtrdot"), h(p, S, x, "⋙", "\\ggg", !0), h(p, S, x, "≷", "\\gtrless", !0), h(p, S, x, "⋛", "\\gtreqless", !0), h(p, S, x, "⪌", "\\gtreqqless", !0), h(p, S, x, "≖", "\\eqcirc", !0), h(p, S, x, "≗", "\\circeq", !0), h(p, S, x, "≜", "\\triangleq", !0), h(p, S, x, "∼", "\\thicksim"), h(p, S, x, "≈", "\\thickapprox"), h(p, S, x, "⫆", "\\supseteqq", !0), h(p, S, x, "⋑", "\\Supset", !0), h(p, S, x, "⊐", "\\sqsupset", !0), h(p, S, x, "≽", "\\succcurlyeq", !0), h(p, S, x, "⋟", "\\curlyeqsucc", !0), h(p, S, x, "≿", "\\succsim", !0), h(p, S, x, "⪸", "\\succapprox", !0), h(p, S, x, "⊳", "\\vartriangleright"), h(p, S, x, "⊵", "\\trianglerighteq"), h(p, S, x, "⊩", "\\Vdash", !0), h(p, S, x, "∣", "\\shortmid"), h(p, S, x, "∥", "\\shortparallel"), h(p, S, x, "≬", "\\between", !0), h(p, S, x, "⋔", "\\pitchfork", !0), h(p, S, x, "∝", "\\varpropto"), h(p, S, x, "◀", "\\blacktriangleleft"), h(p, S, x, "∴", "\\therefore", !0), h(p, S, x, "∍", "\\backepsilon"), h(p, S, x, "▶", "\\blacktriangleright"), h(p, S, x, "∵", "\\because", !0), h(p, S, x, "⋘", "\\llless"), h(p, S, x, "⋙", "\\gggtr"), h(p, S, ue, "⊲", "\\lhd"), h(p, S, ue, "⊳", "\\rhd"), h(p, S, x, "≂", "\\eqsim", !0), h(p, w, x, "⋈", "\\Join"), h(p, S, x, "≑", "\\Doteq", !0), h(p, S, ue, "∔", "\\dotplus", !0), h(p, S, ue, "∖", "\\smallsetminus"), h(p, S, ue, "⋒", "\\Cap", !0), h(p, S, ue, "⋓", "\\Cup", !0), h(p, S, ue, "⩞", "\\doublebarwedge", !0), h(p, S, ue, "⊟", "\\boxminus", !0), h(p, S, ue, "⊞", "\\boxplus", !0), h(p, S, ue, "⋇", "\\divideontimes", !0), h(p, S, ue, "⋉", "\\ltimes", !0), h(p, S, ue, "⋊", "\\rtimes", !0), h(p, S, ue, "⋋", "\\leftthreetimes", !0), h(p, S, ue, "⋌", "\\rightthreetimes", !0), h(p, S, ue, "⋏", "\\curlywedge", !0), h(p, S, ue, "⋎", "\\curlyvee", !0), h(p, S, ue, "⊝", "\\circleddash", !0), h(p, S, ue, "⊛", "\\circledast", !0), h(p, S, ue, "⋅", "\\centerdot"), h(p, S, ue, "⊺", "\\intercal", !0), h(p, S, ue, "⋒", "\\doublecap"), h(p, S, ue, "⋓", "\\doublecup"), h(p, S, ue, "⊠", "\\boxtimes", !0), h(p, S, x, "⇢", "\\dashrightarrow", !0), h(p, S, x, "⇠", "\\dashleftarrow", !0), h(p, S, x, "⇇", "\\leftleftarrows", !0), h(p, S, x, "⇆", "\\leftrightarrows", !0), h(p, S, x, "⇚", "\\Lleftarrow", !0), h(p, S, x, "↞", "\\twoheadleftarrow", !0), h(p, S, x, "↢", "\\leftarrowtail", !0), h(p, S, x, "↫", "\\looparrowleft", !0), h(p, S, x, "⇋", "\\leftrightharpoons", !0), h(p, S, x, "↶", "\\curvearrowleft", !0), h(p, S, x, "↺", "\\circlearrowleft", !0), h(p, S, x, "↰", "\\Lsh", !0), h(p, S, x, "⇈", "\\upuparrows", !0), h(p, S, x, "↿", "\\upharpoonleft", !0), h(p, S, x, "⇃", "\\downharpoonleft", !0), h(p, w, x, "⊶", "\\origof", !0), h(p, w, x, "⊷", "\\imageof", !0), h(p, S, x, "⊸", "\\multimap", !0), h(p, S, x, "↭", "\\leftrightsquigarrow", !0), h(p, S, x, "⇉", "\\rightrightarrows", !0), h(p, S, x, "⇄", "\\rightleftarrows", !0), h(p, S, x, "↠", "\\twoheadrightarrow", !0), h(p, S, x, "↣", "\\rightarrowtail", !0), h(p, S, x, "↬", "\\looparrowright", !0), h(p, S, x, "↷", "\\curvearrowright", !0), h(p, S, x, "↻", "\\circlearrowright", !0), h(p, S, x, "↱", "\\Rsh", !0), h(p, S, x, "⇊", "\\downdownarrows", !0), h(p, S, x, "↾", "\\upharpoonright", !0), h(p, S, x, "⇂", "\\downharpoonright", !0), h(p, S, x, "⇝", "\\rightsquigarrow", !0), h(p, S, x, "⇝", "\\leadsto"), h(p, S, x, "⇛", "\\Rrightarrow", !0), h(p, S, x, "↾", "\\restriction"), h(p, w, T, "‘", "`"), h(p, w, T, "$", "\\$"), h(j, w, T, "$", "\\$"), h(j, w, T, "$", "\\textdollar"), h(p, w, T, "%", "\\%"), h(j, w, T, "%", "\\%"), h(p, w, T, "_", "\\_"), h(j, w, T, "_", "\\_"), h(j, w, T, "_", "\\textunderscore"), h(p, w, T, "∠", "\\angle", !0), h(p, w, T, "∞", "\\infty", !0), h(p, w, T, "′", "\\prime"), h(p, w, T, "△", "\\triangle"), h(p, w, T, "Γ", "\\Gamma", !0), h(p, w, T, "Δ", "\\Delta", !0), h(p, w, T, "Θ", "\\Theta", !0), h(p, w, T, "Λ", "\\Lambda", !0), h(p, w, T, "Ξ", "\\Xi", !0), h(p, w, T, "Π", "\\Pi", !0), h(p, w, T, "Σ", "\\Sigma", !0), h(p, w, T, "Υ", "\\Upsilon", !0), h(p, w, T, "Φ", "\\Phi", !0), h(p, w, T, "Ψ", "\\Psi", !0), h(p, w, T, "Ω", "\\Omega", !0), h(p, w, T, "A", "Α"), h(p, w, T, "B", "Β"), h(p, w, T, "E", "Ε"), h(p, w, T, "Z", "Ζ"), h(p, w, T, "H", "Η"), h(p, w, T, "I", "Ι"), h(p, w, T, "K", "Κ"), h(p, w, T, "M", "Μ"), h(p, w, T, "N", "Ν"), h(p, w, T, "O", "Ο"), h(p, w, T, "P", "Ρ"), h(p, w, T, "T", "Τ"), h(p, w, T, "X", "Χ"), h(p, w, T, "¬", "\\neg", !0), h(p, w, T, "¬", "\\lnot"), h(p, w, T, "⊤", "\\top"), h(p, w, T, "⊥", "\\bot"), h(p, w, T, "∅", "\\emptyset"), h(p, S, T, "∅", "\\varnothing"), h(p, w, E, "α", "\\alpha", !0), h(p, w, E, "β", "\\beta", !0), h(p, w, E, "γ", "\\gamma", !0), h(p, w, E, "δ", "\\delta", !0), h(p, w, E, "ϵ", "\\epsilon", !0), h(p, w, E, "ζ", "\\zeta", !0), h(p, w, E, "η", "\\eta", !0), h(p, w, E, "θ", "\\theta", !0), h(p, w, E, "ι", "\\iota", !0), h(p, w, E, "κ", "\\kappa", !0), h(p, w, E, "λ", "\\lambda", !0), h(p, w, E, "μ", "\\mu", !0), h(p, w, E, "ν", "\\nu", !0), h(p, w, E, "ξ", "\\xi", !0), h(p, w, E, "ο", "\\omicron", !0), h(p, w, E, "π", "\\pi", !0), h(p, w, E, "ρ", "\\rho", !0), h(p, w, E, "σ", "\\sigma", !0), h(p, w, E, "τ", "\\tau", !0), h(p, w, E, "υ", "\\upsilon", !0), h(p, w, E, "ϕ", "\\phi", !0), h(p, w, E, "χ", "\\chi", !0), h(p, w, E, "ψ", "\\psi", !0), h(p, w, E, "ω", "\\omega", !0), h(p, w, E, "ε", "\\varepsilon", !0), h(p, w, E, "ϑ", "\\vartheta", !0), h(p, w, E, "ϖ", "\\varpi", !0), h(p, w, E, "ϱ", "\\varrho", !0), h(p, w, E, "ς", "\\varsigma", !0), h(p, w, E, "φ", "\\varphi", !0), h(p, w, ue, "∗", "*", !0), h(p, w, ue, "+", "+"), h(p, w, ue, "−", "-", !0), h(p, w, ue, "⋅", "\\cdot", !0), h(p, w, ue, "∘", "\\circ", !0), h(p, w, ue, "÷", "\\div", !0), h(p, w, ue, "±", "\\pm", !0), h(p, w, ue, "×", "\\times", !0), h(p, w, ue, "∩", "\\cap", !0), h(p, w, ue, "∪", "\\cup", !0), h(p, w, ue, "∖", "\\setminus", !0), h(p, w, ue, "∧", "\\land"), h(p, w, ue, "∨", "\\lor"), h(p, w, ue, "∧", "\\wedge", !0), h(p, w, ue, "∨", "\\vee", !0), h(p, w, T, "√", "\\surd"), h(p, w, se, "⟨", "\\langle", !0), h(p, w, se, "∣", "\\lvert"), h(p, w, se, "∥", "\\lVert"), h(p, w, lt, "?", "?"), h(p, w, lt, "!", "!"), h(p, w, lt, "⟩", "\\rangle", !0), h(p, w, lt, "∣", "\\rvert"), h(p, w, lt, "∥", "\\rVert"), h(p, w, x, "=", "="), h(p, w, x, ":", ":"), h(p, w, x, "≈", "\\approx", !0), h(p, w, x, "≅", "\\cong", !0), h(p, w, x, "≥", "\\ge"), h(p, w, x, "≥", "\\geq", !0), h(p, w, x, "←", "\\gets"), h(p, w, x, ">", "\\gt", !0), h(p, w, x, "∈", "\\in", !0), h(p, w, x, "", "\\@not"), h(p, w, x, "⊂", "\\subset", !0), h(p, w, x, "⊃", "\\supset", !0), h(p, w, x, "⊆", "\\subseteq", !0), h(p, w, x, "⊇", "\\supseteq", !0), h(p, S, x, "⊈", "\\nsubseteq", !0), h(p, S, x, "⊉", "\\nsupseteq", !0), h(p, w, x, "⊨", "\\models"), h(p, w, x, "←", "\\leftarrow", !0), h(p, w, x, "≤", "\\le"), h(p, w, x, "≤", "\\leq", !0), h(p, w, x, "<", "\\lt", !0), h(p, w, x, "→", "\\rightarrow", !0), h(p, w, x, "→", "\\to"), h(p, S, x, "≱", "\\ngeq", !0), h(p, S, x, "≰", "\\nleq", !0), h(p, w, Ve, " ", "\\ "), h(p, w, Ve, " ", "\\space"), h(p, w, Ve, " ", "\\nobreakspace"), h(j, w, Ve, " ", "\\ "), h(j, w, Ve, " ", " "), h(j, w, Ve, " ", "\\space"), h(j, w, Ve, " ", "\\nobreakspace"), h(p, w, Ve, null, "\\nobreak"), h(p, w, Ve, null, "\\allowbreak"), h(p, w, Be, ",", ","), h(p, w, Be, ";", ";"), h(p, S, ue, "⊼", "\\barwedge", !0), h(p, S, ue, "⊻", "\\veebar", !0), h(p, w, ue, "⊙", "\\odot", !0), h(p, w, ue, "⊕", "\\oplus", !0), h(p, w, ue, "⊗", "\\otimes", !0), h(p, w, T, "∂", "\\partial", !0), h(p, w, ue, "⊘", "\\oslash", !0), h(p, S, ue, "⊚", "\\circledcirc", !0), h(p, S, ue, "⊡", "\\boxdot", !0), h(p, w, ue, "△", "\\bigtriangleup"), h(p, w, ue, "▽", "\\bigtriangledown"), h(p, w, ue, "†", "\\dagger"), h(p, w, ue, "⋄", "\\diamond"), h(p, w, ue, "⋆", "\\star"), h(p, w, ue, "◃", "\\triangleleft"), h(p, w, ue, "▹", "\\triangleright"), h(p, w, se, "{", "\\{"), h(j, w, T, "{", "\\{"), h(j, w, T, "{", "\\textbraceleft"), h(p, w, lt, "}", "\\}"), h(j, w, T, "}", "\\}"), h(j, w, T, "}", "\\textbraceright"), h(p, w, se, "{", "\\lbrace"), h(p, w, lt, "}", "\\rbrace"), h(p, w, se, "[", "\\lbrack", !0), h(j, w, T, "[", "\\lbrack", !0), h(p, w, lt, "]", "\\rbrack", !0), h(j, w, T, "]", "\\rbrack", !0), h(p, w, se, "(", "\\lparen", !0), h(p, w, lt, ")", "\\rparen", !0), h(j, w, T, "<", "\\textless", !0), h(j, w, T, ">", "\\textgreater", !0), h(p, w, se, "⌊", "\\lfloor", !0), h(p, w, lt, "⌋", "\\rfloor", !0), h(p, w, se, "⌈", "\\lceil", !0), h(p, w, lt, "⌉", "\\rceil", !0), h(p, w, T, "\\", "\\backslash"), h(p, w, T, "∣", "|"), h(p, w, T, "∣", "\\vert"), h(j, w, T, "|", "\\textbar", !0), h(p, w, T, "∥", "\\|"), h(p, w, T, "∥", "\\Vert"), h(j, w, T, "∥", "\\textbardbl"), h(j, w, T, "~", "\\textasciitilde"), h(j, w, T, "\\", "\\textbackslash"), h(j, w, T, "^", "\\textasciicircum"), h(p, w, x, "↑", "\\uparrow", !0), h(p, w, x, "⇑", "\\Uparrow", !0), h(p, w, x, "↓", "\\downarrow", !0), h(p, w, x, "⇓", "\\Downarrow", !0), h(p, w, x, "↕", "\\updownarrow", !0), h(p, w, x, "⇕", "\\Updownarrow", !0), h(p, w, Z, "∐", "\\coprod"), h(p, w, Z, "⋁", "\\bigvee"), h(p, w, Z, "⋀", "\\bigwedge"), h(p, w, Z, "⨄", "\\biguplus"), h(p, w, Z, "⋂", "\\bigcap"), h(p, w, Z, "⋃", "\\bigcup"), h(p, w, Z, "∫", "\\int"), h(p, w, Z, "∫", "\\intop"), h(p, w, Z, "∬", "\\iint"), h(p, w, Z, "∭", "\\iiint"), h(p, w, Z, "∏", "\\prod"), h(p, w, Z, "∑", "\\sum"), h(p, w, Z, "⨂", "\\bigotimes"), h(p, w, Z, "⨁", "\\bigoplus"), h(p, w, Z, "⨀", "\\bigodot"), h(p, w, Z, "∮", "\\oint"), h(p, w, Z, "∯", "\\oiint"), h(p, w, Z, "∰", "\\oiiint"), h(p, w, Z, "⨆", "\\bigsqcup"), h(p, w, Z, "∫", "\\smallint"), h(j, w, he, "…", "\\textellipsis"), h(p, w, he, "…", "\\mathellipsis"), h(j, w, he, "…", "\\ldots", !0), h(p, w, he, "…", "\\ldots", !0), h(p, w, he, "⋯", "\\@cdots", !0), h(p, w, he, "⋱", "\\ddots", !0), h(p, w, T, "⋮", "\\varvdots"), h(p, w, Pe, "ˊ", "\\acute"), h(p, w, Pe, "ˋ", "\\grave"), h(p, w, Pe, "¨", "\\ddot"), h(p, w, Pe, "~", "\\tilde"), h(p, w, Pe, "ˉ", "\\bar"), h(p, w, Pe, "˘", "\\breve"), h(p, w, Pe, "ˇ", "\\check"), h(p, w, Pe, "^", "\\hat"), h(p, w, Pe, "⃗", "\\vec"), h(p, w, Pe, "˙", "\\dot"), h(p, w, Pe, "˚", "\\mathring"), h(p, w, E, "", "\\@imath"), h(p, w, E, "", "\\@jmath"), h(p, w, T, "ı", "ı"), h(p, w, T, "ȷ", "ȷ"), h(j, w, T, "ı", "\\i", !0), h(j, w, T, "ȷ", "\\j", !0), h(j, w, T, "ß", "\\ss", !0), h(j, w, T, "æ", "\\ae", !0), h(j, w, T, "œ", "\\oe", !0), h(j, w, T, "ø", "\\o", !0), h(j, w, T, "Æ", "\\AE", !0), h(j, w, T, "Œ", "\\OE", !0), h(j, w, T, "Ø", "\\O", !0), h(j, w, Pe, "ˊ", "\\'"), h(j, w, Pe, "ˋ", "\\`"), h(j, w, Pe, "ˆ", "\\^"), h(j, w, Pe, "˜", "\\~"), h(j, w, Pe, "ˉ", "\\="), h(j, w, Pe, "˘", "\\u"), h(j, w, Pe, "˙", "\\."), h(j, w, Pe, "¸", "\\c"), h(j, w, Pe, "˚", "\\r"), h(j, w, Pe, "ˇ", "\\v"), h(j, w, Pe, "¨", '\\"'), h(j, w, Pe, "˝", "\\H"), h(j, w, Pe, "◯", "\\textcircled");
          var n0 = {
            "--": !0,
            "---": !0,
            "``": !0,
            "''": !0
          };
          h(j, w, T, "–", "--", !0), h(j, w, T, "–", "\\textendash"), h(j, w, T, "—", "---", !0), h(j, w, T, "—", "\\textemdash"), h(j, w, T, "‘", "`", !0), h(j, w, T, "‘", "\\textquoteleft"), h(j, w, T, "’", "'", !0), h(j, w, T, "’", "\\textquoteright"), h(j, w, T, "“", "``", !0), h(j, w, T, "“", "\\textquotedblleft"), h(j, w, T, "”", "''", !0), h(j, w, T, "”", "\\textquotedblright"), h(p, w, T, "°", "\\degree", !0), h(j, w, T, "°", "\\degree"), h(j, w, T, "°", "\\textdegree", !0), h(p, w, T, "£", "\\pounds"), h(p, w, T, "£", "\\mathsterling", !0), h(j, w, T, "£", "\\pounds"), h(j, w, T, "£", "\\textsterling", !0), h(p, S, T, "✠", "\\maltese"), h(j, S, T, "✠", "\\maltese");
          for (var E0 = '0123456789/@."', it = 0; it < E0.length; it++) {
            var Tr = E0.charAt(it);
            h(p, w, T, Tr, Tr);
          }
          for (var Br = '0123456789!@*()-=+";:?/.,', Jn = 0; Jn < Br.length; Jn++) {
            var Ci = Br.charAt(Jn);
            h(j, w, T, Ci, Ci);
          }
          for (var rn = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", $n = 0; $n < rn.length; $n++) {
            var nn = rn.charAt($n);
            h(p, w, E, nn, nn), h(j, w, T, nn, nn);
          }
          h(p, S, T, "C", "ℂ"), h(j, S, T, "C", "ℂ"), h(p, S, T, "H", "ℍ"), h(j, S, T, "H", "ℍ"), h(p, S, T, "N", "ℕ"), h(j, S, T, "N", "ℕ"), h(p, S, T, "P", "ℙ"), h(j, S, T, "P", "ℙ"), h(p, S, T, "Q", "ℚ"), h(j, S, T, "Q", "ℚ"), h(p, S, T, "R", "ℝ"), h(j, S, T, "R", "ℝ"), h(p, S, T, "Z", "ℤ"), h(j, S, T, "Z", "ℤ"), h(p, w, E, "h", "ℎ"), h(j, w, E, "h", "ℎ");
          for (var ge = "", dt = 0; dt < rn.length; dt++) {
            var Qe = rn.charAt(dt);
            ge = String.fromCharCode(55349, 56320 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56372 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56424 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56580 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56684 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56736 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56788 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56840 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56944 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), dt < 26 && (ge = String.fromCharCode(55349, 56632 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge), ge = String.fromCharCode(55349, 56476 + dt), h(p, w, E, Qe, ge), h(j, w, T, Qe, ge));
          }
          ge = "𝕜", h(p, w, E, "k", ge), h(j, w, T, "k", ge);
          for (var X0 = 0; X0 < 10; X0++) {
            var F0 = X0.toString();
            ge = String.fromCharCode(55349, 57294 + X0), h(p, w, E, F0, ge), h(j, w, T, F0, ge), ge = String.fromCharCode(55349, 57314 + X0), h(p, w, E, F0, ge), h(j, w, T, F0, ge), ge = String.fromCharCode(55349, 57324 + X0), h(p, w, E, F0, ge), h(j, w, T, F0, ge), ge = String.fromCharCode(55349, 57334 + X0), h(p, w, E, F0, ge), h(j, w, T, F0, ge);
          }
          for (var ea = "ÐÞþ", ta = 0; ta < ea.length; ta++) {
            var an = ea.charAt(ta);
            h(p, w, E, an, an), h(j, w, T, an, an);
          }
          var ln = [
            ["mathbf", "textbf", "Main-Bold"],
            // A-Z bold upright
            ["mathbf", "textbf", "Main-Bold"],
            // a-z bold upright
            ["mathnormal", "textit", "Math-Italic"],
            // A-Z italic
            ["mathnormal", "textit", "Math-Italic"],
            // a-z italic
            ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
            // A-Z bold italic
            ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
            // a-z bold italic
            // Map fancy A-Z letters to script, not calligraphic.
            // This aligns with unicode-math and math fonts (except Cambria Math).
            ["mathscr", "textscr", "Script-Regular"],
            // A-Z script
            ["", "", ""],
            // a-z script.  No font
            ["", "", ""],
            // A-Z bold script. No font
            ["", "", ""],
            // a-z bold script. No font
            ["mathfrak", "textfrak", "Fraktur-Regular"],
            // A-Z Fraktur
            ["mathfrak", "textfrak", "Fraktur-Regular"],
            // a-z Fraktur
            ["mathbb", "textbb", "AMS-Regular"],
            // A-Z double-struck
            ["mathbb", "textbb", "AMS-Regular"],
            // k double-struck
            // Note that we are using a bold font, but font metrics for regular Fraktur.
            ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
            // A-Z bold Fraktur
            ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
            // a-z bold Fraktur
            ["mathsf", "textsf", "SansSerif-Regular"],
            // A-Z sans-serif
            ["mathsf", "textsf", "SansSerif-Regular"],
            // a-z sans-serif
            ["mathboldsf", "textboldsf", "SansSerif-Bold"],
            // A-Z bold sans-serif
            ["mathboldsf", "textboldsf", "SansSerif-Bold"],
            // a-z bold sans-serif
            ["mathitsf", "textitsf", "SansSerif-Italic"],
            // A-Z italic sans-serif
            ["mathitsf", "textitsf", "SansSerif-Italic"],
            // a-z italic sans-serif
            ["", "", ""],
            // A-Z bold italic sans. No font
            ["", "", ""],
            // a-z bold italic sans. No font
            ["mathtt", "texttt", "Typewriter-Regular"],
            // A-Z monospace
            ["mathtt", "texttt", "Typewriter-Regular"]
            // a-z monospace
          ], Ti = [
            ["mathbf", "textbf", "Main-Bold"],
            // 0-9 bold
            ["", "", ""],
            // 0-9 double-struck. No KaTeX font.
            ["mathsf", "textsf", "SansSerif-Regular"],
            // 0-9 sans-serif
            ["mathboldsf", "textboldsf", "SansSerif-Bold"],
            // 0-9 bold sans-serif
            ["mathtt", "texttt", "Typewriter-Regular"]
            // 0-9 monospace
          ], qu = function(e, r) {
            var a = e.charCodeAt(0), l = e.charCodeAt(1), c = (a - 55296) * 1024 + (l - 56320) + 65536, d = r === "math" ? 0 : 1;
            if (119808 <= c && c < 120484) {
              var b = Math.floor((c - 119808) / 26);
              return [ln[b][2], ln[b][d]];
            } else if (120782 <= c && c <= 120831) {
              var _ = Math.floor((c - 120782) / 10);
              return [Ti[_][2], Ti[_][d]];
            } else {
              if (c === 120485 || c === 120486)
                return [ln[0][2], ln[0][d]];
              if (120486 < c && c < 120782)
                return ["", ""];
              throw new u("Unsupported character: " + e);
            }
          }, sn = function(e, r, a) {
            return Ge[a][e] && Ge[a][e].replace && (e = Ge[a][e].replace), {
              value: e,
              metrics: t0(e, r, a)
            };
          }, Zt = function(e, r, a, l, c) {
            var d = sn(e, r, a), b = d.metrics;
            e = d.value;
            var _;
            if (b) {
              var A = b.italic;
              (a === "text" || l && l.font === "mathit") && (A = 0), _ = new mt(e, b.height, b.depth, A, b.skew, b.width, c);
            } else
              typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + r + "' and mode '" + a + "'")), _ = new mt(e, 0, 0, 0, 0, 0, c);
            if (l) {
              _.maxFontSize = l.sizeMultiplier, l.style.isTight() && _.classes.push("mtight");
              var C = l.getColor();
              C && (_.style.color = C);
            }
            return _;
          }, Pu = function(e, r, a, l) {
            return l === void 0 && (l = []), a.font === "boldsymbol" && sn(e, "Main-Bold", r).metrics ? Zt(e, "Main-Bold", r, a, l.concat(["mathbf"])) : e === "\\" || Ge[r][e].font === "main" ? Zt(e, "Main-Regular", r, a, l) : Zt(e, "AMS-Regular", r, a, l.concat(["amsrm"]));
          }, Hu = function(e, r, a, l, c) {
            return c !== "textord" && sn(e, "Math-BoldItalic", r).metrics ? {
              fontName: "Math-BoldItalic",
              fontClass: "boldsymbol"
            } : {
              fontName: "Main-Bold",
              fontClass: "mathbf"
            };
          }, Uu = function(e, r, a) {
            var l = e.mode, c = e.text, d = ["mord"], b = l === "math" || l === "text" && r.font, _ = b ? r.font : r.fontFamily, A = "", C = "";
            if (c.charCodeAt(0) === 55349) {
              var L = qu(c, l);
              A = L[0], C = L[1];
            }
            if (A.length > 0)
              return Zt(c, A, l, r, d.concat(C));
            if (_) {
              var H, P;
              if (_ === "boldsymbol") {
                var W = Hu(c, l, r, d, a);
                H = W.fontName, P = [W.fontClass];
              } else
                b ? (H = zi[_].fontName, P = [_]) : (H = on(_, r.fontWeight, r.fontShape), P = [_, r.fontWeight, r.fontShape]);
              if (sn(c, H, l).metrics)
                return Zt(c, H, l, r, d.concat(P));
              if (n0.hasOwnProperty(c) && H.slice(0, 10) === "Typewriter") {
                for (var te = [], ie = 0; ie < c.length; ie++)
                  te.push(Zt(c[ie], H, l, r, d.concat(P)));
                return Mi(te);
              }
            }
            if (a === "mathord")
              return Zt(c, "Math-Italic", l, r, d.concat(["mathnormal"]));
            if (a === "textord") {
              var ce = Ge[l][c] && Ge[l][c].font;
              if (ce === "ams") {
                var me = on("amsrm", r.fontWeight, r.fontShape);
                return Zt(c, me, l, r, d.concat("amsrm", r.fontWeight, r.fontShape));
              } else if (ce === "main" || !ce) {
                var de = on("textrm", r.fontWeight, r.fontShape);
                return Zt(c, de, l, r, d.concat(r.fontWeight, r.fontShape));
              } else {
                var Te = on(ce, r.fontWeight, r.fontShape);
                return Zt(c, Te, l, r, d.concat(Te, r.fontWeight, r.fontShape));
              }
            } else
              throw new Error("unexpected type: " + a + " in makeOrd");
          }, Gu = function(e, r) {
            if (wt(e.classes) !== wt(r.classes) || e.skew !== r.skew || e.maxFontSize !== r.maxFontSize)
              return !1;
            if (e.classes.length === 1) {
              var a = e.classes[0];
              if (a === "mbin" || a === "mord")
                return !1;
            }
            for (var l in e.style)
              if (e.style.hasOwnProperty(l) && e.style[l] !== r.style[l])
                return !1;
            for (var c in r.style)
              if (r.style.hasOwnProperty(c) && e.style[c] !== r.style[c])
                return !1;
            return !0;
          }, Vu = function(e) {
            for (var r = 0; r < e.length - 1; r++) {
              var a = e[r], l = e[r + 1];
              a instanceof mt && l instanceof mt && Gu(a, l) && (a.text += l.text, a.height = Math.max(a.height, l.height), a.depth = Math.max(a.depth, l.depth), a.italic = l.italic, e.splice(r + 1, 1), r--);
            }
            return e;
          }, ra = function(e) {
            for (var r = 0, a = 0, l = 0, c = 0; c < e.children.length; c++) {
              var d = e.children[c];
              d.height > r && (r = d.height), d.depth > a && (a = d.depth), d.maxFontSize > l && (l = d.maxFontSize);
            }
            e.height = r, e.depth = a, e.maxFontSize = l;
          }, _t = function(e, r, a, l) {
            var c = new qt(e, r, a, l);
            return ra(c), c;
          }, Bi = function(e, r, a, l) {
            return new qt(e, r, a, l);
          }, Wu = function(e, r, a) {
            var l = _t([e], [], r);
            return l.height = Math.max(a || r.fontMetrics().defaultRuleThickness, r.minRuleThickness), l.style.borderBottomWidth = ne(l.height), l.maxFontSize = 1, l;
          }, ju = function(e, r, a, l) {
            var c = new Sr(e, r, a, l);
            return ra(c), c;
          }, Mi = function(e) {
            var r = new k0(e);
            return ra(r), r;
          }, Xu = function(e, r) {
            return e instanceof k0 ? _t([], [e], r) : e;
          }, Yu = function(e) {
            if (e.positionType === "individualShift") {
              for (var r = e.children, a = [r[0]], l = -r[0].shift - r[0].elem.depth, c = l, d = 1; d < r.length; d++) {
                var b = -r[d].shift - c - r[d].elem.depth, _ = b - (r[d - 1].elem.height + r[d - 1].elem.depth);
                c = c + b, a.push({
                  type: "kern",
                  size: _
                }), a.push(r[d]);
              }
              return {
                children: a,
                depth: l
              };
            }
            var A;
            if (e.positionType === "top") {
              for (var C = e.positionData, L = 0; L < e.children.length; L++) {
                var H = e.children[L];
                C -= H.type === "kern" ? H.size : H.elem.height + H.elem.depth;
              }
              A = C;
            } else if (e.positionType === "bottom")
              A = -e.positionData;
            else {
              var P = e.children[0];
              if (P.type !== "elem")
                throw new Error('First child must have type "elem".');
              if (e.positionType === "shift")
                A = -P.elem.depth - e.positionData;
              else if (e.positionType === "firstBaseline")
                A = -P.elem.depth;
              else
                throw new Error("Invalid positionType " + e.positionType + ".");
            }
            return {
              children: e.children,
              depth: A
            };
          }, Zu = function(e, r) {
            for (var a = Yu(e), l = a.children, c = a.depth, d = 0, b = 0; b < l.length; b++) {
              var _ = l[b];
              if (_.type === "elem") {
                var A = _.elem;
                d = Math.max(d, A.maxFontSize, A.height);
              }
            }
            d += 2;
            var C = _t(["pstrut"], []);
            C.style.height = ne(d);
            for (var L = [], H = c, P = c, W = c, te = 0; te < l.length; te++) {
              var ie = l[te];
              if (ie.type === "kern")
                W += ie.size;
              else {
                var ce = ie.elem, me = ie.wrapperClasses || [], de = ie.wrapperStyle || {}, Te = _t(me, [C, ce], void 0, de);
                Te.style.top = ne(-d - W - ce.depth), ie.marginLeft && (Te.style.marginLeft = ie.marginLeft), ie.marginRight && (Te.style.marginRight = ie.marginRight), L.push(Te), W += ce.height + ce.depth;
              }
              H = Math.min(H, W), P = Math.max(P, W);
            }
            var ye = _t(["vlist"], L);
            ye.style.height = ne(P);
            var ze;
            if (H < 0) {
              var Fe = _t([], []), Le = _t(["vlist"], [Fe]);
              Le.style.height = ne(-H);
              var We = _t(["vlist-s"], [new mt("​")]);
              ze = [_t(["vlist-r"], [ye, We]), _t(["vlist-r"], [Le])];
            } else
              ze = [_t(["vlist-r"], [ye])];
            var st = _t(["vlist-t"], ze);
            return ze.length === 2 && st.classes.push("vlist-t2"), st.height = P, st.depth = -H, st;
          }, Ku = function(e, r) {
            var a = _t(["mspace"], [], r), l = qe(e, r);
            return a.style.marginRight = ne(l), a;
          }, on = function(e, r, a) {
            var l = "";
            switch (e) {
              case "amsrm":
                l = "AMS";
                break;
              case "textrm":
                l = "Main";
                break;
              case "textsf":
                l = "SansSerif";
                break;
              case "texttt":
                l = "Typewriter";
                break;
              default:
                l = e;
            }
            var c;
            return r === "textbf" && a === "textit" ? c = "BoldItalic" : r === "textbf" ? c = "Bold" : r === "textit" ? c = "Italic" : c = "Regular", l + "-" + c;
          }, zi = {
            // styles
            mathbf: {
              variant: "bold",
              fontName: "Main-Bold"
            },
            mathrm: {
              variant: "normal",
              fontName: "Main-Regular"
            },
            textit: {
              variant: "italic",
              fontName: "Main-Italic"
            },
            mathit: {
              variant: "italic",
              fontName: "Main-Italic"
            },
            mathnormal: {
              variant: "italic",
              fontName: "Math-Italic"
            },
            // "boldsymbol" is missing because they require the use of multiple fonts:
            // Math-BoldItalic and Main-Bold.  This is handled by a special case in
            // makeOrd which ends up calling boldsymbol.
            // families
            mathbb: {
              variant: "double-struck",
              fontName: "AMS-Regular"
            },
            mathcal: {
              variant: "script",
              fontName: "Caligraphic-Regular"
            },
            mathfrak: {
              variant: "fraktur",
              fontName: "Fraktur-Regular"
            },
            mathscr: {
              variant: "script",
              fontName: "Script-Regular"
            },
            mathsf: {
              variant: "sans-serif",
              fontName: "SansSerif-Regular"
            },
            mathtt: {
              variant: "monospace",
              fontName: "Typewriter-Regular"
            }
          }, Ni = {
            //   path, width, height
            vec: ["vec", 0.471, 0.714],
            // values from the font glyph
            oiintSize1: ["oiintSize1", 0.957, 0.499],
            // oval to overlay the integrand
            oiintSize2: ["oiintSize2", 1.472, 0.659],
            oiiintSize1: ["oiiintSize1", 1.304, 0.499],
            oiiintSize2: ["oiiintSize2", 1.98, 0.659]
          }, Qu = function(e, r) {
            var a = Ni[e], l = a[0], c = a[1], d = a[2], b = new r0(l), _ = new Pt([b], {
              width: ne(c),
              height: ne(d),
              // Override CSS rule `.katex svg { width: 100% }`
              style: "width:" + ne(c),
              viewBox: "0 0 " + 1e3 * c + " " + 1e3 * d,
              preserveAspectRatio: "xMinYMin"
            }), A = Bi(["overlay"], [_], r);
            return A.height = d, A.style.height = ne(d), A.style.width = ne(c), A;
          }, I = {
            fontMap: zi,
            makeSymbol: Zt,
            mathsym: Pu,
            makeSpan: _t,
            makeSvgSpan: Bi,
            makeLineSpan: Wu,
            makeAnchor: ju,
            makeFragment: Mi,
            wrapFragment: Xu,
            makeVList: Zu,
            makeOrd: Uu,
            makeGlue: Ku,
            staticSvg: Qu,
            svgData: Ni,
            tryCombineChars: Vu
          }, Xe = {
            number: 3,
            unit: "mu"
          }, Y0 = {
            number: 4,
            unit: "mu"
          }, d0 = {
            number: 5,
            unit: "mu"
          }, Ju = {
            mord: {
              mop: Xe,
              mbin: Y0,
              mrel: d0,
              minner: Xe
            },
            mop: {
              mord: Xe,
              mop: Xe,
              mrel: d0,
              minner: Xe
            },
            mbin: {
              mord: Y0,
              mop: Y0,
              mopen: Y0,
              minner: Y0
            },
            mrel: {
              mord: d0,
              mop: d0,
              mopen: d0,
              minner: d0
            },
            mopen: {},
            mclose: {
              mop: Xe,
              mbin: Y0,
              mrel: d0,
              minner: Xe
            },
            mpunct: {
              mord: Xe,
              mop: Xe,
              mrel: d0,
              mopen: Xe,
              mclose: Xe,
              mpunct: Xe,
              minner: Xe
            },
            minner: {
              mord: Xe,
              mop: Xe,
              mbin: Y0,
              mrel: d0,
              mopen: Xe,
              mpunct: Xe,
              minner: Xe
            }
          }, $u = {
            mord: {
              mop: Xe
            },
            mop: {
              mord: Xe,
              mop: Xe
            },
            mbin: {},
            mrel: {},
            mopen: {},
            mclose: {
              mop: Xe
            },
            mpunct: {},
            minner: {
              mop: Xe
            }
          }, Ri = {}, un = {}, cn = {};
          function oe(m) {
            for (var e = m.type, r = m.names, a = m.props, l = m.handler, c = m.htmlBuilder, d = m.mathmlBuilder, b = {
              type: e,
              numArgs: a.numArgs,
              argTypes: a.argTypes,
              allowedInArgument: !!a.allowedInArgument,
              allowedInText: !!a.allowedInText,
              allowedInMath: a.allowedInMath === void 0 ? !0 : a.allowedInMath,
              numOptionalArgs: a.numOptionalArgs || 0,
              infix: !!a.infix,
              primitive: !!a.primitive,
              handler: l
            }, _ = 0; _ < r.length; ++_)
              Ri[r[_]] = b;
            e && (c && (un[e] = c), d && (cn[e] = d));
          }
          function Z0(m) {
            var e = m.type, r = m.htmlBuilder, a = m.mathmlBuilder;
            oe({
              type: e,
              names: [],
              props: {
                numArgs: 0
              },
              handler: function() {
                throw new Error("Should never be called.");
              },
              htmlBuilder: r,
              mathmlBuilder: a
            });
          }
          var hn = function(e) {
            return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
          }, et = function(e) {
            return e.type === "ordgroup" ? e.body : [e];
          }, p0 = I.makeSpan, e1 = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"], t1 = ["rightmost", "mrel", "mclose", "mpunct"], r1 = {
            display: re.DISPLAY,
            text: re.TEXT,
            script: re.SCRIPT,
            scriptscript: re.SCRIPTSCRIPT
          }, n1 = {
            mord: "mord",
            mop: "mop",
            mbin: "mbin",
            mrel: "mrel",
            mopen: "mopen",
            mclose: "mclose",
            mpunct: "mpunct",
            minner: "minner"
          }, at = function(e, r, a, l) {
            l === void 0 && (l = [null, null]);
            for (var c = [], d = 0; d < e.length; d++) {
              var b = Ee(e[d], r);
              if (b instanceof k0) {
                var _ = b.children;
                c.push.apply(c, _);
              } else
                c.push(b);
            }
            if (I.tryCombineChars(c), !a)
              return c;
            var A = r;
            if (e.length === 1) {
              var C = e[0];
              C.type === "sizing" ? A = r.havingSize(C.size) : C.type === "styling" && (A = r.havingStyle(r1[C.style]));
            }
            var L = p0([l[0] || "leftmost"], [], r), H = p0([l[1] || "rightmost"], [], r), P = a === "root";
            return Li(c, function(W, te) {
              var ie = te.classes[0], ce = W.classes[0];
              ie === "mbin" && M.contains(t1, ce) ? te.classes[0] = "mord" : ce === "mbin" && M.contains(e1, ie) && (W.classes[0] = "mord");
            }, {
              node: L
            }, H, P), Li(c, function(W, te) {
              var ie = na(te), ce = na(W), me = ie && ce ? W.hasClass("mtight") ? $u[ie][ce] : Ju[ie][ce] : null;
              if (me)
                return I.makeGlue(me, A);
            }, {
              node: L
            }, H, P), c;
          }, Li = function m(e, r, a, l, c) {
            l && e.push(l);
            for (var d = 0; d < e.length; d++) {
              var b = e[d], _ = Ii(b);
              if (_) {
                m(_.children, r, a, null, c);
                continue;
              }
              var A = !b.hasClass("mspace");
              if (A) {
                var C = r(b, a.node);
                C && (a.insertAfter ? a.insertAfter(C) : (e.unshift(C), d++));
              }
              A ? a.node = b : c && b.hasClass("newline") && (a.node = p0(["leftmost"])), a.insertAfter = /* @__PURE__ */ function(L) {
                return function(H) {
                  e.splice(L + 1, 0, H), d++;
                };
              }(d);
            }
            l && e.pop();
          }, Ii = function(e) {
            return e instanceof k0 || e instanceof Sr || e instanceof qt && e.hasClass("enclosing") ? e : null;
          }, a1 = function m(e, r) {
            var a = Ii(e);
            if (a) {
              var l = a.children;
              if (l.length) {
                if (r === "right")
                  return m(l[l.length - 1], "right");
                if (r === "left")
                  return m(l[0], "left");
              }
            }
            return e;
          }, na = function(e, r) {
            return e ? (r && (e = a1(e, r)), n1[e.classes[0]] || null) : null;
          }, Mr = function(e, r) {
            var a = ["nulldelimiter"].concat(e.baseSizingClasses());
            return p0(r.concat(a));
          }, Ee = function(e, r, a) {
            if (!e)
              return p0();
            if (un[e.type]) {
              var l = un[e.type](e, r);
              if (a && r.size !== a.size) {
                l = p0(r.sizingClasses(a), [l], r);
                var c = r.sizeMultiplier / a.sizeMultiplier;
                l.height *= c, l.depth *= c;
              }
              return l;
            } else
              throw new u("Got group of unknown type: '" + e.type + "'");
          };
          function fn(m, e) {
            var r = p0(["base"], m, e), a = p0(["strut"]);
            return a.style.height = ne(r.height + r.depth), r.depth && (a.style.verticalAlign = ne(-r.depth)), r.children.unshift(a), r;
          }
          function aa(m, e) {
            var r = null;
            m.length === 1 && m[0].type === "tag" && (r = m[0].tag, m = m[0].body);
            var a = at(m, e, "root"), l;
            a.length === 2 && a[1].hasClass("tag") && (l = a.pop());
            for (var c = [], d = [], b = 0; b < a.length; b++)
              if (d.push(a[b]), a[b].hasClass("mbin") || a[b].hasClass("mrel") || a[b].hasClass("allowbreak")) {
                for (var _ = !1; b < a.length - 1 && a[b + 1].hasClass("mspace") && !a[b + 1].hasClass("newline"); )
                  b++, d.push(a[b]), a[b].hasClass("nobreak") && (_ = !0);
                _ || (c.push(fn(d, e)), d = []);
              } else
                a[b].hasClass("newline") && (d.pop(), d.length > 0 && (c.push(fn(d, e)), d = []), c.push(a[b]));
            d.length > 0 && c.push(fn(d, e));
            var A;
            r ? (A = fn(at(r, e, !0)), A.classes = ["tag"], c.push(A)) : l && c.push(l);
            var C = p0(["katex-html"], c);
            if (C.setAttribute("aria-hidden", "true"), A) {
              var L = A.children[0];
              L.style.height = ne(C.height + C.depth), C.depth && (L.style.verticalAlign = ne(-C.depth));
            }
            return C;
          }
          function Oi(m) {
            return new k0(m);
          }
          var Ht = /* @__PURE__ */ function() {
            function m(r, a, l) {
              this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = r, this.attributes = {}, this.children = a || [], this.classes = l || [];
            }
            var e = m.prototype;
            return e.setAttribute = function(a, l) {
              this.attributes[a] = l;
            }, e.getAttribute = function(a) {
              return this.attributes[a];
            }, e.toNode = function() {
              var a = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
              for (var l in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, l) && a.setAttribute(l, this.attributes[l]);
              this.classes.length > 0 && (a.className = wt(this.classes));
              for (var c = 0; c < this.children.length; c++)
                a.appendChild(this.children[c].toNode());
              return a;
            }, e.toMarkup = function() {
              var a = "<" + this.type;
              for (var l in this.attributes)
                Object.prototype.hasOwnProperty.call(this.attributes, l) && (a += " " + l + '="', a += M.escape(this.attributes[l]), a += '"');
              this.classes.length > 0 && (a += ' class ="' + M.escape(wt(this.classes)) + '"'), a += ">";
              for (var c = 0; c < this.children.length; c++)
                a += this.children[c].toMarkup();
              return a += "</" + this.type + ">", a;
            }, e.toText = function() {
              return this.children.map(function(a) {
                return a.toText();
              }).join("");
            }, m;
          }(), zr = /* @__PURE__ */ function() {
            function m(r) {
              this.text = void 0, this.text = r;
            }
            var e = m.prototype;
            return e.toNode = function() {
              return document.createTextNode(this.text);
            }, e.toMarkup = function() {
              return M.escape(this.toText());
            }, e.toText = function() {
              return this.text;
            }, m;
          }(), i1 = /* @__PURE__ */ function() {
            function m(r) {
              this.width = void 0, this.character = void 0, this.width = r, r >= 0.05555 && r <= 0.05556 ? this.character = " " : r >= 0.1666 && r <= 0.1667 ? this.character = " " : r >= 0.2222 && r <= 0.2223 ? this.character = " " : r >= 0.2777 && r <= 0.2778 ? this.character = "  " : r >= -0.05556 && r <= -0.05555 ? this.character = " ⁣" : r >= -0.1667 && r <= -0.1666 ? this.character = " ⁣" : r >= -0.2223 && r <= -0.2222 ? this.character = " ⁣" : r >= -0.2778 && r <= -0.2777 ? this.character = " ⁣" : this.character = null;
            }
            var e = m.prototype;
            return e.toNode = function() {
              if (this.character)
                return document.createTextNode(this.character);
              var a = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
              return a.setAttribute("width", ne(this.width)), a;
            }, e.toMarkup = function() {
              return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + ne(this.width) + '"/>';
            }, e.toText = function() {
              return this.character ? this.character : " ";
            }, m;
          }(), Q = {
            MathNode: Ht,
            TextNode: zr,
            SpaceNode: i1,
            newDocumentFragment: Oi
          }, Ut = function(e, r, a) {
            return Ge[r][e] && Ge[r][e].replace && e.charCodeAt(0) !== 55349 && !(n0.hasOwnProperty(e) && a && (a.fontFamily && a.fontFamily.slice(4, 6) === "tt" || a.font && a.font.slice(4, 6) === "tt")) && (e = Ge[r][e].replace), new Q.TextNode(e);
          }, ia = function(e) {
            return e.length === 1 ? e[0] : new Q.MathNode("mrow", e);
          }, la = function(e, r) {
            if (r.fontFamily === "texttt")
              return "monospace";
            if (r.fontFamily === "textsf")
              return r.fontShape === "textit" && r.fontWeight === "textbf" ? "sans-serif-bold-italic" : r.fontShape === "textit" ? "sans-serif-italic" : r.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
            if (r.fontShape === "textit" && r.fontWeight === "textbf")
              return "bold-italic";
            if (r.fontShape === "textit")
              return "italic";
            if (r.fontWeight === "textbf")
              return "bold";
            var a = r.font;
            if (!a || a === "mathnormal")
              return null;
            var l = e.mode;
            if (a === "mathit")
              return "italic";
            if (a === "boldsymbol")
              return e.type === "textord" ? "bold" : "bold-italic";
            if (a === "mathbf")
              return "bold";
            if (a === "mathbb")
              return "double-struck";
            if (a === "mathfrak")
              return "fraktur";
            if (a === "mathscr" || a === "mathcal")
              return "script";
            if (a === "mathsf")
              return "sans-serif";
            if (a === "mathtt")
              return "monospace";
            var c = e.text;
            if (M.contains(["\\imath", "\\jmath"], c))
              return null;
            Ge[l][c] && Ge[l][c].replace && (c = Ge[l][c].replace);
            var d = I.fontMap[a].fontName;
            return t0(c, d, l) ? I.fontMap[a].variant : null;
          }, kt = function(e, r, a) {
            if (e.length === 1) {
              var l = He(e[0], r);
              return a && l instanceof Ht && l.type === "mo" && (l.setAttribute("lspace", "0em"), l.setAttribute("rspace", "0em")), [l];
            }
            for (var c = [], d, b = 0; b < e.length; b++) {
              var _ = He(e[b], r);
              if (_ instanceof Ht && d instanceof Ht) {
                if (_.type === "mtext" && d.type === "mtext" && _.getAttribute("mathvariant") === d.getAttribute("mathvariant")) {
                  var A;
                  (A = d.children).push.apply(A, _.children);
                  continue;
                } else if (_.type === "mn" && d.type === "mn") {
                  var C;
                  (C = d.children).push.apply(C, _.children);
                  continue;
                } else if (_.type === "mi" && _.children.length === 1 && d.type === "mn") {
                  var L = _.children[0];
                  if (L instanceof zr && L.text === ".") {
                    var H;
                    (H = d.children).push.apply(H, _.children);
                    continue;
                  }
                } else if (d.type === "mi" && d.children.length === 1) {
                  var P = d.children[0];
                  if (P instanceof zr && P.text === "̸" && (_.type === "mo" || _.type === "mi" || _.type === "mn")) {
                    var W = _.children[0];
                    W instanceof zr && W.text.length > 0 && (W.text = W.text.slice(0, 1) + "̸" + W.text.slice(1), c.pop());
                  }
                }
              }
              c.push(_), d = _;
            }
            return c;
          }, C0 = function(e, r, a) {
            return ia(kt(e, r, a));
          }, He = function(e, r) {
            if (!e)
              return new Q.MathNode("mrow");
            if (cn[e.type]) {
              var a = cn[e.type](e, r);
              return a;
            } else
              throw new u("Got group of unknown type: '" + e.type + "'");
          };
          function qi(m, e, r, a, l) {
            var c = kt(m, r), d;
            c.length === 1 && c[0] instanceof Ht && M.contains(["mrow", "mtable"], c[0].type) ? d = c[0] : d = new Q.MathNode("mrow", c);
            var b = new Q.MathNode("annotation", [new Q.TextNode(e)]);
            b.setAttribute("encoding", "application/x-tex");
            var _ = new Q.MathNode("semantics", [d, b]), A = new Q.MathNode("math", [_]);
            A.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), a && A.setAttribute("display", "block");
            var C = l ? "katex" : "katex-mathml";
            return I.makeSpan([C], [A]);
          }
          var Pi = function(e) {
            return new lr({
              style: e.displayMode ? re.DISPLAY : re.TEXT,
              maxSize: e.maxSize,
              minRuleThickness: e.minRuleThickness
            });
          }, Hi = function(e, r) {
            if (r.displayMode) {
              var a = ["katex-display"];
              r.leqno && a.push("leqno"), r.fleqn && a.push("fleqn"), e = I.makeSpan(a, [e]);
            }
            return e;
          }, l1 = function(e, r, a) {
            var l = Pi(a), c;
            if (a.output === "mathml")
              return qi(e, r, l, a.displayMode, !0);
            if (a.output === "html") {
              var d = aa(e, l);
              c = I.makeSpan(["katex"], [d]);
            } else {
              var b = qi(e, r, l, a.displayMode, !1), _ = aa(e, l);
              c = I.makeSpan(["katex"], [b, _]);
            }
            return Hi(c, a);
          }, s1 = function(e, r, a) {
            var l = Pi(a), c = aa(e, l), d = I.makeSpan(["katex"], [c]);
            return Hi(d, a);
          }, o1 = {
            widehat: "^",
            widecheck: "ˇ",
            widetilde: "~",
            utilde: "~",
            overleftarrow: "←",
            underleftarrow: "←",
            xleftarrow: "←",
            overrightarrow: "→",
            underrightarrow: "→",
            xrightarrow: "→",
            underbrace: "⏟",
            overbrace: "⏞",
            overgroup: "⏠",
            undergroup: "⏡",
            overleftrightarrow: "↔",
            underleftrightarrow: "↔",
            xleftrightarrow: "↔",
            Overrightarrow: "⇒",
            xRightarrow: "⇒",
            overleftharpoon: "↼",
            xleftharpoonup: "↼",
            overrightharpoon: "⇀",
            xrightharpoonup: "⇀",
            xLeftarrow: "⇐",
            xLeftrightarrow: "⇔",
            xhookleftarrow: "↩",
            xhookrightarrow: "↪",
            xmapsto: "↦",
            xrightharpoondown: "⇁",
            xleftharpoondown: "↽",
            xrightleftharpoons: "⇌",
            xleftrightharpoons: "⇋",
            xtwoheadleftarrow: "↞",
            xtwoheadrightarrow: "↠",
            xlongequal: "=",
            xtofrom: "⇄",
            xrightleftarrows: "⇄",
            xrightequilibrium: "⇌",
            // Not a perfect match.
            xleftequilibrium: "⇋",
            // None better available.
            "\\cdrightarrow": "→",
            "\\cdleftarrow": "←",
            "\\cdlongequal": "="
          }, u1 = function(e) {
            var r = new Q.MathNode("mo", [new Q.TextNode(o1[e.replace(/^\\/, "")])]);
            return r.setAttribute("stretchy", "true"), r;
          }, c1 = {
            //   path(s), minWidth, height, align
            overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
            overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
            underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
            underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
            xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
            "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
            // CD minwwidth2.5pc
            xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
            "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
            Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
            xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
            xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
            overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
            xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
            xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
            overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
            xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
            xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
            xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
            "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
            xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
            xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
            overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
            overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
            underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
            underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
            xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
            xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
            xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
            xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
            xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
            xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
            overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
            underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
            overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
            undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
            xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
            xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
            // The next three arrows are from the mhchem package.
            // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
            // document as \xrightarrow or \xrightleftharpoons. Those have
            // min-length = 1.75em, so we set min-length on these next three to match.
            xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
            xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
            xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
          }, h1 = function(e) {
            return e.type === "ordgroup" ? e.body.length : 1;
          }, f1 = function(e, r) {
            function a() {
              var _ = 4e5, A = e.label.slice(1);
              if (M.contains(["widehat", "widecheck", "widetilde", "utilde"], A)) {
                var C = e, L = h1(C.base), H, P, W;
                if (L > 5)
                  A === "widehat" || A === "widecheck" ? (H = 420, _ = 2364, W = 0.42, P = A + "4") : (H = 312, _ = 2340, W = 0.34, P = "tilde4");
                else {
                  var te = [1, 1, 2, 2, 3, 3][L];
                  A === "widehat" || A === "widecheck" ? (_ = [0, 1062, 2364, 2364, 2364][te], H = [0, 239, 300, 360, 420][te], W = [0, 0.24, 0.3, 0.3, 0.36, 0.42][te], P = A + te) : (_ = [0, 600, 1033, 2339, 2340][te], H = [0, 260, 286, 306, 312][te], W = [0, 0.26, 0.286, 0.3, 0.306, 0.34][te], P = "tilde" + te);
                }
                var ie = new r0(P), ce = new Pt([ie], {
                  width: "100%",
                  height: ne(W),
                  viewBox: "0 0 " + _ + " " + H,
                  preserveAspectRatio: "none"
                });
                return {
                  span: I.makeSvgSpan([], [ce], r),
                  minWidth: 0,
                  height: W
                };
              } else {
                var me = [], de = c1[A], Te = de[0], ye = de[1], ze = de[2], Fe = ze / 1e3, Le = Te.length, We, st;
                if (Le === 1) {
                  var xt = de[3];
                  We = ["hide-tail"], st = [xt];
                } else if (Le === 2)
                  We = ["halfarrow-left", "halfarrow-right"], st = ["xMinYMin", "xMaxYMin"];
                else if (Le === 3)
                  We = ["brace-left", "brace-center", "brace-right"], st = ["xMinYMin", "xMidYMin", "xMaxYMin"];
                else
                  throw new Error(`Correct katexImagesData or update code here to support
                    ` + Le + " children.");
                for (var Ye = 0; Ye < Le; Ye++) {
                  var K0 = new r0(Te[Ye]), Gt = new Pt([K0], {
                    width: "400em",
                    height: ne(Fe),
                    viewBox: "0 0 " + _ + " " + ze,
                    preserveAspectRatio: st[Ye] + " slice"
                  }), pt = I.makeSvgSpan([We[Ye]], [Gt], r);
                  if (Le === 1)
                    return {
                      span: pt,
                      minWidth: ye,
                      height: Fe
                    };
                  pt.style.height = ne(Fe), me.push(pt);
                }
                return {
                  span: I.makeSpan(["stretchy"], me, r),
                  minWidth: ye,
                  height: Fe
                };
              }
            }
            var l = a(), c = l.span, d = l.minWidth, b = l.height;
            return c.height = b, c.style.height = ne(b), d > 0 && (c.style.minWidth = ne(d)), c;
          }, m1 = function(e, r, a, l, c) {
            var d, b = e.height + e.depth + a + l;
            if (/fbox|color|angl/.test(r)) {
              if (d = I.makeSpan(["stretchy", r], [], c), r === "fbox") {
                var _ = c.color && c.getColor();
                _ && (d.style.borderColor = _);
              }
            } else {
              var A = [];
              /^[bx]cancel$/.test(r) && A.push(new or({
                x1: "0",
                y1: "0",
                x2: "100%",
                y2: "100%",
                "stroke-width": "0.046em"
              })), /^x?cancel$/.test(r) && A.push(new or({
                x1: "0",
                y1: "100%",
                x2: "100%",
                y2: "0",
                "stroke-width": "0.046em"
              }));
              var C = new Pt(A, {
                width: "100%",
                height: ne(b)
              });
              d = I.makeSvgSpan([], [C], c);
            }
            return d.height = b, d.style.height = ne(b), d;
          }, g0 = {
            encloseSpan: m1,
            mathMLnode: u1,
            svgSpan: f1
          };
          function be(m, e) {
            if (!m || m.type !== e)
              throw new Error("Expected node of type " + e + ", but got " + (m ? "node of type " + m.type : String(m)));
            return m;
          }
          function sa(m) {
            var e = mn(m);
            if (!e)
              throw new Error("Expected node of symbol group type, but got " + (m ? "node of type " + m.type : String(m)));
            return e;
          }
          function mn(m) {
            return m && (m.type === "atom" || Cr.hasOwnProperty(m.type)) ? m : null;
          }
          var oa = function(e, r) {
            var a, l, c;
            e && e.type === "supsub" ? (l = be(e.base, "accent"), a = l.base, e.base = a, c = Qn(Ee(e, r)), e.base = l) : (l = be(e, "accent"), a = l.base);
            var d = Ee(a, r.havingCrampedStyle()), b = l.isShifty && M.isCharacterBox(a), _ = 0;
            if (b) {
              var A = M.getBaseElem(a), C = Ee(A, r.havingCrampedStyle());
              _ = Fr(C).skew;
            }
            var L = l.label === "\\c", H = L ? d.height + d.depth : Math.min(d.height, r.fontMetrics().xHeight), P;
            if (l.isStretchy)
              P = g0.svgSpan(l, r), P = I.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: d
                }, {
                  type: "elem",
                  elem: P,
                  wrapperClasses: ["svg-align"],
                  wrapperStyle: _ > 0 ? {
                    width: "calc(100% - " + ne(2 * _) + ")",
                    marginLeft: ne(2 * _)
                  } : void 0
                }]
              }, r);
            else {
              var W, te;
              l.label === "\\vec" ? (W = I.staticSvg("vec", r), te = I.svgData.vec[1]) : (W = I.makeOrd({
                mode: l.mode,
                text: l.label
              }, r, "textord"), W = Fr(W), W.italic = 0, te = W.width, L && (H += W.depth)), P = I.makeSpan(["accent-body"], [W]);
              var ie = l.label === "\\textcircled";
              ie && (P.classes.push("accent-full"), H = d.height);
              var ce = _;
              ie || (ce -= te / 2), P.style.left = ne(ce), l.label === "\\textcircled" && (P.style.top = ".2em"), P = I.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: d
                }, {
                  type: "kern",
                  size: -H
                }, {
                  type: "elem",
                  elem: P
                }]
              }, r);
            }
            var me = I.makeSpan(["mord", "accent"], [P], r);
            return c ? (c.children[0] = me, c.height = Math.max(me.height, c.height), c.classes[0] = "mord", c) : me;
          }, Ui = function(e, r) {
            var a = e.isStretchy ? g0.mathMLnode(e.label) : new Q.MathNode("mo", [Ut(e.label, e.mode)]), l = new Q.MathNode("mover", [He(e.base, r), a]);
            return l.setAttribute("accent", "true"), l;
          }, d1 = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map(function(m) {
            return "\\" + m;
          }).join("|"));
          oe({
            type: "accent",
            names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = hn(r[0]), l = !d1.test(e.funcName), c = !l || e.funcName === "\\widehat" || e.funcName === "\\widetilde" || e.funcName === "\\widecheck";
              return {
                type: "accent",
                mode: e.parser.mode,
                label: e.funcName,
                isStretchy: l,
                isShifty: c,
                base: a
              };
            },
            htmlBuilder: oa,
            mathmlBuilder: Ui
          }), oe({
            type: "accent",
            names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
            props: {
              numArgs: 1,
              allowedInText: !0,
              allowedInMath: !0,
              // unless in strict mode
              argTypes: ["primitive"]
            },
            handler: function(e, r) {
              var a = r[0], l = e.parser.mode;
              return l === "math" && (e.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + e.funcName + " works only in text mode"), l = "text"), {
                type: "accent",
                mode: l,
                label: e.funcName,
                isStretchy: !1,
                isShifty: !0,
                base: a
              };
            },
            htmlBuilder: oa,
            mathmlBuilder: Ui
          }), oe({
            type: "accentUnder",
            names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0];
              return {
                type: "accentUnder",
                mode: a.mode,
                label: l,
                base: c
              };
            },
            htmlBuilder: function(e, r) {
              var a = Ee(e.base, r), l = g0.svgSpan(e, r), c = e.label === "\\utilde" ? 0.12 : 0, d = I.makeVList({
                positionType: "top",
                positionData: a.height,
                children: [{
                  type: "elem",
                  elem: l,
                  wrapperClasses: ["svg-align"]
                }, {
                  type: "kern",
                  size: c
                }, {
                  type: "elem",
                  elem: a
                }]
              }, r);
              return I.makeSpan(["mord", "accentunder"], [d], r);
            },
            mathmlBuilder: function(e, r) {
              var a = g0.mathMLnode(e.label), l = new Q.MathNode("munder", [He(e.base, r), a]);
              return l.setAttribute("accentunder", "true"), l;
            }
          });
          var dn = function(e) {
            var r = new Q.MathNode("mpadded", e ? [e] : []);
            return r.setAttribute("width", "+0.6em"), r.setAttribute("lspace", "0.3em"), r;
          };
          oe({
            type: "xArrow",
            names: [
              "\\xleftarrow",
              "\\xrightarrow",
              "\\xLeftarrow",
              "\\xRightarrow",
              "\\xleftrightarrow",
              "\\xLeftrightarrow",
              "\\xhookleftarrow",
              "\\xhookrightarrow",
              "\\xmapsto",
              "\\xrightharpoondown",
              "\\xrightharpoonup",
              "\\xleftharpoondown",
              "\\xleftharpoonup",
              "\\xrightleftharpoons",
              "\\xleftrightharpoons",
              "\\xlongequal",
              "\\xtwoheadrightarrow",
              "\\xtwoheadleftarrow",
              "\\xtofrom",
              // The next 3 functions are here to support the mhchem extension.
              // Direct use of these functions is discouraged and may break someday.
              "\\xrightleftarrows",
              "\\xrightequilibrium",
              "\\xleftequilibrium",
              // The next 3 functions are here only to support the {CD} environment.
              "\\\\cdrightarrow",
              "\\\\cdleftarrow",
              "\\\\cdlongequal"
            ],
            props: {
              numArgs: 1,
              numOptionalArgs: 1
            },
            handler: function(e, r, a) {
              var l = e.parser, c = e.funcName;
              return {
                type: "xArrow",
                mode: l.mode,
                label: c,
                body: r[0],
                below: a[0]
              };
            },
            // Flow is unable to correctly infer the type of `group`, even though it's
            // unambiguously determined from the passed-in `type` above.
            htmlBuilder: function(e, r) {
              var a = r.style, l = r.havingStyle(a.sup()), c = I.wrapFragment(Ee(e.body, l, r), r), d = e.label.slice(0, 2) === "\\x" ? "x" : "cd";
              c.classes.push(d + "-arrow-pad");
              var b;
              e.below && (l = r.havingStyle(a.sub()), b = I.wrapFragment(Ee(e.below, l, r), r), b.classes.push(d + "-arrow-pad"));
              var _ = g0.svgSpan(e, r), A = -r.fontMetrics().axisHeight + 0.5 * _.height, C = -r.fontMetrics().axisHeight - 0.5 * _.height - 0.111;
              (c.depth > 0.25 || e.label === "\\xleftequilibrium") && (C -= c.depth);
              var L;
              if (b) {
                var H = -r.fontMetrics().axisHeight + b.height + 0.5 * _.height + 0.111;
                L = I.makeVList({
                  positionType: "individualShift",
                  children: [{
                    type: "elem",
                    elem: c,
                    shift: C
                  }, {
                    type: "elem",
                    elem: _,
                    shift: A
                  }, {
                    type: "elem",
                    elem: b,
                    shift: H
                  }]
                }, r);
              } else
                L = I.makeVList({
                  positionType: "individualShift",
                  children: [{
                    type: "elem",
                    elem: c,
                    shift: C
                  }, {
                    type: "elem",
                    elem: _,
                    shift: A
                  }]
                }, r);
              return L.children[0].children[0].children[1].classes.push("svg-align"), I.makeSpan(["mrel", "x-arrow"], [L], r);
            },
            mathmlBuilder: function(e, r) {
              var a = g0.mathMLnode(e.label);
              a.setAttribute("minsize", e.label.charAt(0) === "x" ? "1.75em" : "3.0em");
              var l;
              if (e.body) {
                var c = dn(He(e.body, r));
                if (e.below) {
                  var d = dn(He(e.below, r));
                  l = new Q.MathNode("munderover", [a, d, c]);
                } else
                  l = new Q.MathNode("mover", [a, c]);
              } else if (e.below) {
                var b = dn(He(e.below, r));
                l = new Q.MathNode("munder", [a, b]);
              } else
                l = dn(), l = new Q.MathNode("mover", [a, l]);
              return l;
            }
          });
          var p1 = I.makeSpan;
          function Gi(m, e) {
            var r = at(m.body, e, !0);
            return p1([m.mclass], r, e);
          }
          function Vi(m, e) {
            var r, a = kt(m.body, e);
            return m.mclass === "minner" ? r = new Q.MathNode("mpadded", a) : m.mclass === "mord" ? m.isCharacterBox ? (r = a[0], r.type = "mi") : r = new Q.MathNode("mi", a) : (m.isCharacterBox ? (r = a[0], r.type = "mo") : r = new Q.MathNode("mo", a), m.mclass === "mbin" ? (r.attributes.lspace = "0.22em", r.attributes.rspace = "0.22em") : m.mclass === "mpunct" ? (r.attributes.lspace = "0em", r.attributes.rspace = "0.17em") : m.mclass === "mopen" || m.mclass === "mclose" ? (r.attributes.lspace = "0em", r.attributes.rspace = "0em") : m.mclass === "minner" && (r.attributes.lspace = "0.0556em", r.attributes.width = "+0.1111em")), r;
          }
          oe({
            type: "mclass",
            names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0];
              return {
                type: "mclass",
                mode: a.mode,
                mclass: "m" + l.slice(5),
                // TODO(kevinb): don't prefix with 'm'
                body: et(c),
                isCharacterBox: M.isCharacterBox(c)
              };
            },
            htmlBuilder: Gi,
            mathmlBuilder: Vi
          });
          var pn = function(e) {
            var r = e.type === "ordgroup" && e.body.length ? e.body[0] : e;
            return r.type === "atom" && (r.family === "bin" || r.family === "rel") ? "m" + r.family : "mord";
          };
          oe({
            type: "mclass",
            names: ["\\@binrel"],
            props: {
              numArgs: 2
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "mclass",
                mode: a.mode,
                mclass: pn(r[0]),
                body: et(r[1]),
                isCharacterBox: M.isCharacterBox(r[1])
              };
            }
          }), oe({
            type: "mclass",
            names: ["\\stackrel", "\\overset", "\\underset"],
            props: {
              numArgs: 2
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[1], d = r[0], b;
              l !== "\\stackrel" ? b = pn(c) : b = "mrel";
              var _ = {
                type: "op",
                mode: c.mode,
                limits: !0,
                alwaysHandleSupSub: !0,
                parentIsSupSub: !1,
                symbol: !1,
                suppressBaseShift: l !== "\\stackrel",
                body: et(c)
              }, A = {
                type: "supsub",
                mode: d.mode,
                base: _,
                sup: l === "\\underset" ? null : d,
                sub: l === "\\underset" ? d : null
              };
              return {
                type: "mclass",
                mode: a.mode,
                mclass: b,
                body: [A],
                isCharacterBox: M.isCharacterBox(A)
              };
            },
            htmlBuilder: Gi,
            mathmlBuilder: Vi
          }), oe({
            type: "pmb",
            names: ["\\pmb"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "pmb",
                mode: a.mode,
                mclass: pn(r[0]),
                body: et(r[0])
              };
            },
            htmlBuilder: function(e, r) {
              var a = at(e.body, r, !0), l = I.makeSpan([e.mclass], a, r);
              return l.style.textShadow = "0.02em 0.01em 0.04px", l;
            },
            mathmlBuilder: function(e, r) {
              var a = kt(e.body, r), l = new Q.MathNode("mstyle", a);
              return l.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), l;
            }
          });
          var g1 = {
            ">": "\\\\cdrightarrow",
            "<": "\\\\cdleftarrow",
            "=": "\\\\cdlongequal",
            A: "\\uparrow",
            V: "\\downarrow",
            "|": "\\Vert",
            ".": "no arrow"
          }, Wi = function() {
            return {
              type: "styling",
              body: [],
              mode: "math",
              style: "display"
            };
          }, ji = function(e) {
            return e.type === "textord" && e.text === "@";
          }, v1 = function(e, r) {
            return (e.type === "mathord" || e.type === "atom") && e.text === r;
          };
          function b1(m, e, r) {
            var a = g1[m];
            switch (a) {
              case "\\\\cdrightarrow":
              case "\\\\cdleftarrow":
                return r.callFunction(a, [e[0]], [e[1]]);
              case "\\uparrow":
              case "\\downarrow": {
                var l = r.callFunction("\\\\cdleft", [e[0]], []), c = {
                  type: "atom",
                  text: a,
                  mode: "math",
                  family: "rel"
                }, d = r.callFunction("\\Big", [c], []), b = r.callFunction("\\\\cdright", [e[1]], []), _ = {
                  type: "ordgroup",
                  mode: "math",
                  body: [l, d, b]
                };
                return r.callFunction("\\\\cdparent", [_], []);
              }
              case "\\\\cdlongequal":
                return r.callFunction("\\\\cdlongequal", [], []);
              case "\\Vert": {
                var A = {
                  type: "textord",
                  text: "\\Vert",
                  mode: "math"
                };
                return r.callFunction("\\Big", [A], []);
              }
              default:
                return {
                  type: "textord",
                  text: " ",
                  mode: "math"
                };
            }
          }
          function y1(m) {
            var e = [];
            for (m.gullet.beginGroup(), m.gullet.macros.set("\\cr", "\\\\\\relax"), m.gullet.beginGroup(); ; ) {
              e.push(m.parseExpression(!1, "\\\\")), m.gullet.endGroup(), m.gullet.beginGroup();
              var r = m.fetch().text;
              if (r === "&" || r === "\\\\")
                m.consume();
              else if (r === "\\end") {
                e[e.length - 1].length === 0 && e.pop();
                break;
              } else
                throw new u("Expected \\\\ or \\cr or \\end", m.nextToken);
            }
            for (var a = [], l = [a], c = 0; c < e.length; c++) {
              for (var d = e[c], b = Wi(), _ = 0; _ < d.length; _++)
                if (!ji(d[_]))
                  b.body.push(d[_]);
                else {
                  a.push(b), _ += 1;
                  var A = sa(d[_]).text, C = new Array(2);
                  if (C[0] = {
                    type: "ordgroup",
                    mode: "math",
                    body: []
                  }, C[1] = {
                    type: "ordgroup",
                    mode: "math",
                    body: []
                  }, !("=|.".indexOf(A) > -1))
                    if ("<>AV".indexOf(A) > -1)
                      for (var L = 0; L < 2; L++) {
                        for (var H = !0, P = _ + 1; P < d.length; P++) {
                          if (v1(d[P], A)) {
                            H = !1, _ = P;
                            break;
                          }
                          if (ji(d[P]))
                            throw new u("Missing a " + A + " character to complete a CD arrow.", d[P]);
                          C[L].body.push(d[P]);
                        }
                        if (H)
                          throw new u("Missing a " + A + " character to complete a CD arrow.", d[_]);
                      }
                    else
                      throw new u('Expected one of "<>AV=|." after @', d[_]);
                  var W = b1(A, C, m), te = {
                    type: "styling",
                    body: [W],
                    mode: "math",
                    style: "display"
                    // CD is always displaystyle.
                  };
                  a.push(te), b = Wi();
                }
              c % 2 === 0 ? a.push(b) : a.shift(), a = [], l.push(a);
            }
            m.gullet.endGroup(), m.gullet.endGroup();
            var ie = new Array(l[0].length).fill({
              type: "align",
              align: "c",
              pregap: 0.25,
              // CD package sets \enskip between columns.
              postgap: 0.25
              // So pre and post each get half an \enskip, i.e. 0.25em.
            });
            return {
              type: "array",
              mode: "math",
              body: l,
              arraystretch: 1,
              addJot: !0,
              rowGaps: [null],
              cols: ie,
              colSeparationType: "CD",
              hLinesBeforeRow: new Array(l.length + 1).fill([])
            };
          }
          oe({
            type: "cdlabel",
            names: ["\\\\cdleft", "\\\\cdright"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName;
              return {
                type: "cdlabel",
                mode: a.mode,
                side: l.slice(4),
                label: r[0]
              };
            },
            htmlBuilder: function(e, r) {
              var a = r.havingStyle(r.style.sup()), l = I.wrapFragment(Ee(e.label, a, r), r);
              return l.classes.push("cd-label-" + e.side), l.style.bottom = ne(0.8 - l.depth), l.height = 0, l.depth = 0, l;
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mrow", [He(e.label, r)]);
              return a = new Q.MathNode("mpadded", [a]), a.setAttribute("width", "0"), e.side === "left" && a.setAttribute("lspace", "-1width"), a.setAttribute("voffset", "0.7em"), a = new Q.MathNode("mstyle", [a]), a.setAttribute("displaystyle", "false"), a.setAttribute("scriptlevel", "1"), a;
            }
          }), oe({
            type: "cdlabelparent",
            names: ["\\\\cdparent"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "cdlabelparent",
                mode: a.mode,
                fragment: r[0]
              };
            },
            htmlBuilder: function(e, r) {
              var a = I.wrapFragment(Ee(e.fragment, r), r);
              return a.classes.push("cd-vert-arrow"), a;
            },
            mathmlBuilder: function(e, r) {
              return new Q.MathNode("mrow", [He(e.fragment, r)]);
            }
          }), oe({
            type: "textord",
            names: ["\\@char"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r) {
              for (var a = e.parser, l = be(r[0], "ordgroup"), c = l.body, d = "", b = 0; b < c.length; b++) {
                var _ = be(c[b], "textord");
                d += _.text;
              }
              var A = parseInt(d), C;
              if (isNaN(A))
                throw new u("\\@char has non-numeric argument " + d);
              if (A < 0 || A >= 1114111)
                throw new u("\\@char with invalid code point " + d);
              return A <= 65535 ? C = String.fromCharCode(A) : (A -= 65536, C = String.fromCharCode((A >> 10) + 55296, (A & 1023) + 56320)), {
                type: "textord",
                mode: a.mode,
                text: C
              };
            }
          });
          var Xi = function(e, r) {
            var a = at(e.body, r.withColor(e.color), !1);
            return I.makeFragment(a);
          }, Yi = function(e, r) {
            var a = kt(e.body, r.withColor(e.color)), l = new Q.MathNode("mstyle", a);
            return l.setAttribute("mathcolor", e.color), l;
          };
          oe({
            type: "color",
            names: ["\\textcolor"],
            props: {
              numArgs: 2,
              allowedInText: !0,
              argTypes: ["color", "original"]
            },
            handler: function(e, r) {
              var a = e.parser, l = be(r[0], "color-token").color, c = r[1];
              return {
                type: "color",
                mode: a.mode,
                color: l,
                body: et(c)
              };
            },
            htmlBuilder: Xi,
            mathmlBuilder: Yi
          }), oe({
            type: "color",
            names: ["\\color"],
            props: {
              numArgs: 1,
              allowedInText: !0,
              argTypes: ["color"]
            },
            handler: function(e, r) {
              var a = e.parser, l = e.breakOnTokenText, c = be(r[0], "color-token").color;
              a.gullet.macros.set("\\current@color", c);
              var d = a.parseExpression(!0, l);
              return {
                type: "color",
                mode: a.mode,
                color: c,
                body: d
              };
            },
            htmlBuilder: Xi,
            mathmlBuilder: Yi
          }), oe({
            type: "cr",
            names: ["\\\\"],
            props: {
              numArgs: 0,
              numOptionalArgs: 0,
              allowedInText: !0
            },
            handler: function(e, r, a) {
              var l = e.parser, c = l.gullet.future().text === "[" ? l.parseSizeGroup(!0) : null, d = !l.settings.displayMode || !l.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
              return {
                type: "cr",
                mode: l.mode,
                newLine: d,
                size: c && be(c, "size").value
              };
            },
            // The following builders are called only at the top level,
            // not within tabular/array environments.
            htmlBuilder: function(e, r) {
              var a = I.makeSpan(["mspace"], [], r);
              return e.newLine && (a.classes.push("newline"), e.size && (a.style.marginTop = ne(qe(e.size, r)))), a;
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mspace");
              return e.newLine && (a.setAttribute("linebreak", "newline"), e.size && a.setAttribute("height", ne(qe(e.size, r)))), a;
            }
          });
          var ua = {
            "\\global": "\\global",
            "\\long": "\\\\globallong",
            "\\\\globallong": "\\\\globallong",
            "\\def": "\\gdef",
            "\\gdef": "\\gdef",
            "\\edef": "\\xdef",
            "\\xdef": "\\xdef",
            "\\let": "\\\\globallet",
            "\\futurelet": "\\\\globalfuture"
          }, Zi = function(e) {
            var r = e.text;
            if (/^(?:[\\{}$&#^_]|EOF)$/.test(r))
              throw new u("Expected a control sequence", e);
            return r;
          }, w1 = function(e) {
            var r = e.gullet.popToken();
            return r.text === "=" && (r = e.gullet.popToken(), r.text === " " && (r = e.gullet.popToken())), r;
          }, Ki = function(e, r, a, l) {
            var c = e.gullet.macros.get(a.text);
            c == null && (a.noexpand = !0, c = {
              tokens: [a],
              numArgs: 0,
              // reproduce the same behavior in expansion
              unexpandable: !e.gullet.isExpandable(a.text)
            }), e.gullet.macros.set(r, c, l);
          };
          oe({
            type: "internal",
            names: [
              "\\global",
              "\\long",
              "\\\\globallong"
              // can’t be entered directly
            ],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName;
              r.consumeSpaces();
              var l = r.fetch();
              if (ua[l.text])
                return (a === "\\global" || a === "\\\\globallong") && (l.text = ua[l.text]), be(r.parseFunction(), "internal");
              throw new u("Invalid token after macro prefix", l);
            }
          }), oe({
            type: "internal",
            names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName, l = r.gullet.popToken(), c = l.text;
              if (/^(?:[\\{}$&#^_]|EOF)$/.test(c))
                throw new u("Expected a control sequence", l);
              for (var d = 0, b, _ = [[]]; r.gullet.future().text !== "{"; )
                if (l = r.gullet.popToken(), l.text === "#") {
                  if (r.gullet.future().text === "{") {
                    b = r.gullet.future(), _[d].push("{");
                    break;
                  }
                  if (l = r.gullet.popToken(), !/^[1-9]$/.test(l.text))
                    throw new u('Invalid argument number "' + l.text + '"');
                  if (parseInt(l.text) !== d + 1)
                    throw new u('Argument number "' + l.text + '" out of order');
                  d++, _.push([]);
                } else {
                  if (l.text === "EOF")
                    throw new u("Expected a macro definition");
                  _[d].push(l.text);
                }
              var A = r.gullet.consumeArg(), C = A.tokens;
              return b && C.unshift(b), (a === "\\edef" || a === "\\xdef") && (C = r.gullet.expandTokens(C), C.reverse()), r.gullet.macros.set(c, {
                tokens: C,
                numArgs: d,
                delimiters: _
              }, a === ua[a]), {
                type: "internal",
                mode: r.mode
              };
            }
          }), oe({
            type: "internal",
            names: [
              "\\let",
              "\\\\globallet"
              // can’t be entered directly
            ],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName, l = Zi(r.gullet.popToken());
              r.gullet.consumeSpaces();
              var c = w1(r);
              return Ki(r, l, c, a === "\\\\globallet"), {
                type: "internal",
                mode: r.mode
              };
            }
          }), oe({
            type: "internal",
            names: [
              "\\futurelet",
              "\\\\globalfuture"
              // can’t be entered directly
            ],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName, l = Zi(r.gullet.popToken()), c = r.gullet.popToken(), d = r.gullet.popToken();
              return Ki(r, l, d, a === "\\\\globalfuture"), r.gullet.pushToken(d), r.gullet.pushToken(c), {
                type: "internal",
                mode: r.mode
              };
            }
          });
          var Nr = function(e, r, a) {
            var l = Ge.math[e] && Ge.math[e].replace, c = t0(l || e, r, a);
            if (!c)
              throw new Error("Unsupported symbol " + e + " and font size " + r + ".");
            return c;
          }, ca = function(e, r, a, l) {
            var c = a.havingBaseStyle(r), d = I.makeSpan(l.concat(c.sizingClasses(a)), [e], a), b = c.sizeMultiplier / a.sizeMultiplier;
            return d.height *= b, d.depth *= b, d.maxFontSize = c.sizeMultiplier, d;
          }, Qi = function(e, r, a) {
            var l = r.havingBaseStyle(a), c = (1 - r.sizeMultiplier / l.sizeMultiplier) * r.fontMetrics().axisHeight;
            e.classes.push("delimcenter"), e.style.top = ne(c), e.height -= c, e.depth += c;
          }, _1 = function(e, r, a, l, c, d) {
            var b = I.makeSymbol(e, "Main-Regular", c, l), _ = ca(b, r, l, d);
            return a && Qi(_, l, r), _;
          }, k1 = function(e, r, a, l) {
            return I.makeSymbol(e, "Size" + r + "-Regular", a, l);
          }, Ji = function(e, r, a, l, c, d) {
            var b = k1(e, r, c, l), _ = ca(I.makeSpan(["delimsizing", "size" + r], [b], l), re.TEXT, l, d);
            return a && Qi(_, l, re.TEXT), _;
          }, ha = function(e, r, a) {
            var l;
            r === "Size1-Regular" ? l = "delim-size1" : l = "delim-size4";
            var c = I.makeSpan(["delimsizinginner", l], [I.makeSpan([], [I.makeSymbol(e, r, a)])]);
            return {
              type: "elem",
              elem: c
            };
          }, fa = function(e, r, a) {
            var l = Ot["Size4-Regular"][e.charCodeAt(0)] ? Ot["Size4-Regular"][e.charCodeAt(0)][4] : Ot["Size1-Regular"][e.charCodeAt(0)][4], c = new r0("inner", nr(e, Math.round(1e3 * r))), d = new Pt([c], {
              width: ne(l),
              height: ne(r),
              // Override CSS rule `.katex svg { width: 100% }`
              style: "width:" + ne(l),
              viewBox: "0 0 " + 1e3 * l + " " + Math.round(1e3 * r),
              preserveAspectRatio: "xMinYMin"
            }), b = I.makeSvgSpan([], [d], a);
            return b.height = r, b.style.height = ne(r), b.style.width = ne(l), {
              type: "elem",
              elem: b
            };
          }, ma = 8e-3, gn = {
            type: "kern",
            size: -1 * ma
          }, D1 = ["|", "\\lvert", "\\rvert", "\\vert"], A1 = ["\\|", "\\lVert", "\\rVert", "\\Vert"], $i = function(e, r, a, l, c, d) {
            var b, _, A, C, L = "", H = 0;
            b = A = C = e, _ = null;
            var P = "Size1-Regular";
            e === "\\uparrow" ? A = C = "⏐" : e === "\\Uparrow" ? A = C = "‖" : e === "\\downarrow" ? b = A = "⏐" : e === "\\Downarrow" ? b = A = "‖" : e === "\\updownarrow" ? (b = "\\uparrow", A = "⏐", C = "\\downarrow") : e === "\\Updownarrow" ? (b = "\\Uparrow", A = "‖", C = "\\Downarrow") : M.contains(D1, e) ? (A = "∣", L = "vert", H = 333) : M.contains(A1, e) ? (A = "∥", L = "doublevert", H = 556) : e === "[" || e === "\\lbrack" ? (b = "⎡", A = "⎢", C = "⎣", P = "Size4-Regular", L = "lbrack", H = 667) : e === "]" || e === "\\rbrack" ? (b = "⎤", A = "⎥", C = "⎦", P = "Size4-Regular", L = "rbrack", H = 667) : e === "\\lfloor" || e === "⌊" ? (A = b = "⎢", C = "⎣", P = "Size4-Regular", L = "lfloor", H = 667) : e === "\\lceil" || e === "⌈" ? (b = "⎡", A = C = "⎢", P = "Size4-Regular", L = "lceil", H = 667) : e === "\\rfloor" || e === "⌋" ? (A = b = "⎥", C = "⎦", P = "Size4-Regular", L = "rfloor", H = 667) : e === "\\rceil" || e === "⌉" ? (b = "⎤", A = C = "⎥", P = "Size4-Regular", L = "rceil", H = 667) : e === "(" || e === "\\lparen" ? (b = "⎛", A = "⎜", C = "⎝", P = "Size4-Regular", L = "lparen", H = 875) : e === ")" || e === "\\rparen" ? (b = "⎞", A = "⎟", C = "⎠", P = "Size4-Regular", L = "rparen", H = 875) : e === "\\{" || e === "\\lbrace" ? (b = "⎧", _ = "⎨", C = "⎩", A = "⎪", P = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (b = "⎫", _ = "⎬", C = "⎭", A = "⎪", P = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (b = "⎧", C = "⎩", A = "⎪", P = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (b = "⎫", C = "⎭", A = "⎪", P = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (b = "⎧", C = "⎭", A = "⎪", P = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (b = "⎫", C = "⎩", A = "⎪", P = "Size4-Regular");
            var W = Nr(b, P, c), te = W.height + W.depth, ie = Nr(A, P, c), ce = ie.height + ie.depth, me = Nr(C, P, c), de = me.height + me.depth, Te = 0, ye = 1;
            if (_ !== null) {
              var ze = Nr(_, P, c);
              Te = ze.height + ze.depth, ye = 2;
            }
            var Fe = te + de + Te, Le = Math.max(0, Math.ceil((r - Fe) / (ye * ce))), We = Fe + Le * ye * ce, st = l.fontMetrics().axisHeight;
            a && (st *= l.sizeMultiplier);
            var xt = We / 2 - st, Ye = [];
            if (L.length > 0) {
              var K0 = We - te - de, Gt = Math.round(We * 1e3), pt = Kr(L, Math.round(K0 * 1e3)), z0 = new r0(L, pt), cr = (H / 1e3).toFixed(3) + "em", hr = (Gt / 1e3).toFixed(3) + "em", Ma = new Pt([z0], {
                width: cr,
                height: hr,
                viewBox: "0 0 " + H + " " + Gt
              }), N0 = I.makeSvgSpan([], [Ma], l);
              N0.height = Gt / 1e3, N0.style.width = cr, N0.style.height = hr, Ye.push({
                type: "elem",
                elem: N0
              });
            } else {
              if (Ye.push(ha(C, P, c)), Ye.push(gn), _ === null) {
                var R0 = We - te - de + 2 * ma;
                Ye.push(fa(A, R0, l));
              } else {
                var Vt = (We - te - de - Te) / 2 + 2 * ma;
                Ye.push(fa(A, Vt, l)), Ye.push(gn), Ye.push(ha(_, P, c)), Ye.push(gn), Ye.push(fa(A, Vt, l));
              }
              Ye.push(gn), Ye.push(ha(b, P, c));
            }
            var Ir = l.havingBaseStyle(re.TEXT), za = I.makeVList({
              positionType: "bottom",
              positionData: xt,
              children: Ye
            }, Ir);
            return ca(I.makeSpan(["delimsizing", "mult"], [za], Ir), re.TEXT, l, d);
          }, da = 80, pa = 0.08, ga = function(e, r, a, l, c) {
            var d = _0(e, l, a), b = new r0(e, d), _ = new Pt([b], {
              // Note: 1000:1 ratio of viewBox to document em width.
              width: "400em",
              height: ne(r),
              viewBox: "0 0 400000 " + a,
              preserveAspectRatio: "xMinYMin slice"
            });
            return I.makeSvgSpan(["hide-tail"], [_], c);
          }, x1 = function(e, r) {
            var a = r.havingBaseSizing(), l = nl("\\surd", e * a.sizeMultiplier, rl, a), c = a.sizeMultiplier, d = Math.max(0, r.minRuleThickness - r.fontMetrics().sqrtRuleThickness), b, _ = 0, A = 0, C = 0, L;
            return l.type === "small" ? (C = 1e3 + 1e3 * d + da, e < 1 ? c = 1 : e < 1.4 && (c = 0.7), _ = (1 + d + pa) / c, A = (1 + d) / c, b = ga("sqrtMain", _, C, d, r), b.style.minWidth = "0.853em", L = 0.833 / c) : l.type === "large" ? (C = (1e3 + da) * Rr[l.size], A = (Rr[l.size] + d) / c, _ = (Rr[l.size] + d + pa) / c, b = ga("sqrtSize" + l.size, _, C, d, r), b.style.minWidth = "1.02em", L = 1 / c) : (_ = e + d + pa, A = e + d, C = Math.floor(1e3 * e + d) + da, b = ga("sqrtTall", _, C, d, r), b.style.minWidth = "0.742em", L = 1.056), b.height = A, b.style.height = ne(_), {
              span: b,
              advanceWidth: L,
              // Calculate the actual line width.
              // This actually should depend on the chosen font -- e.g. \boldmath
              // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
              // have thicker rules.
              ruleWidth: (r.fontMetrics().sqrtRuleThickness + d) * c
            };
          }, el = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"], S1 = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"], tl = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"], Rr = [0, 1.2, 1.8, 2.4, 3], E1 = function(e, r, a, l, c) {
            if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), M.contains(el, e) || M.contains(tl, e))
              return Ji(e, r, !1, a, l, c);
            if (M.contains(S1, e))
              return $i(e, Rr[r], !1, a, l, c);
            throw new u("Illegal delimiter: '" + e + "'");
          }, F1 = [{
            type: "small",
            style: re.SCRIPTSCRIPT
          }, {
            type: "small",
            style: re.SCRIPT
          }, {
            type: "small",
            style: re.TEXT
          }, {
            type: "large",
            size: 1
          }, {
            type: "large",
            size: 2
          }, {
            type: "large",
            size: 3
          }, {
            type: "large",
            size: 4
          }], C1 = [{
            type: "small",
            style: re.SCRIPTSCRIPT
          }, {
            type: "small",
            style: re.SCRIPT
          }, {
            type: "small",
            style: re.TEXT
          }, {
            type: "stack"
          }], rl = [{
            type: "small",
            style: re.SCRIPTSCRIPT
          }, {
            type: "small",
            style: re.SCRIPT
          }, {
            type: "small",
            style: re.TEXT
          }, {
            type: "large",
            size: 1
          }, {
            type: "large",
            size: 2
          }, {
            type: "large",
            size: 3
          }, {
            type: "large",
            size: 4
          }, {
            type: "stack"
          }], T1 = function(e) {
            if (e.type === "small")
              return "Main-Regular";
            if (e.type === "large")
              return "Size" + e.size + "-Regular";
            if (e.type === "stack")
              return "Size4-Regular";
            throw new Error("Add support for delim type '" + e.type + "' here.");
          }, nl = function(e, r, a, l) {
            for (var c = Math.min(2, 3 - l.style.size), d = c; d < a.length && a[d].type !== "stack"; d++) {
              var b = Nr(e, T1(a[d]), "math"), _ = b.height + b.depth;
              if (a[d].type === "small") {
                var A = l.havingBaseStyle(a[d].style);
                _ *= A.sizeMultiplier;
              }
              if (_ > r)
                return a[d];
            }
            return a[a.length - 1];
          }, al = function(e, r, a, l, c, d) {
            e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
            var b;
            M.contains(tl, e) ? b = F1 : M.contains(el, e) ? b = rl : b = C1;
            var _ = nl(e, r, b, l);
            return _.type === "small" ? _1(e, _.style, a, l, c, d) : _.type === "large" ? Ji(e, _.size, a, l, c, d) : $i(e, r, a, l, c, d);
          }, B1 = function(e, r, a, l, c, d) {
            var b = l.fontMetrics().axisHeight * l.sizeMultiplier, _ = 901, A = 5 / l.fontMetrics().ptPerEm, C = Math.max(r - b, a + b), L = Math.max(
              // In real TeX, calculations are done using integral values which are
              // 65536 per pt, or 655360 per em. So, the division here truncates in
              // TeX but doesn't here, producing different results. If we wanted to
              // exactly match TeX's calculation, we could do
              //   Math.floor(655360 * maxDistFromAxis / 500) *
              //    delimiterFactor / 655360
              // (To see the difference, compare
              //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
              // in TeX and KaTeX)
              C / 500 * _,
              2 * C - A
            );
            return al(e, L, !0, l, c, d);
          }, v0 = {
            sqrtImage: x1,
            sizedDelim: E1,
            sizeToMaxHeight: Rr,
            customSizedDelim: al,
            leftRightDelim: B1
          }, il = {
            "\\bigl": {
              mclass: "mopen",
              size: 1
            },
            "\\Bigl": {
              mclass: "mopen",
              size: 2
            },
            "\\biggl": {
              mclass: "mopen",
              size: 3
            },
            "\\Biggl": {
              mclass: "mopen",
              size: 4
            },
            "\\bigr": {
              mclass: "mclose",
              size: 1
            },
            "\\Bigr": {
              mclass: "mclose",
              size: 2
            },
            "\\biggr": {
              mclass: "mclose",
              size: 3
            },
            "\\Biggr": {
              mclass: "mclose",
              size: 4
            },
            "\\bigm": {
              mclass: "mrel",
              size: 1
            },
            "\\Bigm": {
              mclass: "mrel",
              size: 2
            },
            "\\biggm": {
              mclass: "mrel",
              size: 3
            },
            "\\Biggm": {
              mclass: "mrel",
              size: 4
            },
            "\\big": {
              mclass: "mord",
              size: 1
            },
            "\\Big": {
              mclass: "mord",
              size: 2
            },
            "\\bigg": {
              mclass: "mord",
              size: 3
            },
            "\\Bigg": {
              mclass: "mord",
              size: 4
            }
          }, M1 = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
          function vn(m, e) {
            var r = mn(m);
            if (r && M.contains(M1, r.text))
              return r;
            throw r ? new u("Invalid delimiter '" + r.text + "' after '" + e.funcName + "'", m) : new u("Invalid delimiter type '" + m.type + "'", m);
          }
          oe({
            type: "delimsizing",
            names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
            props: {
              numArgs: 1,
              argTypes: ["primitive"]
            },
            handler: function(e, r) {
              var a = vn(r[0], e);
              return {
                type: "delimsizing",
                mode: e.parser.mode,
                size: il[e.funcName].size,
                mclass: il[e.funcName].mclass,
                delim: a.text
              };
            },
            htmlBuilder: function(e, r) {
              return e.delim === "." ? I.makeSpan([e.mclass]) : v0.sizedDelim(e.delim, e.size, r, e.mode, [e.mclass]);
            },
            mathmlBuilder: function(e) {
              var r = [];
              e.delim !== "." && r.push(Ut(e.delim, e.mode));
              var a = new Q.MathNode("mo", r);
              e.mclass === "mopen" || e.mclass === "mclose" ? a.setAttribute("fence", "true") : a.setAttribute("fence", "false"), a.setAttribute("stretchy", "true");
              var l = ne(v0.sizeToMaxHeight[e.size]);
              return a.setAttribute("minsize", l), a.setAttribute("maxsize", l), a;
            }
          });
          function ll(m) {
            if (!m.body)
              throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
          }
          oe({
            type: "leftright-right",
            names: ["\\right"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, r) {
              var a = e.parser.gullet.macros.get("\\current@color");
              if (a && typeof a != "string")
                throw new u("\\current@color set to non-string in \\right");
              return {
                type: "leftright-right",
                mode: e.parser.mode,
                delim: vn(r[0], e).text,
                color: a
                // undefined if not set via \color
              };
            }
          }), oe({
            type: "leftright",
            names: ["\\left"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, r) {
              var a = vn(r[0], e), l = e.parser;
              ++l.leftrightDepth;
              var c = l.parseExpression(!1);
              --l.leftrightDepth, l.expect("\\right", !1);
              var d = be(l.parseFunction(), "leftright-right");
              return {
                type: "leftright",
                mode: l.mode,
                body: c,
                left: a.text,
                right: d.delim,
                rightColor: d.color
              };
            },
            htmlBuilder: function(e, r) {
              ll(e);
              for (var a = at(e.body, r, !0, ["mopen", "mclose"]), l = 0, c = 0, d = !1, b = 0; b < a.length; b++)
                a[b].isMiddle ? d = !0 : (l = Math.max(a[b].height, l), c = Math.max(a[b].depth, c));
              l *= r.sizeMultiplier, c *= r.sizeMultiplier;
              var _;
              if (e.left === "." ? _ = Mr(r, ["mopen"]) : _ = v0.leftRightDelim(e.left, l, c, r, e.mode, ["mopen"]), a.unshift(_), d)
                for (var A = 1; A < a.length; A++) {
                  var C = a[A], L = C.isMiddle;
                  L && (a[A] = v0.leftRightDelim(L.delim, l, c, L.options, e.mode, []));
                }
              var H;
              if (e.right === ".")
                H = Mr(r, ["mclose"]);
              else {
                var P = e.rightColor ? r.withColor(e.rightColor) : r;
                H = v0.leftRightDelim(e.right, l, c, P, e.mode, ["mclose"]);
              }
              return a.push(H), I.makeSpan(["minner"], a, r);
            },
            mathmlBuilder: function(e, r) {
              ll(e);
              var a = kt(e.body, r);
              if (e.left !== ".") {
                var l = new Q.MathNode("mo", [Ut(e.left, e.mode)]);
                l.setAttribute("fence", "true"), a.unshift(l);
              }
              if (e.right !== ".") {
                var c = new Q.MathNode("mo", [Ut(e.right, e.mode)]);
                c.setAttribute("fence", "true"), e.rightColor && c.setAttribute("mathcolor", e.rightColor), a.push(c);
              }
              return ia(a);
            }
          }), oe({
            type: "middle",
            names: ["\\middle"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, r) {
              var a = vn(r[0], e);
              if (!e.parser.leftrightDepth)
                throw new u("\\middle without preceding \\left", a);
              return {
                type: "middle",
                mode: e.parser.mode,
                delim: a.text
              };
            },
            htmlBuilder: function(e, r) {
              var a;
              if (e.delim === ".")
                a = Mr(r, []);
              else {
                a = v0.sizedDelim(e.delim, 1, r, e.mode, []);
                var l = {
                  delim: e.delim,
                  options: r
                };
                a.isMiddle = l;
              }
              return a;
            },
            mathmlBuilder: function(e, r) {
              var a = e.delim === "\\vert" || e.delim === "|" ? Ut("|", "text") : Ut(e.delim, e.mode), l = new Q.MathNode("mo", [a]);
              return l.setAttribute("fence", "true"), l.setAttribute("lspace", "0.05em"), l.setAttribute("rspace", "0.05em"), l;
            }
          });
          var va = function(e, r) {
            var a = I.wrapFragment(Ee(e.body, r), r), l = e.label.slice(1), c = r.sizeMultiplier, d, b = 0, _ = M.isCharacterBox(e.body);
            if (l === "sout")
              d = I.makeSpan(["stretchy", "sout"]), d.height = r.fontMetrics().defaultRuleThickness / c, b = -0.5 * r.fontMetrics().xHeight;
            else if (l === "phase") {
              var A = qe({
                number: 0.6,
                unit: "pt"
              }, r), C = qe({
                number: 0.35,
                unit: "ex"
              }, r), L = r.havingBaseSizing();
              c = c / L.sizeMultiplier;
              var H = a.height + a.depth + A + C;
              a.style.paddingLeft = ne(H / 2 + A);
              var P = Math.floor(1e3 * H * c), W = G0(P), te = new Pt([new r0("phase", W)], {
                width: "400em",
                height: ne(P / 1e3),
                viewBox: "0 0 400000 " + P,
                preserveAspectRatio: "xMinYMin slice"
              });
              d = I.makeSvgSpan(["hide-tail"], [te], r), d.style.height = ne(H), b = a.depth + A + C;
            } else {
              /cancel/.test(l) ? _ || a.classes.push("cancel-pad") : l === "angl" ? a.classes.push("anglpad") : a.classes.push("boxpad");
              var ie = 0, ce = 0, me = 0;
              /box/.test(l) ? (me = Math.max(
                r.fontMetrics().fboxrule,
                // default
                r.minRuleThickness
                // User override.
              ), ie = r.fontMetrics().fboxsep + (l === "colorbox" ? 0 : me), ce = ie) : l === "angl" ? (me = Math.max(r.fontMetrics().defaultRuleThickness, r.minRuleThickness), ie = 4 * me, ce = Math.max(0, 0.25 - a.depth)) : (ie = _ ? 0.2 : 0, ce = ie), d = g0.encloseSpan(a, l, ie, ce, r), /fbox|boxed|fcolorbox/.test(l) ? (d.style.borderStyle = "solid", d.style.borderWidth = ne(me)) : l === "angl" && me !== 0.049 && (d.style.borderTopWidth = ne(me), d.style.borderRightWidth = ne(me)), b = a.depth + ce, e.backgroundColor && (d.style.backgroundColor = e.backgroundColor, e.borderColor && (d.style.borderColor = e.borderColor));
            }
            var de;
            if (e.backgroundColor)
              de = I.makeVList({
                positionType: "individualShift",
                children: [
                  // Put the color background behind inner;
                  {
                    type: "elem",
                    elem: d,
                    shift: b
                  },
                  {
                    type: "elem",
                    elem: a,
                    shift: 0
                  }
                ]
              }, r);
            else {
              var Te = /cancel|phase/.test(l) ? ["svg-align"] : [];
              de = I.makeVList({
                positionType: "individualShift",
                children: [
                  // Write the \cancel stroke on top of inner.
                  {
                    type: "elem",
                    elem: a,
                    shift: 0
                  },
                  {
                    type: "elem",
                    elem: d,
                    shift: b,
                    wrapperClasses: Te
                  }
                ]
              }, r);
            }
            return /cancel/.test(l) && (de.height = a.height, de.depth = a.depth), /cancel/.test(l) && !_ ? I.makeSpan(["mord", "cancel-lap"], [de], r) : I.makeSpan(["mord"], [de], r);
          }, ba = function(e, r) {
            var a = 0, l = new Q.MathNode(e.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [He(e.body, r)]);
            switch (e.label) {
              case "\\cancel":
                l.setAttribute("notation", "updiagonalstrike");
                break;
              case "\\bcancel":
                l.setAttribute("notation", "downdiagonalstrike");
                break;
              case "\\phase":
                l.setAttribute("notation", "phasorangle");
                break;
              case "\\sout":
                l.setAttribute("notation", "horizontalstrike");
                break;
              case "\\fbox":
                l.setAttribute("notation", "box");
                break;
              case "\\angl":
                l.setAttribute("notation", "actuarial");
                break;
              case "\\fcolorbox":
              case "\\colorbox":
                if (a = r.fontMetrics().fboxsep * r.fontMetrics().ptPerEm, l.setAttribute("width", "+" + 2 * a + "pt"), l.setAttribute("height", "+" + 2 * a + "pt"), l.setAttribute("lspace", a + "pt"), l.setAttribute("voffset", a + "pt"), e.label === "\\fcolorbox") {
                  var c = Math.max(
                    r.fontMetrics().fboxrule,
                    // default
                    r.minRuleThickness
                    // user override
                  );
                  l.setAttribute("style", "border: " + c + "em solid " + String(e.borderColor));
                }
                break;
              case "\\xcancel":
                l.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
                break;
            }
            return e.backgroundColor && l.setAttribute("mathbackground", e.backgroundColor), l;
          };
          oe({
            type: "enclose",
            names: ["\\colorbox"],
            props: {
              numArgs: 2,
              allowedInText: !0,
              argTypes: ["color", "text"]
            },
            handler: function(e, r, a) {
              var l = e.parser, c = e.funcName, d = be(r[0], "color-token").color, b = r[1];
              return {
                type: "enclose",
                mode: l.mode,
                label: c,
                backgroundColor: d,
                body: b
              };
            },
            htmlBuilder: va,
            mathmlBuilder: ba
          }), oe({
            type: "enclose",
            names: ["\\fcolorbox"],
            props: {
              numArgs: 3,
              allowedInText: !0,
              argTypes: ["color", "color", "text"]
            },
            handler: function(e, r, a) {
              var l = e.parser, c = e.funcName, d = be(r[0], "color-token").color, b = be(r[1], "color-token").color, _ = r[2];
              return {
                type: "enclose",
                mode: l.mode,
                label: c,
                backgroundColor: b,
                borderColor: d,
                body: _
              };
            },
            htmlBuilder: va,
            mathmlBuilder: ba
          }), oe({
            type: "enclose",
            names: ["\\fbox"],
            props: {
              numArgs: 1,
              argTypes: ["hbox"],
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "enclose",
                mode: a.mode,
                label: "\\fbox",
                body: r[0]
              };
            }
          }), oe({
            type: "enclose",
            names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0];
              return {
                type: "enclose",
                mode: a.mode,
                label: l,
                body: c
              };
            },
            htmlBuilder: va,
            mathmlBuilder: ba
          }), oe({
            type: "enclose",
            names: ["\\angl"],
            props: {
              numArgs: 1,
              argTypes: ["hbox"],
              allowedInText: !1
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "enclose",
                mode: a.mode,
                label: "\\angl",
                body: r[0]
              };
            }
          });
          var sl = {};
          function a0(m) {
            for (var e = m.type, r = m.names, a = m.props, l = m.handler, c = m.htmlBuilder, d = m.mathmlBuilder, b = {
              type: e,
              numArgs: a.numArgs || 0,
              allowedInText: !1,
              numOptionalArgs: 0,
              handler: l
            }, _ = 0; _ < r.length; ++_)
              sl[r[_]] = b;
            c && (un[e] = c), d && (cn[e] = d);
          }
          var ol = {};
          function k(m, e) {
            ol[m] = e;
          }
          var Kt = /* @__PURE__ */ function() {
            function m(e, r, a) {
              this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = r, this.end = a;
            }
            return m.range = function(r, a) {
              return a ? !r || !r.loc || !a.loc || r.loc.lexer !== a.loc.lexer ? null : new m(r.loc.lexer, r.loc.start, a.loc.end) : r && r.loc;
            }, m;
          }(), T0 = /* @__PURE__ */ function() {
            function m(r, a) {
              this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = r, this.loc = a;
            }
            var e = m.prototype;
            return e.range = function(a, l) {
              return new m(l, Kt.range(this, a));
            }, m;
          }();
          function ul(m) {
            var e = [];
            m.consumeSpaces();
            var r = m.fetch().text;
            for (r === "\\relax" && (m.consume(), m.consumeSpaces(), r = m.fetch().text); r === "\\hline" || r === "\\hdashline"; )
              m.consume(), e.push(r === "\\hdashline"), m.consumeSpaces(), r = m.fetch().text;
            return e;
          }
          var bn = function(e) {
            var r = e.parser.settings;
            if (!r.displayMode)
              throw new u("{" + e.envName + "} can be used only in display mode.");
          };
          function ya(m) {
            if (m.indexOf("ed") === -1)
              return m.indexOf("*") === -1;
          }
          function B0(m, e, r) {
            var a = e.hskipBeforeAndAfter, l = e.addJot, c = e.cols, d = e.arraystretch, b = e.colSeparationType, _ = e.autoTag, A = e.singleRow, C = e.emptySingleRow, L = e.maxNumCols, H = e.leqno;
            if (m.gullet.beginGroup(), A || m.gullet.macros.set("\\cr", "\\\\\\relax"), !d) {
              var P = m.gullet.expandMacroAsText("\\arraystretch");
              if (P == null)
                d = 1;
              else if (d = parseFloat(P), !d || d < 0)
                throw new u("Invalid \\arraystretch: " + P);
            }
            m.gullet.beginGroup();
            var W = [], te = [W], ie = [], ce = [], me = _ != null ? [] : void 0;
            function de() {
              _ && m.gullet.macros.set("\\@eqnsw", "1", !0);
            }
            function Te() {
              me && (m.gullet.macros.get("\\df@tag") ? (me.push(m.subparse([new T0("\\df@tag")])), m.gullet.macros.set("\\df@tag", void 0, !0)) : me.push(!!_ && m.gullet.macros.get("\\@eqnsw") === "1"));
            }
            for (de(), ce.push(ul(m)); ; ) {
              var ye = m.parseExpression(!1, A ? "\\end" : "\\\\");
              m.gullet.endGroup(), m.gullet.beginGroup(), ye = {
                type: "ordgroup",
                mode: m.mode,
                body: ye
              }, r && (ye = {
                type: "styling",
                mode: m.mode,
                style: r,
                body: [ye]
              }), W.push(ye);
              var ze = m.fetch().text;
              if (ze === "&") {
                if (L && W.length === L) {
                  if (A || b)
                    throw new u("Too many tab characters: &", m.nextToken);
                  m.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
                }
                m.consume();
              } else if (ze === "\\end") {
                Te(), W.length === 1 && ye.type === "styling" && ye.body[0].body.length === 0 && (te.length > 1 || !C) && te.pop(), ce.length < te.length + 1 && ce.push([]);
                break;
              } else if (ze === "\\\\") {
                m.consume();
                var Fe = void 0;
                m.gullet.future().text !== " " && (Fe = m.parseSizeGroup(!0)), ie.push(Fe ? Fe.value : null), Te(), ce.push(ul(m)), W = [], te.push(W), de();
              } else
                throw new u("Expected & or \\\\ or \\cr or \\end", m.nextToken);
            }
            return m.gullet.endGroup(), m.gullet.endGroup(), {
              type: "array",
              mode: m.mode,
              addJot: l,
              arraystretch: d,
              body: te,
              cols: c,
              rowGaps: ie,
              hskipBeforeAndAfter: a,
              hLinesBeforeRow: ce,
              colSeparationType: b,
              tags: me,
              leqno: H
            };
          }
          function wa(m) {
            return m.slice(0, 1) === "d" ? "display" : "text";
          }
          var i0 = function(e, r) {
            var a, l, c = e.body.length, d = e.hLinesBeforeRow, b = 0, _ = new Array(c), A = [], C = Math.max(
              // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
              r.fontMetrics().arrayRuleWidth,
              r.minRuleThickness
              // User override.
            ), L = 1 / r.fontMetrics().ptPerEm, H = 5 * L;
            if (e.colSeparationType && e.colSeparationType === "small") {
              var P = r.havingStyle(re.SCRIPT).sizeMultiplier;
              H = 0.2778 * (P / r.sizeMultiplier);
            }
            var W = e.colSeparationType === "CD" ? qe({
              number: 3,
              unit: "ex"
            }, r) : 12 * L, te = 3 * L, ie = e.arraystretch * W, ce = 0.7 * ie, me = 0.3 * ie, de = 0;
            function Te(kn) {
              for (var Dn = 0; Dn < kn.length; ++Dn)
                Dn > 0 && (de += 0.25), A.push({
                  pos: de,
                  isDashed: kn[Dn]
                });
            }
            for (Te(d[0]), a = 0; a < e.body.length; ++a) {
              var ye = e.body[a], ze = ce, Fe = me;
              b < ye.length && (b = ye.length);
              var Le = new Array(ye.length);
              for (l = 0; l < ye.length; ++l) {
                var We = Ee(ye[l], r);
                Fe < We.depth && (Fe = We.depth), ze < We.height && (ze = We.height), Le[l] = We;
              }
              var st = e.rowGaps[a], xt = 0;
              st && (xt = qe(st, r), xt > 0 && (xt += me, Fe < xt && (Fe = xt), xt = 0)), e.addJot && (Fe += te), Le.height = ze, Le.depth = Fe, de += ze, Le.pos = de, de += Fe + xt, _[a] = Le, Te(d[a + 1]);
            }
            var Ye = de / 2 + r.fontMetrics().axisHeight, K0 = e.cols || [], Gt = [], pt, z0, cr = [];
            if (e.tags && e.tags.some(function(kn) {
              return kn;
            }))
              for (a = 0; a < c; ++a) {
                var hr = _[a], Ma = hr.pos - Ye, N0 = e.tags[a], R0 = void 0;
                N0 === !0 ? R0 = I.makeSpan(["eqn-num"], [], r) : N0 === !1 ? R0 = I.makeSpan([], [], r) : R0 = I.makeSpan([], at(N0, r, !0), r), R0.depth = hr.depth, R0.height = hr.height, cr.push({
                  type: "elem",
                  elem: R0,
                  shift: Ma
                });
              }
            for (
              l = 0, z0 = 0;
              // Continue while either there are more columns or more column
              // descriptions, so trailing separators don't get lost.
              l < b || z0 < K0.length;
              ++l, ++z0
            ) {
              for (var Vt = K0[z0] || {}, Ir = !0; Vt.type === "separator"; ) {
                if (Ir || (pt = I.makeSpan(["arraycolsep"], []), pt.style.width = ne(r.fontMetrics().doubleRuleSep), Gt.push(pt)), Vt.separator === "|" || Vt.separator === ":") {
                  var za = Vt.separator === "|" ? "solid" : "dashed", fr = I.makeSpan(["vertical-separator"], [], r);
                  fr.style.height = ne(de), fr.style.borderRightWidth = ne(C), fr.style.borderRightStyle = za, fr.style.margin = "0 " + ne(-C / 2);
                  var Vl = de - Ye;
                  Vl && (fr.style.verticalAlign = ne(-Vl)), Gt.push(fr);
                } else
                  throw new u("Invalid separator type: " + Vt.separator);
                z0++, Vt = K0[z0] || {}, Ir = !1;
              }
              if (!(l >= b)) {
                var mr = void 0;
                (l > 0 || e.hskipBeforeAndAfter) && (mr = M.deflt(Vt.pregap, H), mr !== 0 && (pt = I.makeSpan(["arraycolsep"], []), pt.style.width = ne(mr), Gt.push(pt)));
                var dr = [];
                for (a = 0; a < c; ++a) {
                  var wn = _[a], _n = wn[l];
                  if (_n) {
                    var ic = wn.pos - Ye;
                    _n.depth = wn.depth, _n.height = wn.height, dr.push({
                      type: "elem",
                      elem: _n,
                      shift: ic
                    });
                  }
                }
                dr = I.makeVList({
                  positionType: "individualShift",
                  children: dr
                }, r), dr = I.makeSpan(["col-align-" + (Vt.align || "c")], [dr]), Gt.push(dr), (l < b - 1 || e.hskipBeforeAndAfter) && (mr = M.deflt(Vt.postgap, H), mr !== 0 && (pt = I.makeSpan(["arraycolsep"], []), pt.style.width = ne(mr), Gt.push(pt)));
              }
            }
            if (_ = I.makeSpan(["mtable"], Gt), A.length > 0) {
              for (var lc = I.makeLineSpan("hline", r, C), sc = I.makeLineSpan("hdashline", r, C), Na = [{
                type: "elem",
                elem: _,
                shift: 0
              }]; A.length > 0; ) {
                var Wl = A.pop(), jl = Wl.pos - Ye;
                Wl.isDashed ? Na.push({
                  type: "elem",
                  elem: sc,
                  shift: jl
                }) : Na.push({
                  type: "elem",
                  elem: lc,
                  shift: jl
                });
              }
              _ = I.makeVList({
                positionType: "individualShift",
                children: Na
              }, r);
            }
            if (cr.length === 0)
              return I.makeSpan(["mord"], [_], r);
            var Ra = I.makeVList({
              positionType: "individualShift",
              children: cr
            }, r);
            return Ra = I.makeSpan(["tag"], [Ra], r), I.makeFragment([_, Ra]);
          }, z1 = {
            c: "center ",
            l: "left ",
            r: "right "
          }, l0 = function(e, r) {
            for (var a = [], l = new Q.MathNode("mtd", [], ["mtr-glue"]), c = new Q.MathNode("mtd", [], ["mml-eqn-num"]), d = 0; d < e.body.length; d++) {
              for (var b = e.body[d], _ = [], A = 0; A < b.length; A++)
                _.push(new Q.MathNode("mtd", [He(b[A], r)]));
              e.tags && e.tags[d] && (_.unshift(l), _.push(l), e.leqno ? _.unshift(c) : _.push(c)), a.push(new Q.MathNode("mtr", _));
            }
            var C = new Q.MathNode("mtable", a), L = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
            C.setAttribute("rowspacing", ne(L));
            var H = "", P = "";
            if (e.cols && e.cols.length > 0) {
              var W = e.cols, te = "", ie = !1, ce = 0, me = W.length;
              W[0].type === "separator" && (H += "top ", ce = 1), W[W.length - 1].type === "separator" && (H += "bottom ", me -= 1);
              for (var de = ce; de < me; de++)
                W[de].type === "align" ? (P += z1[W[de].align], ie && (te += "none "), ie = !0) : W[de].type === "separator" && ie && (te += W[de].separator === "|" ? "solid " : "dashed ", ie = !1);
              C.setAttribute("columnalign", P.trim()), /[sd]/.test(te) && C.setAttribute("columnlines", te.trim());
            }
            if (e.colSeparationType === "align") {
              for (var Te = e.cols || [], ye = "", ze = 1; ze < Te.length; ze++)
                ye += ze % 2 ? "0em " : "1em ";
              C.setAttribute("columnspacing", ye.trim());
            } else
              e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? C.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? C.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? C.setAttribute("columnspacing", "0.5em") : C.setAttribute("columnspacing", "1em");
            var Fe = "", Le = e.hLinesBeforeRow;
            H += Le[0].length > 0 ? "left " : "", H += Le[Le.length - 1].length > 0 ? "right " : "";
            for (var We = 1; We < Le.length - 1; We++)
              Fe += Le[We].length === 0 ? "none " : Le[We][0] ? "dashed " : "solid ";
            return /[sd]/.test(Fe) && C.setAttribute("rowlines", Fe.trim()), H !== "" && (C = new Q.MathNode("menclose", [C]), C.setAttribute("notation", H.trim())), e.arraystretch && e.arraystretch < 1 && (C = new Q.MathNode("mstyle", [C]), C.setAttribute("scriptlevel", "1")), C;
          }, cl = function(e, r) {
            e.envName.indexOf("ed") === -1 && bn(e);
            var a = [], l = e.envName.indexOf("at") > -1 ? "alignat" : "align", c = e.envName === "split", d = B0(e.parser, {
              cols: a,
              addJot: !0,
              autoTag: c ? void 0 : ya(e.envName),
              emptySingleRow: !0,
              colSeparationType: l,
              maxNumCols: c ? 2 : void 0,
              leqno: e.parser.settings.leqno
            }, "display"), b, _ = 0, A = {
              type: "ordgroup",
              mode: e.mode,
              body: []
            };
            if (r[0] && r[0].type === "ordgroup") {
              for (var C = "", L = 0; L < r[0].body.length; L++) {
                var H = be(r[0].body[L], "textord");
                C += H.text;
              }
              b = Number(C), _ = b * 2;
            }
            var P = !_;
            d.body.forEach(function(ce) {
              for (var me = 1; me < ce.length; me += 2) {
                var de = be(ce[me], "styling"), Te = be(de.body[0], "ordgroup");
                Te.body.unshift(A);
              }
              if (P)
                _ < ce.length && (_ = ce.length);
              else {
                var ye = ce.length / 2;
                if (b < ye)
                  throw new u("Too many math in a row: " + ("expected " + b + ", but got " + ye), ce[0]);
              }
            });
            for (var W = 0; W < _; ++W) {
              var te = "r", ie = 0;
              W % 2 === 1 ? te = "l" : W > 0 && P && (ie = 1), a[W] = {
                type: "align",
                align: te,
                pregap: ie,
                postgap: 0
              };
            }
            return d.colSeparationType = P ? "align" : "alignat", d;
          };
          a0({
            type: "array",
            names: ["array", "darray"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = mn(r[0]), l = a ? [r[0]] : be(r[0], "ordgroup").body, c = l.map(function(b) {
                var _ = sa(b), A = _.text;
                if ("lcr".indexOf(A) !== -1)
                  return {
                    type: "align",
                    align: A
                  };
                if (A === "|")
                  return {
                    type: "separator",
                    separator: "|"
                  };
                if (A === ":")
                  return {
                    type: "separator",
                    separator: ":"
                  };
                throw new u("Unknown column alignment: " + A, b);
              }), d = {
                cols: c,
                hskipBeforeAndAfter: !0,
                // \@preamble in lttab.dtx
                maxNumCols: c.length
              };
              return B0(e.parser, d, wa(e.envName));
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var r = {
                matrix: null,
                pmatrix: ["(", ")"],
                bmatrix: ["[", "]"],
                Bmatrix: ["\\{", "\\}"],
                vmatrix: ["|", "|"],
                Vmatrix: ["\\Vert", "\\Vert"]
              }[e.envName.replace("*", "")], a = "c", l = {
                hskipBeforeAndAfter: !1,
                cols: [{
                  type: "align",
                  align: a
                }]
              };
              if (e.envName.charAt(e.envName.length - 1) === "*") {
                var c = e.parser;
                if (c.consumeSpaces(), c.fetch().text === "[") {
                  if (c.consume(), c.consumeSpaces(), a = c.fetch().text, "lcr".indexOf(a) === -1)
                    throw new u("Expected l or c or r", c.nextToken);
                  c.consume(), c.consumeSpaces(), c.expect("]"), c.consume(), l.cols = [{
                    type: "align",
                    align: a
                  }];
                }
              }
              var d = B0(e.parser, l, wa(e.envName)), b = Math.max.apply(Math, [0].concat(d.body.map(function(_) {
                return _.length;
              })));
              return d.cols = new Array(b).fill({
                type: "align",
                align: a
              }), r ? {
                type: "leftright",
                mode: e.mode,
                body: [d],
                left: r[0],
                right: r[1],
                rightColor: void 0
                // \right uninfluenced by \color in array
              } : d;
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["smallmatrix"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var r = {
                arraystretch: 0.5
              }, a = B0(e.parser, r, "script");
              return a.colSeparationType = "small", a;
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["subarray"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = mn(r[0]), l = a ? [r[0]] : be(r[0], "ordgroup").body, c = l.map(function(b) {
                var _ = sa(b), A = _.text;
                if ("lc".indexOf(A) !== -1)
                  return {
                    type: "align",
                    align: A
                  };
                throw new u("Unknown column alignment: " + A, b);
              });
              if (c.length > 1)
                throw new u("{subarray} can contain only one column");
              var d = {
                cols: c,
                hskipBeforeAndAfter: !1,
                arraystretch: 0.5
              };
              if (d = B0(e.parser, d, "script"), d.body.length > 0 && d.body[0].length > 1)
                throw new u("{subarray} can contain only one column");
              return d;
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["cases", "dcases", "rcases", "drcases"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var r = {
                arraystretch: 1.2,
                cols: [{
                  type: "align",
                  align: "l",
                  pregap: 0,
                  // TODO(kevinb) get the current style.
                  // For now we use the metrics for TEXT style which is what we were
                  // doing before.  Before attempting to get the current style we
                  // should look at TeX's behavior especially for \over and matrices.
                  postgap: 1
                  /* 1em quad */
                }, {
                  type: "align",
                  align: "l",
                  pregap: 0,
                  postgap: 0
                }]
              }, a = B0(e.parser, r, wa(e.envName));
              return {
                type: "leftright",
                mode: e.mode,
                body: [a],
                left: e.envName.indexOf("r") > -1 ? "." : "\\{",
                right: e.envName.indexOf("r") > -1 ? "\\}" : ".",
                rightColor: void 0
              };
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["align", "align*", "aligned", "split"],
            props: {
              numArgs: 0
            },
            handler: cl,
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["gathered", "gather", "gather*"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              M.contains(["gather", "gather*"], e.envName) && bn(e);
              var r = {
                cols: [{
                  type: "align",
                  align: "c"
                }],
                addJot: !0,
                colSeparationType: "gather",
                autoTag: ya(e.envName),
                emptySingleRow: !0,
                leqno: e.parser.settings.leqno
              };
              return B0(e.parser, r, "display");
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["alignat", "alignat*", "alignedat"],
            props: {
              numArgs: 1
            },
            handler: cl,
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["equation", "equation*"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              bn(e);
              var r = {
                autoTag: ya(e.envName),
                emptySingleRow: !0,
                singleRow: !0,
                maxNumCols: 1,
                leqno: e.parser.settings.leqno
              };
              return B0(e.parser, r, "display");
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), a0({
            type: "array",
            names: ["CD"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              return bn(e), y1(e.parser);
            },
            htmlBuilder: i0,
            mathmlBuilder: l0
          }), k("\\nonumber", "\\gdef\\@eqnsw{0}"), k("\\notag", "\\nonumber"), oe({
            type: "text",
            // Doesn't matter what this is.
            names: ["\\hline", "\\hdashline"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              allowedInMath: !0
            },
            handler: function(e, r) {
              throw new u(e.funcName + " valid only within array environment");
            }
          });
          var N1 = sl, hl = N1;
          oe({
            type: "environment",
            names: ["\\begin", "\\end"],
            props: {
              numArgs: 1,
              argTypes: ["text"]
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0];
              if (c.type !== "ordgroup")
                throw new u("Invalid environment name", c);
              for (var d = "", b = 0; b < c.body.length; ++b)
                d += be(c.body[b], "textord").text;
              if (l === "\\begin") {
                if (!hl.hasOwnProperty(d))
                  throw new u("No such environment: " + d, c);
                var _ = hl[d], A = a.parseArguments("\\begin{" + d + "}", _), C = A.args, L = A.optArgs, H = {
                  mode: a.mode,
                  envName: d,
                  parser: a
                }, P = _.handler(H, C, L);
                a.expect("\\end", !1);
                var W = a.nextToken, te = be(a.parseFunction(), "environment");
                if (te.name !== d)
                  throw new u("Mismatch: \\begin{" + d + "} matched by \\end{" + te.name + "}", W);
                return P;
              }
              return {
                type: "environment",
                mode: a.mode,
                name: d,
                nameGroup: c
              };
            }
          });
          var fl = function(e, r) {
            var a = e.font, l = r.withFont(a);
            return Ee(e.body, l);
          }, ml = function(e, r) {
            var a = e.font, l = r.withFont(a);
            return He(e.body, l);
          }, dl = {
            "\\Bbb": "\\mathbb",
            "\\bold": "\\mathbf",
            "\\frak": "\\mathfrak",
            "\\bm": "\\boldsymbol"
          };
          oe({
            type: "font",
            names: [
              // styles, except \boldsymbol defined below
              "\\mathrm",
              "\\mathit",
              "\\mathbf",
              "\\mathnormal",
              // families
              "\\mathbb",
              "\\mathcal",
              "\\mathfrak",
              "\\mathscr",
              "\\mathsf",
              "\\mathtt",
              // aliases, except \bm defined below
              "\\Bbb",
              "\\bold",
              "\\frak"
            ],
            props: {
              numArgs: 1,
              allowedInArgument: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = hn(r[0]), d = l;
              return d in dl && (d = dl[d]), {
                type: "font",
                mode: a.mode,
                font: d.slice(1),
                body: c
              };
            },
            htmlBuilder: fl,
            mathmlBuilder: ml
          }), oe({
            type: "mclass",
            names: ["\\boldsymbol", "\\bm"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser, l = r[0], c = M.isCharacterBox(l);
              return {
                type: "mclass",
                mode: a.mode,
                mclass: pn(l),
                body: [{
                  type: "font",
                  mode: a.mode,
                  font: "boldsymbol",
                  body: l
                }],
                isCharacterBox: c
              };
            }
          }), oe({
            type: "font",
            names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = e.breakOnTokenText, d = a.mode, b = a.parseExpression(!0, c), _ = "math" + l.slice(1);
              return {
                type: "font",
                mode: d,
                font: _,
                body: {
                  type: "ordgroup",
                  mode: a.mode,
                  body: b
                }
              };
            },
            htmlBuilder: fl,
            mathmlBuilder: ml
          });
          var pl = function(e, r) {
            var a = r;
            return e === "display" ? a = a.id >= re.SCRIPT.id ? a.text() : re.DISPLAY : e === "text" && a.size === re.DISPLAY.size ? a = re.TEXT : e === "script" ? a = re.SCRIPT : e === "scriptscript" && (a = re.SCRIPTSCRIPT), a;
          }, _a = function(e, r) {
            var a = pl(e.size, r.style), l = a.fracNum(), c = a.fracDen(), d;
            d = r.havingStyle(l);
            var b = Ee(e.numer, d, r);
            if (e.continued) {
              var _ = 8.5 / r.fontMetrics().ptPerEm, A = 3.5 / r.fontMetrics().ptPerEm;
              b.height = b.height < _ ? _ : b.height, b.depth = b.depth < A ? A : b.depth;
            }
            d = r.havingStyle(c);
            var C = Ee(e.denom, d, r), L, H, P;
            e.hasBarLine ? (e.barSize ? (H = qe(e.barSize, r), L = I.makeLineSpan("frac-line", r, H)) : L = I.makeLineSpan("frac-line", r), H = L.height, P = L.height) : (L = null, H = 0, P = r.fontMetrics().defaultRuleThickness);
            var W, te, ie;
            a.size === re.DISPLAY.size || e.size === "display" ? (W = r.fontMetrics().num1, H > 0 ? te = 3 * P : te = 7 * P, ie = r.fontMetrics().denom1) : (H > 0 ? (W = r.fontMetrics().num2, te = P) : (W = r.fontMetrics().num3, te = 3 * P), ie = r.fontMetrics().denom2);
            var ce;
            if (L) {
              var de = r.fontMetrics().axisHeight;
              W - b.depth - (de + 0.5 * H) < te && (W += te - (W - b.depth - (de + 0.5 * H))), de - 0.5 * H - (C.height - ie) < te && (ie += te - (de - 0.5 * H - (C.height - ie)));
              var Te = -(de - 0.5 * H);
              ce = I.makeVList({
                positionType: "individualShift",
                children: [{
                  type: "elem",
                  elem: C,
                  shift: ie
                }, {
                  type: "elem",
                  elem: L,
                  shift: Te
                }, {
                  type: "elem",
                  elem: b,
                  shift: -W
                }]
              }, r);
            } else {
              var me = W - b.depth - (C.height - ie);
              me < te && (W += 0.5 * (te - me), ie += 0.5 * (te - me)), ce = I.makeVList({
                positionType: "individualShift",
                children: [{
                  type: "elem",
                  elem: C,
                  shift: ie
                }, {
                  type: "elem",
                  elem: b,
                  shift: -W
                }]
              }, r);
            }
            d = r.havingStyle(a), ce.height *= d.sizeMultiplier / r.sizeMultiplier, ce.depth *= d.sizeMultiplier / r.sizeMultiplier;
            var ye;
            a.size === re.DISPLAY.size ? ye = r.fontMetrics().delim1 : a.size === re.SCRIPTSCRIPT.size ? ye = r.havingStyle(re.SCRIPT).fontMetrics().delim2 : ye = r.fontMetrics().delim2;
            var ze, Fe;
            return e.leftDelim == null ? ze = Mr(r, ["mopen"]) : ze = v0.customSizedDelim(e.leftDelim, ye, !0, r.havingStyle(a), e.mode, ["mopen"]), e.continued ? Fe = I.makeSpan([]) : e.rightDelim == null ? Fe = Mr(r, ["mclose"]) : Fe = v0.customSizedDelim(e.rightDelim, ye, !0, r.havingStyle(a), e.mode, ["mclose"]), I.makeSpan(["mord"].concat(d.sizingClasses(r)), [ze, I.makeSpan(["mfrac"], [ce]), Fe], r);
          }, ka = function(e, r) {
            var a = new Q.MathNode("mfrac", [He(e.numer, r), He(e.denom, r)]);
            if (!e.hasBarLine)
              a.setAttribute("linethickness", "0px");
            else if (e.barSize) {
              var l = qe(e.barSize, r);
              a.setAttribute("linethickness", ne(l));
            }
            var c = pl(e.size, r.style);
            if (c.size !== r.style.size) {
              a = new Q.MathNode("mstyle", [a]);
              var d = c.size === re.DISPLAY.size ? "true" : "false";
              a.setAttribute("displaystyle", d), a.setAttribute("scriptlevel", "0");
            }
            if (e.leftDelim != null || e.rightDelim != null) {
              var b = [];
              if (e.leftDelim != null) {
                var _ = new Q.MathNode("mo", [new Q.TextNode(e.leftDelim.replace("\\", ""))]);
                _.setAttribute("fence", "true"), b.push(_);
              }
              if (b.push(a), e.rightDelim != null) {
                var A = new Q.MathNode("mo", [new Q.TextNode(e.rightDelim.replace("\\", ""))]);
                A.setAttribute("fence", "true"), b.push(A);
              }
              return ia(b);
            }
            return a;
          };
          oe({
            type: "genfrac",
            names: [
              "\\dfrac",
              "\\frac",
              "\\tfrac",
              "\\dbinom",
              "\\binom",
              "\\tbinom",
              "\\\\atopfrac",
              // can’t be entered directly
              "\\\\bracefrac",
              "\\\\brackfrac"
              // ditto
            ],
            props: {
              numArgs: 2,
              allowedInArgument: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0], d = r[1], b, _ = null, A = null, C = "auto";
              switch (l) {
                case "\\dfrac":
                case "\\frac":
                case "\\tfrac":
                  b = !0;
                  break;
                case "\\\\atopfrac":
                  b = !1;
                  break;
                case "\\dbinom":
                case "\\binom":
                case "\\tbinom":
                  b = !1, _ = "(", A = ")";
                  break;
                case "\\\\bracefrac":
                  b = !1, _ = "\\{", A = "\\}";
                  break;
                case "\\\\brackfrac":
                  b = !1, _ = "[", A = "]";
                  break;
                default:
                  throw new Error("Unrecognized genfrac command");
              }
              switch (l) {
                case "\\dfrac":
                case "\\dbinom":
                  C = "display";
                  break;
                case "\\tfrac":
                case "\\tbinom":
                  C = "text";
                  break;
              }
              return {
                type: "genfrac",
                mode: a.mode,
                continued: !1,
                numer: c,
                denom: d,
                hasBarLine: b,
                leftDelim: _,
                rightDelim: A,
                size: C,
                barSize: null
              };
            },
            htmlBuilder: _a,
            mathmlBuilder: ka
          }), oe({
            type: "genfrac",
            names: ["\\cfrac"],
            props: {
              numArgs: 2
            },
            handler: function(e, r) {
              var a = e.parser;
              e.funcName;
              var l = r[0], c = r[1];
              return {
                type: "genfrac",
                mode: a.mode,
                continued: !0,
                numer: l,
                denom: c,
                hasBarLine: !0,
                leftDelim: null,
                rightDelim: null,
                size: "display",
                barSize: null
              };
            }
          }), oe({
            type: "infix",
            names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
            props: {
              numArgs: 0,
              infix: !0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName, l = e.token, c;
              switch (a) {
                case "\\over":
                  c = "\\frac";
                  break;
                case "\\choose":
                  c = "\\binom";
                  break;
                case "\\atop":
                  c = "\\\\atopfrac";
                  break;
                case "\\brace":
                  c = "\\\\bracefrac";
                  break;
                case "\\brack":
                  c = "\\\\brackfrac";
                  break;
                default:
                  throw new Error("Unrecognized infix genfrac command");
              }
              return {
                type: "infix",
                mode: r.mode,
                replaceWith: c,
                token: l
              };
            }
          });
          var gl = ["display", "text", "script", "scriptscript"], vl = function(e) {
            var r = null;
            return e.length > 0 && (r = e, r = r === "." ? null : r), r;
          };
          oe({
            type: "genfrac",
            names: ["\\genfrac"],
            props: {
              numArgs: 6,
              allowedInArgument: !0,
              argTypes: ["math", "math", "size", "text", "math", "math"]
            },
            handler: function(e, r) {
              var a = e.parser, l = r[4], c = r[5], d = hn(r[0]), b = d.type === "atom" && d.family === "open" ? vl(d.text) : null, _ = hn(r[1]), A = _.type === "atom" && _.family === "close" ? vl(_.text) : null, C = be(r[2], "size"), L, H = null;
              C.isBlank ? L = !0 : (H = C.value, L = H.number > 0);
              var P = "auto", W = r[3];
              if (W.type === "ordgroup") {
                if (W.body.length > 0) {
                  var te = be(W.body[0], "textord");
                  P = gl[Number(te.text)];
                }
              } else
                W = be(W, "textord"), P = gl[Number(W.text)];
              return {
                type: "genfrac",
                mode: a.mode,
                numer: l,
                denom: c,
                continued: !1,
                hasBarLine: L,
                barSize: H,
                leftDelim: b,
                rightDelim: A,
                size: P
              };
            },
            htmlBuilder: _a,
            mathmlBuilder: ka
          }), oe({
            type: "infix",
            names: ["\\above"],
            props: {
              numArgs: 1,
              argTypes: ["size"],
              infix: !0
            },
            handler: function(e, r) {
              var a = e.parser;
              e.funcName;
              var l = e.token;
              return {
                type: "infix",
                mode: a.mode,
                replaceWith: "\\\\abovefrac",
                size: be(r[0], "size").value,
                token: l
              };
            }
          }), oe({
            type: "genfrac",
            names: ["\\\\abovefrac"],
            props: {
              numArgs: 3,
              argTypes: ["math", "size", "math"]
            },
            handler: function(e, r) {
              var a = e.parser;
              e.funcName;
              var l = r[0], c = $(be(r[1], "infix").size), d = r[2], b = c.number > 0;
              return {
                type: "genfrac",
                mode: a.mode,
                numer: l,
                denom: d,
                continued: !1,
                hasBarLine: b,
                barSize: c,
                leftDelim: null,
                rightDelim: null,
                size: "auto"
              };
            },
            htmlBuilder: _a,
            mathmlBuilder: ka
          });
          var bl = function(e, r) {
            var a = r.style, l, c;
            e.type === "supsub" ? (l = e.sup ? Ee(e.sup, r.havingStyle(a.sup()), r) : Ee(e.sub, r.havingStyle(a.sub()), r), c = be(e.base, "horizBrace")) : c = be(e, "horizBrace");
            var d = Ee(c.base, r.havingBaseStyle(re.DISPLAY)), b = g0.svgSpan(c, r), _;
            if (c.isOver ? (_ = I.makeVList({
              positionType: "firstBaseline",
              children: [{
                type: "elem",
                elem: d
              }, {
                type: "kern",
                size: 0.1
              }, {
                type: "elem",
                elem: b
              }]
            }, r), _.children[0].children[0].children[1].classes.push("svg-align")) : (_ = I.makeVList({
              positionType: "bottom",
              positionData: d.depth + 0.1 + b.height,
              children: [{
                type: "elem",
                elem: b
              }, {
                type: "kern",
                size: 0.1
              }, {
                type: "elem",
                elem: d
              }]
            }, r), _.children[0].children[0].children[0].classes.push("svg-align")), l) {
              var A = I.makeSpan(["mord", c.isOver ? "mover" : "munder"], [_], r);
              c.isOver ? _ = I.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: A
                }, {
                  type: "kern",
                  size: 0.2
                }, {
                  type: "elem",
                  elem: l
                }]
              }, r) : _ = I.makeVList({
                positionType: "bottom",
                positionData: A.depth + 0.2 + l.height + l.depth,
                children: [{
                  type: "elem",
                  elem: l
                }, {
                  type: "kern",
                  size: 0.2
                }, {
                  type: "elem",
                  elem: A
                }]
              }, r);
            }
            return I.makeSpan(["mord", c.isOver ? "mover" : "munder"], [_], r);
          }, R1 = function(e, r) {
            var a = g0.mathMLnode(e.label);
            return new Q.MathNode(e.isOver ? "mover" : "munder", [He(e.base, r), a]);
          };
          oe({
            type: "horizBrace",
            names: ["\\overbrace", "\\underbrace"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName;
              return {
                type: "horizBrace",
                mode: a.mode,
                label: l,
                isOver: /^\\over/.test(l),
                base: r[0]
              };
            },
            htmlBuilder: bl,
            mathmlBuilder: R1
          }), oe({
            type: "href",
            names: ["\\href"],
            props: {
              numArgs: 2,
              argTypes: ["url", "original"],
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = r[1], c = be(r[0], "url").url;
              return a.settings.isTrusted({
                command: "\\href",
                url: c
              }) ? {
                type: "href",
                mode: a.mode,
                href: c,
                body: et(l)
              } : a.formatUnsupportedCmd("\\href");
            },
            htmlBuilder: function(e, r) {
              var a = at(e.body, r, !1);
              return I.makeAnchor(e.href, [], a, r);
            },
            mathmlBuilder: function(e, r) {
              var a = C0(e.body, r);
              return a instanceof Ht || (a = new Ht("mrow", [a])), a.setAttribute("href", e.href), a;
            }
          }), oe({
            type: "href",
            names: ["\\url"],
            props: {
              numArgs: 1,
              argTypes: ["url"],
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = be(r[0], "url").url;
              if (!a.settings.isTrusted({
                command: "\\url",
                url: l
              }))
                return a.formatUnsupportedCmd("\\url");
              for (var c = [], d = 0; d < l.length; d++) {
                var b = l[d];
                b === "~" && (b = "\\textasciitilde"), c.push({
                  type: "textord",
                  mode: "text",
                  text: b
                });
              }
              var _ = {
                type: "text",
                mode: a.mode,
                font: "\\texttt",
                body: c
              };
              return {
                type: "href",
                mode: a.mode,
                href: l,
                body: et(_)
              };
            }
          }), oe({
            type: "hbox",
            names: ["\\hbox"],
            props: {
              numArgs: 1,
              argTypes: ["text"],
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "hbox",
                mode: a.mode,
                body: et(r[0])
              };
            },
            htmlBuilder: function(e, r) {
              var a = at(e.body, r, !1);
              return I.makeFragment(a);
            },
            mathmlBuilder: function(e, r) {
              return new Q.MathNode("mrow", kt(e.body, r));
            }
          }), oe({
            type: "html",
            names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
            props: {
              numArgs: 2,
              argTypes: ["raw", "original"],
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName;
              e.token;
              var c = be(r[0], "raw").string, d = r[1];
              a.settings.strict && a.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
              var b, _ = {};
              switch (l) {
                case "\\htmlClass":
                  _.class = c, b = {
                    command: "\\htmlClass",
                    class: c
                  };
                  break;
                case "\\htmlId":
                  _.id = c, b = {
                    command: "\\htmlId",
                    id: c
                  };
                  break;
                case "\\htmlStyle":
                  _.style = c, b = {
                    command: "\\htmlStyle",
                    style: c
                  };
                  break;
                case "\\htmlData": {
                  for (var A = c.split(","), C = 0; C < A.length; C++) {
                    var L = A[C].split("=");
                    if (L.length !== 2)
                      throw new u("Error parsing key-value for \\htmlData");
                    _["data-" + L[0].trim()] = L[1].trim();
                  }
                  b = {
                    command: "\\htmlData",
                    attributes: _
                  };
                  break;
                }
                default:
                  throw new Error("Unrecognized html command");
              }
              return a.settings.isTrusted(b) ? {
                type: "html",
                mode: a.mode,
                attributes: _,
                body: et(d)
              } : a.formatUnsupportedCmd(l);
            },
            htmlBuilder: function(e, r) {
              var a = at(e.body, r, !1), l = ["enclosing"];
              e.attributes.class && l.push.apply(l, e.attributes.class.trim().split(/\s+/));
              var c = I.makeSpan(l, a, r);
              for (var d in e.attributes)
                d !== "class" && e.attributes.hasOwnProperty(d) && c.setAttribute(d, e.attributes[d]);
              return c;
            },
            mathmlBuilder: function(e, r) {
              return C0(e.body, r);
            }
          }), oe({
            type: "htmlmathml",
            names: ["\\html@mathml"],
            props: {
              numArgs: 2,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "htmlmathml",
                mode: a.mode,
                html: et(r[0]),
                mathml: et(r[1])
              };
            },
            htmlBuilder: function(e, r) {
              var a = at(e.html, r, !1);
              return I.makeFragment(a);
            },
            mathmlBuilder: function(e, r) {
              return C0(e.mathml, r);
            }
          });
          var Da = function(e) {
            if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
              return {
                number: +e,
                unit: "bp"
              };
            var r = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
            if (!r)
              throw new u("Invalid size: '" + e + "' in \\includegraphics");
            var a = {
              number: +(r[1] + r[2]),
              // sign + magnitude, cast to number
              unit: r[3]
            };
            if (!sr(a))
              throw new u("Invalid unit: '" + a.unit + "' in \\includegraphics.");
            return a;
          };
          oe({
            type: "includegraphics",
            names: ["\\includegraphics"],
            props: {
              numArgs: 1,
              numOptionalArgs: 1,
              argTypes: ["raw", "url"],
              allowedInText: !1
            },
            handler: function(e, r, a) {
              var l = e.parser, c = {
                number: 0,
                unit: "em"
              }, d = {
                number: 0.9,
                unit: "em"
              }, b = {
                number: 0,
                unit: "em"
              }, _ = "";
              if (a[0])
                for (var A = be(a[0], "raw").string, C = A.split(","), L = 0; L < C.length; L++) {
                  var H = C[L].split("=");
                  if (H.length === 2) {
                    var P = H[1].trim();
                    switch (H[0].trim()) {
                      case "alt":
                        _ = P;
                        break;
                      case "width":
                        c = Da(P);
                        break;
                      case "height":
                        d = Da(P);
                        break;
                      case "totalheight":
                        b = Da(P);
                        break;
                      default:
                        throw new u("Invalid key: '" + H[0] + "' in \\includegraphics.");
                    }
                  }
                }
              var W = be(r[0], "url").url;
              return _ === "" && (_ = W, _ = _.replace(/^.*[\\/]/, ""), _ = _.substring(0, _.lastIndexOf("."))), l.settings.isTrusted({
                command: "\\includegraphics",
                url: W
              }) ? {
                type: "includegraphics",
                mode: l.mode,
                alt: _,
                width: c,
                height: d,
                totalheight: b,
                src: W
              } : l.formatUnsupportedCmd("\\includegraphics");
            },
            htmlBuilder: function(e, r) {
              var a = qe(e.height, r), l = 0;
              e.totalheight.number > 0 && (l = qe(e.totalheight, r) - a);
              var c = 0;
              e.width.number > 0 && (c = qe(e.width, r));
              var d = {
                height: ne(a + l)
              };
              c > 0 && (d.width = ne(c)), l > 0 && (d.verticalAlign = ne(-l));
              var b = new tn(e.src, e.alt, d);
              return b.height = a, b.depth = l, b;
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mglyph", []);
              a.setAttribute("alt", e.alt);
              var l = qe(e.height, r), c = 0;
              if (e.totalheight.number > 0 && (c = qe(e.totalheight, r) - l, a.setAttribute("valign", ne(-c))), a.setAttribute("height", ne(l + c)), e.width.number > 0) {
                var d = qe(e.width, r);
                a.setAttribute("width", ne(d));
              }
              return a.setAttribute("src", e.src), a;
            }
          }), oe({
            type: "kern",
            names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
            props: {
              numArgs: 1,
              argTypes: ["size"],
              primitive: !0,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = be(r[0], "size");
              if (a.settings.strict) {
                var d = l[1] === "m", b = c.value.unit === "mu";
                d ? (b || a.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + l + " supports only mu units, " + ("not " + c.value.unit + " units")), a.mode !== "math" && a.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + l + " works only in math mode")) : b && a.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + l + " doesn't support mu units");
              }
              return {
                type: "kern",
                mode: a.mode,
                dimension: c.value
              };
            },
            htmlBuilder: function(e, r) {
              return I.makeGlue(e.dimension, r);
            },
            mathmlBuilder: function(e, r) {
              var a = qe(e.dimension, r);
              return new Q.SpaceNode(a);
            }
          }), oe({
            type: "lap",
            names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0];
              return {
                type: "lap",
                mode: a.mode,
                alignment: l.slice(5),
                body: c
              };
            },
            htmlBuilder: function(e, r) {
              var a;
              e.alignment === "clap" ? (a = I.makeSpan([], [Ee(e.body, r)]), a = I.makeSpan(["inner"], [a], r)) : a = I.makeSpan(["inner"], [Ee(e.body, r)]);
              var l = I.makeSpan(["fix"], []), c = I.makeSpan([e.alignment], [a, l], r), d = I.makeSpan(["strut"]);
              return d.style.height = ne(c.height + c.depth), c.depth && (d.style.verticalAlign = ne(-c.depth)), c.children.unshift(d), c = I.makeSpan(["thinbox"], [c], r), I.makeSpan(["mord", "vbox"], [c], r);
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mpadded", [He(e.body, r)]);
              if (e.alignment !== "rlap") {
                var l = e.alignment === "llap" ? "-1" : "-0.5";
                a.setAttribute("lspace", l + "width");
              }
              return a.setAttribute("width", "0px"), a;
            }
          }), oe({
            type: "styling",
            names: ["\\(", "$"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              allowedInMath: !1
            },
            handler: function(e, r) {
              var a = e.funcName, l = e.parser, c = l.mode;
              l.switchMode("math");
              var d = a === "\\(" ? "\\)" : "$", b = l.parseExpression(!1, d);
              return l.expect(d), l.switchMode(c), {
                type: "styling",
                mode: l.mode,
                style: "text",
                body: b
              };
            }
          }), oe({
            type: "text",
            // Doesn't matter what this is.
            names: ["\\)", "\\]"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              allowedInMath: !1
            },
            handler: function(e, r) {
              throw new u("Mismatched " + e.funcName);
            }
          });
          var yl = function(e, r) {
            switch (r.style.size) {
              case re.DISPLAY.size:
                return e.display;
              case re.TEXT.size:
                return e.text;
              case re.SCRIPT.size:
                return e.script;
              case re.SCRIPTSCRIPT.size:
                return e.scriptscript;
              default:
                return e.text;
            }
          };
          oe({
            type: "mathchoice",
            names: ["\\mathchoice"],
            props: {
              numArgs: 4,
              primitive: !0
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "mathchoice",
                mode: a.mode,
                display: et(r[0]),
                text: et(r[1]),
                script: et(r[2]),
                scriptscript: et(r[3])
              };
            },
            htmlBuilder: function(e, r) {
              var a = yl(e, r), l = at(a, r, !1);
              return I.makeFragment(l);
            },
            mathmlBuilder: function(e, r) {
              var a = yl(e, r);
              return C0(a, r);
            }
          });
          var wl = function(e, r, a, l, c, d, b) {
            e = I.makeSpan([], [e]);
            var _ = a && M.isCharacterBox(a), A, C;
            if (r) {
              var L = Ee(r, l.havingStyle(c.sup()), l);
              C = {
                elem: L,
                kern: Math.max(l.fontMetrics().bigOpSpacing1, l.fontMetrics().bigOpSpacing3 - L.depth)
              };
            }
            if (a) {
              var H = Ee(a, l.havingStyle(c.sub()), l);
              A = {
                elem: H,
                kern: Math.max(l.fontMetrics().bigOpSpacing2, l.fontMetrics().bigOpSpacing4 - H.height)
              };
            }
            var P;
            if (C && A) {
              var W = l.fontMetrics().bigOpSpacing5 + A.elem.height + A.elem.depth + A.kern + e.depth + b;
              P = I.makeVList({
                positionType: "bottom",
                positionData: W,
                children: [{
                  type: "kern",
                  size: l.fontMetrics().bigOpSpacing5
                }, {
                  type: "elem",
                  elem: A.elem,
                  marginLeft: ne(-d)
                }, {
                  type: "kern",
                  size: A.kern
                }, {
                  type: "elem",
                  elem: e
                }, {
                  type: "kern",
                  size: C.kern
                }, {
                  type: "elem",
                  elem: C.elem,
                  marginLeft: ne(d)
                }, {
                  type: "kern",
                  size: l.fontMetrics().bigOpSpacing5
                }]
              }, l);
            } else if (A) {
              var te = e.height - b;
              P = I.makeVList({
                positionType: "top",
                positionData: te,
                children: [{
                  type: "kern",
                  size: l.fontMetrics().bigOpSpacing5
                }, {
                  type: "elem",
                  elem: A.elem,
                  marginLeft: ne(-d)
                }, {
                  type: "kern",
                  size: A.kern
                }, {
                  type: "elem",
                  elem: e
                }]
              }, l);
            } else if (C) {
              var ie = e.depth + b;
              P = I.makeVList({
                positionType: "bottom",
                positionData: ie,
                children: [{
                  type: "elem",
                  elem: e
                }, {
                  type: "kern",
                  size: C.kern
                }, {
                  type: "elem",
                  elem: C.elem,
                  marginLeft: ne(d)
                }, {
                  type: "kern",
                  size: l.fontMetrics().bigOpSpacing5
                }]
              }, l);
            } else
              return e;
            var ce = [P];
            if (A && d !== 0 && !_) {
              var me = I.makeSpan(["mspace"], [], l);
              me.style.marginRight = ne(d), ce.unshift(me);
            }
            return I.makeSpan(["mop", "op-limits"], ce, l);
          }, _l = ["\\smallint"], ur = function(e, r) {
            var a, l, c = !1, d;
            e.type === "supsub" ? (a = e.sup, l = e.sub, d = be(e.base, "op"), c = !0) : d = be(e, "op");
            var b = r.style, _ = !1;
            b.size === re.DISPLAY.size && d.symbol && !M.contains(_l, d.name) && (_ = !0);
            var A;
            if (d.symbol) {
              var C = _ ? "Size2-Regular" : "Size1-Regular", L = "";
              if ((d.name === "\\oiint" || d.name === "\\oiiint") && (L = d.name.slice(1), d.name = L === "oiint" ? "\\iint" : "\\iiint"), A = I.makeSymbol(d.name, C, "math", r, ["mop", "op-symbol", _ ? "large-op" : "small-op"]), L.length > 0) {
                var H = A.italic, P = I.staticSvg(L + "Size" + (_ ? "2" : "1"), r);
                A = I.makeVList({
                  positionType: "individualShift",
                  children: [{
                    type: "elem",
                    elem: A,
                    shift: 0
                  }, {
                    type: "elem",
                    elem: P,
                    shift: _ ? 0.08 : 0
                  }]
                }, r), d.name = "\\" + L, A.classes.unshift("mop"), A.italic = H;
              }
            } else if (d.body) {
              var W = at(d.body, r, !0);
              W.length === 1 && W[0] instanceof mt ? (A = W[0], A.classes[0] = "mop") : A = I.makeSpan(["mop"], W, r);
            } else {
              for (var te = [], ie = 1; ie < d.name.length; ie++)
                te.push(I.mathsym(d.name[ie], d.mode, r));
              A = I.makeSpan(["mop"], te, r);
            }
            var ce = 0, me = 0;
            return (A instanceof mt || d.name === "\\oiint" || d.name === "\\oiiint") && !d.suppressBaseShift && (ce = (A.height - A.depth) / 2 - r.fontMetrics().axisHeight, me = A.italic), c ? wl(A, a, l, r, b, me, ce) : (ce && (A.style.position = "relative", A.style.top = ne(ce)), A);
          }, Lr = function(e, r) {
            var a;
            if (e.symbol)
              a = new Ht("mo", [Ut(e.name, e.mode)]), M.contains(_l, e.name) && a.setAttribute("largeop", "false");
            else if (e.body)
              a = new Ht("mo", kt(e.body, r));
            else {
              a = new Ht("mi", [new zr(e.name.slice(1))]);
              var l = new Ht("mo", [Ut("⁡", "text")]);
              e.parentIsSupSub ? a = new Ht("mrow", [a, l]) : a = Oi([a, l]);
            }
            return a;
          }, L1 = {
            "∏": "\\prod",
            "∐": "\\coprod",
            "∑": "\\sum",
            "⋀": "\\bigwedge",
            "⋁": "\\bigvee",
            "⋂": "\\bigcap",
            "⋃": "\\bigcup",
            "⨀": "\\bigodot",
            "⨁": "\\bigoplus",
            "⨂": "\\bigotimes",
            "⨄": "\\biguplus",
            "⨆": "\\bigsqcup"
          };
          oe({
            type: "op",
            names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
            props: {
              numArgs: 0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = l;
              return c.length === 1 && (c = L1[c]), {
                type: "op",
                mode: a.mode,
                limits: !0,
                parentIsSupSub: !1,
                symbol: !0,
                name: c
              };
            },
            htmlBuilder: ur,
            mathmlBuilder: Lr
          }), oe({
            type: "op",
            names: ["\\mathop"],
            props: {
              numArgs: 1,
              primitive: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = r[0];
              return {
                type: "op",
                mode: a.mode,
                limits: !1,
                parentIsSupSub: !1,
                symbol: !1,
                body: et(l)
              };
            },
            htmlBuilder: ur,
            mathmlBuilder: Lr
          });
          var I1 = {
            "∫": "\\int",
            "∬": "\\iint",
            "∭": "\\iiint",
            "∮": "\\oint",
            "∯": "\\oiint",
            "∰": "\\oiiint"
          };
          oe({
            type: "op",
            names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName;
              return {
                type: "op",
                mode: r.mode,
                limits: !1,
                parentIsSupSub: !1,
                symbol: !1,
                name: a
              };
            },
            htmlBuilder: ur,
            mathmlBuilder: Lr
          }), oe({
            type: "op",
            names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName;
              return {
                type: "op",
                mode: r.mode,
                limits: !0,
                parentIsSupSub: !1,
                symbol: !1,
                name: a
              };
            },
            htmlBuilder: ur,
            mathmlBuilder: Lr
          }), oe({
            type: "op",
            names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
            props: {
              numArgs: 0
            },
            handler: function(e) {
              var r = e.parser, a = e.funcName, l = a;
              return l.length === 1 && (l = I1[l]), {
                type: "op",
                mode: r.mode,
                limits: !1,
                parentIsSupSub: !1,
                symbol: !0,
                name: l
              };
            },
            htmlBuilder: ur,
            mathmlBuilder: Lr
          });
          var kl = function(e, r) {
            var a, l, c = !1, d;
            e.type === "supsub" ? (a = e.sup, l = e.sub, d = be(e.base, "operatorname"), c = !0) : d = be(e, "operatorname");
            var b;
            if (d.body.length > 0) {
              for (var _ = d.body.map(function(H) {
                var P = H.text;
                return typeof P == "string" ? {
                  type: "textord",
                  mode: H.mode,
                  text: P
                } : H;
              }), A = at(_, r.withFont("mathrm"), !0), C = 0; C < A.length; C++) {
                var L = A[C];
                L instanceof mt && (L.text = L.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
              }
              b = I.makeSpan(["mop"], A, r);
            } else
              b = I.makeSpan(["mop"], [], r);
            return c ? wl(b, a, l, r, r.style, 0, 0) : b;
          }, O1 = function(e, r) {
            for (var a = kt(e.body, r.withFont("mathrm")), l = !0, c = 0; c < a.length; c++) {
              var d = a[c];
              if (!(d instanceof Q.SpaceNode))
                if (d instanceof Q.MathNode)
                  switch (d.type) {
                    case "mi":
                    case "mn":
                    case "ms":
                    case "mspace":
                    case "mtext":
                      break;
                    case "mo": {
                      var b = d.children[0];
                      d.children.length === 1 && b instanceof Q.TextNode ? b.text = b.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : l = !1;
                      break;
                    }
                    default:
                      l = !1;
                  }
                else
                  l = !1;
            }
            if (l) {
              var _ = a.map(function(L) {
                return L.toText();
              }).join("");
              a = [new Q.TextNode(_)];
            }
            var A = new Q.MathNode("mi", a);
            A.setAttribute("mathvariant", "normal");
            var C = new Q.MathNode("mo", [Ut("⁡", "text")]);
            return e.parentIsSupSub ? new Q.MathNode("mrow", [A, C]) : Q.newDocumentFragment([A, C]);
          };
          oe({
            type: "operatorname",
            names: ["\\operatorname@", "\\operatornamewithlimits"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0];
              return {
                type: "operatorname",
                mode: a.mode,
                body: et(c),
                alwaysHandleSupSub: l === "\\operatornamewithlimits",
                limits: !1,
                parentIsSupSub: !1
              };
            },
            htmlBuilder: kl,
            mathmlBuilder: O1
          }), k("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@"), Z0({
            type: "ordgroup",
            htmlBuilder: function(e, r) {
              return e.semisimple ? I.makeFragment(at(e.body, r, !1)) : I.makeSpan(["mord"], at(e.body, r, !0), r);
            },
            mathmlBuilder: function(e, r) {
              return C0(e.body, r, !0);
            }
          }), oe({
            type: "overline",
            names: ["\\overline"],
            props: {
              numArgs: 1
            },
            handler: function(e, r) {
              var a = e.parser, l = r[0];
              return {
                type: "overline",
                mode: a.mode,
                body: l
              };
            },
            htmlBuilder: function(e, r) {
              var a = Ee(e.body, r.havingCrampedStyle()), l = I.makeLineSpan("overline-line", r), c = r.fontMetrics().defaultRuleThickness, d = I.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: a
                }, {
                  type: "kern",
                  size: 3 * c
                }, {
                  type: "elem",
                  elem: l
                }, {
                  type: "kern",
                  size: c
                }]
              }, r);
              return I.makeSpan(["mord", "overline"], [d], r);
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mo", [new Q.TextNode("‾")]);
              a.setAttribute("stretchy", "true");
              var l = new Q.MathNode("mover", [He(e.body, r), a]);
              return l.setAttribute("accent", "true"), l;
            }
          }), oe({
            type: "phantom",
            names: ["\\phantom"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = r[0];
              return {
                type: "phantom",
                mode: a.mode,
                body: et(l)
              };
            },
            htmlBuilder: function(e, r) {
              var a = at(e.body, r.withPhantom(), !1);
              return I.makeFragment(a);
            },
            mathmlBuilder: function(e, r) {
              var a = kt(e.body, r);
              return new Q.MathNode("mphantom", a);
            }
          }), oe({
            type: "hphantom",
            names: ["\\hphantom"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = r[0];
              return {
                type: "hphantom",
                mode: a.mode,
                body: l
              };
            },
            htmlBuilder: function(e, r) {
              var a = I.makeSpan([], [Ee(e.body, r.withPhantom())]);
              if (a.height = 0, a.depth = 0, a.children)
                for (var l = 0; l < a.children.length; l++)
                  a.children[l].height = 0, a.children[l].depth = 0;
              return a = I.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: a
                }]
              }, r), I.makeSpan(["mord"], [a], r);
            },
            mathmlBuilder: function(e, r) {
              var a = kt(et(e.body), r), l = new Q.MathNode("mphantom", a), c = new Q.MathNode("mpadded", [l]);
              return c.setAttribute("height", "0px"), c.setAttribute("depth", "0px"), c;
            }
          }), oe({
            type: "vphantom",
            names: ["\\vphantom"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = r[0];
              return {
                type: "vphantom",
                mode: a.mode,
                body: l
              };
            },
            htmlBuilder: function(e, r) {
              var a = I.makeSpan(["inner"], [Ee(e.body, r.withPhantom())]), l = I.makeSpan(["fix"], []);
              return I.makeSpan(["mord", "rlap"], [a, l], r);
            },
            mathmlBuilder: function(e, r) {
              var a = kt(et(e.body), r), l = new Q.MathNode("mphantom", a), c = new Q.MathNode("mpadded", [l]);
              return c.setAttribute("width", "0px"), c;
            }
          }), oe({
            type: "raisebox",
            names: ["\\raisebox"],
            props: {
              numArgs: 2,
              argTypes: ["size", "hbox"],
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = be(r[0], "size").value, c = r[1];
              return {
                type: "raisebox",
                mode: a.mode,
                dy: l,
                body: c
              };
            },
            htmlBuilder: function(e, r) {
              var a = Ee(e.body, r), l = qe(e.dy, r);
              return I.makeVList({
                positionType: "shift",
                positionData: -l,
                children: [{
                  type: "elem",
                  elem: a
                }]
              }, r);
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mpadded", [He(e.body, r)]), l = e.dy.number + e.dy.unit;
              return a.setAttribute("voffset", l), a;
            }
          }), oe({
            type: "internal",
            names: ["\\relax"],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e) {
              var r = e.parser;
              return {
                type: "internal",
                mode: r.mode
              };
            }
          }), oe({
            type: "rule",
            names: ["\\rule"],
            props: {
              numArgs: 2,
              numOptionalArgs: 1,
              argTypes: ["size", "size", "size"]
            },
            handler: function(e, r, a) {
              var l = e.parser, c = a[0], d = be(r[0], "size"), b = be(r[1], "size");
              return {
                type: "rule",
                mode: l.mode,
                shift: c && be(c, "size").value,
                width: d.value,
                height: b.value
              };
            },
            htmlBuilder: function(e, r) {
              var a = I.makeSpan(["mord", "rule"], [], r), l = qe(e.width, r), c = qe(e.height, r), d = e.shift ? qe(e.shift, r) : 0;
              return a.style.borderRightWidth = ne(l), a.style.borderTopWidth = ne(c), a.style.bottom = ne(d), a.width = l, a.height = c + d, a.depth = -d, a.maxFontSize = c * 1.125 * r.sizeMultiplier, a;
            },
            mathmlBuilder: function(e, r) {
              var a = qe(e.width, r), l = qe(e.height, r), c = e.shift ? qe(e.shift, r) : 0, d = r.color && r.getColor() || "black", b = new Q.MathNode("mspace");
              b.setAttribute("mathbackground", d), b.setAttribute("width", ne(a)), b.setAttribute("height", ne(l));
              var _ = new Q.MathNode("mpadded", [b]);
              return c >= 0 ? _.setAttribute("height", ne(c)) : (_.setAttribute("height", ne(c)), _.setAttribute("depth", ne(-c))), _.setAttribute("voffset", ne(c)), _;
            }
          });
          function Dl(m, e, r) {
            for (var a = at(m, e, !1), l = e.sizeMultiplier / r.sizeMultiplier, c = 0; c < a.length; c++) {
              var d = a[c].classes.indexOf("sizing");
              d < 0 ? Array.prototype.push.apply(a[c].classes, e.sizingClasses(r)) : a[c].classes[d + 1] === "reset-size" + e.size && (a[c].classes[d + 1] = "reset-size" + r.size), a[c].height *= l, a[c].depth *= l;
            }
            return I.makeFragment(a);
          }
          var Al = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], q1 = function(e, r) {
            var a = r.havingSize(e.size);
            return Dl(e.body, a, r);
          };
          oe({
            type: "sizing",
            names: Al,
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.breakOnTokenText, l = e.funcName, c = e.parser, d = c.parseExpression(!1, a);
              return {
                type: "sizing",
                mode: c.mode,
                // Figure out what size to use based on the list of functions above
                size: Al.indexOf(l) + 1,
                body: d
              };
            },
            htmlBuilder: q1,
            mathmlBuilder: function(e, r) {
              var a = r.havingSize(e.size), l = kt(e.body, a), c = new Q.MathNode("mstyle", l);
              return c.setAttribute("mathsize", ne(a.sizeMultiplier)), c;
            }
          }), oe({
            type: "smash",
            names: ["\\smash"],
            props: {
              numArgs: 1,
              numOptionalArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r, a) {
              var l = e.parser, c = !1, d = !1, b = a[0] && be(a[0], "ordgroup");
              if (b)
                for (var _ = "", A = 0; A < b.body.length; ++A) {
                  var C = b.body[A];
                  if (_ = C.text, _ === "t")
                    c = !0;
                  else if (_ === "b")
                    d = !0;
                  else {
                    c = !1, d = !1;
                    break;
                  }
                }
              else
                c = !0, d = !0;
              var L = r[0];
              return {
                type: "smash",
                mode: l.mode,
                body: L,
                smashHeight: c,
                smashDepth: d
              };
            },
            htmlBuilder: function(e, r) {
              var a = I.makeSpan([], [Ee(e.body, r)]);
              if (!e.smashHeight && !e.smashDepth)
                return a;
              if (e.smashHeight && (a.height = 0, a.children))
                for (var l = 0; l < a.children.length; l++)
                  a.children[l].height = 0;
              if (e.smashDepth && (a.depth = 0, a.children))
                for (var c = 0; c < a.children.length; c++)
                  a.children[c].depth = 0;
              var d = I.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: a
                }]
              }, r);
              return I.makeSpan(["mord"], [d], r);
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mpadded", [He(e.body, r)]);
              return e.smashHeight && a.setAttribute("height", "0px"), e.smashDepth && a.setAttribute("depth", "0px"), a;
            }
          }), oe({
            type: "sqrt",
            names: ["\\sqrt"],
            props: {
              numArgs: 1,
              numOptionalArgs: 1
            },
            handler: function(e, r, a) {
              var l = e.parser, c = a[0], d = r[0];
              return {
                type: "sqrt",
                mode: l.mode,
                body: d,
                index: c
              };
            },
            htmlBuilder: function(e, r) {
              var a = Ee(e.body, r.havingCrampedStyle());
              a.height === 0 && (a.height = r.fontMetrics().xHeight), a = I.wrapFragment(a, r);
              var l = r.fontMetrics(), c = l.defaultRuleThickness, d = c;
              r.style.id < re.TEXT.id && (d = r.fontMetrics().xHeight);
              var b = c + d / 4, _ = a.height + a.depth + b + c, A = v0.sqrtImage(_, r), C = A.span, L = A.ruleWidth, H = A.advanceWidth, P = C.height - L;
              P > a.height + a.depth + b && (b = (b + P - a.height - a.depth) / 2);
              var W = C.height - a.height - b - L;
              a.style.paddingLeft = ne(H);
              var te = I.makeVList({
                positionType: "firstBaseline",
                children: [{
                  type: "elem",
                  elem: a,
                  wrapperClasses: ["svg-align"]
                }, {
                  type: "kern",
                  size: -(a.height + W)
                }, {
                  type: "elem",
                  elem: C
                }, {
                  type: "kern",
                  size: L
                }]
              }, r);
              if (e.index) {
                var ie = r.havingStyle(re.SCRIPTSCRIPT), ce = Ee(e.index, ie, r), me = 0.6 * (te.height - te.depth), de = I.makeVList({
                  positionType: "shift",
                  positionData: -me,
                  children: [{
                    type: "elem",
                    elem: ce
                  }]
                }, r), Te = I.makeSpan(["root"], [de]);
                return I.makeSpan(["mord", "sqrt"], [Te, te], r);
              } else
                return I.makeSpan(["mord", "sqrt"], [te], r);
            },
            mathmlBuilder: function(e, r) {
              var a = e.body, l = e.index;
              return l ? new Q.MathNode("mroot", [He(a, r), He(l, r)]) : new Q.MathNode("msqrt", [He(a, r)]);
            }
          });
          var xl = {
            display: re.DISPLAY,
            text: re.TEXT,
            script: re.SCRIPT,
            scriptscript: re.SCRIPTSCRIPT
          };
          oe({
            type: "styling",
            names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
            props: {
              numArgs: 0,
              allowedInText: !0,
              primitive: !0
            },
            handler: function(e, r) {
              var a = e.breakOnTokenText, l = e.funcName, c = e.parser, d = c.parseExpression(!0, a), b = l.slice(1, l.length - 5);
              return {
                type: "styling",
                mode: c.mode,
                // Figure out what style to use by pulling out the style from
                // the function name
                style: b,
                body: d
              };
            },
            htmlBuilder: function(e, r) {
              var a = xl[e.style], l = r.havingStyle(a).withFont("");
              return Dl(e.body, l, r);
            },
            mathmlBuilder: function(e, r) {
              var a = xl[e.style], l = r.havingStyle(a), c = kt(e.body, l), d = new Q.MathNode("mstyle", c), b = {
                display: ["0", "true"],
                text: ["0", "false"],
                script: ["1", "false"],
                scriptscript: ["2", "false"]
              }, _ = b[e.style];
              return d.setAttribute("scriptlevel", _[0]), d.setAttribute("displaystyle", _[1]), d;
            }
          });
          var P1 = function(e, r) {
            var a = e.base;
            if (a)
              if (a.type === "op") {
                var l = a.limits && (r.style.size === re.DISPLAY.size || a.alwaysHandleSupSub);
                return l ? ur : null;
              } else if (a.type === "operatorname") {
                var c = a.alwaysHandleSupSub && (r.style.size === re.DISPLAY.size || a.limits);
                return c ? kl : null;
              } else {
                if (a.type === "accent")
                  return M.isCharacterBox(a.base) ? oa : null;
                if (a.type === "horizBrace") {
                  var d = !e.sub;
                  return d === a.isOver ? bl : null;
                } else
                  return null;
              }
            else
              return null;
          };
          Z0({
            type: "supsub",
            htmlBuilder: function(e, r) {
              var a = P1(e, r);
              if (a)
                return a(e, r);
              var l = e.base, c = e.sup, d = e.sub, b = Ee(l, r), _, A, C = r.fontMetrics(), L = 0, H = 0, P = l && M.isCharacterBox(l);
              if (c) {
                var W = r.havingStyle(r.style.sup());
                _ = Ee(c, W, r), P || (L = b.height - W.fontMetrics().supDrop * W.sizeMultiplier / r.sizeMultiplier);
              }
              if (d) {
                var te = r.havingStyle(r.style.sub());
                A = Ee(d, te, r), P || (H = b.depth + te.fontMetrics().subDrop * te.sizeMultiplier / r.sizeMultiplier);
              }
              var ie;
              r.style === re.DISPLAY ? ie = C.sup1 : r.style.cramped ? ie = C.sup3 : ie = C.sup2;
              var ce = r.sizeMultiplier, me = ne(0.5 / C.ptPerEm / ce), de = null;
              if (A) {
                var Te = e.base && e.base.type === "op" && e.base.name && (e.base.name === "\\oiint" || e.base.name === "\\oiiint");
                (b instanceof mt || Te) && (de = ne(-b.italic));
              }
              var ye;
              if (_ && A) {
                L = Math.max(L, ie, _.depth + 0.25 * C.xHeight), H = Math.max(H, C.sub2);
                var ze = C.defaultRuleThickness, Fe = 4 * ze;
                if (L - _.depth - (A.height - H) < Fe) {
                  H = Fe - (L - _.depth) + A.height;
                  var Le = 0.8 * C.xHeight - (L - _.depth);
                  Le > 0 && (L += Le, H -= Le);
                }
                var We = [{
                  type: "elem",
                  elem: A,
                  shift: H,
                  marginRight: me,
                  marginLeft: de
                }, {
                  type: "elem",
                  elem: _,
                  shift: -L,
                  marginRight: me
                }];
                ye = I.makeVList({
                  positionType: "individualShift",
                  children: We
                }, r);
              } else if (A) {
                H = Math.max(H, C.sub1, A.height - 0.8 * C.xHeight);
                var st = [{
                  type: "elem",
                  elem: A,
                  marginLeft: de,
                  marginRight: me
                }];
                ye = I.makeVList({
                  positionType: "shift",
                  positionData: H,
                  children: st
                }, r);
              } else if (_)
                L = Math.max(L, ie, _.depth + 0.25 * C.xHeight), ye = I.makeVList({
                  positionType: "shift",
                  positionData: -L,
                  children: [{
                    type: "elem",
                    elem: _,
                    marginRight: me
                  }]
                }, r);
              else
                throw new Error("supsub must have either sup or sub.");
              var xt = na(b, "right") || "mord";
              return I.makeSpan([xt], [b, I.makeSpan(["msupsub"], [ye])], r);
            },
            mathmlBuilder: function(e, r) {
              var a = !1, l, c;
              e.base && e.base.type === "horizBrace" && (c = !!e.sup, c === e.base.isOver && (a = !0, l = e.base.isOver)), e.base && (e.base.type === "op" || e.base.type === "operatorname") && (e.base.parentIsSupSub = !0);
              var d = [He(e.base, r)];
              e.sub && d.push(He(e.sub, r)), e.sup && d.push(He(e.sup, r));
              var b;
              if (a)
                b = l ? "mover" : "munder";
              else if (e.sub)
                if (e.sup) {
                  var C = e.base;
                  C && C.type === "op" && C.limits && r.style === re.DISPLAY || C && C.type === "operatorname" && C.alwaysHandleSupSub && (r.style === re.DISPLAY || C.limits) ? b = "munderover" : b = "msubsup";
                } else {
                  var A = e.base;
                  A && A.type === "op" && A.limits && (r.style === re.DISPLAY || A.alwaysHandleSupSub) || A && A.type === "operatorname" && A.alwaysHandleSupSub && (A.limits || r.style === re.DISPLAY) ? b = "munder" : b = "msub";
                }
              else {
                var _ = e.base;
                _ && _.type === "op" && _.limits && (r.style === re.DISPLAY || _.alwaysHandleSupSub) || _ && _.type === "operatorname" && _.alwaysHandleSupSub && (_.limits || r.style === re.DISPLAY) ? b = "mover" : b = "msup";
              }
              return new Q.MathNode(b, d);
            }
          }), Z0({
            type: "atom",
            htmlBuilder: function(e, r) {
              return I.mathsym(e.text, e.mode, r, ["m" + e.family]);
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mo", [Ut(e.text, e.mode)]);
              if (e.family === "bin") {
                var l = la(e, r);
                l === "bold-italic" && a.setAttribute("mathvariant", l);
              } else
                e.family === "punct" ? a.setAttribute("separator", "true") : (e.family === "open" || e.family === "close") && a.setAttribute("stretchy", "false");
              return a;
            }
          });
          var Sl = {
            mi: "italic",
            mn: "normal",
            mtext: "normal"
          };
          Z0({
            type: "mathord",
            htmlBuilder: function(e, r) {
              return I.makeOrd(e, r, "mathord");
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mi", [Ut(e.text, e.mode, r)]), l = la(e, r) || "italic";
              return l !== Sl[a.type] && a.setAttribute("mathvariant", l), a;
            }
          }), Z0({
            type: "textord",
            htmlBuilder: function(e, r) {
              return I.makeOrd(e, r, "textord");
            },
            mathmlBuilder: function(e, r) {
              var a = Ut(e.text, e.mode, r), l = la(e, r) || "normal", c;
              return e.mode === "text" ? c = new Q.MathNode("mtext", [a]) : /[0-9]/.test(e.text) ? c = new Q.MathNode("mn", [a]) : e.text === "\\prime" ? c = new Q.MathNode("mo", [a]) : c = new Q.MathNode("mi", [a]), l !== Sl[c.type] && c.setAttribute("mathvariant", l), c;
            }
          });
          var Aa = {
            "\\nobreak": "nobreak",
            "\\allowbreak": "allowbreak"
          }, xa = {
            " ": {},
            "\\ ": {},
            "~": {
              className: "nobreak"
            },
            "\\space": {},
            "\\nobreakspace": {
              className: "nobreak"
            }
          };
          Z0({
            type: "spacing",
            htmlBuilder: function(e, r) {
              if (xa.hasOwnProperty(e.text)) {
                var a = xa[e.text].className || "";
                if (e.mode === "text") {
                  var l = I.makeOrd(e, r, "textord");
                  return l.classes.push(a), l;
                } else
                  return I.makeSpan(["mspace", a], [I.mathsym(e.text, e.mode, r)], r);
              } else {
                if (Aa.hasOwnProperty(e.text))
                  return I.makeSpan(["mspace", Aa[e.text]], [], r);
                throw new u('Unknown type of space "' + e.text + '"');
              }
            },
            mathmlBuilder: function(e, r) {
              var a;
              if (xa.hasOwnProperty(e.text))
                a = new Q.MathNode("mtext", [new Q.TextNode(" ")]);
              else {
                if (Aa.hasOwnProperty(e.text))
                  return new Q.MathNode("mspace");
                throw new u('Unknown type of space "' + e.text + '"');
              }
              return a;
            }
          });
          var El = function() {
            var e = new Q.MathNode("mtd", []);
            return e.setAttribute("width", "50%"), e;
          };
          Z0({
            type: "tag",
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mtable", [new Q.MathNode("mtr", [El(), new Q.MathNode("mtd", [C0(e.body, r)]), El(), new Q.MathNode("mtd", [C0(e.tag, r)])])]);
              return a.setAttribute("width", "100%"), a;
            }
          });
          var Fl = {
            "\\text": void 0,
            "\\textrm": "textrm",
            "\\textsf": "textsf",
            "\\texttt": "texttt",
            "\\textnormal": "textrm"
          }, Cl = {
            "\\textbf": "textbf",
            "\\textmd": "textmd"
          }, H1 = {
            "\\textit": "textit",
            "\\textup": "textup"
          }, Tl = function(e, r) {
            var a = e.font;
            return a ? Fl[a] ? r.withTextFontFamily(Fl[a]) : Cl[a] ? r.withTextFontWeight(Cl[a]) : r.withTextFontShape(H1[a]) : r;
          };
          oe({
            type: "text",
            names: [
              // Font families
              "\\text",
              "\\textrm",
              "\\textsf",
              "\\texttt",
              "\\textnormal",
              // Font weights
              "\\textbf",
              "\\textmd",
              // Font Shapes
              "\\textit",
              "\\textup"
            ],
            props: {
              numArgs: 1,
              argTypes: ["text"],
              allowedInArgument: !0,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser, l = e.funcName, c = r[0];
              return {
                type: "text",
                mode: a.mode,
                body: et(c),
                font: l
              };
            },
            htmlBuilder: function(e, r) {
              var a = Tl(e, r), l = at(e.body, a, !0);
              return I.makeSpan(["mord", "text"], l, a);
            },
            mathmlBuilder: function(e, r) {
              var a = Tl(e, r);
              return C0(e.body, a);
            }
          }), oe({
            type: "underline",
            names: ["\\underline"],
            props: {
              numArgs: 1,
              allowedInText: !0
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "underline",
                mode: a.mode,
                body: r[0]
              };
            },
            htmlBuilder: function(e, r) {
              var a = Ee(e.body, r), l = I.makeLineSpan("underline-line", r), c = r.fontMetrics().defaultRuleThickness, d = I.makeVList({
                positionType: "top",
                positionData: a.height,
                children: [{
                  type: "kern",
                  size: c
                }, {
                  type: "elem",
                  elem: l
                }, {
                  type: "kern",
                  size: 3 * c
                }, {
                  type: "elem",
                  elem: a
                }]
              }, r);
              return I.makeSpan(["mord", "underline"], [d], r);
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.MathNode("mo", [new Q.TextNode("‾")]);
              a.setAttribute("stretchy", "true");
              var l = new Q.MathNode("munder", [He(e.body, r), a]);
              return l.setAttribute("accentunder", "true"), l;
            }
          }), oe({
            type: "vcenter",
            names: ["\\vcenter"],
            props: {
              numArgs: 1,
              argTypes: ["original"],
              // In LaTeX, \vcenter can act only on a box.
              allowedInText: !1
            },
            handler: function(e, r) {
              var a = e.parser;
              return {
                type: "vcenter",
                mode: a.mode,
                body: r[0]
              };
            },
            htmlBuilder: function(e, r) {
              var a = Ee(e.body, r), l = r.fontMetrics().axisHeight, c = 0.5 * (a.height - l - (a.depth + l));
              return I.makeVList({
                positionType: "shift",
                positionData: c,
                children: [{
                  type: "elem",
                  elem: a
                }]
              }, r);
            },
            mathmlBuilder: function(e, r) {
              return new Q.MathNode("mpadded", [He(e.body, r)], ["vcenter"]);
            }
          }), oe({
            type: "verb",
            names: ["\\verb"],
            props: {
              numArgs: 0,
              allowedInText: !0
            },
            handler: function(e, r, a) {
              throw new u("\\verb ended by end of line instead of matching delimiter");
            },
            htmlBuilder: function(e, r) {
              for (var a = Bl(e), l = [], c = r.havingStyle(r.style.text()), d = 0; d < a.length; d++) {
                var b = a[d];
                b === "~" && (b = "\\textasciitilde"), l.push(I.makeSymbol(b, "Typewriter-Regular", e.mode, c, ["mord", "texttt"]));
              }
              return I.makeSpan(["mord", "text"].concat(c.sizingClasses(r)), I.tryCombineChars(l), c);
            },
            mathmlBuilder: function(e, r) {
              var a = new Q.TextNode(Bl(e)), l = new Q.MathNode("mtext", [a]);
              return l.setAttribute("mathvariant", "monospace"), l;
            }
          });
          var Bl = function(e) {
            return e.body.replace(/ /g, e.star ? "␣" : " ");
          }, U1 = Ri, M0 = U1, Ml = `[ \r
	]`, G1 = "\\\\[a-zA-Z@]+", V1 = "\\\\[^\uD800-\uDFFF]", W1 = "(" + G1 + ")" + Ml + "*", j1 = `\\\\(
|[ \r	]+
?)[ \r	]*`, Sa = "[̀-ͯ]", X1 = new RegExp(Sa + "+$"), Y1 = "(" + Ml + "+)|" + // whitespace
          (j1 + "|") + // \whitespace
          "([!-\\[\\]-‧‪-퟿豈-￿]" + // single codepoint
          (Sa + "*") + // ...plus accents
          "|[\uD800-\uDBFF][\uDC00-\uDFFF]" + // surrogate pair
          (Sa + "*") + // ...plus accents
          "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + // \verb unstarred
          ("|" + W1) + // \macroName + spaces
          ("|" + V1 + ")"), zl = /* @__PURE__ */ function() {
            function m(r, a) {
              this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = r, this.settings = a, this.tokenRegex = new RegExp(Y1, "g"), this.catcodes = {
                "%": 14,
                // comment character
                "~": 13
                // active character
              };
            }
            var e = m.prototype;
            return e.setCatcode = function(a, l) {
              this.catcodes[a] = l;
            }, e.lex = function() {
              var a = this.input, l = this.tokenRegex.lastIndex;
              if (l === a.length)
                return new T0("EOF", new Kt(this, l, l));
              var c = this.tokenRegex.exec(a);
              if (c === null || c.index !== l)
                throw new u("Unexpected character: '" + a[l] + "'", new T0(a[l], new Kt(this, l, l + 1)));
              var d = c[6] || c[3] || (c[2] ? "\\ " : " ");
              if (this.catcodes[d] === 14) {
                var b = a.indexOf(`
`, this.tokenRegex.lastIndex);
                return b === -1 ? (this.tokenRegex.lastIndex = a.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = b + 1, this.lex();
              }
              return new T0(d, new Kt(this, l, this.tokenRegex.lastIndex));
            }, m;
          }(), Z1 = /* @__PURE__ */ function() {
            function m(r, a) {
              r === void 0 && (r = {}), a === void 0 && (a = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = a, this.builtins = r, this.undefStack = [];
            }
            var e = m.prototype;
            return e.beginGroup = function() {
              this.undefStack.push({});
            }, e.endGroup = function() {
              if (this.undefStack.length === 0)
                throw new u("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
              var a = this.undefStack.pop();
              for (var l in a)
                a.hasOwnProperty(l) && (a[l] == null ? delete this.current[l] : this.current[l] = a[l]);
            }, e.endGroups = function() {
              for (; this.undefStack.length > 0; )
                this.endGroup();
            }, e.has = function(a) {
              return this.current.hasOwnProperty(a) || this.builtins.hasOwnProperty(a);
            }, e.get = function(a) {
              return this.current.hasOwnProperty(a) ? this.current[a] : this.builtins[a];
            }, e.set = function(a, l, c) {
              if (c === void 0 && (c = !1), c) {
                for (var d = 0; d < this.undefStack.length; d++)
                  delete this.undefStack[d][a];
                this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][a] = l);
              } else {
                var b = this.undefStack[this.undefStack.length - 1];
                b && !b.hasOwnProperty(a) && (b[a] = this.current[a]);
              }
              l == null ? delete this.current[a] : this.current[a] = l;
            }, m;
          }(), K1 = ol, Q1 = K1;
          k("\\noexpand", function(m) {
            var e = m.popToken();
            return m.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
              tokens: [e],
              numArgs: 0
            };
          }), k("\\expandafter", function(m) {
            var e = m.popToken();
            return m.expandOnce(!0), {
              tokens: [e],
              numArgs: 0
            };
          }), k("\\@firstoftwo", function(m) {
            var e = m.consumeArgs(2);
            return {
              tokens: e[0],
              numArgs: 0
            };
          }), k("\\@secondoftwo", function(m) {
            var e = m.consumeArgs(2);
            return {
              tokens: e[1],
              numArgs: 0
            };
          }), k("\\@ifnextchar", function(m) {
            var e = m.consumeArgs(3);
            m.consumeSpaces();
            var r = m.future();
            return e[0].length === 1 && e[0][0].text === r.text ? {
              tokens: e[1],
              numArgs: 0
            } : {
              tokens: e[2],
              numArgs: 0
            };
          }), k("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}"), k("\\TextOrMath", function(m) {
            var e = m.consumeArgs(2);
            return m.mode === "text" ? {
              tokens: e[0],
              numArgs: 0
            } : {
              tokens: e[1],
              numArgs: 0
            };
          });
          var Nl = {
            0: 0,
            1: 1,
            2: 2,
            3: 3,
            4: 4,
            5: 5,
            6: 6,
            7: 7,
            8: 8,
            9: 9,
            a: 10,
            A: 10,
            b: 11,
            B: 11,
            c: 12,
            C: 12,
            d: 13,
            D: 13,
            e: 14,
            E: 14,
            f: 15,
            F: 15
          };
          k("\\char", function(m) {
            var e = m.popToken(), r, a = "";
            if (e.text === "'")
              r = 8, e = m.popToken();
            else if (e.text === '"')
              r = 16, e = m.popToken();
            else if (e.text === "`")
              if (e = m.popToken(), e.text[0] === "\\")
                a = e.text.charCodeAt(1);
              else {
                if (e.text === "EOF")
                  throw new u("\\char` missing argument");
                a = e.text.charCodeAt(0);
              }
            else
              r = 10;
            if (r) {
              if (a = Nl[e.text], a == null || a >= r)
                throw new u("Invalid base-" + r + " digit " + e.text);
              for (var l; (l = Nl[m.future().text]) != null && l < r; )
                a *= r, a += l, m.popToken();
            }
            return "\\@char{" + a + "}";
          });
          var Ea = function(e, r, a) {
            var l = e.consumeArg().tokens;
            if (l.length !== 1)
              throw new u("\\newcommand's first argument must be a macro name");
            var c = l[0].text, d = e.isDefined(c);
            if (d && !r)
              throw new u("\\newcommand{" + c + "} attempting to redefine " + (c + "; use \\renewcommand"));
            if (!d && !a)
              throw new u("\\renewcommand{" + c + "} when command " + c + " does not yet exist; use \\newcommand");
            var b = 0;
            if (l = e.consumeArg().tokens, l.length === 1 && l[0].text === "[") {
              for (var _ = "", A = e.expandNextToken(); A.text !== "]" && A.text !== "EOF"; )
                _ += A.text, A = e.expandNextToken();
              if (!_.match(/^\s*[0-9]+\s*$/))
                throw new u("Invalid number of arguments: " + _);
              b = parseInt(_), l = e.consumeArg().tokens;
            }
            return e.macros.set(c, {
              tokens: l,
              numArgs: b
            }), "";
          };
          k("\\newcommand", function(m) {
            return Ea(m, !1, !0);
          }), k("\\renewcommand", function(m) {
            return Ea(m, !0, !1);
          }), k("\\providecommand", function(m) {
            return Ea(m, !0, !0);
          }), k("\\message", function(m) {
            var e = m.consumeArgs(1)[0];
            return console.log(e.reverse().map(function(r) {
              return r.text;
            }).join("")), "";
          }), k("\\errmessage", function(m) {
            var e = m.consumeArgs(1)[0];
            return console.error(e.reverse().map(function(r) {
              return r.text;
            }).join("")), "";
          }), k("\\show", function(m) {
            var e = m.popToken(), r = e.text;
            return console.log(e, m.macros.get(r), M0[r], Ge.math[r], Ge.text[r]), "";
          }), k("\\bgroup", "{"), k("\\egroup", "}"), k("~", "\\nobreakspace"), k("\\lq", "`"), k("\\rq", "'"), k("\\aa", "\\r a"), k("\\AA", "\\r A"), k("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}"), k("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}"), k("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}"), k("ℬ", "\\mathscr{B}"), k("ℰ", "\\mathscr{E}"), k("ℱ", "\\mathscr{F}"), k("ℋ", "\\mathscr{H}"), k("ℐ", "\\mathscr{I}"), k("ℒ", "\\mathscr{L}"), k("ℳ", "\\mathscr{M}"), k("ℛ", "\\mathscr{R}"), k("ℭ", "\\mathfrak{C}"), k("ℌ", "\\mathfrak{H}"), k("ℨ", "\\mathfrak{Z}"), k("\\Bbbk", "\\Bbb{k}"), k("·", "\\cdotp"), k("\\llap", "\\mathllap{\\textrm{#1}}"), k("\\rlap", "\\mathrlap{\\textrm{#1}}"), k("\\clap", "\\mathclap{\\textrm{#1}}"), k("\\mathstrut", "\\vphantom{(}"), k("\\underbar", "\\underline{\\text{#1}}"), k("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}'), k("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}"), k("\\ne", "\\neq"), k("≠", "\\neq"), k("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}"), k("∉", "\\notin"), k("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}"), k("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}"), k("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}"), k("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}"), k("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}"), k("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}"), k("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}"), k("⟂", "\\perp"), k("‼", "\\mathclose{!\\mkern-0.8mu!}"), k("∌", "\\notni"), k("⌜", "\\ulcorner"), k("⌝", "\\urcorner"), k("⌞", "\\llcorner"), k("⌟", "\\lrcorner"), k("©", "\\copyright"), k("®", "\\textregistered"), k("️", "\\textregistered"), k("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}'), k("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}'), k("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}'), k("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}'), k("\\vdots", "\\mathord{\\varvdots\\rule{0pt}{15pt}}"), k("⋮", "\\vdots"), k("\\varGamma", "\\mathit{\\Gamma}"), k("\\varDelta", "\\mathit{\\Delta}"), k("\\varTheta", "\\mathit{\\Theta}"), k("\\varLambda", "\\mathit{\\Lambda}"), k("\\varXi", "\\mathit{\\Xi}"), k("\\varPi", "\\mathit{\\Pi}"), k("\\varSigma", "\\mathit{\\Sigma}"), k("\\varUpsilon", "\\mathit{\\Upsilon}"), k("\\varPhi", "\\mathit{\\Phi}"), k("\\varPsi", "\\mathit{\\Psi}"), k("\\varOmega", "\\mathit{\\Omega}"), k("\\substack", "\\begin{subarray}{c}#1\\end{subarray}"), k("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax"), k("\\boxed", "\\fbox{$\\displaystyle{#1}$}"), k("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;"), k("\\implies", "\\DOTSB\\;\\Longrightarrow\\;"), k("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
          var Rl = {
            ",": "\\dotsc",
            "\\not": "\\dotsb",
            // \keybin@ checks for the following:
            "+": "\\dotsb",
            "=": "\\dotsb",
            "<": "\\dotsb",
            ">": "\\dotsb",
            "-": "\\dotsb",
            "*": "\\dotsb",
            ":": "\\dotsb",
            // Symbols whose definition starts with \DOTSB:
            "\\DOTSB": "\\dotsb",
            "\\coprod": "\\dotsb",
            "\\bigvee": "\\dotsb",
            "\\bigwedge": "\\dotsb",
            "\\biguplus": "\\dotsb",
            "\\bigcap": "\\dotsb",
            "\\bigcup": "\\dotsb",
            "\\prod": "\\dotsb",
            "\\sum": "\\dotsb",
            "\\bigotimes": "\\dotsb",
            "\\bigoplus": "\\dotsb",
            "\\bigodot": "\\dotsb",
            "\\bigsqcup": "\\dotsb",
            "\\And": "\\dotsb",
            "\\longrightarrow": "\\dotsb",
            "\\Longrightarrow": "\\dotsb",
            "\\longleftarrow": "\\dotsb",
            "\\Longleftarrow": "\\dotsb",
            "\\longleftrightarrow": "\\dotsb",
            "\\Longleftrightarrow": "\\dotsb",
            "\\mapsto": "\\dotsb",
            "\\longmapsto": "\\dotsb",
            "\\hookrightarrow": "\\dotsb",
            "\\doteq": "\\dotsb",
            // Symbols whose definition starts with \mathbin:
            "\\mathbin": "\\dotsb",
            // Symbols whose definition starts with \mathrel:
            "\\mathrel": "\\dotsb",
            "\\relbar": "\\dotsb",
            "\\Relbar": "\\dotsb",
            "\\xrightarrow": "\\dotsb",
            "\\xleftarrow": "\\dotsb",
            // Symbols whose definition starts with \DOTSI:
            "\\DOTSI": "\\dotsi",
            "\\int": "\\dotsi",
            "\\oint": "\\dotsi",
            "\\iint": "\\dotsi",
            "\\iiint": "\\dotsi",
            "\\iiiint": "\\dotsi",
            "\\idotsint": "\\dotsi",
            // Symbols whose definition starts with \DOTSX:
            "\\DOTSX": "\\dotsx"
          };
          k("\\dots", function(m) {
            var e = "\\dotso", r = m.expandAfterFuture().text;
            return r in Rl ? e = Rl[r] : (r.slice(0, 4) === "\\not" || r in Ge.math && M.contains(["bin", "rel"], Ge.math[r].group)) && (e = "\\dotsb"), e;
          });
          var Fa = {
            // \rightdelim@ checks for the following:
            ")": !0,
            "]": !0,
            "\\rbrack": !0,
            "\\}": !0,
            "\\rbrace": !0,
            "\\rangle": !0,
            "\\rceil": !0,
            "\\rfloor": !0,
            "\\rgroup": !0,
            "\\rmoustache": !0,
            "\\right": !0,
            "\\bigr": !0,
            "\\biggr": !0,
            "\\Bigr": !0,
            "\\Biggr": !0,
            // \extra@ also tests for the following:
            $: !0,
            // \extrap@ checks for the following:
            ";": !0,
            ".": !0,
            ",": !0
          };
          k("\\dotso", function(m) {
            var e = m.future().text;
            return e in Fa ? "\\ldots\\," : "\\ldots";
          }), k("\\dotsc", function(m) {
            var e = m.future().text;
            return e in Fa && e !== "," ? "\\ldots\\," : "\\ldots";
          }), k("\\cdots", function(m) {
            var e = m.future().text;
            return e in Fa ? "\\@cdots\\," : "\\@cdots";
          }), k("\\dotsb", "\\cdots"), k("\\dotsm", "\\cdots"), k("\\dotsi", "\\!\\cdots"), k("\\dotsx", "\\ldots\\,"), k("\\DOTSI", "\\relax"), k("\\DOTSB", "\\relax"), k("\\DOTSX", "\\relax"), k("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax"), k("\\,", "\\tmspace+{3mu}{.1667em}"), k("\\thinspace", "\\,"), k("\\>", "\\mskip{4mu}"), k("\\:", "\\tmspace+{4mu}{.2222em}"), k("\\medspace", "\\:"), k("\\;", "\\tmspace+{5mu}{.2777em}"), k("\\thickspace", "\\;"), k("\\!", "\\tmspace-{3mu}{.1667em}"), k("\\negthinspace", "\\!"), k("\\negmedspace", "\\tmspace-{4mu}{.2222em}"), k("\\negthickspace", "\\tmspace-{5mu}{.277em}"), k("\\enspace", "\\kern.5em "), k("\\enskip", "\\hskip.5em\\relax"), k("\\quad", "\\hskip1em\\relax"), k("\\qquad", "\\hskip2em\\relax"), k("\\tag", "\\@ifstar\\tag@literal\\tag@paren"), k("\\tag@paren", "\\tag@literal{({#1})}"), k("\\tag@literal", function(m) {
            if (m.macros.get("\\df@tag"))
              throw new u("Multiple \\tag");
            return "\\gdef\\df@tag{\\text{#1}}";
          }), k("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}"), k("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)"), k("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}"), k("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1"), k("\\newline", "\\\\\\relax"), k("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
          var Ll = ne(Ot["Main-Regular"][84][1] - 0.7 * Ot["Main-Regular"][65][1]);
          k("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + Ll + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}"), k("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + Ll + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}"), k("\\hspace", "\\@ifstar\\@hspacer\\@hspace"), k("\\@hspace", "\\hskip #1\\relax"), k("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax"), k("\\ordinarycolon", ":"), k("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}"), k("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}'), k("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}'), k("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}'), k("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}'), k("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}'), k("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}'), k("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}'), k("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}'), k("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}'), k("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}'), k("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}'), k("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}'), k("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}'), k("∷", "\\dblcolon"), k("∹", "\\eqcolon"), k("≔", "\\coloneqq"), k("≕", "\\eqqcolon"), k("⩴", "\\Coloneqq"), k("\\ratio", "\\vcentcolon"), k("\\coloncolon", "\\dblcolon"), k("\\colonequals", "\\coloneqq"), k("\\coloncolonequals", "\\Coloneqq"), k("\\equalscolon", "\\eqqcolon"), k("\\equalscoloncolon", "\\Eqqcolon"), k("\\colonminus", "\\coloneq"), k("\\coloncolonminus", "\\Coloneq"), k("\\minuscolon", "\\eqcolon"), k("\\minuscoloncolon", "\\Eqcolon"), k("\\coloncolonapprox", "\\Colonapprox"), k("\\coloncolonsim", "\\Colonsim"), k("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), k("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}"), k("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), k("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}"), k("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}"), k("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}"), k("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}"), k("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}"), k("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}"), k("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}"), k("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}"), k("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}"), k("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}"), k("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}"), k("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}"), k("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}"), k("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}"), k("\\nleqq", "\\html@mathml{\\@nleqq}{≰}"), k("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}"), k("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}"), k("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}"), k("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}"), k("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}"), k("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}"), k("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}"), k("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}"), k("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}"), k("\\imath", "\\html@mathml{\\@imath}{ı}"), k("\\jmath", "\\html@mathml{\\@jmath}{ȷ}"), k("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}"), k("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}"), k("⟦", "\\llbracket"), k("⟧", "\\rrbracket"), k("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}"), k("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}"), k("⦃", "\\lBrace"), k("⦄", "\\rBrace"), k("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}"), k("⦵", "\\minuso"), k("\\darr", "\\downarrow"), k("\\dArr", "\\Downarrow"), k("\\Darr", "\\Downarrow"), k("\\lang", "\\langle"), k("\\rang", "\\rangle"), k("\\uarr", "\\uparrow"), k("\\uArr", "\\Uparrow"), k("\\Uarr", "\\Uparrow"), k("\\N", "\\mathbb{N}"), k("\\R", "\\mathbb{R}"), k("\\Z", "\\mathbb{Z}"), k("\\alef", "\\aleph"), k("\\alefsym", "\\aleph"), k("\\Alpha", "\\mathrm{A}"), k("\\Beta", "\\mathrm{B}"), k("\\bull", "\\bullet"), k("\\Chi", "\\mathrm{X}"), k("\\clubs", "\\clubsuit"), k("\\cnums", "\\mathbb{C}"), k("\\Complex", "\\mathbb{C}"), k("\\Dagger", "\\ddagger"), k("\\diamonds", "\\diamondsuit"), k("\\empty", "\\emptyset"), k("\\Epsilon", "\\mathrm{E}"), k("\\Eta", "\\mathrm{H}"), k("\\exist", "\\exists"), k("\\harr", "\\leftrightarrow"), k("\\hArr", "\\Leftrightarrow"), k("\\Harr", "\\Leftrightarrow"), k("\\hearts", "\\heartsuit"), k("\\image", "\\Im"), k("\\infin", "\\infty"), k("\\Iota", "\\mathrm{I}"), k("\\isin", "\\in"), k("\\Kappa", "\\mathrm{K}"), k("\\larr", "\\leftarrow"), k("\\lArr", "\\Leftarrow"), k("\\Larr", "\\Leftarrow"), k("\\lrarr", "\\leftrightarrow"), k("\\lrArr", "\\Leftrightarrow"), k("\\Lrarr", "\\Leftrightarrow"), k("\\Mu", "\\mathrm{M}"), k("\\natnums", "\\mathbb{N}"), k("\\Nu", "\\mathrm{N}"), k("\\Omicron", "\\mathrm{O}"), k("\\plusmn", "\\pm"), k("\\rarr", "\\rightarrow"), k("\\rArr", "\\Rightarrow"), k("\\Rarr", "\\Rightarrow"), k("\\real", "\\Re"), k("\\reals", "\\mathbb{R}"), k("\\Reals", "\\mathbb{R}"), k("\\Rho", "\\mathrm{P}"), k("\\sdot", "\\cdot"), k("\\sect", "\\S"), k("\\spades", "\\spadesuit"), k("\\sub", "\\subset"), k("\\sube", "\\subseteq"), k("\\supe", "\\supseteq"), k("\\Tau", "\\mathrm{T}"), k("\\thetasym", "\\vartheta"), k("\\weierp", "\\wp"), k("\\Zeta", "\\mathrm{Z}"), k("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}"), k("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}"), k("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits"), k("\\bra", "\\mathinner{\\langle{#1}|}"), k("\\ket", "\\mathinner{|{#1}\\rangle}"), k("\\braket", "\\mathinner{\\langle{#1}\\rangle}"), k("\\Bra", "\\left\\langle#1\\right|"), k("\\Ket", "\\left|#1\\right\\rangle");
          var Il = function(e) {
            return function(r) {
              var a = r.consumeArg().tokens, l = r.consumeArg().tokens, c = r.consumeArg().tokens, d = r.consumeArg().tokens, b = r.macros.get("|"), _ = r.macros.get("\\|");
              r.macros.beginGroup();
              var A = function(P) {
                return function(W) {
                  e && (W.macros.set("|", b), c.length && W.macros.set("\\|", _));
                  var te = P;
                  if (!P && c.length) {
                    var ie = W.future();
                    ie.text === "|" && (W.popToken(), te = !0);
                  }
                  return {
                    tokens: te ? c : l,
                    numArgs: 0
                  };
                };
              };
              r.macros.set("|", A(!1)), c.length && r.macros.set("\\|", A(!0));
              var C = r.consumeArg().tokens, L = r.expandTokens([].concat(d, C, a));
              return r.macros.endGroup(), {
                tokens: L.reverse(),
                numArgs: 0
              };
            };
          };
          k("\\bra@ket", Il(!1)), k("\\bra@set", Il(!0)), k("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}"), k("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}"), k("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}"), k("\\angln", "{\\angl n}"), k("\\blue", "\\textcolor{##6495ed}{#1}"), k("\\orange", "\\textcolor{##ffa500}{#1}"), k("\\pink", "\\textcolor{##ff00af}{#1}"), k("\\red", "\\textcolor{##df0030}{#1}"), k("\\green", "\\textcolor{##28ae7b}{#1}"), k("\\gray", "\\textcolor{gray}{#1}"), k("\\purple", "\\textcolor{##9d38bd}{#1}"), k("\\blueA", "\\textcolor{##ccfaff}{#1}"), k("\\blueB", "\\textcolor{##80f6ff}{#1}"), k("\\blueC", "\\textcolor{##63d9ea}{#1}"), k("\\blueD", "\\textcolor{##11accd}{#1}"), k("\\blueE", "\\textcolor{##0c7f99}{#1}"), k("\\tealA", "\\textcolor{##94fff5}{#1}"), k("\\tealB", "\\textcolor{##26edd5}{#1}"), k("\\tealC", "\\textcolor{##01d1c1}{#1}"), k("\\tealD", "\\textcolor{##01a995}{#1}"), k("\\tealE", "\\textcolor{##208170}{#1}"), k("\\greenA", "\\textcolor{##b6ffb0}{#1}"), k("\\greenB", "\\textcolor{##8af281}{#1}"), k("\\greenC", "\\textcolor{##74cf70}{#1}"), k("\\greenD", "\\textcolor{##1fab54}{#1}"), k("\\greenE", "\\textcolor{##0d923f}{#1}"), k("\\goldA", "\\textcolor{##ffd0a9}{#1}"), k("\\goldB", "\\textcolor{##ffbb71}{#1}"), k("\\goldC", "\\textcolor{##ff9c39}{#1}"), k("\\goldD", "\\textcolor{##e07d10}{#1}"), k("\\goldE", "\\textcolor{##a75a05}{#1}"), k("\\redA", "\\textcolor{##fca9a9}{#1}"), k("\\redB", "\\textcolor{##ff8482}{#1}"), k("\\redC", "\\textcolor{##f9685d}{#1}"), k("\\redD", "\\textcolor{##e84d39}{#1}"), k("\\redE", "\\textcolor{##bc2612}{#1}"), k("\\maroonA", "\\textcolor{##ffbde0}{#1}"), k("\\maroonB", "\\textcolor{##ff92c6}{#1}"), k("\\maroonC", "\\textcolor{##ed5fa6}{#1}"), k("\\maroonD", "\\textcolor{##ca337c}{#1}"), k("\\maroonE", "\\textcolor{##9e034e}{#1}"), k("\\purpleA", "\\textcolor{##ddd7ff}{#1}"), k("\\purpleB", "\\textcolor{##c6b9fc}{#1}"), k("\\purpleC", "\\textcolor{##aa87ff}{#1}"), k("\\purpleD", "\\textcolor{##7854ab}{#1}"), k("\\purpleE", "\\textcolor{##543b78}{#1}"), k("\\mintA", "\\textcolor{##f5f9e8}{#1}"), k("\\mintB", "\\textcolor{##edf2df}{#1}"), k("\\mintC", "\\textcolor{##e0e5cc}{#1}"), k("\\grayA", "\\textcolor{##f6f7f7}{#1}"), k("\\grayB", "\\textcolor{##f0f1f2}{#1}"), k("\\grayC", "\\textcolor{##e3e5e6}{#1}"), k("\\grayD", "\\textcolor{##d6d8da}{#1}"), k("\\grayE", "\\textcolor{##babec2}{#1}"), k("\\grayF", "\\textcolor{##888d93}{#1}"), k("\\grayG", "\\textcolor{##626569}{#1}"), k("\\grayH", "\\textcolor{##3b3e40}{#1}"), k("\\grayI", "\\textcolor{##21242c}{#1}"), k("\\kaBlue", "\\textcolor{##314453}{#1}"), k("\\kaGreen", "\\textcolor{##71B307}{#1}");
          var Ol = {
            "^": !0,
            // Parser.js
            _: !0,
            // Parser.js
            "\\limits": !0,
            // Parser.js
            "\\nolimits": !0
            // Parser.js
          }, J1 = /* @__PURE__ */ function() {
            function m(r, a, l) {
              this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = a, this.expansionCount = 0, this.feed(r), this.macros = new Z1(Q1, a.macros), this.mode = l, this.stack = [];
            }
            var e = m.prototype;
            return e.feed = function(a) {
              this.lexer = new zl(a, this.settings);
            }, e.switchMode = function(a) {
              this.mode = a;
            }, e.beginGroup = function() {
              this.macros.beginGroup();
            }, e.endGroup = function() {
              this.macros.endGroup();
            }, e.endGroups = function() {
              this.macros.endGroups();
            }, e.future = function() {
              return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
            }, e.popToken = function() {
              return this.future(), this.stack.pop();
            }, e.pushToken = function(a) {
              this.stack.push(a);
            }, e.pushTokens = function(a) {
              var l;
              (l = this.stack).push.apply(l, a);
            }, e.scanArgument = function(a) {
              var l, c, d;
              if (a) {
                if (this.consumeSpaces(), this.future().text !== "[")
                  return null;
                l = this.popToken();
                var b = this.consumeArg(["]"]);
                d = b.tokens, c = b.end;
              } else {
                var _ = this.consumeArg();
                d = _.tokens, l = _.start, c = _.end;
              }
              return this.pushToken(new T0("EOF", c.loc)), this.pushTokens(d), l.range(c, "");
            }, e.consumeSpaces = function() {
              for (; ; ) {
                var a = this.future();
                if (a.text === " ")
                  this.stack.pop();
                else
                  break;
              }
            }, e.consumeArg = function(a) {
              var l = [], c = a && a.length > 0;
              c || this.consumeSpaces();
              var d = this.future(), b, _ = 0, A = 0;
              do {
                if (b = this.popToken(), l.push(b), b.text === "{")
                  ++_;
                else if (b.text === "}") {
                  if (--_, _ === -1)
                    throw new u("Extra }", b);
                } else if (b.text === "EOF")
                  throw new u("Unexpected end of input in a macro argument, expected '" + (a && c ? a[A] : "}") + "'", b);
                if (a && c)
                  if ((_ === 0 || _ === 1 && a[A] === "{") && b.text === a[A]) {
                    if (++A, A === a.length) {
                      l.splice(-A, A);
                      break;
                    }
                  } else
                    A = 0;
              } while (_ !== 0 || c);
              return d.text === "{" && l[l.length - 1].text === "}" && (l.pop(), l.shift()), l.reverse(), {
                tokens: l,
                start: d,
                end: b
              };
            }, e.consumeArgs = function(a, l) {
              if (l) {
                if (l.length !== a + 1)
                  throw new u("The length of delimiters doesn't match the number of args!");
                for (var c = l[0], d = 0; d < c.length; d++) {
                  var b = this.popToken();
                  if (c[d] !== b.text)
                    throw new u("Use of the macro doesn't match its definition", b);
                }
              }
              for (var _ = [], A = 0; A < a; A++)
                _.push(this.consumeArg(l && l[A + 1]).tokens);
              return _;
            }, e.expandOnce = function(a) {
              var l = this.popToken(), c = l.text, d = l.noexpand ? null : this._getExpansion(c);
              if (d == null || a && d.unexpandable) {
                if (a && d == null && c[0] === "\\" && !this.isDefined(c))
                  throw new u("Undefined control sequence: " + c);
                return this.pushToken(l), !1;
              }
              if (this.expansionCount++, this.expansionCount > this.settings.maxExpand)
                throw new u("Too many expansions: infinite loop or need to increase maxExpand setting");
              var b = d.tokens, _ = this.consumeArgs(d.numArgs, d.delimiters);
              if (d.numArgs) {
                b = b.slice();
                for (var A = b.length - 1; A >= 0; --A) {
                  var C = b[A];
                  if (C.text === "#") {
                    if (A === 0)
                      throw new u("Incomplete placeholder at end of macro body", C);
                    if (C = b[--A], C.text === "#")
                      b.splice(A + 1, 1);
                    else if (/^[1-9]$/.test(C.text)) {
                      var L;
                      (L = b).splice.apply(L, [A, 2].concat(_[+C.text - 1]));
                    } else
                      throw new u("Not a valid argument number", C);
                  }
                }
              }
              return this.pushTokens(b), b.length;
            }, e.expandAfterFuture = function() {
              return this.expandOnce(), this.future();
            }, e.expandNextToken = function() {
              for (; ; )
                if (this.expandOnce() === !1) {
                  var a = this.stack.pop();
                  return a.treatAsRelax && (a.text = "\\relax"), a;
                }
              throw new Error();
            }, e.expandMacro = function(a) {
              return this.macros.has(a) ? this.expandTokens([new T0(a)]) : void 0;
            }, e.expandTokens = function(a) {
              var l = [], c = this.stack.length;
              for (this.pushTokens(a); this.stack.length > c; )
                if (this.expandOnce(!0) === !1) {
                  var d = this.stack.pop();
                  d.treatAsRelax && (d.noexpand = !1, d.treatAsRelax = !1), l.push(d);
                }
              return l;
            }, e.expandMacroAsText = function(a) {
              var l = this.expandMacro(a);
              return l && l.map(function(c) {
                return c.text;
              }).join("");
            }, e._getExpansion = function(a) {
              var l = this.macros.get(a);
              if (l == null)
                return l;
              if (a.length === 1) {
                var c = this.lexer.catcodes[a];
                if (c != null && c !== 13)
                  return;
              }
              var d = typeof l == "function" ? l(this) : l;
              if (typeof d == "string") {
                var b = 0;
                if (d.indexOf("#") !== -1)
                  for (var _ = d.replace(/##/g, ""); _.indexOf("#" + (b + 1)) !== -1; )
                    ++b;
                for (var A = new zl(d, this.settings), C = [], L = A.lex(); L.text !== "EOF"; )
                  C.push(L), L = A.lex();
                C.reverse();
                var H = {
                  tokens: C,
                  numArgs: b
                };
                return H;
              }
              return d;
            }, e.isDefined = function(a) {
              return this.macros.has(a) || M0.hasOwnProperty(a) || Ge.math.hasOwnProperty(a) || Ge.text.hasOwnProperty(a) || Ol.hasOwnProperty(a);
            }, e.isExpandable = function(a) {
              var l = this.macros.get(a);
              return l != null ? typeof l == "string" || typeof l == "function" || !l.unexpandable : M0.hasOwnProperty(a) && !M0[a].primitive;
            }, m;
          }(), ql = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, yn = Object.freeze({
            "₊": "+",
            "₋": "-",
            "₌": "=",
            "₍": "(",
            "₎": ")",
            "₀": "0",
            "₁": "1",
            "₂": "2",
            "₃": "3",
            "₄": "4",
            "₅": "5",
            "₆": "6",
            "₇": "7",
            "₈": "8",
            "₉": "9",
            "ₐ": "a",
            "ₑ": "e",
            "ₕ": "h",
            "ᵢ": "i",
            "ⱼ": "j",
            "ₖ": "k",
            "ₗ": "l",
            "ₘ": "m",
            "ₙ": "n",
            "ₒ": "o",
            "ₚ": "p",
            "ᵣ": "r",
            "ₛ": "s",
            "ₜ": "t",
            "ᵤ": "u",
            "ᵥ": "v",
            "ₓ": "x",
            "ᵦ": "β",
            "ᵧ": "γ",
            "ᵨ": "ρ",
            "ᵩ": "ϕ",
            "ᵪ": "χ",
            "⁺": "+",
            "⁻": "-",
            "⁼": "=",
            "⁽": "(",
            "⁾": ")",
            "⁰": "0",
            "¹": "1",
            "²": "2",
            "³": "3",
            "⁴": "4",
            "⁵": "5",
            "⁶": "6",
            "⁷": "7",
            "⁸": "8",
            "⁹": "9",
            "ᴬ": "A",
            "ᴮ": "B",
            "ᴰ": "D",
            "ᴱ": "E",
            "ᴳ": "G",
            "ᴴ": "H",
            "ᴵ": "I",
            "ᴶ": "J",
            "ᴷ": "K",
            "ᴸ": "L",
            "ᴹ": "M",
            "ᴺ": "N",
            "ᴼ": "O",
            "ᴾ": "P",
            "ᴿ": "R",
            "ᵀ": "T",
            "ᵁ": "U",
            "ⱽ": "V",
            "ᵂ": "W",
            "ᵃ": "a",
            "ᵇ": "b",
            "ᶜ": "c",
            "ᵈ": "d",
            "ᵉ": "e",
            "ᶠ": "f",
            "ᵍ": "g",
            ʰ: "h",
            "ⁱ": "i",
            ʲ: "j",
            "ᵏ": "k",
            ˡ: "l",
            "ᵐ": "m",
            ⁿ: "n",
            "ᵒ": "o",
            "ᵖ": "p",
            ʳ: "r",
            ˢ: "s",
            "ᵗ": "t",
            "ᵘ": "u",
            "ᵛ": "v",
            ʷ: "w",
            ˣ: "x",
            ʸ: "y",
            "ᶻ": "z",
            "ᵝ": "β",
            "ᵞ": "γ",
            "ᵟ": "δ",
            "ᵠ": "ϕ",
            "ᵡ": "χ",
            "ᶿ": "θ"
          }), Ca = {
            "́": {
              text: "\\'",
              math: "\\acute"
            },
            "̀": {
              text: "\\`",
              math: "\\grave"
            },
            "̈": {
              text: '\\"',
              math: "\\ddot"
            },
            "̃": {
              text: "\\~",
              math: "\\tilde"
            },
            "̄": {
              text: "\\=",
              math: "\\bar"
            },
            "̆": {
              text: "\\u",
              math: "\\breve"
            },
            "̌": {
              text: "\\v",
              math: "\\check"
            },
            "̂": {
              text: "\\^",
              math: "\\hat"
            },
            "̇": {
              text: "\\.",
              math: "\\dot"
            },
            "̊": {
              text: "\\r",
              math: "\\mathring"
            },
            "̋": {
              text: "\\H"
            },
            "̧": {
              text: "\\c"
            }
          }, Pl = {
            á: "á",
            à: "à",
            ä: "ä",
            ǟ: "ǟ",
            ã: "ã",
            ā: "ā",
            ă: "ă",
            ắ: "ắ",
            ằ: "ằ",
            ẵ: "ẵ",
            ǎ: "ǎ",
            â: "â",
            ấ: "ấ",
            ầ: "ầ",
            ẫ: "ẫ",
            ȧ: "ȧ",
            ǡ: "ǡ",
            å: "å",
            ǻ: "ǻ",
            ḃ: "ḃ",
            ć: "ć",
            ḉ: "ḉ",
            č: "č",
            ĉ: "ĉ",
            ċ: "ċ",
            ç: "ç",
            ď: "ď",
            ḋ: "ḋ",
            ḑ: "ḑ",
            é: "é",
            è: "è",
            ë: "ë",
            ẽ: "ẽ",
            ē: "ē",
            ḗ: "ḗ",
            ḕ: "ḕ",
            ĕ: "ĕ",
            ḝ: "ḝ",
            ě: "ě",
            ê: "ê",
            ế: "ế",
            ề: "ề",
            ễ: "ễ",
            ė: "ė",
            ȩ: "ȩ",
            ḟ: "ḟ",
            ǵ: "ǵ",
            ḡ: "ḡ",
            ğ: "ğ",
            ǧ: "ǧ",
            ĝ: "ĝ",
            ġ: "ġ",
            ģ: "ģ",
            ḧ: "ḧ",
            ȟ: "ȟ",
            ĥ: "ĥ",
            ḣ: "ḣ",
            ḩ: "ḩ",
            í: "í",
            ì: "ì",
            ï: "ï",
            ḯ: "ḯ",
            ĩ: "ĩ",
            ī: "ī",
            ĭ: "ĭ",
            ǐ: "ǐ",
            î: "î",
            ǰ: "ǰ",
            ĵ: "ĵ",
            ḱ: "ḱ",
            ǩ: "ǩ",
            ķ: "ķ",
            ĺ: "ĺ",
            ľ: "ľ",
            ļ: "ļ",
            ḿ: "ḿ",
            ṁ: "ṁ",
            ń: "ń",
            ǹ: "ǹ",
            ñ: "ñ",
            ň: "ň",
            ṅ: "ṅ",
            ņ: "ņ",
            ó: "ó",
            ò: "ò",
            ö: "ö",
            ȫ: "ȫ",
            õ: "õ",
            ṍ: "ṍ",
            ṏ: "ṏ",
            ȭ: "ȭ",
            ō: "ō",
            ṓ: "ṓ",
            ṑ: "ṑ",
            ŏ: "ŏ",
            ǒ: "ǒ",
            ô: "ô",
            ố: "ố",
            ồ: "ồ",
            ỗ: "ỗ",
            ȯ: "ȯ",
            ȱ: "ȱ",
            ő: "ő",
            ṕ: "ṕ",
            ṗ: "ṗ",
            ŕ: "ŕ",
            ř: "ř",
            ṙ: "ṙ",
            ŗ: "ŗ",
            ś: "ś",
            ṥ: "ṥ",
            š: "š",
            ṧ: "ṧ",
            ŝ: "ŝ",
            ṡ: "ṡ",
            ş: "ş",
            ẗ: "ẗ",
            ť: "ť",
            ṫ: "ṫ",
            ţ: "ţ",
            ú: "ú",
            ù: "ù",
            ü: "ü",
            ǘ: "ǘ",
            ǜ: "ǜ",
            ǖ: "ǖ",
            ǚ: "ǚ",
            ũ: "ũ",
            ṹ: "ṹ",
            ū: "ū",
            ṻ: "ṻ",
            ŭ: "ŭ",
            ǔ: "ǔ",
            û: "û",
            ů: "ů",
            ű: "ű",
            ṽ: "ṽ",
            ẃ: "ẃ",
            ẁ: "ẁ",
            ẅ: "ẅ",
            ŵ: "ŵ",
            ẇ: "ẇ",
            ẘ: "ẘ",
            ẍ: "ẍ",
            ẋ: "ẋ",
            ý: "ý",
            ỳ: "ỳ",
            ÿ: "ÿ",
            ỹ: "ỹ",
            ȳ: "ȳ",
            ŷ: "ŷ",
            ẏ: "ẏ",
            ẙ: "ẙ",
            ź: "ź",
            ž: "ž",
            ẑ: "ẑ",
            ż: "ż",
            Á: "Á",
            À: "À",
            Ä: "Ä",
            Ǟ: "Ǟ",
            Ã: "Ã",
            Ā: "Ā",
            Ă: "Ă",
            Ắ: "Ắ",
            Ằ: "Ằ",
            Ẵ: "Ẵ",
            Ǎ: "Ǎ",
            Â: "Â",
            Ấ: "Ấ",
            Ầ: "Ầ",
            Ẫ: "Ẫ",
            Ȧ: "Ȧ",
            Ǡ: "Ǡ",
            Å: "Å",
            Ǻ: "Ǻ",
            Ḃ: "Ḃ",
            Ć: "Ć",
            Ḉ: "Ḉ",
            Č: "Č",
            Ĉ: "Ĉ",
            Ċ: "Ċ",
            Ç: "Ç",
            Ď: "Ď",
            Ḋ: "Ḋ",
            Ḑ: "Ḑ",
            É: "É",
            È: "È",
            Ë: "Ë",
            Ẽ: "Ẽ",
            Ē: "Ē",
            Ḗ: "Ḗ",
            Ḕ: "Ḕ",
            Ĕ: "Ĕ",
            Ḝ: "Ḝ",
            Ě: "Ě",
            Ê: "Ê",
            Ế: "Ế",
            Ề: "Ề",
            Ễ: "Ễ",
            Ė: "Ė",
            Ȩ: "Ȩ",
            Ḟ: "Ḟ",
            Ǵ: "Ǵ",
            Ḡ: "Ḡ",
            Ğ: "Ğ",
            Ǧ: "Ǧ",
            Ĝ: "Ĝ",
            Ġ: "Ġ",
            Ģ: "Ģ",
            Ḧ: "Ḧ",
            Ȟ: "Ȟ",
            Ĥ: "Ĥ",
            Ḣ: "Ḣ",
            Ḩ: "Ḩ",
            Í: "Í",
            Ì: "Ì",
            Ï: "Ï",
            Ḯ: "Ḯ",
            Ĩ: "Ĩ",
            Ī: "Ī",
            Ĭ: "Ĭ",
            Ǐ: "Ǐ",
            Î: "Î",
            İ: "İ",
            Ĵ: "Ĵ",
            Ḱ: "Ḱ",
            Ǩ: "Ǩ",
            Ķ: "Ķ",
            Ĺ: "Ĺ",
            Ľ: "Ľ",
            Ļ: "Ļ",
            Ḿ: "Ḿ",
            Ṁ: "Ṁ",
            Ń: "Ń",
            Ǹ: "Ǹ",
            Ñ: "Ñ",
            Ň: "Ň",
            Ṅ: "Ṅ",
            Ņ: "Ņ",
            Ó: "Ó",
            Ò: "Ò",
            Ö: "Ö",
            Ȫ: "Ȫ",
            Õ: "Õ",
            Ṍ: "Ṍ",
            Ṏ: "Ṏ",
            Ȭ: "Ȭ",
            Ō: "Ō",
            Ṓ: "Ṓ",
            Ṑ: "Ṑ",
            Ŏ: "Ŏ",
            Ǒ: "Ǒ",
            Ô: "Ô",
            Ố: "Ố",
            Ồ: "Ồ",
            Ỗ: "Ỗ",
            Ȯ: "Ȯ",
            Ȱ: "Ȱ",
            Ő: "Ő",
            Ṕ: "Ṕ",
            Ṗ: "Ṗ",
            Ŕ: "Ŕ",
            Ř: "Ř",
            Ṙ: "Ṙ",
            Ŗ: "Ŗ",
            Ś: "Ś",
            Ṥ: "Ṥ",
            Š: "Š",
            Ṧ: "Ṧ",
            Ŝ: "Ŝ",
            Ṡ: "Ṡ",
            Ş: "Ş",
            Ť: "Ť",
            Ṫ: "Ṫ",
            Ţ: "Ţ",
            Ú: "Ú",
            Ù: "Ù",
            Ü: "Ü",
            Ǘ: "Ǘ",
            Ǜ: "Ǜ",
            Ǖ: "Ǖ",
            Ǚ: "Ǚ",
            Ũ: "Ũ",
            Ṹ: "Ṹ",
            Ū: "Ū",
            Ṻ: "Ṻ",
            Ŭ: "Ŭ",
            Ǔ: "Ǔ",
            Û: "Û",
            Ů: "Ů",
            Ű: "Ű",
            Ṽ: "Ṽ",
            Ẃ: "Ẃ",
            Ẁ: "Ẁ",
            Ẅ: "Ẅ",
            Ŵ: "Ŵ",
            Ẇ: "Ẇ",
            Ẍ: "Ẍ",
            Ẋ: "Ẋ",
            Ý: "Ý",
            Ỳ: "Ỳ",
            Ÿ: "Ÿ",
            Ỹ: "Ỹ",
            Ȳ: "Ȳ",
            Ŷ: "Ŷ",
            Ẏ: "Ẏ",
            Ź: "Ź",
            Ž: "Ž",
            Ẑ: "Ẑ",
            Ż: "Ż",
            ά: "ά",
            ὰ: "ὰ",
            ᾱ: "ᾱ",
            ᾰ: "ᾰ",
            έ: "έ",
            ὲ: "ὲ",
            ή: "ή",
            ὴ: "ὴ",
            ί: "ί",
            ὶ: "ὶ",
            ϊ: "ϊ",
            ΐ: "ΐ",
            ῒ: "ῒ",
            ῑ: "ῑ",
            ῐ: "ῐ",
            ό: "ό",
            ὸ: "ὸ",
            ύ: "ύ",
            ὺ: "ὺ",
            ϋ: "ϋ",
            ΰ: "ΰ",
            ῢ: "ῢ",
            ῡ: "ῡ",
            ῠ: "ῠ",
            ώ: "ώ",
            ὼ: "ὼ",
            Ύ: "Ύ",
            Ὺ: "Ὺ",
            Ϋ: "Ϋ",
            Ῡ: "Ῡ",
            Ῠ: "Ῠ",
            Ώ: "Ώ",
            Ὼ: "Ὼ"
          }, Hl = /* @__PURE__ */ function() {
            function m(r, a) {
              this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new J1(r, a, this.mode), this.settings = a, this.leftrightDepth = 0;
            }
            var e = m.prototype;
            return e.expect = function(a, l) {
              if (l === void 0 && (l = !0), this.fetch().text !== a)
                throw new u("Expected '" + a + "', got '" + this.fetch().text + "'", this.fetch());
              l && this.consume();
            }, e.consume = function() {
              this.nextToken = null;
            }, e.fetch = function() {
              return this.nextToken == null && (this.nextToken = this.gullet.expandNextToken()), this.nextToken;
            }, e.switchMode = function(a) {
              this.mode = a, this.gullet.switchMode(a);
            }, e.parse = function() {
              this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
              try {
                var a = this.parseExpression(!1);
                return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), a;
              } finally {
                this.gullet.endGroups();
              }
            }, e.subparse = function(a) {
              var l = this.nextToken;
              this.consume(), this.gullet.pushToken(new T0("}")), this.gullet.pushTokens(a);
              var c = this.parseExpression(!1);
              return this.expect("}"), this.nextToken = l, c;
            }, e.parseExpression = function(a, l) {
              for (var c = []; ; ) {
                this.mode === "math" && this.consumeSpaces();
                var d = this.fetch();
                if (m.endOfExpression.indexOf(d.text) !== -1 || l && d.text === l || a && M0[d.text] && M0[d.text].infix)
                  break;
                var b = this.parseAtom(l);
                if (b) {
                  if (b.type === "internal")
                    continue;
                } else
                  break;
                c.push(b);
              }
              return this.mode === "text" && this.formLigatures(c), this.handleInfixNodes(c);
            }, e.handleInfixNodes = function(a) {
              for (var l = -1, c, d = 0; d < a.length; d++)
                if (a[d].type === "infix") {
                  if (l !== -1)
                    throw new u("only one infix operator per group", a[d].token);
                  l = d, c = a[d].replaceWith;
                }
              if (l !== -1 && c) {
                var b, _, A = a.slice(0, l), C = a.slice(l + 1);
                A.length === 1 && A[0].type === "ordgroup" ? b = A[0] : b = {
                  type: "ordgroup",
                  mode: this.mode,
                  body: A
                }, C.length === 1 && C[0].type === "ordgroup" ? _ = C[0] : _ = {
                  type: "ordgroup",
                  mode: this.mode,
                  body: C
                };
                var L;
                return c === "\\\\abovefrac" ? L = this.callFunction(c, [b, a[l], _], []) : L = this.callFunction(c, [b, _], []), [L];
              } else
                return a;
            }, e.handleSupSubscript = function(a) {
              var l = this.fetch(), c = l.text;
              this.consume(), this.consumeSpaces();
              var d = this.parseGroup(a);
              if (!d)
                throw new u("Expected group after '" + c + "'", l);
              return d;
            }, e.formatUnsupportedCmd = function(a) {
              for (var l = [], c = 0; c < a.length; c++)
                l.push({
                  type: "textord",
                  mode: "text",
                  text: a[c]
                });
              var d = {
                type: "text",
                mode: this.mode,
                body: l
              }, b = {
                type: "color",
                mode: this.mode,
                color: this.settings.errorColor,
                body: [d]
              };
              return b;
            }, e.parseAtom = function(a) {
              var l = this.parseGroup("atom", a);
              if (this.mode === "text")
                return l;
              for (var c, d; ; ) {
                this.consumeSpaces();
                var b = this.fetch();
                if (b.text === "\\limits" || b.text === "\\nolimits") {
                  if (l && l.type === "op") {
                    var _ = b.text === "\\limits";
                    l.limits = _, l.alwaysHandleSupSub = !0;
                  } else if (l && l.type === "operatorname")
                    l.alwaysHandleSupSub && (l.limits = b.text === "\\limits");
                  else
                    throw new u("Limit controls must follow a math operator", b);
                  this.consume();
                } else if (b.text === "^") {
                  if (c)
                    throw new u("Double superscript", b);
                  c = this.handleSupSubscript("superscript");
                } else if (b.text === "_") {
                  if (d)
                    throw new u("Double subscript", b);
                  d = this.handleSupSubscript("subscript");
                } else if (b.text === "'") {
                  if (c)
                    throw new u("Double superscript", b);
                  var A = {
                    type: "textord",
                    mode: this.mode,
                    text: "\\prime"
                  }, C = [A];
                  for (this.consume(); this.fetch().text === "'"; )
                    C.push(A), this.consume();
                  this.fetch().text === "^" && C.push(this.handleSupSubscript("superscript")), c = {
                    type: "ordgroup",
                    mode: this.mode,
                    body: C
                  };
                } else if (yn[b.text]) {
                  var L = yn[b.text], H = ql.test(b.text);
                  for (this.consume(); ; ) {
                    var P = this.fetch().text;
                    if (!yn[P] || ql.test(P) !== H)
                      break;
                    this.consume(), L += yn[P];
                  }
                  var W = new m(L, this.settings).parse();
                  H ? d = {
                    type: "ordgroup",
                    mode: "math",
                    body: W
                  } : c = {
                    type: "ordgroup",
                    mode: "math",
                    body: W
                  };
                } else
                  break;
              }
              return c || d ? {
                type: "supsub",
                mode: this.mode,
                base: l,
                sup: c,
                sub: d
              } : l;
            }, e.parseFunction = function(a, l) {
              var c = this.fetch(), d = c.text, b = M0[d];
              if (!b)
                return null;
              if (this.consume(), l && l !== "atom" && !b.allowedInArgument)
                throw new u("Got function '" + d + "' with no arguments" + (l ? " as " + l : ""), c);
              if (this.mode === "text" && !b.allowedInText)
                throw new u("Can't use function '" + d + "' in text mode", c);
              if (this.mode === "math" && b.allowedInMath === !1)
                throw new u("Can't use function '" + d + "' in math mode", c);
              var _ = this.parseArguments(d, b), A = _.args, C = _.optArgs;
              return this.callFunction(d, A, C, c, a);
            }, e.callFunction = function(a, l, c, d, b) {
              var _ = {
                funcName: a,
                parser: this,
                token: d,
                breakOnTokenText: b
              }, A = M0[a];
              if (A && A.handler)
                return A.handler(_, l, c);
              throw new u("No function handler for " + a);
            }, e.parseArguments = function(a, l) {
              var c = l.numArgs + l.numOptionalArgs;
              if (c === 0)
                return {
                  args: [],
                  optArgs: []
                };
              for (var d = [], b = [], _ = 0; _ < c; _++) {
                var A = l.argTypes && l.argTypes[_], C = _ < l.numOptionalArgs;
                (l.primitive && A == null || // \sqrt expands into primitive if optional argument doesn't exist
                l.type === "sqrt" && _ === 1 && b[0] == null) && (A = "primitive");
                var L = this.parseGroupOfType("argument to '" + a + "'", A, C);
                if (C)
                  b.push(L);
                else if (L != null)
                  d.push(L);
                else
                  throw new u("Null argument, please report this as a bug");
              }
              return {
                args: d,
                optArgs: b
              };
            }, e.parseGroupOfType = function(a, l, c) {
              switch (l) {
                case "color":
                  return this.parseColorGroup(c);
                case "size":
                  return this.parseSizeGroup(c);
                case "url":
                  return this.parseUrlGroup(c);
                case "math":
                case "text":
                  return this.parseArgumentGroup(c, l);
                case "hbox": {
                  var d = this.parseArgumentGroup(c, "text");
                  return d != null ? {
                    type: "styling",
                    mode: d.mode,
                    body: [d],
                    style: "text"
                    // simulate \textstyle
                  } : null;
                }
                case "raw": {
                  var b = this.parseStringGroup("raw", c);
                  return b != null ? {
                    type: "raw",
                    mode: "text",
                    string: b.text
                  } : null;
                }
                case "primitive": {
                  if (c)
                    throw new u("A primitive argument cannot be optional");
                  var _ = this.parseGroup(a);
                  if (_ == null)
                    throw new u("Expected group as " + a, this.fetch());
                  return _;
                }
                case "original":
                case null:
                case void 0:
                  return this.parseArgumentGroup(c);
                default:
                  throw new u("Unknown group type as " + a, this.fetch());
              }
            }, e.consumeSpaces = function() {
              for (; this.fetch().text === " "; )
                this.consume();
            }, e.parseStringGroup = function(a, l) {
              var c = this.gullet.scanArgument(l);
              if (c == null)
                return null;
              for (var d = "", b; (b = this.fetch()).text !== "EOF"; )
                d += b.text, this.consume();
              return this.consume(), c.text = d, c;
            }, e.parseRegexGroup = function(a, l) {
              for (var c = this.fetch(), d = c, b = "", _; (_ = this.fetch()).text !== "EOF" && a.test(b + _.text); )
                d = _, b += d.text, this.consume();
              if (b === "")
                throw new u("Invalid " + l + ": '" + c.text + "'", c);
              return c.range(d, b);
            }, e.parseColorGroup = function(a) {
              var l = this.parseStringGroup("color", a);
              if (l == null)
                return null;
              var c = /^(#[a-f0-9]{3}|#?[a-f0-9]{6}|[a-z]+)$/i.exec(l.text);
              if (!c)
                throw new u("Invalid color: '" + l.text + "'", l);
              var d = c[0];
              return /^[0-9a-f]{6}$/i.test(d) && (d = "#" + d), {
                type: "color-token",
                mode: this.mode,
                color: d
              };
            }, e.parseSizeGroup = function(a) {
              var l, c = !1;
              if (this.gullet.consumeSpaces(), !a && this.gullet.future().text !== "{" ? l = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : l = this.parseStringGroup("size", a), !l)
                return null;
              !a && l.text.length === 0 && (l.text = "0pt", c = !0);
              var d = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(l.text);
              if (!d)
                throw new u("Invalid size: '" + l.text + "'", l);
              var b = {
                number: +(d[1] + d[2]),
                // sign + magnitude, cast to number
                unit: d[3]
              };
              if (!sr(b))
                throw new u("Invalid unit: '" + b.unit + "'", l);
              return {
                type: "size",
                mode: this.mode,
                value: b,
                isBlank: c
              };
            }, e.parseUrlGroup = function(a) {
              this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
              var l = this.parseStringGroup("url", a);
              if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), l == null)
                return null;
              var c = l.text.replace(/\\([#$%&~_^{}])/g, "$1");
              return {
                type: "url",
                mode: this.mode,
                url: c
              };
            }, e.parseArgumentGroup = function(a, l) {
              var c = this.gullet.scanArgument(a);
              if (c == null)
                return null;
              var d = this.mode;
              l && this.switchMode(l), this.gullet.beginGroup();
              var b = this.parseExpression(!1, "EOF");
              this.expect("EOF"), this.gullet.endGroup();
              var _ = {
                type: "ordgroup",
                mode: this.mode,
                loc: c.loc,
                body: b
              };
              return l && this.switchMode(d), _;
            }, e.parseGroup = function(a, l) {
              var c = this.fetch(), d = c.text, b;
              if (d === "{" || d === "\\begingroup") {
                this.consume();
                var _ = d === "{" ? "}" : "\\endgroup";
                this.gullet.beginGroup();
                var A = this.parseExpression(!1, _), C = this.fetch();
                this.expect(_), this.gullet.endGroup(), b = {
                  type: "ordgroup",
                  mode: this.mode,
                  loc: Kt.range(c, C),
                  body: A,
                  // A group formed by \begingroup...\endgroup is a semi-simple group
                  // which doesn't affect spacing in math mode, i.e., is transparent.
                  // https://tex.stackexchange.com/questions/1930/when-should-one-
                  // use-begingroup-instead-of-bgroup
                  semisimple: d === "\\begingroup" || void 0
                };
              } else if (b = this.parseFunction(l, a) || this.parseSymbol(), b == null && d[0] === "\\" && !Ol.hasOwnProperty(d)) {
                if (this.settings.throwOnError)
                  throw new u("Undefined control sequence: " + d, c);
                b = this.formatUnsupportedCmd(d), this.consume();
              }
              return b;
            }, e.formLigatures = function(a) {
              for (var l = a.length - 1, c = 0; c < l; ++c) {
                var d = a[c], b = d.text;
                b === "-" && a[c + 1].text === "-" && (c + 1 < l && a[c + 2].text === "-" ? (a.splice(c, 3, {
                  type: "textord",
                  mode: "text",
                  loc: Kt.range(d, a[c + 2]),
                  text: "---"
                }), l -= 2) : (a.splice(c, 2, {
                  type: "textord",
                  mode: "text",
                  loc: Kt.range(d, a[c + 1]),
                  text: "--"
                }), l -= 1)), (b === "'" || b === "`") && a[c + 1].text === b && (a.splice(c, 2, {
                  type: "textord",
                  mode: "text",
                  loc: Kt.range(d, a[c + 1]),
                  text: b + b
                }), l -= 1);
              }
            }, e.parseSymbol = function() {
              var a = this.fetch(), l = a.text;
              if (/^\\verb[^a-zA-Z]/.test(l)) {
                this.consume();
                var c = l.slice(5), d = c.charAt(0) === "*";
                if (d && (c = c.slice(1)), c.length < 2 || c.charAt(0) !== c.slice(-1))
                  throw new u(`\\verb assertion failed --
                    please report what input caused this bug`);
                return c = c.slice(1, -1), {
                  type: "verb",
                  mode: "text",
                  body: c,
                  star: d
                };
              }
              Pl.hasOwnProperty(l[0]) && !Ge[this.mode][l[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + l[0] + '" used in math mode', a), l = Pl[l[0]] + l.slice(1));
              var b = X1.exec(l);
              b && (l = l.substring(0, b.index), l === "i" ? l = "ı" : l === "j" && (l = "ȷ"));
              var _;
              if (Ge[this.mode][l]) {
                this.settings.strict && this.mode === "math" && ea.indexOf(l) >= 0 && this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + l[0] + '" used in math mode', a);
                var A = Ge[this.mode][l].group, C = Kt.range(a), L;
                if (m0.hasOwnProperty(A)) {
                  var H = A;
                  L = {
                    type: "atom",
                    mode: this.mode,
                    family: H,
                    loc: C,
                    text: l
                  };
                } else
                  L = {
                    type: A,
                    mode: this.mode,
                    loc: C,
                    text: l
                  };
                _ = L;
              } else if (l.charCodeAt(0) >= 128)
                this.settings.strict && (yt(l.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + l[0] + '" used in math mode', a) : this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + l[0] + '"' + (" (" + l.charCodeAt(0) + ")"), a)), _ = {
                  type: "textord",
                  mode: "text",
                  loc: Kt.range(a),
                  text: l
                };
              else
                return null;
              if (this.consume(), b)
                for (var P = 0; P < b[0].length; P++) {
                  var W = b[0][P];
                  if (!Ca[W])
                    throw new u("Unknown accent ' " + W + "'", a);
                  var te = Ca[W][this.mode] || Ca[W].text;
                  if (!te)
                    throw new u("Accent " + W + " unsupported in " + this.mode + " mode", a);
                  _ = {
                    type: "accent",
                    mode: this.mode,
                    loc: Kt.range(a),
                    label: te,
                    isStretchy: !1,
                    isShifty: !0,
                    // $FlowFixMe
                    base: _
                  };
                }
              return _;
            }, m;
          }();
          Hl.endOfExpression = ["}", "\\endgroup", "\\end", "\\right", "&"];
          var $1 = function(e, r) {
            if (!(typeof e == "string" || e instanceof String))
              throw new TypeError("KaTeX can only parse string typed expression");
            var a = new Hl(e, r);
            delete a.gullet.macros.current["\\df@tag"];
            var l = a.parse();
            if (delete a.gullet.macros.current["\\current@color"], delete a.gullet.macros.current["\\color"], a.gullet.macros.get("\\df@tag")) {
              if (!r.displayMode)
                throw new u("\\tag works only in display equations");
              l = [{
                type: "tag",
                mode: "text",
                body: l,
                tag: a.subparse([new T0("\\df@tag")])
              }];
            }
            return l;
          }, Ta = $1, Ul = function(e, r, a) {
            r.textContent = "";
            var l = Ba(e, a).toNode();
            r.appendChild(l);
          };
          typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), Ul = function() {
            throw new u("KaTeX doesn't work in quirks mode.");
          });
          var ec = function(e, r) {
            var a = Ba(e, r).toMarkup();
            return a;
          }, tc = function(e, r) {
            var a = new N(r);
            return Ta(e, a);
          }, Gl = function(e, r, a) {
            if (a.throwOnError || !(e instanceof u))
              throw e;
            var l = I.makeSpan(["katex-error"], [new mt(r)]);
            return l.setAttribute("title", e.toString()), l.setAttribute("style", "color:" + a.errorColor), l;
          }, Ba = function(e, r) {
            var a = new N(r);
            try {
              var l = Ta(e, a);
              return l1(l, e, a);
            } catch (c) {
              return Gl(c, e, a);
            }
          }, rc = function(e, r) {
            var a = new N(r);
            try {
              var l = Ta(e, a);
              return s1(l, e, a);
            } catch (c) {
              return Gl(c, e, a);
            }
          }, nc = {
            /**
             * Current KaTeX version
             */
            version: "0.16.9",
            /**
             * Renders the given LaTeX into an HTML+MathML combination, and adds
             * it as a child to the specified DOM node.
             */
            render: Ul,
            /**
             * Renders the given LaTeX into an HTML+MathML combination string,
             * for sending to the client.
             */
            renderToString: ec,
            /**
             * KaTeX error, usually during parsing.
             */
            ParseError: u,
            /**
             * The shema of Settings
             */
            SETTINGS_SCHEMA: z,
            /**
             * Parses the given LaTeX into KaTeX's internal parse tree structure,
             * without rendering to HTML or MathML.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __parse: tc,
            /**
             * Renders the given LaTeX into an HTML+MathML internal DOM tree
             * representation, without flattening that representation to a string.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __renderToDomTree: Ba,
            /**
             * Renders the given LaTeX into an HTML internal DOM tree representation,
             * without MathML and without flattening that representation to a string.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __renderToHTMLTree: rc,
            /**
             * extends internal font metrics object with a new object
             * each key in the new object represents a font name
            */
            __setFontMetrics: x0,
            /**
             * adds a new symbol to builtin symbols table
             */
            __defineSymbol: h,
            /**
             * adds a new function to builtin function list,
             * which directly produce parse tree elements
             * and have their own html/mathml builders
             */
            __defineFunction: oe,
            /**
             * adds a new macro to builtin macro list
             */
            __defineMacro: k,
            /**
             * Expose the dom tree node types, which can be useful for type checking nodes.
             *
             * NOTE: This method is not currently recommended for public use.
             * The internal tree representation is unstable and is very likely
             * to change. Use at your own risk.
             */
            __domTree: {
              Span: qt,
              Anchor: Sr,
              SymbolNode: mt,
              SvgNode: Pt,
              PathNode: r0,
              LineNode: or
            }
          }, ac = nc;
          return i = i.default, i;
        }()
      );
    });
  }(ei)), ei.exports;
}
(function(s, t) {
  (function(i, o) {
    s.exports = o(Tf());
  })(typeof self < "u" ? self : Hn, function(n) {
    return (
      /******/
      function() {
        var i = {
          /***/
          771: (
            /***/
            function(g) {
              g.exports = n;
            }
          )
          /******/
        }, o = {};
        function u(g) {
          var v = o[g];
          if (v !== void 0)
            return v.exports;
          var y = o[g] = {
            /******/
            // no module.id needed
            /******/
            // no module.loaded needed
            /******/
            exports: {}
            /******/
          };
          return i[g](y, y.exports, u), y.exports;
        }
        (function() {
          u.n = function(g) {
            var v = g && g.__esModule ? (
              /******/
              function() {
                return g.default;
              }
            ) : (
              /******/
              function() {
                return g;
              }
            );
            return u.d(v, { a: v }), v;
          };
        })(), function() {
          u.d = function(g, v) {
            for (var y in v)
              u.o(v, y) && !u.o(g, y) && Object.defineProperty(g, y, { enumerable: !0, get: v[y] });
          };
        }(), function() {
          u.o = function(g, v) {
            return Object.prototype.hasOwnProperty.call(g, v);
          };
        }();
        var f = {};
        return function() {
          u.d(f, {
            default: function() {
              return (
                /* binding */
                M
              );
            }
          });
          var g = u(771), v = /* @__PURE__ */ u.n(g), y = function(F, N, O) {
            for (var R = O, U = 0, J = F.length; R < N.length; ) {
              var V = N[R];
              if (U <= 0 && N.slice(R, R + J) === F)
                return R;
              V === "\\" ? R++ : V === "{" ? U++ : V === "}" && U--, R++;
            }
            return -1;
          }, D = function(F) {
            return F.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
          }, B = /^\\begin{/, q = function(F, N) {
            for (var O, R = [], U = new RegExp("(" + N.map(function(fe) {
              return D(fe.left);
            }).join("|") + ")"); O = F.search(U), O !== -1; ) {
              O > 0 && (R.push({
                type: "text",
                data: F.slice(0, O)
              }), F = F.slice(O));
              var J = N.findIndex(function(fe) {
                return F.startsWith(fe.left);
              });
              if (O = y(N[J].right, F, N[J].left.length), O === -1)
                break;
              var V = F.slice(0, O + N[J].right.length), ee = B.test(V) ? V : F.slice(N[J].left.length, O);
              R.push({
                type: "math",
                data: ee,
                rawData: V,
                display: N[J].display
              }), F = F.slice(O + N[J].right.length);
            }
            return F !== "" && R.push({
              type: "text",
              data: F
            }), R;
          }, G = q, K = function(F, N) {
            var O = G(F, N.delimiters);
            if (O.length === 1 && O[0].type === "text")
              return null;
            for (var R = document.createDocumentFragment(), U = 0; U < O.length; U++)
              if (O[U].type === "text")
                R.appendChild(document.createTextNode(O[U].data));
              else {
                var J = document.createElement("span"), V = O[U].data;
                N.displayMode = O[U].display;
                try {
                  N.preProcess && (V = N.preProcess(V)), v().render(V, J, N);
                } catch (ee) {
                  if (!(ee instanceof v().ParseError))
                    throw ee;
                  N.errorCallback("KaTeX auto-render: Failed to parse `" + O[U].data + "` with ", ee), R.appendChild(document.createTextNode(O[U].rawData));
                  continue;
                }
                R.appendChild(J);
              }
            return R;
          }, $ = function z(F, N) {
            for (var O = 0; O < F.childNodes.length; O++) {
              var R = F.childNodes[O];
              if (R.nodeType === 3) {
                for (var U = R.textContent, J = R.nextSibling, V = 0; J && J.nodeType === Node.TEXT_NODE; )
                  U += J.textContent, J = J.nextSibling, V++;
                var ee = K(U, N);
                if (ee) {
                  for (var fe = 0; fe < V; fe++)
                    R.nextSibling.remove();
                  O += ee.childNodes.length - 1, F.replaceChild(ee, R);
                } else
                  O += V;
              } else
                R.nodeType === 1 && function() {
                  var xe = " " + R.className + " ", ve = N.ignoredTags.indexOf(R.nodeName.toLowerCase()) === -1 && N.ignoredClasses.every(function(Se) {
                    return xe.indexOf(" " + Se + " ") === -1;
                  });
                  ve && z(R, N);
                }();
            }
          }, X = function(F, N) {
            if (!F)
              throw new Error("No element provided to render");
            var O = {};
            for (var R in N)
              N.hasOwnProperty(R) && (O[R] = N[R]);
            O.delimiters = O.delimiters || [
              {
                left: "$$",
                right: "$$",
                display: !0
              },
              {
                left: "\\(",
                right: "\\)",
                display: !1
              },
              // LaTeX uses $…$, but it ruins the display of normal `$` in text:
              // {left: "$", right: "$", display: false},
              // $ must come after $$
              // Render AMS environments even if outside $$…$$ delimiters.
              {
                left: "\\begin{equation}",
                right: "\\end{equation}",
                display: !0
              },
              {
                left: "\\begin{align}",
                right: "\\end{align}",
                display: !0
              },
              {
                left: "\\begin{alignat}",
                right: "\\end{alignat}",
                display: !0
              },
              {
                left: "\\begin{gather}",
                right: "\\end{gather}",
                display: !0
              },
              {
                left: "\\begin{CD}",
                right: "\\end{CD}",
                display: !0
              },
              {
                left: "\\[",
                right: "\\]",
                display: !0
              }
            ], O.ignoredTags = O.ignoredTags || ["script", "noscript", "style", "textarea", "pre", "code", "option"], O.ignoredClasses = O.ignoredClasses || [], O.errorCallback = O.errorCallback || console.error, O.macros = O.macros || {}, $(F, O);
          }, M = X;
        }(), f = f.default, f;
      }()
    );
  });
})(ou);
var Bf = ou.exports;
const Mf = /* @__PURE__ */ su(Bf);
function yi() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let rr = yi();
function uu(s) {
  rr = s;
}
const cu = /[&<>"']/, zf = new RegExp(cu.source, "g"), hu = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Nf = new RegExp(hu.source, "g"), Rf = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Cs = (s) => Rf[s];
function Tt(s, t) {
  if (t) {
    if (cu.test(s))
      return s.replace(zf, Cs);
  } else if (hu.test(s))
    return s.replace(Nf, Cs);
  return s;
}
const Lf = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function If(s) {
  return s.replace(Lf, (t, n) => (n = n.toLowerCase(), n === "colon" ? ":" : n.charAt(0) === "#" ? n.charAt(1) === "x" ? String.fromCharCode(parseInt(n.substring(2), 16)) : String.fromCharCode(+n.substring(1)) : ""));
}
const Of = /(^|[^\[])\^/g;
function Oe(s, t) {
  let n = typeof s == "string" ? s : s.source;
  t = t || "";
  const i = {
    replace: (o, u) => {
      let f = typeof u == "string" ? u : u.source;
      return f = f.replace(Of, "$1"), n = n.replace(o, f), i;
    },
    getRegex: () => new RegExp(n, t)
  };
  return i;
}
function Ts(s) {
  try {
    s = encodeURI(s).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return s;
}
const Vr = { exec: () => null };
function Bs(s, t) {
  const n = s.replace(/\|/g, (u, f, g) => {
    let v = !1, y = f;
    for (; --y >= 0 && g[y] === "\\"; )
      v = !v;
    return v ? "|" : " |";
  }), i = n.split(/ \|/);
  let o = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i[i.length - 1].trim() && i.pop(), t)
    if (i.length > t)
      i.splice(t);
    else
      for (; i.length < t; )
        i.push("");
  for (; o < i.length; o++)
    i[o] = i[o].trim().replace(/\\\|/g, "|");
  return i;
}
function Bn(s, t, n) {
  const i = s.length;
  if (i === 0)
    return "";
  let o = 0;
  for (; o < i; ) {
    const u = s.charAt(i - o - 1);
    if (u === t && !n)
      o++;
    else if (u !== t && n)
      o++;
    else
      break;
  }
  return s.slice(0, i - o);
}
function qf(s, t) {
  if (s.indexOf(t[1]) === -1)
    return -1;
  let n = 0;
  for (let i = 0; i < s.length; i++)
    if (s[i] === "\\")
      i++;
    else if (s[i] === t[0])
      n++;
    else if (s[i] === t[1] && (n--, n < 0))
      return i;
  return -1;
}
function Ms(s, t, n, i) {
  const o = t.href, u = t.title ? Tt(t.title) : null, f = s[1].replace(/\\([\[\]])/g, "$1");
  if (s[0].charAt(0) !== "!") {
    i.state.inLink = !0;
    const g = {
      type: "link",
      raw: n,
      href: o,
      title: u,
      text: f,
      tokens: i.inlineTokens(f)
    };
    return i.state.inLink = !1, g;
  }
  return {
    type: "image",
    raw: n,
    href: o,
    title: u,
    text: Tt(f)
  };
}
function Pf(s, t) {
  const n = s.match(/^(\s+)(?:```)/);
  if (n === null)
    return t;
  const i = n[1];
  return t.split(`
`).map((o) => {
    const u = o.match(/^\s+/);
    if (u === null)
      return o;
    const [f] = u;
    return f.length >= i.length ? o.slice(i.length) : o;
  }).join(`
`);
}
class Un {
  // set by the lexer
  constructor(t) {
    je(this, "options");
    je(this, "rules");
    // set by the lexer
    je(this, "lexer");
    this.options = t || rr;
  }
  space(t) {
    const n = this.rules.block.newline.exec(t);
    if (n && n[0].length > 0)
      return {
        type: "space",
        raw: n[0]
      };
  }
  code(t) {
    const n = this.rules.block.code.exec(t);
    if (n) {
      const i = n[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: n[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? i : Bn(i, `
`)
      };
    }
  }
  fences(t) {
    const n = this.rules.block.fences.exec(t);
    if (n) {
      const i = n[0], o = Pf(i, n[3] || "");
      return {
        type: "code",
        raw: i,
        lang: n[2] ? n[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : n[2],
        text: o
      };
    }
  }
  heading(t) {
    const n = this.rules.block.heading.exec(t);
    if (n) {
      let i = n[2].trim();
      if (/#$/.test(i)) {
        const o = Bn(i, "#");
        (this.options.pedantic || !o || / $/.test(o)) && (i = o.trim());
      }
      return {
        type: "heading",
        raw: n[0],
        depth: n[1].length,
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  hr(t) {
    const n = this.rules.block.hr.exec(t);
    if (n)
      return {
        type: "hr",
        raw: n[0]
      };
  }
  blockquote(t) {
    const n = this.rules.block.blockquote.exec(t);
    if (n) {
      const i = Bn(n[0].replace(/^ *>[ \t]?/gm, ""), `
`), o = this.lexer.state.top;
      this.lexer.state.top = !0;
      const u = this.lexer.blockTokens(i);
      return this.lexer.state.top = o, {
        type: "blockquote",
        raw: n[0],
        tokens: u,
        text: i
      };
    }
  }
  list(t) {
    let n = this.rules.block.list.exec(t);
    if (n) {
      let i = n[1].trim();
      const o = i.length > 1, u = {
        type: "list",
        raw: "",
        ordered: o,
        start: o ? +i.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      i = o ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = o ? i : "[*+-]");
      const f = new RegExp(`^( {0,3}${i})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let g = "", v = "", y = !1;
      for (; t; ) {
        let D = !1;
        if (!(n = f.exec(t)) || this.rules.block.hr.test(t))
          break;
        g = n[0], t = t.substring(g.length);
        let B = n[2].split(`
`, 1)[0].replace(/^\t+/, (M) => " ".repeat(3 * M.length)), q = t.split(`
`, 1)[0], G = 0;
        this.options.pedantic ? (G = 2, v = B.trimStart()) : (G = n[2].search(/[^ ]/), G = G > 4 ? 1 : G, v = B.slice(G), G += n[1].length);
        let K = !1;
        if (!B && /^ *$/.test(q) && (g += q + `
`, t = t.substring(q.length + 1), D = !0), !D) {
          const M = new RegExp(`^ {0,${Math.min(3, G - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), z = new RegExp(`^ {0,${Math.min(3, G - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), F = new RegExp(`^ {0,${Math.min(3, G - 1)}}(?:\`\`\`|~~~)`), N = new RegExp(`^ {0,${Math.min(3, G - 1)}}#`);
          for (; t; ) {
            const O = t.split(`
`, 1)[0];
            if (q = O, this.options.pedantic && (q = q.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), F.test(q) || N.test(q) || M.test(q) || z.test(t))
              break;
            if (q.search(/[^ ]/) >= G || !q.trim())
              v += `
` + q.slice(G);
            else {
              if (K || B.search(/[^ ]/) >= 4 || F.test(B) || N.test(B) || z.test(B))
                break;
              v += `
` + q;
            }
            !K && !q.trim() && (K = !0), g += O + `
`, t = t.substring(O.length + 1), B = q.slice(G);
          }
        }
        u.loose || (y ? u.loose = !0 : /\n *\n *$/.test(g) && (y = !0));
        let $ = null, X;
        this.options.gfm && ($ = /^\[[ xX]\] /.exec(v), $ && (X = $[0] !== "[ ] ", v = v.replace(/^\[[ xX]\] +/, ""))), u.items.push({
          type: "list_item",
          raw: g,
          task: !!$,
          checked: X,
          loose: !1,
          text: v,
          tokens: []
        }), u.raw += g;
      }
      u.items[u.items.length - 1].raw = g.trimEnd(), u.items[u.items.length - 1].text = v.trimEnd(), u.raw = u.raw.trimEnd();
      for (let D = 0; D < u.items.length; D++)
        if (this.lexer.state.top = !1, u.items[D].tokens = this.lexer.blockTokens(u.items[D].text, []), !u.loose) {
          const B = u.items[D].tokens.filter((G) => G.type === "space"), q = B.length > 0 && B.some((G) => /\n.*\n/.test(G.raw));
          u.loose = q;
        }
      if (u.loose)
        for (let D = 0; D < u.items.length; D++)
          u.items[D].loose = !0;
      return u;
    }
  }
  html(t) {
    const n = this.rules.block.html.exec(t);
    if (n)
      return {
        type: "html",
        block: !0,
        raw: n[0],
        pre: n[1] === "pre" || n[1] === "script" || n[1] === "style",
        text: n[0]
      };
  }
  def(t) {
    const n = this.rules.block.def.exec(t);
    if (n) {
      const i = n[1].toLowerCase().replace(/\s+/g, " "), o = n[2] ? n[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", u = n[3] ? n[3].substring(1, n[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : n[3];
      return {
        type: "def",
        tag: i,
        raw: n[0],
        href: o,
        title: u
      };
    }
  }
  table(t) {
    const n = this.rules.block.table.exec(t);
    if (!n || !/[:|]/.test(n[2]))
      return;
    const i = Bs(n[1]), o = n[2].replace(/^\||\| *$/g, "").split("|"), u = n[3] && n[3].trim() ? n[3].replace(/\n[ \t]*$/, "").split(`
`) : [], f = {
      type: "table",
      raw: n[0],
      header: [],
      align: [],
      rows: []
    };
    if (i.length === o.length) {
      for (const g of o)
        /^ *-+: *$/.test(g) ? f.align.push("right") : /^ *:-+: *$/.test(g) ? f.align.push("center") : /^ *:-+ *$/.test(g) ? f.align.push("left") : f.align.push(null);
      for (const g of i)
        f.header.push({
          text: g,
          tokens: this.lexer.inline(g)
        });
      for (const g of u)
        f.rows.push(Bs(g, f.header.length).map((v) => ({
          text: v,
          tokens: this.lexer.inline(v)
        })));
      return f;
    }
  }
  lheading(t) {
    const n = this.rules.block.lheading.exec(t);
    if (n)
      return {
        type: "heading",
        raw: n[0],
        depth: n[2].charAt(0) === "=" ? 1 : 2,
        text: n[1],
        tokens: this.lexer.inline(n[1])
      };
  }
  paragraph(t) {
    const n = this.rules.block.paragraph.exec(t);
    if (n) {
      const i = n[1].charAt(n[1].length - 1) === `
` ? n[1].slice(0, -1) : n[1];
      return {
        type: "paragraph",
        raw: n[0],
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  text(t) {
    const n = this.rules.block.text.exec(t);
    if (n)
      return {
        type: "text",
        raw: n[0],
        text: n[0],
        tokens: this.lexer.inline(n[0])
      };
  }
  escape(t) {
    const n = this.rules.inline.escape.exec(t);
    if (n)
      return {
        type: "escape",
        raw: n[0],
        text: Tt(n[1])
      };
  }
  tag(t) {
    const n = this.rules.inline.tag.exec(t);
    if (n)
      return !this.lexer.state.inLink && /^<a /i.test(n[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(n[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(n[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(n[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: n[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: n[0]
      };
  }
  link(t) {
    const n = this.rules.inline.link.exec(t);
    if (n) {
      const i = n[2].trim();
      if (!this.options.pedantic && /^</.test(i)) {
        if (!/>$/.test(i))
          return;
        const f = Bn(i.slice(0, -1), "\\");
        if ((i.length - f.length) % 2 === 0)
          return;
      } else {
        const f = qf(n[2], "()");
        if (f > -1) {
          const v = (n[0].indexOf("!") === 0 ? 5 : 4) + n[1].length + f;
          n[2] = n[2].substring(0, f), n[0] = n[0].substring(0, v).trim(), n[3] = "";
        }
      }
      let o = n[2], u = "";
      if (this.options.pedantic) {
        const f = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(o);
        f && (o = f[1], u = f[3]);
      } else
        u = n[3] ? n[3].slice(1, -1) : "";
      return o = o.trim(), /^</.test(o) && (this.options.pedantic && !/>$/.test(i) ? o = o.slice(1) : o = o.slice(1, -1)), Ms(n, {
        href: o && o.replace(this.rules.inline.anyPunctuation, "$1"),
        title: u && u.replace(this.rules.inline.anyPunctuation, "$1")
      }, n[0], this.lexer);
    }
  }
  reflink(t, n) {
    let i;
    if ((i = this.rules.inline.reflink.exec(t)) || (i = this.rules.inline.nolink.exec(t))) {
      const o = (i[2] || i[1]).replace(/\s+/g, " "), u = n[o.toLowerCase()];
      if (!u) {
        const f = i[0].charAt(0);
        return {
          type: "text",
          raw: f,
          text: f
        };
      }
      return Ms(i, u, i[0], this.lexer);
    }
  }
  emStrong(t, n, i = "") {
    let o = this.rules.inline.emStrongLDelim.exec(t);
    if (!o || o[3] && i.match(/[\p{L}\p{N}]/u))
      return;
    if (!(o[1] || o[2] || "") || !i || this.rules.inline.punctuation.exec(i)) {
      const f = [...o[0]].length - 1;
      let g, v, y = f, D = 0;
      const B = o[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (B.lastIndex = 0, n = n.slice(-1 * t.length + f); (o = B.exec(n)) != null; ) {
        if (g = o[1] || o[2] || o[3] || o[4] || o[5] || o[6], !g)
          continue;
        if (v = [...g].length, o[3] || o[4]) {
          y += v;
          continue;
        } else if ((o[5] || o[6]) && f % 3 && !((f + v) % 3)) {
          D += v;
          continue;
        }
        if (y -= v, y > 0)
          continue;
        v = Math.min(v, v + y + D);
        const q = [...o[0]][0].length, G = t.slice(0, f + o.index + q + v);
        if (Math.min(f, v) % 2) {
          const $ = G.slice(1, -1);
          return {
            type: "em",
            raw: G,
            text: $,
            tokens: this.lexer.inlineTokens($)
          };
        }
        const K = G.slice(2, -2);
        return {
          type: "strong",
          raw: G,
          text: K,
          tokens: this.lexer.inlineTokens(K)
        };
      }
    }
  }
  codespan(t) {
    const n = this.rules.inline.code.exec(t);
    if (n) {
      let i = n[2].replace(/\n/g, " ");
      const o = /[^ ]/.test(i), u = /^ /.test(i) && / $/.test(i);
      return o && u && (i = i.substring(1, i.length - 1)), i = Tt(i, !0), {
        type: "codespan",
        raw: n[0],
        text: i
      };
    }
  }
  br(t) {
    const n = this.rules.inline.br.exec(t);
    if (n)
      return {
        type: "br",
        raw: n[0]
      };
  }
  del(t) {
    const n = this.rules.inline.del.exec(t);
    if (n)
      return {
        type: "del",
        raw: n[0],
        text: n[2],
        tokens: this.lexer.inlineTokens(n[2])
      };
  }
  autolink(t) {
    const n = this.rules.inline.autolink.exec(t);
    if (n) {
      let i, o;
      return n[2] === "@" ? (i = Tt(n[1]), o = "mailto:" + i) : (i = Tt(n[1]), o = i), {
        type: "link",
        raw: n[0],
        text: i,
        href: o,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  url(t) {
    var i;
    let n;
    if (n = this.rules.inline.url.exec(t)) {
      let o, u;
      if (n[2] === "@")
        o = Tt(n[0]), u = "mailto:" + o;
      else {
        let f;
        do
          f = n[0], n[0] = ((i = this.rules.inline._backpedal.exec(n[0])) == null ? void 0 : i[0]) ?? "";
        while (f !== n[0]);
        o = Tt(n[0]), n[1] === "www." ? u = "http://" + n[0] : u = n[0];
      }
      return {
        type: "link",
        raw: n[0],
        text: o,
        href: u,
        tokens: [
          {
            type: "text",
            raw: o,
            text: o
          }
        ]
      };
    }
  }
  inlineText(t) {
    const n = this.rules.inline.text.exec(t);
    if (n) {
      let i;
      return this.lexer.state.inRawBlock ? i = n[0] : i = Tt(n[0]), {
        type: "text",
        raw: n[0],
        text: i
      };
    }
  }
}
const Hf = /^(?: *(?:\n|$))+/, Uf = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Gf = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Xr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Vf = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, fu = /(?:[*+-]|\d{1,9}[.)])/, mu = Oe(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, fu).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), wi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Wf = /^[^\n]+/, _i = /(?!\s*\])(?:\\.|[^\[\]\\])+/, jf = Oe(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", _i).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Xf = Oe(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, fu).getRegex(), Xn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", ki = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Yf = Oe("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", ki).replace("tag", Xn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), du = Oe(wi).replace("hr", Xr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Xn).getRegex(), Zf = Oe(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", du).getRegex(), Di = {
  blockquote: Zf,
  code: Uf,
  def: jf,
  fences: Gf,
  heading: Vf,
  hr: Xr,
  html: Yf,
  lheading: mu,
  list: Xf,
  newline: Hf,
  paragraph: du,
  table: Vr,
  text: Wf
}, zs = Oe("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Xr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Xn).getRegex(), Kf = {
  ...Di,
  table: zs,
  paragraph: Oe(wi).replace("hr", Xr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", zs).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Xn).getRegex()
}, Qf = {
  ...Di,
  html: Oe(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", ki).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Vr,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Oe(wi).replace("hr", Xr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", mu).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, pu = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Jf = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, gu = /^( {2,}|\\)\n(?!\s*$)/, $f = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Yr = "\\p{P}\\p{S}", e2 = Oe(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Yr).getRegex(), t2 = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, r2 = Oe(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Yr).getRegex(), n2 = Oe("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Yr).getRegex(), a2 = Oe("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Yr).getRegex(), i2 = Oe(/\\([punct])/, "gu").replace(/punct/g, Yr).getRegex(), l2 = Oe(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), s2 = Oe(ki).replace("(?:-->|$)", "-->").getRegex(), o2 = Oe("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", s2).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Gn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, u2 = Oe(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Gn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), vu = Oe(/^!?\[(label)\]\[(ref)\]/).replace("label", Gn).replace("ref", _i).getRegex(), bu = Oe(/^!?\[(ref)\](?:\[\])?/).replace("ref", _i).getRegex(), c2 = Oe("reflink|nolink(?!\\()", "g").replace("reflink", vu).replace("nolink", bu).getRegex(), Ai = {
  _backpedal: Vr,
  // only used for GFM url
  anyPunctuation: i2,
  autolink: l2,
  blockSkip: t2,
  br: gu,
  code: Jf,
  del: Vr,
  emStrongLDelim: r2,
  emStrongRDelimAst: n2,
  emStrongRDelimUnd: a2,
  escape: pu,
  link: u2,
  nolink: bu,
  punctuation: e2,
  reflink: vu,
  reflinkSearch: c2,
  tag: o2,
  text: $f,
  url: Vr
}, h2 = {
  ...Ai,
  link: Oe(/^!?\[(label)\]\((.*?)\)/).replace("label", Gn).getRegex(),
  reflink: Oe(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Gn).getRegex()
}, mi = {
  ...Ai,
  escape: Oe(pu).replace("])", "~|])").getRegex(),
  url: Oe(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, f2 = {
  ...mi,
  br: Oe(gu).replace("{2,}", "*").getRegex(),
  text: Oe(mi.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Mn = {
  normal: Di,
  gfm: Kf,
  pedantic: Qf
}, Ur = {
  normal: Ai,
  gfm: mi,
  breaks: f2,
  pedantic: h2
};
class o0 {
  constructor(t) {
    je(this, "tokens");
    je(this, "options");
    je(this, "state");
    je(this, "tokenizer");
    je(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || rr, this.options.tokenizer = this.options.tokenizer || new Un(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const n = {
      block: Mn.normal,
      inline: Ur.normal
    };
    this.options.pedantic ? (n.block = Mn.pedantic, n.inline = Ur.pedantic) : this.options.gfm && (n.block = Mn.gfm, this.options.breaks ? n.inline = Ur.breaks : n.inline = Ur.gfm), this.tokenizer.rules = n;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Mn,
      inline: Ur
    };
  }
  /**
   * Static Lex Method
   */
  static lex(t, n) {
    return new o0(n).lex(t);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(t, n) {
    return new o0(n).inlineTokens(t);
  }
  /**
   * Preprocessing
   */
  lex(t) {
    t = t.replace(/\r\n|\r/g, `
`), this.blockTokens(t, this.tokens);
    for (let n = 0; n < this.inlineQueue.length; n++) {
      const i = this.inlineQueue[n];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, n = []) {
    this.options.pedantic ? t = t.replace(/\t/g, "    ").replace(/^ +$/gm, "") : t = t.replace(/^( *)(\t+)/gm, (g, v, y) => v + "    ".repeat(y.length));
    let i, o, u, f;
    for (; t; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((g) => (i = g.call({ lexer: this }, t, n)) ? (t = t.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.space(t)) {
          t = t.substring(i.raw.length), i.raw.length === 1 && n.length > 0 ? n[n.length - 1].raw += `
` : n.push(i);
          continue;
        }
        if (i = this.tokenizer.code(t)) {
          t = t.substring(i.raw.length), o = n[n.length - 1], o && (o.type === "paragraph" || o.type === "text") ? (o.raw += `
` + i.raw, o.text += `
` + i.text, this.inlineQueue[this.inlineQueue.length - 1].src = o.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.fences(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.heading(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.hr(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.blockquote(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.list(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.html(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.def(t)) {
          t = t.substring(i.raw.length), o = n[n.length - 1], o && (o.type === "paragraph" || o.type === "text") ? (o.raw += `
` + i.raw, o.text += `
` + i.raw, this.inlineQueue[this.inlineQueue.length - 1].src = o.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
            href: i.href,
            title: i.title
          });
          continue;
        }
        if (i = this.tokenizer.table(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.lheading(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (u = t, this.options.extensions && this.options.extensions.startBlock) {
          let g = 1 / 0;
          const v = t.slice(1);
          let y;
          this.options.extensions.startBlock.forEach((D) => {
            y = D.call({ lexer: this }, v), typeof y == "number" && y >= 0 && (g = Math.min(g, y));
          }), g < 1 / 0 && g >= 0 && (u = t.substring(0, g + 1));
        }
        if (this.state.top && (i = this.tokenizer.paragraph(u))) {
          o = n[n.length - 1], f && o.type === "paragraph" ? (o.raw += `
` + i.raw, o.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = o.text) : n.push(i), f = u.length !== t.length, t = t.substring(i.raw.length);
          continue;
        }
        if (i = this.tokenizer.text(t)) {
          t = t.substring(i.raw.length), o = n[n.length - 1], o && o.type === "text" ? (o.raw += `
` + i.raw, o.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = o.text) : n.push(i);
          continue;
        }
        if (t) {
          const g = "Infinite loop on byte: " + t.charCodeAt(0);
          if (this.options.silent) {
            console.error(g);
            break;
          } else
            throw new Error(g);
        }
      }
    return this.state.top = !0, n;
  }
  inline(t, n = []) {
    return this.inlineQueue.push({ src: t, tokens: n }), n;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(t, n = []) {
    let i, o, u, f = t, g, v, y;
    if (this.tokens.links) {
      const D = Object.keys(this.tokens.links);
      if (D.length > 0)
        for (; (g = this.tokenizer.rules.inline.reflinkSearch.exec(f)) != null; )
          D.includes(g[0].slice(g[0].lastIndexOf("[") + 1, -1)) && (f = f.slice(0, g.index) + "[" + "a".repeat(g[0].length - 2) + "]" + f.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (g = this.tokenizer.rules.inline.blockSkip.exec(f)) != null; )
      f = f.slice(0, g.index) + "[" + "a".repeat(g[0].length - 2) + "]" + f.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (g = this.tokenizer.rules.inline.anyPunctuation.exec(f)) != null; )
      f = f.slice(0, g.index) + "++" + f.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; t; )
      if (v || (y = ""), v = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((D) => (i = D.call({ lexer: this }, t, n)) ? (t = t.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.escape(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.tag(t)) {
          t = t.substring(i.raw.length), o = n[n.length - 1], o && i.type === "text" && o.type === "text" ? (o.raw += i.raw, o.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.link(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.reflink(t, this.tokens.links)) {
          t = t.substring(i.raw.length), o = n[n.length - 1], o && i.type === "text" && o.type === "text" ? (o.raw += i.raw, o.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.emStrong(t, f, y)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.codespan(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.br(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.del(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.autolink(t)) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (!this.state.inLink && (i = this.tokenizer.url(t))) {
          t = t.substring(i.raw.length), n.push(i);
          continue;
        }
        if (u = t, this.options.extensions && this.options.extensions.startInline) {
          let D = 1 / 0;
          const B = t.slice(1);
          let q;
          this.options.extensions.startInline.forEach((G) => {
            q = G.call({ lexer: this }, B), typeof q == "number" && q >= 0 && (D = Math.min(D, q));
          }), D < 1 / 0 && D >= 0 && (u = t.substring(0, D + 1));
        }
        if (i = this.tokenizer.inlineText(u)) {
          t = t.substring(i.raw.length), i.raw.slice(-1) !== "_" && (y = i.raw.slice(-1)), v = !0, o = n[n.length - 1], o && o.type === "text" ? (o.raw += i.raw, o.text += i.text) : n.push(i);
          continue;
        }
        if (t) {
          const D = "Infinite loop on byte: " + t.charCodeAt(0);
          if (this.options.silent) {
            console.error(D);
            break;
          } else
            throw new Error(D);
        }
      }
    return n;
  }
}
class Vn {
  constructor(t) {
    je(this, "options");
    this.options = t || rr;
  }
  code(t, n, i) {
    var u;
    const o = (u = (n || "").match(/^\S*/)) == null ? void 0 : u[0];
    return t = t.replace(/\n$/, "") + `
`, o ? '<pre><code class="language-' + Tt(o) + '">' + (i ? t : Tt(t, !0)) + `</code></pre>
` : "<pre><code>" + (i ? t : Tt(t, !0)) + `</code></pre>
`;
  }
  blockquote(t) {
    return `<blockquote>
${t}</blockquote>
`;
  }
  html(t, n) {
    return t;
  }
  heading(t, n, i) {
    return `<h${n}>${t}</h${n}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(t, n, i) {
    const o = n ? "ol" : "ul", u = n && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + o + u + `>
` + t + "</" + o + `>
`;
  }
  listitem(t, n, i) {
    return `<li>${t}</li>
`;
  }
  checkbox(t) {
    return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(t) {
    return `<p>${t}</p>
`;
  }
  table(t, n) {
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + n + `</table>
`;
  }
  tablerow(t) {
    return `<tr>
${t}</tr>
`;
  }
  tablecell(t, n) {
    const i = n.header ? "th" : "td";
    return (n.align ? `<${i} align="${n.align}">` : `<${i}>`) + t + `</${i}>
`;
  }
  /**
   * span level renderer
   */
  strong(t) {
    return `<strong>${t}</strong>`;
  }
  em(t) {
    return `<em>${t}</em>`;
  }
  codespan(t) {
    return `<code>${t}</code>`;
  }
  br() {
    return "<br>";
  }
  del(t) {
    return `<del>${t}</del>`;
  }
  link(t, n, i) {
    const o = Ts(t);
    if (o === null)
      return i;
    t = o;
    let u = '<a href="' + t + '"';
    return n && (u += ' title="' + n + '"'), u += ">" + i + "</a>", u;
  }
  image(t, n, i) {
    const o = Ts(t);
    if (o === null)
      return i;
    t = o;
    let u = `<img src="${t}" alt="${i}"`;
    return n && (u += ` title="${n}"`), u += ">", u;
  }
  text(t) {
    return t;
  }
}
class xi {
  // no need for block level renderers
  strong(t) {
    return t;
  }
  em(t) {
    return t;
  }
  codespan(t) {
    return t;
  }
  del(t) {
    return t;
  }
  html(t) {
    return t;
  }
  text(t) {
    return t;
  }
  link(t, n, i) {
    return "" + i;
  }
  image(t, n, i) {
    return "" + i;
  }
  br() {
    return "";
  }
}
class u0 {
  constructor(t) {
    je(this, "options");
    je(this, "renderer");
    je(this, "textRenderer");
    this.options = t || rr, this.options.renderer = this.options.renderer || new Vn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new xi();
  }
  /**
   * Static Parse Method
   */
  static parse(t, n) {
    return new u0(n).parse(t);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(t, n) {
    return new u0(n).parseInline(t);
  }
  /**
   * Parse Loop
   */
  parse(t, n = !0) {
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const u = t[o];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[u.type]) {
        const f = u, g = this.options.extensions.renderers[f.type].call({ parser: this }, f);
        if (g !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(f.type)) {
          i += g || "";
          continue;
        }
      }
      switch (u.type) {
        case "space":
          continue;
        case "hr": {
          i += this.renderer.hr();
          continue;
        }
        case "heading": {
          const f = u;
          i += this.renderer.heading(this.parseInline(f.tokens), f.depth, If(this.parseInline(f.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const f = u;
          i += this.renderer.code(f.text, f.lang, !!f.escaped);
          continue;
        }
        case "table": {
          const f = u;
          let g = "", v = "";
          for (let D = 0; D < f.header.length; D++)
            v += this.renderer.tablecell(this.parseInline(f.header[D].tokens), { header: !0, align: f.align[D] });
          g += this.renderer.tablerow(v);
          let y = "";
          for (let D = 0; D < f.rows.length; D++) {
            const B = f.rows[D];
            v = "";
            for (let q = 0; q < B.length; q++)
              v += this.renderer.tablecell(this.parseInline(B[q].tokens), { header: !1, align: f.align[q] });
            y += this.renderer.tablerow(v);
          }
          i += this.renderer.table(g, y);
          continue;
        }
        case "blockquote": {
          const f = u, g = this.parse(f.tokens);
          i += this.renderer.blockquote(g);
          continue;
        }
        case "list": {
          const f = u, g = f.ordered, v = f.start, y = f.loose;
          let D = "";
          for (let B = 0; B < f.items.length; B++) {
            const q = f.items[B], G = q.checked, K = q.task;
            let $ = "";
            if (q.task) {
              const X = this.renderer.checkbox(!!G);
              y ? q.tokens.length > 0 && q.tokens[0].type === "paragraph" ? (q.tokens[0].text = X + " " + q.tokens[0].text, q.tokens[0].tokens && q.tokens[0].tokens.length > 0 && q.tokens[0].tokens[0].type === "text" && (q.tokens[0].tokens[0].text = X + " " + q.tokens[0].tokens[0].text)) : q.tokens.unshift({
                type: "text",
                text: X + " "
              }) : $ += X + " ";
            }
            $ += this.parse(q.tokens, y), D += this.renderer.listitem($, K, !!G);
          }
          i += this.renderer.list(D, g, v);
          continue;
        }
        case "html": {
          const f = u;
          i += this.renderer.html(f.text, f.block);
          continue;
        }
        case "paragraph": {
          const f = u;
          i += this.renderer.paragraph(this.parseInline(f.tokens));
          continue;
        }
        case "text": {
          let f = u, g = f.tokens ? this.parseInline(f.tokens) : f.text;
          for (; o + 1 < t.length && t[o + 1].type === "text"; )
            f = t[++o], g += `
` + (f.tokens ? this.parseInline(f.tokens) : f.text);
          i += n ? this.renderer.paragraph(g) : g;
          continue;
        }
        default: {
          const f = 'Token with "' + u.type + '" type was not found.';
          if (this.options.silent)
            return console.error(f), "";
          throw new Error(f);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(t, n) {
    n = n || this.renderer;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const u = t[o];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[u.type]) {
        const f = this.options.extensions.renderers[u.type].call({ parser: this }, u);
        if (f !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(u.type)) {
          i += f || "";
          continue;
        }
      }
      switch (u.type) {
        case "escape": {
          const f = u;
          i += n.text(f.text);
          break;
        }
        case "html": {
          const f = u;
          i += n.html(f.text);
          break;
        }
        case "link": {
          const f = u;
          i += n.link(f.href, f.title, this.parseInline(f.tokens, n));
          break;
        }
        case "image": {
          const f = u;
          i += n.image(f.href, f.title, f.text);
          break;
        }
        case "strong": {
          const f = u;
          i += n.strong(this.parseInline(f.tokens, n));
          break;
        }
        case "em": {
          const f = u;
          i += n.em(this.parseInline(f.tokens, n));
          break;
        }
        case "codespan": {
          const f = u;
          i += n.codespan(f.text);
          break;
        }
        case "br": {
          i += n.br();
          break;
        }
        case "del": {
          const f = u;
          i += n.del(this.parseInline(f.tokens, n));
          break;
        }
        case "text": {
          const f = u;
          i += n.text(f.text);
          break;
        }
        default: {
          const f = 'Token with "' + u.type + '" type was not found.';
          if (this.options.silent)
            return console.error(f), "";
          throw new Error(f);
        }
      }
    }
    return i;
  }
}
class Wr {
  constructor(t) {
    je(this, "options");
    this.options = t || rr;
  }
  /**
   * Process markdown before marked
   */
  preprocess(t) {
    return t;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(t) {
    return t;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(t) {
    return t;
  }
}
je(Wr, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var jr, di, jn, wu;
class yu {
  constructor(...t) {
    La(this, jr);
    La(this, jn);
    je(this, "defaults", yi());
    je(this, "options", this.setOptions);
    je(this, "parse", An(this, jr, di).call(this, o0.lex, u0.parse));
    je(this, "parseInline", An(this, jr, di).call(this, o0.lexInline, u0.parseInline));
    je(this, "Parser", u0);
    je(this, "Renderer", Vn);
    je(this, "TextRenderer", xi);
    je(this, "Lexer", o0);
    je(this, "Tokenizer", Un);
    je(this, "Hooks", Wr);
    this.use(...t);
  }
  /**
   * Run callback for every token
   */
  walkTokens(t, n) {
    var o, u;
    let i = [];
    for (const f of t)
      switch (i = i.concat(n.call(this, f)), f.type) {
        case "table": {
          const g = f;
          for (const v of g.header)
            i = i.concat(this.walkTokens(v.tokens, n));
          for (const v of g.rows)
            for (const y of v)
              i = i.concat(this.walkTokens(y.tokens, n));
          break;
        }
        case "list": {
          const g = f;
          i = i.concat(this.walkTokens(g.items, n));
          break;
        }
        default: {
          const g = f;
          (u = (o = this.defaults.extensions) == null ? void 0 : o.childTokens) != null && u[g.type] ? this.defaults.extensions.childTokens[g.type].forEach((v) => {
            const y = g[v].flat(1 / 0);
            i = i.concat(this.walkTokens(y, n));
          }) : g.tokens && (i = i.concat(this.walkTokens(g.tokens, n)));
        }
      }
    return i;
  }
  use(...t) {
    const n = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return t.forEach((i) => {
      const o = { ...i };
      if (o.async = this.defaults.async || o.async || !1, i.extensions && (i.extensions.forEach((u) => {
        if (!u.name)
          throw new Error("extension name required");
        if ("renderer" in u) {
          const f = n.renderers[u.name];
          f ? n.renderers[u.name] = function(...g) {
            let v = u.renderer.apply(this, g);
            return v === !1 && (v = f.apply(this, g)), v;
          } : n.renderers[u.name] = u.renderer;
        }
        if ("tokenizer" in u) {
          if (!u.level || u.level !== "block" && u.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const f = n[u.level];
          f ? f.unshift(u.tokenizer) : n[u.level] = [u.tokenizer], u.start && (u.level === "block" ? n.startBlock ? n.startBlock.push(u.start) : n.startBlock = [u.start] : u.level === "inline" && (n.startInline ? n.startInline.push(u.start) : n.startInline = [u.start]));
        }
        "childTokens" in u && u.childTokens && (n.childTokens[u.name] = u.childTokens);
      }), o.extensions = n), i.renderer) {
        const u = this.defaults.renderer || new Vn(this.defaults);
        for (const f in i.renderer) {
          if (!(f in u))
            throw new Error(`renderer '${f}' does not exist`);
          if (f === "options")
            continue;
          const g = f, v = i.renderer[g], y = u[g];
          u[g] = (...D) => {
            let B = v.apply(u, D);
            return B === !1 && (B = y.apply(u, D)), B || "";
          };
        }
        o.renderer = u;
      }
      if (i.tokenizer) {
        const u = this.defaults.tokenizer || new Un(this.defaults);
        for (const f in i.tokenizer) {
          if (!(f in u))
            throw new Error(`tokenizer '${f}' does not exist`);
          if (["options", "rules", "lexer"].includes(f))
            continue;
          const g = f, v = i.tokenizer[g], y = u[g];
          u[g] = (...D) => {
            let B = v.apply(u, D);
            return B === !1 && (B = y.apply(u, D)), B;
          };
        }
        o.tokenizer = u;
      }
      if (i.hooks) {
        const u = this.defaults.hooks || new Wr();
        for (const f in i.hooks) {
          if (!(f in u))
            throw new Error(`hook '${f}' does not exist`);
          if (f === "options")
            continue;
          const g = f, v = i.hooks[g], y = u[g];
          Wr.passThroughHooks.has(f) ? u[g] = (D) => {
            if (this.defaults.async)
              return Promise.resolve(v.call(u, D)).then((q) => y.call(u, q));
            const B = v.call(u, D);
            return y.call(u, B);
          } : u[g] = (...D) => {
            let B = v.apply(u, D);
            return B === !1 && (B = y.apply(u, D)), B;
          };
        }
        o.hooks = u;
      }
      if (i.walkTokens) {
        const u = this.defaults.walkTokens, f = i.walkTokens;
        o.walkTokens = function(g) {
          let v = [];
          return v.push(f.call(this, g)), u && (v = v.concat(u.call(this, g))), v;
        };
      }
      this.defaults = { ...this.defaults, ...o };
    }), this;
  }
  setOptions(t) {
    return this.defaults = { ...this.defaults, ...t }, this;
  }
  lexer(t, n) {
    return o0.lex(t, n ?? this.defaults);
  }
  parser(t, n) {
    return u0.parse(t, n ?? this.defaults);
  }
}
jr = new WeakSet(), di = function(t, n) {
  return (i, o) => {
    const u = { ...o }, f = { ...this.defaults, ...u };
    this.defaults.async === !0 && u.async === !1 && (f.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), f.async = !0);
    const g = An(this, jn, wu).call(this, !!f.silent, !!f.async);
    if (typeof i > "u" || i === null)
      return g(new Error("marked(): input parameter is undefined or null"));
    if (typeof i != "string")
      return g(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(i) + ", string expected"));
    if (f.hooks && (f.hooks.options = f), f.async)
      return Promise.resolve(f.hooks ? f.hooks.preprocess(i) : i).then((v) => t(v, f)).then((v) => f.hooks ? f.hooks.processAllTokens(v) : v).then((v) => f.walkTokens ? Promise.all(this.walkTokens(v, f.walkTokens)).then(() => v) : v).then((v) => n(v, f)).then((v) => f.hooks ? f.hooks.postprocess(v) : v).catch(g);
    try {
      f.hooks && (i = f.hooks.preprocess(i));
      let v = t(i, f);
      f.hooks && (v = f.hooks.processAllTokens(v)), f.walkTokens && this.walkTokens(v, f.walkTokens);
      let y = n(v, f);
      return f.hooks && (y = f.hooks.postprocess(y)), y;
    } catch (v) {
      return g(v);
    }
  };
}, jn = new WeakSet(), wu = function(t, n) {
  return (i) => {
    if (i.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
      const o = "<p>An error occurred:</p><pre>" + Tt(i.message + "", !0) + "</pre>";
      return n ? Promise.resolve(o) : o;
    }
    if (n)
      return Promise.reject(i);
    throw i;
  };
};
const er = new yu();
function Ie(s, t) {
  return er.parse(s, t);
}
Ie.options = Ie.setOptions = function(s) {
  return er.setOptions(s), Ie.defaults = er.defaults, uu(Ie.defaults), Ie;
};
Ie.getDefaults = yi;
Ie.defaults = rr;
Ie.use = function(...s) {
  return er.use(...s), Ie.defaults = er.defaults, uu(Ie.defaults), Ie;
};
Ie.walkTokens = function(s, t) {
  return er.walkTokens(s, t);
};
Ie.parseInline = er.parseInline;
Ie.Parser = u0;
Ie.parser = u0.parse;
Ie.Renderer = Vn;
Ie.TextRenderer = xi;
Ie.Lexer = o0;
Ie.lexer = o0.lex;
Ie.Tokenizer = Un;
Ie.Hooks = Wr;
Ie.parse = Ie;
Ie.options;
Ie.setOptions;
Ie.use;
Ie.walkTokens;
Ie.parseInline;
u0.parse;
o0.lex;
function m2(s) {
  if (typeof s == "function" && (s = {
    highlight: s
  }), !s || typeof s.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof s.langPrefix != "string" && (s.langPrefix = "language-"), {
    async: !!s.async,
    walkTokens(t) {
      if (t.type !== "code")
        return;
      const n = Ns(t.lang);
      if (s.async)
        return Promise.resolve(s.highlight(t.text, n, t.lang || "")).then(Rs(t));
      const i = s.highlight(t.text, n, t.lang || "");
      if (i instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      Rs(t)(i);
    },
    renderer: {
      code(t, n, i) {
        const o = Ns(n), u = o ? ` class="${s.langPrefix}${Is(o)}"` : "";
        return t = t.replace(/\n$/, ""), `<pre><code${u}>${i ? t : Is(t, !0)}
</code></pre>`;
      }
    }
  };
}
function Ns(s) {
  return (s || "").match(/\S*/)[0];
}
function Rs(s) {
  return (t) => {
    typeof t == "string" && t !== s.text && (s.escaped = !0, s.text = t);
  };
}
const _u = /[&<>"']/, d2 = new RegExp(_u.source, "g"), ku = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, p2 = new RegExp(ku.source, "g"), g2 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Ls = (s) => g2[s];
function Is(s, t) {
  if (t) {
    if (_u.test(s))
      return s.replace(d2, Ls);
  } else if (ku.test(s))
    return s.replace(p2, Ls);
  return s;
}
const v2 = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, b2 = Object.hasOwnProperty;
class Du {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(t, n) {
    const i = this;
    let o = y2(t, n === !0);
    const u = o;
    for (; b2.call(i.occurrences, o); )
      i.occurrences[u]++, o = u + "-" + i.occurrences[u];
    return i.occurrences[o] = 0, o;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function y2(s, t) {
  return typeof s != "string" ? "" : (t || (s = s.toLowerCase()), s.replace(v2, "").replace(/ /g, "-"));
}
let Os, qs = [];
function w2({ prefix: s = "" } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return qs = [], Os = new Du(), t;
      }
    },
    renderer: {
      heading(t, n, i) {
        i = i.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const o = `${s}${Os.slug(i)}`, u = { level: n, text: t, id: o };
        return qs.push(u), `<h${n} id="${o}">${t}</h${n}>
`;
      }
    }
  };
}
var Au = { exports: {} };
(function(s) {
  var t = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var n = function(i) {
    var o = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, u = 0, f = {}, g = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: i.Prism && i.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: i.Prism && i.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function z(F) {
          return F instanceof v ? new v(F.type, z(F.content), F.alias) : Array.isArray(F) ? F.map(z) : F.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(z) {
          return Object.prototype.toString.call(z).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(z) {
          return z.__id || Object.defineProperty(z, "__id", { value: ++u }), z.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function z(F, N) {
          N = N || {};
          var O, R;
          switch (g.util.type(F)) {
            case "Object":
              if (R = g.util.objId(F), N[R])
                return N[R];
              O = /** @type {Record<string, any>} */
              {}, N[R] = O;
              for (var U in F)
                F.hasOwnProperty(U) && (O[U] = z(F[U], N));
              return (
                /** @type {any} */
                O
              );
            case "Array":
              return R = g.util.objId(F), N[R] ? N[R] : (O = [], N[R] = O, /** @type {Array} */
              /** @type {any} */
              F.forEach(function(J, V) {
                O[V] = z(J, N);
              }), /** @type {any} */
              O);
            default:
              return F;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(z) {
          for (; z; ) {
            var F = o.exec(z.className);
            if (F)
              return F[1].toLowerCase();
            z = z.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(z, F) {
          z.className = z.className.replace(RegExp(o, "gi"), ""), z.classList.add("language-" + F);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document && 1 < 2)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (O) {
            var z = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(O.stack) || [])[1];
            if (z) {
              var F = document.getElementsByTagName("script");
              for (var N in F)
                if (F[N].src == z)
                  return F[N];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(z, F, N) {
          for (var O = "no-" + F; z; ) {
            var R = z.classList;
            if (R.contains(F))
              return !0;
            if (R.contains(O))
              return !1;
            z = z.parentElement;
          }
          return !!N;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: f,
        plaintext: f,
        text: f,
        txt: f,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(z, F) {
          var N = g.util.clone(g.languages[z]);
          for (var O in F)
            N[O] = F[O];
          return N;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(z, F, N, O) {
          O = O || /** @type {any} */
          g.languages;
          var R = O[z], U = {};
          for (var J in R)
            if (R.hasOwnProperty(J)) {
              if (J == F)
                for (var V in N)
                  N.hasOwnProperty(V) && (U[V] = N[V]);
              N.hasOwnProperty(J) || (U[J] = R[J]);
            }
          var ee = O[z];
          return O[z] = U, g.languages.DFS(g.languages, function(fe, xe) {
            xe === ee && fe != z && (this[fe] = U);
          }), U;
        },
        // Traverse a language definition with Depth First Search
        DFS: function z(F, N, O, R) {
          R = R || {};
          var U = g.util.objId;
          for (var J in F)
            if (F.hasOwnProperty(J)) {
              N.call(F, J, F[J], O || J);
              var V = F[J], ee = g.util.type(V);
              ee === "Object" && !R[U(V)] ? (R[U(V)] = !0, z(V, N, null, R)) : ee === "Array" && !R[U(V)] && (R[U(V)] = !0, z(V, N, J, R));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(z, F) {
        g.highlightAllUnder(document, z, F);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(z, F, N) {
        var O = {
          callback: N,
          container: z,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        g.hooks.run("before-highlightall", O), O.elements = Array.prototype.slice.apply(O.container.querySelectorAll(O.selector)), g.hooks.run("before-all-elements-highlight", O);
        for (var R = 0, U; U = O.elements[R++]; )
          g.highlightElement(U, F === !0, O.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(z, F, N) {
        var O = g.util.getLanguage(z), R = g.languages[O];
        g.util.setLanguage(z, O);
        var U = z.parentElement;
        U && U.nodeName.toLowerCase() === "pre" && g.util.setLanguage(U, O);
        var J = z.textContent, V = {
          element: z,
          language: O,
          grammar: R,
          code: J
        };
        function ee(xe) {
          V.highlightedCode = xe, g.hooks.run("before-insert", V), V.element.innerHTML = V.highlightedCode, g.hooks.run("after-highlight", V), g.hooks.run("complete", V), N && N.call(V.element);
        }
        if (g.hooks.run("before-sanity-check", V), U = V.element.parentElement, U && U.nodeName.toLowerCase() === "pre" && !U.hasAttribute("tabindex") && U.setAttribute("tabindex", "0"), !V.code) {
          g.hooks.run("complete", V), N && N.call(V.element);
          return;
        }
        if (g.hooks.run("before-highlight", V), !V.grammar) {
          ee(g.util.encode(V.code));
          return;
        }
        if (F && i.Worker) {
          var fe = new Worker(g.filename);
          fe.onmessage = function(xe) {
            ee(xe.data);
          }, fe.postMessage(JSON.stringify({
            language: V.language,
            code: V.code,
            immediateClose: !0
          }));
        } else
          ee(g.highlight(V.code, V.grammar, V.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(z, F, N) {
        var O = {
          code: z,
          grammar: F,
          language: N
        };
        if (g.hooks.run("before-tokenize", O), !O.grammar)
          throw new Error('The language "' + O.language + '" has no grammar.');
        return O.tokens = g.tokenize(O.code, O.grammar), g.hooks.run("after-tokenize", O), v.stringify(g.util.encode(O.tokens), O.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(z, F) {
        var N = F.rest;
        if (N) {
          for (var O in N)
            F[O] = N[O];
          delete F.rest;
        }
        var R = new B();
        return q(R, R.head, z), D(z, R, F, R.head, 0), K(R);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(z, F) {
          var N = g.hooks.all;
          N[z] = N[z] || [], N[z].push(F);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(z, F) {
          var N = g.hooks.all[z];
          if (!(!N || !N.length))
            for (var O = 0, R; R = N[O++]; )
              R(F);
        }
      },
      Token: v
    };
    i.Prism = g;
    function v(z, F, N, O) {
      this.type = z, this.content = F, this.alias = N, this.length = (O || "").length | 0;
    }
    v.stringify = function z(F, N) {
      if (typeof F == "string")
        return F;
      if (Array.isArray(F)) {
        var O = "";
        return F.forEach(function(ee) {
          O += z(ee, N);
        }), O;
      }
      var R = {
        type: F.type,
        content: z(F.content, N),
        tag: "span",
        classes: ["token", F.type],
        attributes: {},
        language: N
      }, U = F.alias;
      U && (Array.isArray(U) ? Array.prototype.push.apply(R.classes, U) : R.classes.push(U)), g.hooks.run("wrap", R);
      var J = "";
      for (var V in R.attributes)
        J += " " + V + '="' + (R.attributes[V] || "").replace(/"/g, "&quot;") + '"';
      return "<" + R.tag + ' class="' + R.classes.join(" ") + '"' + J + ">" + R.content + "</" + R.tag + ">";
    };
    function y(z, F, N, O) {
      z.lastIndex = F;
      var R = z.exec(N);
      if (R && O && R[1]) {
        var U = R[1].length;
        R.index += U, R[0] = R[0].slice(U);
      }
      return R;
    }
    function D(z, F, N, O, R, U) {
      for (var J in N)
        if (!(!N.hasOwnProperty(J) || !N[J])) {
          var V = N[J];
          V = Array.isArray(V) ? V : [V];
          for (var ee = 0; ee < V.length; ++ee) {
            if (U && U.cause == J + "," + ee)
              return;
            var fe = V[ee], xe = fe.inside, ve = !!fe.lookbehind, Se = !!fe.greedy, Je = fe.alias;
            if (Se && !fe.pattern.global) {
              var ft = fe.pattern.toString().match(/[imsuy]*$/)[0];
              fe.pattern = RegExp(fe.pattern.source, ft + "g");
            }
            for (var ct = fe.pattern || fe, Ne = O.next, Y = R; Ne !== F.tail && !(U && Y >= U.reach); Y += Ne.value.length, Ne = Ne.next) {
              var Me = Ne.value;
              if (F.length > z.length)
                return;
              if (!(Me instanceof v)) {
                var re = 1, Ue;
                if (Se) {
                  if (Ue = y(ct, Y, z, ve), !Ue || Ue.index >= z.length)
                    break;
                  var ht = Ue.index, le = Ue.index + Ue[0].length, Ke = Y;
                  for (Ke += Ne.value.length; ht >= Ke; )
                    Ne = Ne.next, Ke += Ne.value.length;
                  if (Ke -= Ne.value.length, Y = Ke, Ne.value instanceof v)
                    continue;
                  for (var yt = Ne; yt !== F.tail && (Ke < le || typeof yt.value == "string"); yt = yt.next)
                    re++, Ke += yt.value.length;
                  re--, Me = z.slice(Y, Ke), Ue.index -= Y;
                } else if (Ue = y(ct, 0, Me, ve), !Ue)
                  continue;
                var ht = Ue.index, It = Ue[0], ae = Me.slice(0, ht), nt = Me.slice(ht + It.length), Re = Y + Me.length;
                U && Re > U.reach && (U.reach = Re);
                var tt = Ne.prev;
                ae && (tt = q(F, tt, ae), Y += ae.length), G(F, tt, re);
                var G0 = new v(J, xe ? g.tokenize(It, xe) : It, Je, It);
                if (Ne = q(F, tt, G0), nt && q(F, Ne, nt), re > 1) {
                  var f0 = {
                    cause: J + "," + ee,
                    reach: Re
                  };
                  D(z, F, N, Ne.prev, Y, f0), U && f0.reach > U.reach && (U.reach = f0.reach);
                }
              }
            }
          }
        }
    }
    function B() {
      var z = { value: null, prev: null, next: null }, F = { value: null, prev: z, next: null };
      z.next = F, this.head = z, this.tail = F, this.length = 0;
    }
    function q(z, F, N) {
      var O = F.next, R = { value: N, prev: F, next: O };
      return F.next = R, O.prev = R, z.length++, R;
    }
    function G(z, F, N) {
      for (var O = F.next, R = 0; R < N && O !== z.tail; R++)
        O = O.next;
      F.next = O, O.prev = F, z.length -= R;
    }
    function K(z) {
      for (var F = [], N = z.head.next; N !== z.tail; )
        F.push(N.value), N = N.next;
      return F;
    }
    if (!i.document)
      return i.addEventListener && (g.disableWorkerMessageHandler || i.addEventListener("message", function(z) {
        var F = JSON.parse(z.data), N = F.language, O = F.code, R = F.immediateClose;
        i.postMessage(g.highlight(O, g.languages[N], N)), R && i.close();
      }, !1)), g;
    var $ = g.util.currentScript();
    $ && (g.filename = $.src, $.hasAttribute("data-manual") && (g.manual = !0));
    function X() {
      g.manual || g.highlightAll();
    }
    if (!g.manual) {
      var M = document.readyState;
      M === "loading" || M === "interactive" && $ && $.defer ? document.addEventListener("DOMContentLoaded", X) : window.requestAnimationFrame ? window.requestAnimationFrame(X) : window.setTimeout(X, 16);
    }
    return g;
  }(t);
  s.exports && (s.exports = n), typeof Hn < "u" && (Hn.Prism = n), n.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, n.languages.markup.tag.inside["attr-value"].inside.entity = n.languages.markup.entity, n.languages.markup.doctype.inside["internal-subset"].inside = n.languages.markup, n.hooks.add("wrap", function(i) {
    i.type === "entity" && (i.attributes.title = i.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(n.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(o, u) {
      var f = {};
      f["language-" + u] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: n.languages[u]
      }, f.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var g = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: f
        }
      };
      g["language-" + u] = {
        pattern: /[\s\S]+/,
        inside: n.languages[u]
      };
      var v = {};
      v[o] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return o;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: g
      }, n.languages.insertBefore("markup", "cdata", v);
    }
  }), Object.defineProperty(n.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(i, o) {
      n.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + i + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [o, "language-" + o],
                inside: n.languages[o]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), n.languages.html = n.languages.markup, n.languages.mathml = n.languages.markup, n.languages.svg = n.languages.markup, n.languages.xml = n.languages.extend("markup", {}), n.languages.ssml = n.languages.xml, n.languages.atom = n.languages.xml, n.languages.rss = n.languages.xml, function(i) {
    var o = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    i.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + o.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + o.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + o.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + o.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: o,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, i.languages.css.atrule.inside.rest = i.languages.css;
    var u = i.languages.markup;
    u && (u.tag.addInlined("style", "css"), u.tag.addAttribute("style", "css"));
  }(n), n.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, n.languages.javascript = n.languages.extend("clike", {
    "class-name": [
      n.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), n.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, n.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: n.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: n.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), n.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: n.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), n.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), n.languages.markup && (n.languages.markup.tag.addInlined("script", "javascript"), n.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), n.languages.js = n.languages.javascript, function() {
    if (typeof n > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var i = "Loading…", o = function($, X) {
      return "✖ Error " + $ + " while fetching file: " + X;
    }, u = "✖ Error: File does not exist or is empty", f = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, g = "data-src-status", v = "loading", y = "loaded", D = "failed", B = "pre[data-src]:not([" + g + '="' + y + '"]):not([' + g + '="' + v + '"])';
    function q($, X, M) {
      var z = new XMLHttpRequest();
      z.open("GET", $, !0), z.onreadystatechange = function() {
        z.readyState == 4 && (z.status < 400 && z.responseText ? X(z.responseText) : z.status >= 400 ? M(o(z.status, z.statusText)) : M(u));
      }, z.send(null);
    }
    function G($) {
      var X = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec($ || "");
      if (X) {
        var M = Number(X[1]), z = X[2], F = X[3];
        return z ? F ? [M, Number(F)] : [M, void 0] : [M, M];
      }
    }
    n.hooks.add("before-highlightall", function($) {
      $.selector += ", " + B;
    }), n.hooks.add("before-sanity-check", function($) {
      var X = (
        /** @type {HTMLPreElement} */
        $.element
      );
      if (X.matches(B)) {
        $.code = "", X.setAttribute(g, v);
        var M = X.appendChild(document.createElement("CODE"));
        M.textContent = i;
        var z = X.getAttribute("data-src"), F = $.language;
        if (F === "none") {
          var N = (/\.(\w+)$/.exec(z) || [, "none"])[1];
          F = f[N] || N;
        }
        n.util.setLanguage(M, F), n.util.setLanguage(X, F);
        var O = n.plugins.autoloader;
        O && O.loadLanguages(F), q(
          z,
          function(R) {
            X.setAttribute(g, y);
            var U = G(X.getAttribute("data-range"));
            if (U) {
              var J = R.split(/\r\n?|\n/g), V = U[0], ee = U[1] == null ? J.length : U[1];
              V < 0 && (V += J.length), V = Math.max(0, Math.min(V - 1, J.length)), ee < 0 && (ee += J.length), ee = Math.max(0, Math.min(ee, J.length)), R = J.slice(V, ee).join(`
`), X.hasAttribute("data-start") || X.setAttribute("data-start", String(V + 1));
            }
            M.textContent = R, n.highlightElement(M);
          },
          function(R) {
            X.setAttribute(g, D), M.textContent = R;
          }
        );
      }
    }), n.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(X) {
        for (var M = (X || document).querySelectorAll(B), z = 0, F; F = M[z++]; )
          n.highlightElement(F);
      }
    };
    var K = !1;
    n.fileHighlight = function() {
      K || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), K = !0), n.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Au);
var _2 = Au.exports;
const ti = /* @__PURE__ */ su(_2);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(s) {
  var t = /\\(?:[^a-z()[\]]|[a-z*]+)/i, n = {
    "equation-command": {
      pattern: t,
      alias: "regex"
    }
  };
  s.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: n,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: n,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: t,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, s.languages.tex = s.languages.latex, s.languages.context = s.languages.latex;
})(Prism);
(function(s) {
  var t = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", n = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, i = {
    bash: n,
    environment: {
      pattern: RegExp("\\$" + t),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + t),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  s.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + t),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: n
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: i.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + t),
      alias: "constant"
    },
    variable: i.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, n.inside = s.languages.bash;
  for (var o = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], u = i.variable[1].inside, f = 0; f < o.length; f++)
    u[o[f]] = s.languages.bash[o[f]];
  s.languages.sh = s.languages.bash, s.languages.shell = s.languages.bash;
})(Prism);
function Ps(s, t) {
  return s ?? t();
}
function k2(s) {
  let t, n = s[0], i = 1;
  for (; i < s.length; ) {
    const o = s[i], u = s[i + 1];
    if (i += 2, (o === "optionalAccess" || o === "optionalCall") && n == null)
      return;
    o === "access" || o === "optionalAccess" ? (t = n, n = u(n)) : (o === "call" || o === "optionalCall") && (n = u((...f) => n.call(t, ...f)), t = void 0);
  }
  return n;
}
const D2 = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', A2 = `<svg
xmlns="http://www.w3.org/2000/svg"
width="100%"
height="100%"
viewBox="0 0 32 32"
><path
  fill="currentColor"
  d="M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"
/><path fill="currentColor" d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z" /></svg>`, x2 = `<svg
xmlns="http://www.w3.org/2000/svg"
width="100%"
height="100%"
viewBox="0 0 24 24"
fill="none"
stroke="currentColor"
stroke-width="3"
stroke-linecap="round"
stroke-linejoin="round"><polyline points="20 6 9 17 4 12" /></svg>`, Hs = `<button title="copy" class="copy_code_button">
<span class="copy-text">${A2}</span>
<span class="check">${x2}</span>
</button>`, xu = /[&<>"']/, S2 = new RegExp(xu.source, "g"), Su = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, E2 = new RegExp(Su.source, "g"), F2 = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Us = (s) => F2[s] || "";
function ri(s, t) {
  if (t) {
    if (xu.test(s))
      return s.replace(S2, Us);
  } else if (Su.test(s))
    return s.replace(E2, Us);
  return s;
}
const C2 = {
  code(s, t, n) {
    const i = Ps(k2([Ps(t, () => ""), "access", (o) => o.match, "call", (o) => o(/\S*/), "optionalAccess", (o) => o[0]]), () => "");
    return s = s.replace(/\n$/, "") + `
`, i ? '<div class="code_wrap">' + Hs + '<pre><code class="language-' + ri(i) + '">' + (n ? s : ri(s, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Hs + "<pre><code>" + (n ? s : ri(s, !0)) + `</code></pre></div>
`;
  }
}, T2 = new Du();
function B2({
  header_links: s,
  line_breaks: t
}) {
  const n = new yu();
  return n.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: t
    },
    m2({
      highlight: (i, o) => ti.languages[o] ? ti.highlight(i, ti.languages[o], o) : i
    }),
    { renderer: C2 }
  ), s && (n.use(w2()), n.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(i) {
          const o = i.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), u = "h" + T2.slug(o), f = i.depth, g = this.parser.parseInline(i.tokens);
          return `<h${f} id="${u}"><a class="md-header-anchor" href="#${u}">${D2}</a>${g}</h${f}>
`;
        }
      }
    ]
  })), n;
}
const {
  HtmlTag: M2,
  SvelteComponent: z2,
  attr: N2,
  binding_callbacks: R2,
  detach: Si,
  element: L2,
  empty: I2,
  init: O2,
  insert: Ei,
  noop: Gs,
  safe_not_equal: q2,
  set_data: P2,
  text: H2,
  toggle_class: Vs
} = window.__gradio__svelte__internal, { afterUpdate: U2, createEventDispatcher: Yd } = window.__gradio__svelte__internal;
function G2(s) {
  let t;
  return {
    c() {
      t = H2(
        /*html*/
        s[3]
      );
    },
    m(n, i) {
      Ei(n, t, i);
    },
    p(n, i) {
      i & /*html*/
      8 && P2(
        t,
        /*html*/
        n[3]
      );
    },
    d(n) {
      n && Si(t);
    }
  };
}
function V2(s) {
  let t, n;
  return {
    c() {
      t = new M2(!1), n = I2(), t.a = n;
    },
    m(i, o) {
      t.m(
        /*html*/
        s[3],
        i,
        o
      ), Ei(i, n, o);
    },
    p(i, o) {
      o & /*html*/
      8 && t.p(
        /*html*/
        i[3]
      );
    },
    d(i) {
      i && (Si(n), t.d());
    }
  };
}
function W2(s) {
  let t;
  function n(u, f) {
    return (
      /*render_markdown*/
      u[1] ? V2 : G2
    );
  }
  let i = n(s), o = i(s);
  return {
    c() {
      t = L2("span"), o.c(), N2(t, "class", "md svelte-k1dqs7"), Vs(
        t,
        "chatbot",
        /*chatbot*/
        s[0]
      );
    },
    m(u, f) {
      Ei(u, t, f), o.m(t, null), s[9](t);
    },
    p(u, [f]) {
      i === (i = n(u)) && o ? o.p(u, f) : (o.d(1), o = i(u), o && (o.c(), o.m(t, null))), f & /*chatbot*/
      1 && Vs(
        t,
        "chatbot",
        /*chatbot*/
        u[0]
      );
    },
    i: Gs,
    o: Gs,
    d(u) {
      u && Si(t), o.d(), s[9](null);
    }
  };
}
function j2(s, t, n) {
  let { chatbot: i = !0 } = t, { message: o } = t, { sanitize_html: u = !0 } = t, { latex_delimiters: f = [] } = t, { render_markdown: g = !0 } = t, { line_breaks: v = !0 } = t, { header_links: y = !1 } = t, D, B;
  const q = B2({ header_links: y, line_breaks: v }), G = (M) => {
    try {
      return !!M && new URL(M, location.href).origin !== location.origin;
    } catch {
      return !1;
    }
  };
  Es.addHook("afterSanitizeAttributes", function(M) {
    "target" in M && G(M.getAttribute("href")) && (M.setAttribute("target", "_blank"), M.setAttribute("rel", "noopener noreferrer"));
  });
  function K(M) {
    return g && (M = q.parse(M)), u && (M = Es.sanitize(M)), M;
  }
  async function $(M) {
    f.length > 0 && M && Mf(D, {
      delimiters: f,
      throwOnError: !1
    });
  }
  U2(() => $(o));
  function X(M) {
    R2[M ? "unshift" : "push"](() => {
      D = M, n(2, D);
    });
  }
  return s.$$set = (M) => {
    "chatbot" in M && n(0, i = M.chatbot), "message" in M && n(4, o = M.message), "sanitize_html" in M && n(5, u = M.sanitize_html), "latex_delimiters" in M && n(6, f = M.latex_delimiters), "render_markdown" in M && n(1, g = M.render_markdown), "line_breaks" in M && n(7, v = M.line_breaks), "header_links" in M && n(8, y = M.header_links);
  }, s.$$.update = () => {
    s.$$.dirty & /*message*/
    16 && (o && o.trim() ? n(3, B = K(o)) : n(3, B = ""));
  }, [
    i,
    g,
    D,
    B,
    o,
    u,
    f,
    v,
    y,
    X
  ];
}
class Eu extends z2 {
  constructor(t) {
    super(), O2(this, t, j2, W2, q2, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8
    });
  }
}
function vr(s) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; s > 1e3 && n < t.length - 1; )
    s /= 1e3, n++;
  let i = t[n];
  return (Number.isInteger(s) ? s : s.toFixed(1)) + i;
}
function Pn() {
}
function X2(s, t) {
  return s != s ? t == t : s !== t || s && typeof s == "object" || typeof s == "function";
}
const Fu = typeof window < "u";
let Ws = Fu ? () => window.performance.now() : () => Date.now(), Cu = Fu ? (s) => requestAnimationFrame(s) : Pn;
const yr = /* @__PURE__ */ new Set();
function Tu(s) {
  yr.forEach((t) => {
    t.c(s) || (yr.delete(t), t.f());
  }), yr.size !== 0 && Cu(Tu);
}
function Y2(s) {
  let t;
  return yr.size === 0 && Cu(Tu), {
    promise: new Promise((n) => {
      yr.add(t = { c: s, f: n });
    }),
    abort() {
      yr.delete(t);
    }
  };
}
const pr = [];
function Z2(s, t = Pn) {
  let n;
  const i = /* @__PURE__ */ new Set();
  function o(g) {
    if (X2(s, g) && (s = g, n)) {
      const v = !pr.length;
      for (const y of i)
        y[1](), pr.push(y, s);
      if (v) {
        for (let y = 0; y < pr.length; y += 2)
          pr[y][0](pr[y + 1]);
        pr.length = 0;
      }
    }
  }
  function u(g) {
    o(g(s));
  }
  function f(g, v = Pn) {
    const y = [g, v];
    return i.add(y), i.size === 1 && (n = t(o, u) || Pn), g(s), () => {
      i.delete(y), i.size === 0 && n && (n(), n = null);
    };
  }
  return { set: o, update: u, subscribe: f };
}
function js(s) {
  return Object.prototype.toString.call(s) === "[object Date]";
}
function pi(s, t, n, i) {
  if (typeof n == "number" || js(n)) {
    const o = i - n, u = (n - t) / (s.dt || 1 / 60), f = s.opts.stiffness * o, g = s.opts.damping * u, v = (f - g) * s.inv_mass, y = (u + v) * s.dt;
    return Math.abs(y) < s.opts.precision && Math.abs(o) < s.opts.precision ? i : (s.settled = !1, js(n) ? new Date(n.getTime() + y) : n + y);
  } else {
    if (Array.isArray(n))
      return n.map(
        (o, u) => pi(s, t[u], n[u], i[u])
      );
    if (typeof n == "object") {
      const o = {};
      for (const u in n)
        o[u] = pi(s, t[u], n[u], i[u]);
      return o;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function Xs(s, t = {}) {
  const n = Z2(s), { stiffness: i = 0.15, damping: o = 0.8, precision: u = 0.01 } = t;
  let f, g, v, y = s, D = s, B = 1, q = 0, G = !1;
  function K(X, M = {}) {
    D = X;
    const z = v = {};
    return s == null || M.hard || $.stiffness >= 1 && $.damping >= 1 ? (G = !0, f = Ws(), y = X, n.set(s = D), Promise.resolve()) : (M.soft && (q = 1 / ((M.soft === !0 ? 0.5 : +M.soft) * 60), B = 0), g || (f = Ws(), G = !1, g = Y2((F) => {
      if (G)
        return G = !1, g = null, !1;
      B = Math.min(B + q, 1);
      const N = {
        inv_mass: B,
        opts: $,
        settled: !0,
        dt: (F - f) * 60 / 1e3
      }, O = pi(N, y, s, D);
      return f = F, y = s, n.set(s = O), N.settled && (g = null), !N.settled;
    })), new Promise((F) => {
      g.promise.then(() => {
        z === v && F();
      });
    }));
  }
  const $ = {
    set: K,
    update: (X, M) => K(X(D, s), M),
    subscribe: n.subscribe,
    stiffness: i,
    damping: o,
    precision: u
  };
  return $;
}
const {
  SvelteComponent: K2,
  append: Qt,
  attr: Ce,
  component_subscribe: Ys,
  detach: Q2,
  element: J2,
  init: $2,
  insert: em,
  noop: Zs,
  safe_not_equal: tm,
  set_style: zn,
  svg_element: Jt,
  toggle_class: Ks
} = window.__gradio__svelte__internal, { onMount: rm } = window.__gradio__svelte__internal;
function nm(s) {
  let t, n, i, o, u, f, g, v, y, D, B, q;
  return {
    c() {
      t = J2("div"), n = Jt("svg"), i = Jt("g"), o = Jt("path"), u = Jt("path"), f = Jt("path"), g = Jt("path"), v = Jt("g"), y = Jt("path"), D = Jt("path"), B = Jt("path"), q = Jt("path"), Ce(o, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), Ce(o, "fill", "#FF7C00"), Ce(o, "fill-opacity", "0.4"), Ce(o, "class", "svelte-43sxxs"), Ce(u, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), Ce(u, "fill", "#FF7C00"), Ce(u, "class", "svelte-43sxxs"), Ce(f, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), Ce(f, "fill", "#FF7C00"), Ce(f, "fill-opacity", "0.4"), Ce(f, "class", "svelte-43sxxs"), Ce(g, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), Ce(g, "fill", "#FF7C00"), Ce(g, "class", "svelte-43sxxs"), zn(i, "transform", "translate(" + /*$top*/
      s[1][0] + "px, " + /*$top*/
      s[1][1] + "px)"), Ce(y, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), Ce(y, "fill", "#FF7C00"), Ce(y, "fill-opacity", "0.4"), Ce(y, "class", "svelte-43sxxs"), Ce(D, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), Ce(D, "fill", "#FF7C00"), Ce(D, "class", "svelte-43sxxs"), Ce(B, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), Ce(B, "fill", "#FF7C00"), Ce(B, "fill-opacity", "0.4"), Ce(B, "class", "svelte-43sxxs"), Ce(q, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), Ce(q, "fill", "#FF7C00"), Ce(q, "class", "svelte-43sxxs"), zn(v, "transform", "translate(" + /*$bottom*/
      s[2][0] + "px, " + /*$bottom*/
      s[2][1] + "px)"), Ce(n, "viewBox", "-1200 -1200 3000 3000"), Ce(n, "fill", "none"), Ce(n, "xmlns", "http://www.w3.org/2000/svg"), Ce(n, "class", "svelte-43sxxs"), Ce(t, "class", "svelte-43sxxs"), Ks(
        t,
        "margin",
        /*margin*/
        s[0]
      );
    },
    m(G, K) {
      em(G, t, K), Qt(t, n), Qt(n, i), Qt(i, o), Qt(i, u), Qt(i, f), Qt(i, g), Qt(n, v), Qt(v, y), Qt(v, D), Qt(v, B), Qt(v, q);
    },
    p(G, [K]) {
      K & /*$top*/
      2 && zn(i, "transform", "translate(" + /*$top*/
      G[1][0] + "px, " + /*$top*/
      G[1][1] + "px)"), K & /*$bottom*/
      4 && zn(v, "transform", "translate(" + /*$bottom*/
      G[2][0] + "px, " + /*$bottom*/
      G[2][1] + "px)"), K & /*margin*/
      1 && Ks(
        t,
        "margin",
        /*margin*/
        G[0]
      );
    },
    i: Zs,
    o: Zs,
    d(G) {
      G && Q2(t);
    }
  };
}
function am(s, t, n) {
  let i, o, { margin: u = !0 } = t;
  const f = Xs([0, 0]);
  Ys(s, f, (q) => n(1, i = q));
  const g = Xs([0, 0]);
  Ys(s, g, (q) => n(2, o = q));
  let v;
  async function y() {
    await Promise.all([f.set([125, 140]), g.set([-125, -140])]), await Promise.all([f.set([-125, 140]), g.set([125, -140])]), await Promise.all([f.set([-125, 0]), g.set([125, -0])]), await Promise.all([f.set([125, 0]), g.set([-125, 0])]);
  }
  async function D() {
    await y(), v || D();
  }
  async function B() {
    await Promise.all([f.set([125, 0]), g.set([-125, 0])]), D();
  }
  return rm(() => (B(), () => v = !0)), s.$$set = (q) => {
    "margin" in q && n(0, u = q.margin);
  }, [u, i, o, f, g];
}
class im extends K2 {
  constructor(t) {
    super(), $2(this, t, am, nm, tm, { margin: 0 });
  }
}
const {
  SvelteComponent: lm,
  append: $0,
  attr: c0,
  binding_callbacks: Qs,
  check_outros: Bu,
  create_component: sm,
  create_slot: om,
  destroy_component: um,
  destroy_each: Mu,
  detach: we,
  element: y0,
  empty: Ar,
  ensure_array_like: Wn,
  get_all_dirty_from_scope: cm,
  get_slot_changes: hm,
  group_outros: zu,
  init: fm,
  insert: _e,
  mount_component: mm,
  noop: gi,
  safe_not_equal: dm,
  set_data: Yt,
  set_style: U0,
  space: h0,
  text: Ze,
  toggle_class: jt,
  transition_in: wr,
  transition_out: _r,
  update_slot_base: pm
} = window.__gradio__svelte__internal, { tick: gm } = window.__gradio__svelte__internal, { onDestroy: vm } = window.__gradio__svelte__internal, bm = (s) => ({}), Js = (s) => ({});
function $s(s, t, n) {
  const i = s.slice();
  return i[38] = t[n], i[40] = n, i;
}
function eo(s, t, n) {
  const i = s.slice();
  return i[38] = t[n], i;
}
function ym(s) {
  let t, n = (
    /*i18n*/
    s[1]("common.error") + ""
  ), i, o, u;
  const f = (
    /*#slots*/
    s[29].error
  ), g = om(
    f,
    s,
    /*$$scope*/
    s[28],
    Js
  );
  return {
    c() {
      t = y0("span"), i = Ze(n), o = h0(), g && g.c(), c0(t, "class", "error svelte-1yserjw");
    },
    m(v, y) {
      _e(v, t, y), $0(t, i), _e(v, o, y), g && g.m(v, y), u = !0;
    },
    p(v, y) {
      (!u || y[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      v[1]("common.error") + "") && Yt(i, n), g && g.p && (!u || y[0] & /*$$scope*/
      268435456) && pm(
        g,
        f,
        v,
        /*$$scope*/
        v[28],
        u ? hm(
          f,
          /*$$scope*/
          v[28],
          y,
          bm
        ) : cm(
          /*$$scope*/
          v[28]
        ),
        Js
      );
    },
    i(v) {
      u || (wr(g, v), u = !0);
    },
    o(v) {
      _r(g, v), u = !1;
    },
    d(v) {
      v && (we(t), we(o)), g && g.d(v);
    }
  };
}
function wm(s) {
  let t, n, i, o, u, f, g, v, y, D = (
    /*variant*/
    s[8] === "default" && /*show_eta_bar*/
    s[18] && /*show_progress*/
    s[6] === "full" && to(s)
  );
  function B(F, N) {
    if (
      /*progress*/
      F[7]
    )
      return Dm;
    if (
      /*queue_position*/
      F[2] !== null && /*queue_size*/
      F[3] !== void 0 && /*queue_position*/
      F[2] >= 0
    )
      return km;
    if (
      /*queue_position*/
      F[2] === 0
    )
      return _m;
  }
  let q = B(s), G = q && q(s), K = (
    /*timer*/
    s[5] && ao(s)
  );
  const $ = [Em, Sm], X = [];
  function M(F, N) {
    return (
      /*last_progress_level*/
      F[15] != null ? 0 : (
        /*show_progress*/
        F[6] === "full" ? 1 : -1
      )
    );
  }
  ~(u = M(s)) && (f = X[u] = $[u](s));
  let z = !/*timer*/
  s[5] && ho(s);
  return {
    c() {
      D && D.c(), t = h0(), n = y0("div"), G && G.c(), i = h0(), K && K.c(), o = h0(), f && f.c(), g = h0(), z && z.c(), v = Ar(), c0(n, "class", "progress-text svelte-1yserjw"), jt(
        n,
        "meta-text-center",
        /*variant*/
        s[8] === "center"
      ), jt(
        n,
        "meta-text",
        /*variant*/
        s[8] === "default"
      );
    },
    m(F, N) {
      D && D.m(F, N), _e(F, t, N), _e(F, n, N), G && G.m(n, null), $0(n, i), K && K.m(n, null), _e(F, o, N), ~u && X[u].m(F, N), _e(F, g, N), z && z.m(F, N), _e(F, v, N), y = !0;
    },
    p(F, N) {
      /*variant*/
      F[8] === "default" && /*show_eta_bar*/
      F[18] && /*show_progress*/
      F[6] === "full" ? D ? D.p(F, N) : (D = to(F), D.c(), D.m(t.parentNode, t)) : D && (D.d(1), D = null), q === (q = B(F)) && G ? G.p(F, N) : (G && G.d(1), G = q && q(F), G && (G.c(), G.m(n, i))), /*timer*/
      F[5] ? K ? K.p(F, N) : (K = ao(F), K.c(), K.m(n, null)) : K && (K.d(1), K = null), (!y || N[0] & /*variant*/
      256) && jt(
        n,
        "meta-text-center",
        /*variant*/
        F[8] === "center"
      ), (!y || N[0] & /*variant*/
      256) && jt(
        n,
        "meta-text",
        /*variant*/
        F[8] === "default"
      );
      let O = u;
      u = M(F), u === O ? ~u && X[u].p(F, N) : (f && (zu(), _r(X[O], 1, 1, () => {
        X[O] = null;
      }), Bu()), ~u ? (f = X[u], f ? f.p(F, N) : (f = X[u] = $[u](F), f.c()), wr(f, 1), f.m(g.parentNode, g)) : f = null), /*timer*/
      F[5] ? z && (z.d(1), z = null) : z ? z.p(F, N) : (z = ho(F), z.c(), z.m(v.parentNode, v));
    },
    i(F) {
      y || (wr(f), y = !0);
    },
    o(F) {
      _r(f), y = !1;
    },
    d(F) {
      F && (we(t), we(n), we(o), we(g), we(v)), D && D.d(F), G && G.d(), K && K.d(), ~u && X[u].d(F), z && z.d(F);
    }
  };
}
function to(s) {
  let t, n = `translateX(${/*eta_level*/
  (s[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = y0("div"), c0(t, "class", "eta-bar svelte-1yserjw"), U0(t, "transform", n);
    },
    m(i, o) {
      _e(i, t, o);
    },
    p(i, o) {
      o[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && U0(t, "transform", n);
    },
    d(i) {
      i && we(t);
    }
  };
}
function _m(s) {
  let t;
  return {
    c() {
      t = Ze("processing |");
    },
    m(n, i) {
      _e(n, t, i);
    },
    p: gi,
    d(n) {
      n && we(t);
    }
  };
}
function km(s) {
  let t, n = (
    /*queue_position*/
    s[2] + 1 + ""
  ), i, o, u, f;
  return {
    c() {
      t = Ze("queue: "), i = Ze(n), o = Ze("/"), u = Ze(
        /*queue_size*/
        s[3]
      ), f = Ze(" |");
    },
    m(g, v) {
      _e(g, t, v), _e(g, i, v), _e(g, o, v), _e(g, u, v), _e(g, f, v);
    },
    p(g, v) {
      v[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      g[2] + 1 + "") && Yt(i, n), v[0] & /*queue_size*/
      8 && Yt(
        u,
        /*queue_size*/
        g[3]
      );
    },
    d(g) {
      g && (we(t), we(i), we(o), we(u), we(f));
    }
  };
}
function Dm(s) {
  let t, n = Wn(
    /*progress*/
    s[7]
  ), i = [];
  for (let o = 0; o < n.length; o += 1)
    i[o] = no(eo(s, n, o));
  return {
    c() {
      for (let o = 0; o < i.length; o += 1)
        i[o].c();
      t = Ar();
    },
    m(o, u) {
      for (let f = 0; f < i.length; f += 1)
        i[f] && i[f].m(o, u);
      _e(o, t, u);
    },
    p(o, u) {
      if (u[0] & /*progress*/
      128) {
        n = Wn(
          /*progress*/
          o[7]
        );
        let f;
        for (f = 0; f < n.length; f += 1) {
          const g = eo(o, n, f);
          i[f] ? i[f].p(g, u) : (i[f] = no(g), i[f].c(), i[f].m(t.parentNode, t));
        }
        for (; f < i.length; f += 1)
          i[f].d(1);
        i.length = n.length;
      }
    },
    d(o) {
      o && we(t), Mu(i, o);
    }
  };
}
function ro(s) {
  let t, n = (
    /*p*/
    s[38].unit + ""
  ), i, o, u = " ", f;
  function g(D, B) {
    return (
      /*p*/
      D[38].length != null ? xm : Am
    );
  }
  let v = g(s), y = v(s);
  return {
    c() {
      y.c(), t = h0(), i = Ze(n), o = Ze(" | "), f = Ze(u);
    },
    m(D, B) {
      y.m(D, B), _e(D, t, B), _e(D, i, B), _e(D, o, B), _e(D, f, B);
    },
    p(D, B) {
      v === (v = g(D)) && y ? y.p(D, B) : (y.d(1), y = v(D), y && (y.c(), y.m(t.parentNode, t))), B[0] & /*progress*/
      128 && n !== (n = /*p*/
      D[38].unit + "") && Yt(i, n);
    },
    d(D) {
      D && (we(t), we(i), we(o), we(f)), y.d(D);
    }
  };
}
function Am(s) {
  let t = vr(
    /*p*/
    s[38].index || 0
  ) + "", n;
  return {
    c() {
      n = Ze(t);
    },
    m(i, o) {
      _e(i, n, o);
    },
    p(i, o) {
      o[0] & /*progress*/
      128 && t !== (t = vr(
        /*p*/
        i[38].index || 0
      ) + "") && Yt(n, t);
    },
    d(i) {
      i && we(n);
    }
  };
}
function xm(s) {
  let t = vr(
    /*p*/
    s[38].index || 0
  ) + "", n, i, o = vr(
    /*p*/
    s[38].length
  ) + "", u;
  return {
    c() {
      n = Ze(t), i = Ze("/"), u = Ze(o);
    },
    m(f, g) {
      _e(f, n, g), _e(f, i, g), _e(f, u, g);
    },
    p(f, g) {
      g[0] & /*progress*/
      128 && t !== (t = vr(
        /*p*/
        f[38].index || 0
      ) + "") && Yt(n, t), g[0] & /*progress*/
      128 && o !== (o = vr(
        /*p*/
        f[38].length
      ) + "") && Yt(u, o);
    },
    d(f) {
      f && (we(n), we(i), we(u));
    }
  };
}
function no(s) {
  let t, n = (
    /*p*/
    s[38].index != null && ro(s)
  );
  return {
    c() {
      n && n.c(), t = Ar();
    },
    m(i, o) {
      n && n.m(i, o), _e(i, t, o);
    },
    p(i, o) {
      /*p*/
      i[38].index != null ? n ? n.p(i, o) : (n = ro(i), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && we(t), n && n.d(i);
    }
  };
}
function ao(s) {
  let t, n = (
    /*eta*/
    s[0] ? `/${/*formatted_eta*/
    s[19]}` : ""
  ), i, o;
  return {
    c() {
      t = Ze(
        /*formatted_timer*/
        s[20]
      ), i = Ze(n), o = Ze("s");
    },
    m(u, f) {
      _e(u, t, f), _e(u, i, f), _e(u, o, f);
    },
    p(u, f) {
      f[0] & /*formatted_timer*/
      1048576 && Yt(
        t,
        /*formatted_timer*/
        u[20]
      ), f[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      u[0] ? `/${/*formatted_eta*/
      u[19]}` : "") && Yt(i, n);
    },
    d(u) {
      u && (we(t), we(i), we(o));
    }
  };
}
function Sm(s) {
  let t, n;
  return t = new im({
    props: { margin: (
      /*variant*/
      s[8] === "default"
    ) }
  }), {
    c() {
      sm(t.$$.fragment);
    },
    m(i, o) {
      mm(t, i, o), n = !0;
    },
    p(i, o) {
      const u = {};
      o[0] & /*variant*/
      256 && (u.margin = /*variant*/
      i[8] === "default"), t.$set(u);
    },
    i(i) {
      n || (wr(t.$$.fragment, i), n = !0);
    },
    o(i) {
      _r(t.$$.fragment, i), n = !1;
    },
    d(i) {
      um(t, i);
    }
  };
}
function Em(s) {
  let t, n, i, o, u, f = `${/*last_progress_level*/
  s[15] * 100}%`, g = (
    /*progress*/
    s[7] != null && io(s)
  );
  return {
    c() {
      t = y0("div"), n = y0("div"), g && g.c(), i = h0(), o = y0("div"), u = y0("div"), c0(n, "class", "progress-level-inner svelte-1yserjw"), c0(u, "class", "progress-bar svelte-1yserjw"), U0(u, "width", f), c0(o, "class", "progress-bar-wrap svelte-1yserjw"), c0(t, "class", "progress-level svelte-1yserjw");
    },
    m(v, y) {
      _e(v, t, y), $0(t, n), g && g.m(n, null), $0(t, i), $0(t, o), $0(o, u), s[30](u);
    },
    p(v, y) {
      /*progress*/
      v[7] != null ? g ? g.p(v, y) : (g = io(v), g.c(), g.m(n, null)) : g && (g.d(1), g = null), y[0] & /*last_progress_level*/
      32768 && f !== (f = `${/*last_progress_level*/
      v[15] * 100}%`) && U0(u, "width", f);
    },
    i: gi,
    o: gi,
    d(v) {
      v && we(t), g && g.d(), s[30](null);
    }
  };
}
function io(s) {
  let t, n = Wn(
    /*progress*/
    s[7]
  ), i = [];
  for (let o = 0; o < n.length; o += 1)
    i[o] = co($s(s, n, o));
  return {
    c() {
      for (let o = 0; o < i.length; o += 1)
        i[o].c();
      t = Ar();
    },
    m(o, u) {
      for (let f = 0; f < i.length; f += 1)
        i[f] && i[f].m(o, u);
      _e(o, t, u);
    },
    p(o, u) {
      if (u[0] & /*progress_level, progress*/
      16512) {
        n = Wn(
          /*progress*/
          o[7]
        );
        let f;
        for (f = 0; f < n.length; f += 1) {
          const g = $s(o, n, f);
          i[f] ? i[f].p(g, u) : (i[f] = co(g), i[f].c(), i[f].m(t.parentNode, t));
        }
        for (; f < i.length; f += 1)
          i[f].d(1);
        i.length = n.length;
      }
    },
    d(o) {
      o && we(t), Mu(i, o);
    }
  };
}
function lo(s) {
  let t, n, i, o, u = (
    /*i*/
    s[40] !== 0 && Fm()
  ), f = (
    /*p*/
    s[38].desc != null && so(s)
  ), g = (
    /*p*/
    s[38].desc != null && /*progress_level*/
    s[14] && /*progress_level*/
    s[14][
      /*i*/
      s[40]
    ] != null && oo()
  ), v = (
    /*progress_level*/
    s[14] != null && uo(s)
  );
  return {
    c() {
      u && u.c(), t = h0(), f && f.c(), n = h0(), g && g.c(), i = h0(), v && v.c(), o = Ar();
    },
    m(y, D) {
      u && u.m(y, D), _e(y, t, D), f && f.m(y, D), _e(y, n, D), g && g.m(y, D), _e(y, i, D), v && v.m(y, D), _e(y, o, D);
    },
    p(y, D) {
      /*p*/
      y[38].desc != null ? f ? f.p(y, D) : (f = so(y), f.c(), f.m(n.parentNode, n)) : f && (f.d(1), f = null), /*p*/
      y[38].desc != null && /*progress_level*/
      y[14] && /*progress_level*/
      y[14][
        /*i*/
        y[40]
      ] != null ? g || (g = oo(), g.c(), g.m(i.parentNode, i)) : g && (g.d(1), g = null), /*progress_level*/
      y[14] != null ? v ? v.p(y, D) : (v = uo(y), v.c(), v.m(o.parentNode, o)) : v && (v.d(1), v = null);
    },
    d(y) {
      y && (we(t), we(n), we(i), we(o)), u && u.d(y), f && f.d(y), g && g.d(y), v && v.d(y);
    }
  };
}
function Fm(s) {
  let t;
  return {
    c() {
      t = Ze(" /");
    },
    m(n, i) {
      _e(n, t, i);
    },
    d(n) {
      n && we(t);
    }
  };
}
function so(s) {
  let t = (
    /*p*/
    s[38].desc + ""
  ), n;
  return {
    c() {
      n = Ze(t);
    },
    m(i, o) {
      _e(i, n, o);
    },
    p(i, o) {
      o[0] & /*progress*/
      128 && t !== (t = /*p*/
      i[38].desc + "") && Yt(n, t);
    },
    d(i) {
      i && we(n);
    }
  };
}
function oo(s) {
  let t;
  return {
    c() {
      t = Ze("-");
    },
    m(n, i) {
      _e(n, t, i);
    },
    d(n) {
      n && we(t);
    }
  };
}
function uo(s) {
  let t = (100 * /*progress_level*/
  (s[14][
    /*i*/
    s[40]
  ] || 0)).toFixed(1) + "", n, i;
  return {
    c() {
      n = Ze(t), i = Ze("%");
    },
    m(o, u) {
      _e(o, n, u), _e(o, i, u);
    },
    p(o, u) {
      u[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (o[14][
        /*i*/
        o[40]
      ] || 0)).toFixed(1) + "") && Yt(n, t);
    },
    d(o) {
      o && (we(n), we(i));
    }
  };
}
function co(s) {
  let t, n = (
    /*p*/
    (s[38].desc != null || /*progress_level*/
    s[14] && /*progress_level*/
    s[14][
      /*i*/
      s[40]
    ] != null) && lo(s)
  );
  return {
    c() {
      n && n.c(), t = Ar();
    },
    m(i, o) {
      n && n.m(i, o), _e(i, t, o);
    },
    p(i, o) {
      /*p*/
      i[38].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[40]
      ] != null ? n ? n.p(i, o) : (n = lo(i), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && we(t), n && n.d(i);
    }
  };
}
function ho(s) {
  let t, n;
  return {
    c() {
      t = y0("p"), n = Ze(
        /*loading_text*/
        s[9]
      ), c0(t, "class", "loading svelte-1yserjw");
    },
    m(i, o) {
      _e(i, t, o), $0(t, n);
    },
    p(i, o) {
      o[0] & /*loading_text*/
      512 && Yt(
        n,
        /*loading_text*/
        i[9]
      );
    },
    d(i) {
      i && we(t);
    }
  };
}
function Cm(s) {
  let t, n, i, o, u;
  const f = [wm, ym], g = [];
  function v(y, D) {
    return (
      /*status*/
      y[4] === "pending" ? 0 : (
        /*status*/
        y[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = v(s)) && (i = g[n] = f[n](s)), {
    c() {
      t = y0("div"), i && i.c(), c0(t, "class", o = "wrap " + /*variant*/
      s[8] + " " + /*show_progress*/
      s[6] + " svelte-1yserjw"), jt(t, "hide", !/*status*/
      s[4] || /*status*/
      s[4] === "complete" || /*show_progress*/
      s[6] === "hidden"), jt(
        t,
        "translucent",
        /*variant*/
        s[8] === "center" && /*status*/
        (s[4] === "pending" || /*status*/
        s[4] === "error") || /*translucent*/
        s[11] || /*show_progress*/
        s[6] === "minimal"
      ), jt(
        t,
        "generating",
        /*status*/
        s[4] === "generating"
      ), jt(
        t,
        "border",
        /*border*/
        s[12]
      ), U0(
        t,
        "position",
        /*absolute*/
        s[10] ? "absolute" : "static"
      ), U0(
        t,
        "padding",
        /*absolute*/
        s[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(y, D) {
      _e(y, t, D), ~n && g[n].m(t, null), s[31](t), u = !0;
    },
    p(y, D) {
      let B = n;
      n = v(y), n === B ? ~n && g[n].p(y, D) : (i && (zu(), _r(g[B], 1, 1, () => {
        g[B] = null;
      }), Bu()), ~n ? (i = g[n], i ? i.p(y, D) : (i = g[n] = f[n](y), i.c()), wr(i, 1), i.m(t, null)) : i = null), (!u || D[0] & /*variant, show_progress*/
      320 && o !== (o = "wrap " + /*variant*/
      y[8] + " " + /*show_progress*/
      y[6] + " svelte-1yserjw")) && c0(t, "class", o), (!u || D[0] & /*variant, show_progress, status, show_progress*/
      336) && jt(t, "hide", !/*status*/
      y[4] || /*status*/
      y[4] === "complete" || /*show_progress*/
      y[6] === "hidden"), (!u || D[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && jt(
        t,
        "translucent",
        /*variant*/
        y[8] === "center" && /*status*/
        (y[4] === "pending" || /*status*/
        y[4] === "error") || /*translucent*/
        y[11] || /*show_progress*/
        y[6] === "minimal"
      ), (!u || D[0] & /*variant, show_progress, status*/
      336) && jt(
        t,
        "generating",
        /*status*/
        y[4] === "generating"
      ), (!u || D[0] & /*variant, show_progress, border*/
      4416) && jt(
        t,
        "border",
        /*border*/
        y[12]
      ), D[0] & /*absolute*/
      1024 && U0(
        t,
        "position",
        /*absolute*/
        y[10] ? "absolute" : "static"
      ), D[0] & /*absolute*/
      1024 && U0(
        t,
        "padding",
        /*absolute*/
        y[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(y) {
      u || (wr(i), u = !0);
    },
    o(y) {
      _r(i), u = !1;
    },
    d(y) {
      y && we(t), ~n && g[n].d(), s[31](null);
    }
  };
}
let Nn = [], ni = !1;
async function Tm(s, t = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
    if (Nn.push(s), !ni)
      ni = !0;
    else
      return;
    await gm(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let i = 0; i < Nn.length; i++) {
        const u = Nn[i].getBoundingClientRect();
        (i === 0 || u.top + window.scrollY <= n[0]) && (n[0] = u.top + window.scrollY, n[1] = i);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), ni = !1, Nn = [];
    });
  }
}
function Bm(s, t, n) {
  let i, { $$slots: o = {}, $$scope: u } = t, { i18n: f } = t, { eta: g = null } = t, { queue_position: v } = t, { queue_size: y } = t, { status: D } = t, { scroll_to_output: B = !1 } = t, { timer: q = !0 } = t, { show_progress: G = "full" } = t, { message: K = null } = t, { progress: $ = null } = t, { variant: X = "default" } = t, { loading_text: M = "Loading..." } = t, { absolute: z = !0 } = t, { translucent: F = !1 } = t, { border: N = !1 } = t, { autoscroll: O } = t, R, U = !1, J = 0, V = 0, ee = null, fe = null, xe = 0, ve = null, Se, Je = null, ft = !0;
  const ct = () => {
    n(0, g = n(26, ee = n(19, Me = null))), n(24, J = performance.now()), n(25, V = 0), U = !0, Ne();
  };
  function Ne() {
    requestAnimationFrame(() => {
      n(25, V = (performance.now() - J) / 1e3), U && Ne();
    });
  }
  function Y() {
    n(25, V = 0), n(0, g = n(26, ee = n(19, Me = null))), U && (U = !1);
  }
  vm(() => {
    U && Y();
  });
  let Me = null;
  function re(le) {
    Qs[le ? "unshift" : "push"](() => {
      Je = le, n(16, Je), n(7, $), n(14, ve), n(15, Se);
    });
  }
  function Ue(le) {
    Qs[le ? "unshift" : "push"](() => {
      R = le, n(13, R);
    });
  }
  return s.$$set = (le) => {
    "i18n" in le && n(1, f = le.i18n), "eta" in le && n(0, g = le.eta), "queue_position" in le && n(2, v = le.queue_position), "queue_size" in le && n(3, y = le.queue_size), "status" in le && n(4, D = le.status), "scroll_to_output" in le && n(21, B = le.scroll_to_output), "timer" in le && n(5, q = le.timer), "show_progress" in le && n(6, G = le.show_progress), "message" in le && n(22, K = le.message), "progress" in le && n(7, $ = le.progress), "variant" in le && n(8, X = le.variant), "loading_text" in le && n(9, M = le.loading_text), "absolute" in le && n(10, z = le.absolute), "translucent" in le && n(11, F = le.translucent), "border" in le && n(12, N = le.border), "autoscroll" in le && n(23, O = le.autoscroll), "$$scope" in le && n(28, u = le.$$scope);
  }, s.$$.update = () => {
    s.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    218103809 && (g === null && n(0, g = ee), g != null && ee !== g && (n(27, fe = (performance.now() - J) / 1e3 + g), n(19, Me = fe.toFixed(1)), n(26, ee = g))), s.$$.dirty[0] & /*eta_from_start, timer_diff*/
    167772160 && n(17, xe = fe === null || fe <= 0 || !V ? null : Math.min(V / fe, 1)), s.$$.dirty[0] & /*progress*/
    128 && $ != null && n(18, ft = !1), s.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && ($ != null ? n(14, ve = $.map((le) => {
      if (le.index != null && le.length != null)
        return le.index / le.length;
      if (le.progress != null)
        return le.progress;
    })) : n(14, ve = null), ve ? (n(15, Se = ve[ve.length - 1]), Je && (Se === 0 ? n(16, Je.style.transition = "0", Je) : n(16, Je.style.transition = "150ms", Je))) : n(15, Se = void 0)), s.$$.dirty[0] & /*status*/
    16 && (D === "pending" ? ct() : Y()), s.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    10493968 && R && B && (D === "pending" || D === "complete") && Tm(R, O), s.$$.dirty[0] & /*status, message*/
    4194320, s.$$.dirty[0] & /*timer_diff*/
    33554432 && n(20, i = V.toFixed(1));
  }, [
    g,
    f,
    v,
    y,
    D,
    q,
    G,
    $,
    X,
    M,
    z,
    F,
    N,
    R,
    ve,
    Se,
    Je,
    xe,
    ft,
    Me,
    i,
    B,
    K,
    O,
    J,
    V,
    ee,
    fe,
    u,
    o,
    re,
    Ue
  ];
}
class Mm extends lm {
  constructor(t) {
    super(), fm(
      this,
      t,
      Bm,
      Cm,
      dm,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 21,
        timer: 5,
        show_progress: 6,
        message: 22,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 23
      },
      null,
      [-1, -1]
    );
  }
}
new Intl.Collator(0, { numeric: 1 }).compare;
const {
  SvelteComponent: zm,
  append: Nm,
  attr: Rn,
  check_outros: fo,
  create_component: Nu,
  destroy_component: Ru,
  detach: Rm,
  element: Lm,
  group_outros: mo,
  init: Im,
  insert: Om,
  listen: qm,
  mount_component: Lu,
  safe_not_equal: Pm,
  space: Hm,
  transition_in: P0,
  transition_out: br
} = window.__gradio__svelte__internal, { onDestroy: Um } = window.__gradio__svelte__internal;
function po(s) {
  let t, n;
  return t = new q4({}), {
    c() {
      Nu(t.$$.fragment);
    },
    m(i, o) {
      Lu(t, i, o), n = !0;
    },
    i(i) {
      n || (P0(t.$$.fragment, i), n = !0);
    },
    o(i) {
      br(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Ru(t, i);
    }
  };
}
function go(s) {
  let t, n;
  return t = new A4({}), {
    c() {
      Nu(t.$$.fragment);
    },
    m(i, o) {
      Lu(t, i, o), n = !0;
    },
    i(i) {
      n || (P0(t.$$.fragment, i), n = !0);
    },
    o(i) {
      br(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Ru(t, i);
    }
  };
}
function Gm(s) {
  let t, n, i, o, u, f, g = !/*copied*/
  s[0] && po(), v = (
    /*copied*/
    s[0] && go()
  );
  return {
    c() {
      t = Lm("button"), g && g.c(), n = Hm(), v && v.c(), Rn(t, "class", "action svelte-1qsp0z8"), Rn(t, "title", "copy"), Rn(t, "aria-label", i = /*copied*/
      s[0] ? "Copied message" : "Copy message");
    },
    m(y, D) {
      Om(y, t, D), g && g.m(t, null), Nm(t, n), v && v.m(t, null), o = !0, u || (f = qm(
        t,
        "click",
        /*handle_copy*/
        s[1]
      ), u = !0);
    },
    p(y, [D]) {
      /*copied*/
      y[0] ? g && (mo(), br(g, 1, 1, () => {
        g = null;
      }), fo()) : g ? D & /*copied*/
      1 && P0(g, 1) : (g = po(), g.c(), P0(g, 1), g.m(t, n)), /*copied*/
      y[0] ? v ? D & /*copied*/
      1 && P0(v, 1) : (v = go(), v.c(), P0(v, 1), v.m(t, null)) : v && (mo(), br(v, 1, 1, () => {
        v = null;
      }), fo()), (!o || D & /*copied*/
      1 && i !== (i = /*copied*/
      y[0] ? "Copied message" : "Copy message")) && Rn(t, "aria-label", i);
    },
    i(y) {
      o || (P0(g), P0(v), o = !0);
    },
    o(y) {
      br(g), br(v), o = !1;
    },
    d(y) {
      y && Rm(t), g && g.d(), v && v.d(), u = !1, f();
    }
  };
}
function Vm(s, t, n) {
  let i = !1, { value: o } = t, u;
  function f() {
    n(0, i = !0), u && clearTimeout(u), u = setTimeout(
      () => {
        n(0, i = !1);
      },
      2e3
    );
  }
  async function g() {
    if ("clipboard" in navigator)
      await navigator.clipboard.writeText(o), f();
    else {
      const v = document.createElement("textarea");
      v.value = o, v.style.position = "absolute", v.style.left = "-999999px", document.body.prepend(v), v.select();
      try {
        document.execCommand("copy"), f();
      } catch (y) {
        console.error(y);
      } finally {
        v.remove();
      }
    }
  }
  return Um(() => {
    u && clearTimeout(u);
  }), s.$$set = (v) => {
    "value" in v && n(2, o = v.value);
  }, [i, g, o];
}
class Wm extends zm {
  constructor(t) {
    super(), Im(this, t, Vm, Gm, Pm, { value: 2 });
  }
}
const {
  SvelteComponent: jm,
  attr: gr,
  create_component: vo,
  destroy_component: bo,
  detach: ai,
  element: yo,
  init: Xm,
  insert: ii,
  listen: wo,
  mount_component: _o,
  run_all: Ym,
  safe_not_equal: Zm,
  space: Km,
  transition_in: ko,
  transition_out: Do
} = window.__gradio__svelte__internal;
function Qm(s) {
  let t, n, i, o, u, f, g, v, y, D;
  return n = new th({
    props: { selected: (
      /*selected*/
      s[1] === "like"
    ) }
  }), f = new X4({
    props: {
      selected: (
        /*selected*/
        s[1] === "dislike"
      )
    }
  }), {
    c() {
      t = yo("button"), vo(n.$$.fragment), o = Km(), u = yo("button"), vo(f.$$.fragment), gr(t, "aria-label", i = /*selected*/
      s[1] === "like" ? "clicked like" : "like"), gr(t, "class", "svelte-1nphhme"), gr(u, "aria-label", g = /*selected*/
      s[1] === "dislike" ? "clicked dislike" : "dislike"), gr(u, "class", "svelte-1nphhme");
    },
    m(B, q) {
      ii(B, t, q), _o(n, t, null), ii(B, o, q), ii(B, u, q), _o(f, u, null), v = !0, y || (D = [
        wo(
          t,
          "click",
          /*click_handler*/
          s[2]
        ),
        wo(
          u,
          "click",
          /*click_handler_1*/
          s[3]
        )
      ], y = !0);
    },
    p(B, [q]) {
      const G = {};
      q & /*selected*/
      2 && (G.selected = /*selected*/
      B[1] === "like"), n.$set(G), (!v || q & /*selected*/
      2 && i !== (i = /*selected*/
      B[1] === "like" ? "clicked like" : "like")) && gr(t, "aria-label", i);
      const K = {};
      q & /*selected*/
      2 && (K.selected = /*selected*/
      B[1] === "dislike"), f.$set(K), (!v || q & /*selected*/
      2 && g !== (g = /*selected*/
      B[1] === "dislike" ? "clicked dislike" : "dislike")) && gr(u, "aria-label", g);
    },
    i(B) {
      v || (ko(n.$$.fragment, B), ko(f.$$.fragment, B), v = !0);
    },
    o(B) {
      Do(n.$$.fragment, B), Do(f.$$.fragment, B), v = !1;
    },
    d(B) {
      B && (ai(t), ai(o), ai(u)), bo(n), bo(f), y = !1, Ym(D);
    }
  };
}
function Jm(s, t, n) {
  let { handle_action: i } = t, o = null;
  const u = () => {
    n(1, o = "like"), i(o);
  }, f = () => {
    n(1, o = "dislike"), i(o);
  };
  return s.$$set = (g) => {
    "handle_action" in g && n(0, i = g.handle_action);
  }, [i, o, u, f];
}
class $m extends jm {
  constructor(t) {
    super(), Xm(this, t, Jm, Qm, Zm, { handle_action: 0 });
  }
}
const {
  SvelteComponent: ed,
  attr: Ln,
  detach: td,
  element: rd,
  init: nd,
  insert: ad,
  noop: Ao,
  safe_not_equal: id,
  set_style: xo
} = window.__gradio__svelte__internal;
function ld(s) {
  let t;
  return {
    c() {
      t = rd("div"), t.innerHTML = `<span class="sr-only">Loading content</span> <div class="dot-flashing svelte-1pwlswb"></div>
	 
	<div class="dot-flashing svelte-1pwlswb"></div>
	 
	<div class="dot-flashing svelte-1pwlswb"></div>`, Ln(t, "class", "message pending svelte-1pwlswb"), Ln(t, "role", "status"), Ln(t, "aria-label", "Loading response"), Ln(t, "aria-live", "polite"), xo(
        t,
        "border-radius",
        /*layout*/
        s[0] === "bubble" ? "var(--radius-xxl)" : "none"
      );
    },
    m(n, i) {
      ad(n, t, i);
    },
    p(n, [i]) {
      i & /*layout*/
      1 && xo(
        t,
        "border-radius",
        /*layout*/
        n[0] === "bubble" ? "var(--radius-xxl)" : "none"
      );
    },
    i: Ao,
    o: Ao,
    d(n) {
      n && td(t);
    }
  };
}
function sd(s, t, n) {
  let { layout: i = "bubble" } = t;
  return s.$$set = (o) => {
    "layout" in o && n(0, i = o.layout);
  }, [i];
}
class od extends ed {
  constructor(t) {
    super(), nd(this, t, sd, ld, id, { layout: 0 });
  }
}
const {
  SvelteComponent: ud,
  action_destroyer: cd,
  append: w0,
  attr: Ae,
  binding_callbacks: hd,
  bubble: Dt,
  check_outros: Bt,
  create_component: Nt,
  destroy_component: Rt,
  destroy_each: Fi,
  detach: ot,
  element: Xt,
  empty: Zr,
  ensure_array_like: kr,
  group_outros: Mt,
  init: fd,
  insert: ut,
  listen: So,
  mount_component: Lt,
  noop: Dr,
  null_to_empty: Eo,
  run_all: md,
  safe_not_equal: dd,
  set_data: Iu,
  set_style: Gr,
  space: tr,
  text: Ou,
  toggle_class: rt,
  transition_in: pe,
  transition_out: ke
} = window.__gradio__svelte__internal, { beforeUpdate: pd, afterUpdate: gd, createEventDispatcher: vd } = window.__gradio__svelte__internal;
function Fo(s, t, n) {
  const i = s.slice();
  return i[41] = t[n], i[43] = n, i;
}
function Co(s, t, n) {
  const i = s.slice();
  return i[44] = t[n], i[46] = n, i;
}
function To(s, t, n) {
  const i = s.slice();
  return i[47] = t[n], i[49] = n, i;
}
function Bo(s) {
  let t, n, i;
  return n = new mh({
    props: {
      i18n: (
        /*i18n*/
        s[13]
      ),
      formatter: pc,
      value: (
        /*value*/
        s[0]
      )
    }
  }), n.$on(
    "error",
    /*error_handler*/
    s[21]
  ), n.$on(
    "share",
    /*share_handler*/
    s[22]
  ), {
    c() {
      t = Xt("div"), Nt(n.$$.fragment), Ae(t, "class", "share-button svelte-10ymup0");
    },
    m(o, u) {
      ut(o, t, u), Lt(n, t, null), i = !0;
    },
    p(o, u) {
      const f = {};
      u[0] & /*i18n*/
      8192 && (f.i18n = /*i18n*/
      o[13]), u[0] & /*value*/
      1 && (f.value = /*value*/
      o[0]), n.$set(f);
    },
    i(o) {
      i || (pe(n.$$.fragment, o), i = !0);
    },
    o(o) {
      ke(n.$$.fragment, o), i = !1;
    },
    d(o) {
      o && ot(t), Rt(n);
    }
  };
}
function Mo(s) {
  let t, n, i, o = kr(
    /*value*/
    s[0]
  ), u = [];
  for (let v = 0; v < o.length; v += 1)
    u[v] = Po(Fo(s, o, v));
  const f = (v) => ke(u[v], 1, 1, () => {
    u[v] = null;
  });
  let g = (
    /*pending_message*/
    s[2] && Ho(s)
  );
  return {
    c() {
      for (let v = 0; v < u.length; v += 1)
        u[v].c();
      t = tr(), g && g.c(), n = Zr();
    },
    m(v, y) {
      for (let D = 0; D < u.length; D += 1)
        u[D] && u[D].m(v, y);
      ut(v, t, y), g && g.m(v, y), ut(v, n, y), i = !0;
    },
    p(v, y) {
      if (y[0] & /*value, layout, avatar_images, bubble_full_width, show_copy_button, handle_like, likeable, render_markdown, rtl, selectable, handle_select, latex_delimiters, sanitize_html, line_breaks, scroll*/
      483291) {
        o = kr(
          /*value*/
          v[0]
        );
        let D;
        for (D = 0; D < o.length; D += 1) {
          const B = Fo(v, o, D);
          u[D] ? (u[D].p(B, y), pe(u[D], 1)) : (u[D] = Po(B), u[D].c(), pe(u[D], 1), u[D].m(t.parentNode, t));
        }
        for (Mt(), D = o.length; D < u.length; D += 1)
          f(D);
        Bt();
      }
      /*pending_message*/
      v[2] ? g ? (g.p(v, y), y[0] & /*pending_message*/
      4 && pe(g, 1)) : (g = Ho(v), g.c(), pe(g, 1), g.m(n.parentNode, n)) : g && (Mt(), ke(g, 1, 1, () => {
        g = null;
      }), Bt());
    },
    i(v) {
      if (!i) {
        for (let y = 0; y < o.length; y += 1)
          pe(u[y]);
        pe(g), i = !0;
      }
    },
    o(v) {
      u = u.filter(Boolean);
      for (let y = 0; y < u.length; y += 1)
        ke(u[y]);
      ke(g), i = !1;
    },
    d(v) {
      v && (ot(t), ot(n)), Fi(u, v), g && g.d(v);
    }
  };
}
function zo(s) {
  let t, n, i, o, u, f, g, v, y, D, B, q, G, K, $, X, M, z = (
    /*avatar_images*/
    s[8][
      /*j*/
      s[46]
    ] !== null && No(s)
  );
  const F = [
    Dd,
    kd,
    _d,
    wd,
    yd,
    bd
  ], N = [];
  function O(V, ee) {
    var fe, xe, ve, Se, Je, ft, ct;
    return ee[0] & /*value*/
    1 && (u = null), ee[0] & /*value*/
    1 && (f = null), ee[0] & /*value*/
    1 && (g = null), ee[0] & /*value*/
    1 && (v = null), typeof /*message*/
    V[44] == "string" ? 0 : (u == null && (u = /*message*/
    V[44] !== null && Object.prototype.toString.call(
      /*message*/
      V[44]
    ) === "[object Array]"), u ? 1 : (f == null && (f = !!/*message*/
    (V[44] !== null && /*message*/
    ((xe = (fe = V[44].file) == null ? void 0 : fe.mime_type) != null && xe.includes("audio")))), f ? 2 : (g == null && (g = !!/*message*/
    (V[44] !== null && /*message*/
    ((Se = (ve = V[44].file) == null ? void 0 : ve.mime_type) != null && Se.includes("video")))), g ? 3 : (v == null && (v = !!/*message*/
    (V[44] !== null && /*message*/
    ((ft = (Je = V[44].file) == null ? void 0 : Je.mime_type) != null && ft.includes("image")))), v ? 4 : (
      /*message*/
      V[44] !== null && /*message*/
      ((ct = V[44].file) == null ? void 0 : ct.url) !== null ? 5 : -1
    )))));
  }
  ~(y = O(s, [-1, -1])) && (D = N[y] = F[y](s));
  function R() {
    return (
      /*click_handler*/
      s[35](
        /*i*/
        s[43],
        /*j*/
        s[46],
        /*message*/
        s[44]
      )
    );
  }
  function U(...V) {
    return (
      /*keydown_handler*/
      s[36](
        /*i*/
        s[43],
        /*j*/
        s[46],
        /*message*/
        s[44],
        ...V
      )
    );
  }
  let J = (
    /*likeable*/
    (s[4] && /*j*/
    s[46] !== 0 || /*show_copy_button*/
    s[7] && /*message*/
    s[44] && typeof /*message*/
    s[44] == "string") && Lo(s)
  );
  return {
    c() {
      var V, ee, fe;
      t = Xt("div"), z && z.c(), n = tr(), i = Xt("div"), o = Xt("button"), D && D.c(), G = tr(), J && J.c(), Ae(
        o,
        "data-testid",
        /*j*/
        s[46] == 0 ? "user" : "bot"
      ), Ae(o, "dir", B = /*rtl*/
      s[6] ? "rtl" : "ltr"), Ae(o, "aria-label", q = /*j*/
      (s[46] == 0 ? "user" : "bot") + "'s message: " + (typeof /*message*/
      s[44] == "string" ? (
        /*message*/
        s[44]
      ) : `a file of type ${/*message*/
      (V = s[44].file) == null ? void 0 : V.mime_type}, ${/*message*/
      ((ee = s[44].file) == null ? void 0 : ee.alt_text) ?? /*message*/
      ((fe = s[44].file) == null ? void 0 : fe.orig_name) ?? ""}`)), Ae(o, "class", "svelte-10ymup0"), rt(
        o,
        "latest",
        /*i*/
        s[43] === /*value*/
        s[0].length - 1
      ), rt(o, "message-markdown-disabled", !/*render_markdown*/
      s[11]), rt(
        o,
        "selectable",
        /*selectable*/
        s[3]
      ), Gr(o, "user-select", "text"), Gr(
        o,
        "text-align",
        /*rtl*/
        s[6] ? "right" : "left"
      ), Ae(i, "class", "message " + /*j*/
      (s[46] == 0 ? "user" : "bot") + " svelte-10ymup0"), rt(
        i,
        "message-fit",
        /*layout*/
        s[14] === "bubble" && !/*bubble_full_width*/
        s[10]
      ), rt(
        i,
        "panel-full-width",
        /*layout*/
        s[14] === "panel"
      ), rt(
        i,
        "message-bubble-border",
        /*layout*/
        s[14] === "bubble"
      ), rt(i, "message-markdown-disabled", !/*render_markdown*/
      s[11]), Gr(
        i,
        "text-align",
        /*rtl*/
        s[6] && /*j*/
        s[46] == 0 ? "left" : "right"
      ), Ae(t, "class", K = "message-row " + /*layout*/
      s[14] + " " + /*j*/
      (s[46] == 0 ? "user-row" : "bot-row") + " svelte-10ymup0");
    },
    m(V, ee) {
      ut(V, t, ee), z && z.m(t, null), w0(t, n), w0(t, i), w0(i, o), ~y && N[y].m(o, null), w0(t, G), J && J.m(t, null), $ = !0, X || (M = [
        So(o, "click", R),
        So(o, "keydown", U)
      ], X = !0);
    },
    p(V, ee) {
      var xe, ve, Se;
      s = V, /*avatar_images*/
      s[8][
        /*j*/
        s[46]
      ] !== null ? z ? (z.p(s, ee), ee[0] & /*avatar_images*/
      256 && pe(z, 1)) : (z = No(s), z.c(), pe(z, 1), z.m(t, n)) : z && (Mt(), ke(z, 1, 1, () => {
        z = null;
      }), Bt());
      let fe = y;
      y = O(s, ee), y === fe ? ~y && N[y].p(s, ee) : (D && (Mt(), ke(N[fe], 1, 1, () => {
        N[fe] = null;
      }), Bt()), ~y ? (D = N[y], D ? D.p(s, ee) : (D = N[y] = F[y](s), D.c()), pe(D, 1), D.m(o, null)) : D = null), (!$ || ee[0] & /*rtl*/
      64 && B !== (B = /*rtl*/
      s[6] ? "rtl" : "ltr")) && Ae(o, "dir", B), (!$ || ee[0] & /*value*/
      1 && q !== (q = /*j*/
      (s[46] == 0 ? "user" : "bot") + "'s message: " + (typeof /*message*/
      s[44] == "string" ? (
        /*message*/
        s[44]
      ) : `a file of type ${/*message*/
      (xe = s[44].file) == null ? void 0 : xe.mime_type}, ${/*message*/
      ((ve = s[44].file) == null ? void 0 : ve.alt_text) ?? /*message*/
      ((Se = s[44].file) == null ? void 0 : Se.orig_name) ?? ""}`))) && Ae(o, "aria-label", q), (!$ || ee[0] & /*value*/
      1) && rt(
        o,
        "latest",
        /*i*/
        s[43] === /*value*/
        s[0].length - 1
      ), (!$ || ee[0] & /*render_markdown*/
      2048) && rt(o, "message-markdown-disabled", !/*render_markdown*/
      s[11]), (!$ || ee[0] & /*selectable*/
      8) && rt(
        o,
        "selectable",
        /*selectable*/
        s[3]
      ), ee[0] & /*rtl*/
      64 && Gr(
        o,
        "text-align",
        /*rtl*/
        s[6] ? "right" : "left"
      ), (!$ || ee[0] & /*layout, bubble_full_width*/
      17408) && rt(
        i,
        "message-fit",
        /*layout*/
        s[14] === "bubble" && !/*bubble_full_width*/
        s[10]
      ), (!$ || ee[0] & /*layout*/
      16384) && rt(
        i,
        "panel-full-width",
        /*layout*/
        s[14] === "panel"
      ), (!$ || ee[0] & /*layout*/
      16384) && rt(
        i,
        "message-bubble-border",
        /*layout*/
        s[14] === "bubble"
      ), (!$ || ee[0] & /*render_markdown*/
      2048) && rt(i, "message-markdown-disabled", !/*render_markdown*/
      s[11]), ee[0] & /*rtl*/
      64 && Gr(
        i,
        "text-align",
        /*rtl*/
        s[6] && /*j*/
        s[46] == 0 ? "left" : "right"
      ), /*likeable*/
      s[4] && /*j*/
      s[46] !== 0 || /*show_copy_button*/
      s[7] && /*message*/
      s[44] && typeof /*message*/
      s[44] == "string" ? J ? (J.p(s, ee), ee[0] & /*likeable, show_copy_button, value*/
      145 && pe(J, 1)) : (J = Lo(s), J.c(), pe(J, 1), J.m(t, null)) : J && (Mt(), ke(J, 1, 1, () => {
        J = null;
      }), Bt()), (!$ || ee[0] & /*layout*/
      16384 && K !== (K = "message-row " + /*layout*/
      s[14] + " " + /*j*/
      (s[46] == 0 ? "user-row" : "bot-row") + " svelte-10ymup0")) && Ae(t, "class", K);
    },
    i(V) {
      $ || (pe(z), pe(D), pe(J), $ = !0);
    },
    o(V) {
      ke(z), ke(D), ke(J), $ = !1;
    },
    d(V) {
      V && ot(t), z && z.d(), ~y && N[y].d(), J && J.d(), X = !1, md(M);
    }
  };
}
function No(s) {
  var o;
  let t, n, i;
  return n = new bi({
    props: {
      class: "avatar-image",
      src: (
        /*avatar_images*/
        (o = s[8][
          /*j*/
          s[46]
        ]) == null ? void 0 : o.url
      ),
      alt: (
        /*j*/
        (s[46] == 0 ? "user" : "bot") + " avatar"
      )
    }
  }), {
    c() {
      t = Xt("div"), Nt(n.$$.fragment), Ae(t, "class", "avatar-container svelte-10ymup0");
    },
    m(u, f) {
      ut(u, t, f), Lt(n, t, null), i = !0;
    },
    p(u, f) {
      var v;
      const g = {};
      f[0] & /*avatar_images*/
      256 && (g.src = /*avatar_images*/
      (v = u[8][
        /*j*/
        u[46]
      ]) == null ? void 0 : v.url), n.$set(g);
    },
    i(u) {
      i || (pe(n.$$.fragment, u), i = !0);
    },
    o(u) {
      ke(n.$$.fragment, u), i = !1;
    },
    d(u) {
      u && ot(t), Rt(n);
    }
  };
}
function bd(s) {
  var f, g;
  let t, n = (
    /*message*/
    (((f = s[44].file) == null ? void 0 : f.orig_name) || /*message*/
    ((g = s[44].file) == null ? void 0 : g.path)) + ""
  ), i, o, u;
  return {
    c() {
      var v, y, D;
      t = Xt("a"), i = Ou(n), Ae(t, "data-testid", "chatbot-file"), Ae(t, "href", o = /*message*/
      (v = s[44].file) == null ? void 0 : v.url), Ae(t, "target", "_blank"), Ae(t, "download", u = window.__is_colab__ ? null : (
        /*message*/
        ((y = s[44].file) == null ? void 0 : y.orig_name) || /*message*/
        ((D = s[44].file) == null ? void 0 : D.path)
      )), Ae(t, "class", "svelte-10ymup0");
    },
    m(v, y) {
      ut(v, t, y), w0(t, i);
    },
    p(v, y) {
      var D, B, q, G, K;
      y[0] & /*value*/
      1 && n !== (n = /*message*/
      (((D = v[44].file) == null ? void 0 : D.orig_name) || /*message*/
      ((B = v[44].file) == null ? void 0 : B.path)) + "") && Iu(i, n), y[0] & /*value*/
      1 && o !== (o = /*message*/
      (q = v[44].file) == null ? void 0 : q.url) && Ae(t, "href", o), y[0] & /*value*/
      1 && u !== (u = window.__is_colab__ ? null : (
        /*message*/
        ((G = v[44].file) == null ? void 0 : G.orig_name) || /*message*/
        ((K = v[44].file) == null ? void 0 : K.path)
      )) && Ae(t, "download", u);
    },
    i: Dr,
    o: Dr,
    d(v) {
      v && ot(t);
    }
  };
}
function yd(s) {
  var i;
  let t, n;
  return t = new bi({
    props: {
      "data-testid": "chatbot-image",
      src: (
        /*message*/
        (i = s[44].file) == null ? void 0 : i.url
      ),
      alt: (
        /*message*/
        s[44].alt_text
      )
    }
  }), {
    c() {
      Nt(t.$$.fragment);
    },
    m(o, u) {
      Lt(t, o, u), n = !0;
    },
    p(o, u) {
      var g;
      const f = {};
      u[0] & /*value*/
      1 && (f.src = /*message*/
      (g = o[44].file) == null ? void 0 : g.url), u[0] & /*value*/
      1 && (f.alt = /*message*/
      o[44].alt_text), t.$set(f);
    },
    i(o) {
      n || (pe(t.$$.fragment, o), n = !0);
    },
    o(o) {
      ke(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Rt(t, o);
    }
  };
}
function wd(s) {
  var i;
  let t, n;
  return t = new tu({
    props: {
      "data-testid": "chatbot-video",
      controls: !0,
      src: (
        /*message*/
        (i = s[44].file) == null ? void 0 : i.url
      ),
      title: (
        /*message*/
        s[44].alt_text
      ),
      preload: "auto",
      $$slots: { default: [Ad] },
      $$scope: { ctx: s }
    }
  }), t.$on(
    "play",
    /*play_handler_3*/
    s[32]
  ), t.$on(
    "pause",
    /*pause_handler_3*/
    s[33]
  ), t.$on(
    "ended",
    /*ended_handler_3*/
    s[34]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(o, u) {
      Lt(t, o, u), n = !0;
    },
    p(o, u) {
      var g;
      const f = {};
      u[0] & /*value*/
      1 && (f.src = /*message*/
      (g = o[44].file) == null ? void 0 : g.url), u[0] & /*value*/
      1 && (f.title = /*message*/
      o[44].alt_text), u[1] & /*$$scope*/
      524288 && (f.$$scope = { dirty: u, ctx: o }), t.$set(f);
    },
    i(o) {
      n || (pe(t.$$.fragment, o), n = !0);
    },
    o(o) {
      ke(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Rt(t, o);
    }
  };
}
function _d(s) {
  var i;
  let t, n;
  return t = new eu({
    props: {
      "data-testid": "chatbot-audio",
      controls: !0,
      preload: "metadata",
      src: (
        /*message*/
        (i = s[44].file) == null ? void 0 : i.url
      ),
      title: (
        /*message*/
        s[44].alt_text
      )
    }
  }), t.$on(
    "play",
    /*play_handler_2*/
    s[29]
  ), t.$on(
    "pause",
    /*pause_handler_2*/
    s[30]
  ), t.$on(
    "ended",
    /*ended_handler_2*/
    s[31]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(o, u) {
      Lt(t, o, u), n = !0;
    },
    p(o, u) {
      var g;
      const f = {};
      u[0] & /*value*/
      1 && (f.src = /*message*/
      (g = o[44].file) == null ? void 0 : g.url), u[0] & /*value*/
      1 && (f.title = /*message*/
      o[44].alt_text), t.$set(f);
    },
    i(o) {
      n || (pe(t.$$.fragment, o), n = !0);
    },
    o(o) {
      ke(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Rt(t, o);
    }
  };
}
function kd(s) {
  let t, n, i = kr(
    /*message*/
    s[44]
  ), o = [];
  for (let f = 0; f < i.length; f += 1)
    o[f] = Ro(To(s, i, f));
  const u = (f) => ke(o[f], 1, 1, () => {
    o[f] = null;
  });
  return {
    c() {
      for (let f = 0; f < o.length; f += 1)
        o[f].c();
      t = Zr();
    },
    m(f, g) {
      for (let v = 0; v < o.length; v += 1)
        o[v] && o[v].m(f, g);
      ut(f, t, g), n = !0;
    },
    p(f, g) {
      if (g[0] & /*value, latex_delimiters, sanitize_html, render_markdown, line_breaks, scroll*/
      72195) {
        i = kr(
          /*message*/
          f[44]
        );
        let v;
        for (v = 0; v < i.length; v += 1) {
          const y = To(f, i, v);
          o[v] ? (o[v].p(y, g), pe(o[v], 1)) : (o[v] = Ro(y), o[v].c(), pe(o[v], 1), o[v].m(t.parentNode, t));
        }
        for (Mt(), v = i.length; v < o.length; v += 1)
          u(v);
        Bt();
      }
    },
    i(f) {
      if (!n) {
        for (let g = 0; g < i.length; g += 1)
          pe(o[g]);
        n = !0;
      }
    },
    o(f) {
      o = o.filter(Boolean);
      for (let g = 0; g < o.length; g += 1)
        ke(o[g]);
      n = !1;
    },
    d(f) {
      f && ot(t), Fi(o, f);
    }
  };
}
function Dd(s) {
  let t, n;
  return t = new Eu({
    props: {
      message: (
        /*message*/
        s[44]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        s[1]
      ),
      sanitize_html: (
        /*sanitize_html*/
        s[9]
      ),
      render_markdown: (
        /*render_markdown*/
        s[11]
      ),
      line_breaks: (
        /*line_breaks*/
        s[12]
      )
    }
  }), t.$on(
    "load",
    /*scroll*/
    s[16]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(i, o) {
      Lt(t, i, o), n = !0;
    },
    p(i, o) {
      const u = {};
      o[0] & /*value*/
      1 && (u.message = /*message*/
      i[44]), o[0] & /*latex_delimiters*/
      2 && (u.latex_delimiters = /*latex_delimiters*/
      i[1]), o[0] & /*sanitize_html*/
      512 && (u.sanitize_html = /*sanitize_html*/
      i[9]), o[0] & /*render_markdown*/
      2048 && (u.render_markdown = /*render_markdown*/
      i[11]), o[0] & /*line_breaks*/
      4096 && (u.line_breaks = /*line_breaks*/
      i[12]), t.$set(u);
    },
    i(i) {
      n || (pe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      ke(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Rt(t, i);
    }
  };
}
function Ad(s) {
  let t;
  return {
    c() {
      t = Xt("track"), Ae(t, "kind", "captions"), Ae(t, "class", "svelte-10ymup0");
    },
    m(n, i) {
      ut(n, t, i);
    },
    p: Dr,
    d(n) {
      n && ot(t);
    }
  };
}
function xd(s) {
  var g, v;
  let t, n = (
    /*part*/
    (((g = s[47].file) == null ? void 0 : g.orig_name) || /*part*/
    ((v = s[47].file) == null ? void 0 : v.path)) + ""
  ), i, o, u, f;
  return {
    c() {
      var y, D, B;
      t = Xt("a"), i = Ou(n), o = tr(), Ae(t, "data-testid", "chatbot-file"), Ae(t, "href", u = /*part*/
      (y = s[47].file) == null ? void 0 : y.url), Ae(t, "target", "_blank"), Ae(t, "download", f = window.__is_colab__ ? null : (
        /*part*/
        ((D = s[47].file) == null ? void 0 : D.orig_name) || /*part*/
        ((B = s[47].file) == null ? void 0 : B.path)
      )), Ae(t, "class", "svelte-10ymup0");
    },
    m(y, D) {
      ut(y, t, D), w0(t, i), w0(t, o);
    },
    p(y, D) {
      var B, q, G, K, $;
      D[0] & /*value*/
      1 && n !== (n = /*part*/
      (((B = y[47].file) == null ? void 0 : B.orig_name) || /*part*/
      ((q = y[47].file) == null ? void 0 : q.path)) + "") && Iu(i, n), D[0] & /*value*/
      1 && u !== (u = /*part*/
      (G = y[47].file) == null ? void 0 : G.url) && Ae(t, "href", u), D[0] & /*value*/
      1 && f !== (f = window.__is_colab__ ? null : (
        /*part*/
        ((K = y[47].file) == null ? void 0 : K.orig_name) || /*part*/
        (($ = y[47].file) == null ? void 0 : $.path)
      )) && Ae(t, "download", f);
    },
    i: Dr,
    o: Dr,
    d(y) {
      y && ot(t);
    }
  };
}
function Sd(s) {
  var i;
  let t, n;
  return t = new bi({
    props: {
      "data-testid": "chatbot-image",
      src: (
        /*part*/
        (i = s[47].file) == null ? void 0 : i.url
      ),
      alt: (
        /*part*/
        s[47].alt_text
      )
    }
  }), {
    c() {
      Nt(t.$$.fragment);
    },
    m(o, u) {
      Lt(t, o, u), n = !0;
    },
    p(o, u) {
      var g;
      const f = {};
      u[0] & /*value*/
      1 && (f.src = /*part*/
      (g = o[47].file) == null ? void 0 : g.url), u[0] & /*value*/
      1 && (f.alt = /*part*/
      o[47].alt_text), t.$set(f);
    },
    i(o) {
      n || (pe(t.$$.fragment, o), n = !0);
    },
    o(o) {
      ke(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Rt(t, o);
    }
  };
}
function Ed(s) {
  var i;
  let t, n;
  return t = new tu({
    props: {
      "data-testid": "chatbot-video-" + /*k*/
      s[49],
      controls: !0,
      src: (
        /*part*/
        (i = s[47].file) == null ? void 0 : i.url
      ),
      title: (
        /*part*/
        s[47].alt_text
      ),
      preload: "auto",
      $$slots: { default: [Td] },
      $$scope: { ctx: s }
    }
  }), t.$on(
    "play",
    /*play_handler_1*/
    s[26]
  ), t.$on(
    "pause",
    /*pause_handler_1*/
    s[27]
  ), t.$on(
    "ended",
    /*ended_handler_1*/
    s[28]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(o, u) {
      Lt(t, o, u), n = !0;
    },
    p(o, u) {
      var g;
      const f = {};
      u[0] & /*value*/
      1 && (f.src = /*part*/
      (g = o[47].file) == null ? void 0 : g.url), u[0] & /*value*/
      1 && (f.title = /*part*/
      o[47].alt_text), u[1] & /*$$scope*/
      524288 && (f.$$scope = { dirty: u, ctx: o }), t.$set(f);
    },
    i(o) {
      n || (pe(t.$$.fragment, o), n = !0);
    },
    o(o) {
      ke(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Rt(t, o);
    }
  };
}
function Fd(s) {
  var i;
  let t, n;
  return t = new eu({
    props: {
      "data-testid": "chatbot-audio-" + /*k*/
      s[49],
      controls: !0,
      preload: "metadata",
      src: (
        /*part*/
        (i = s[47].file) == null ? void 0 : i.url
      ),
      title: (
        /*part*/
        s[47].alt_text
      )
    }
  }), t.$on(
    "play",
    /*play_handler*/
    s[23]
  ), t.$on(
    "pause",
    /*pause_handler*/
    s[24]
  ), t.$on(
    "ended",
    /*ended_handler*/
    s[25]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(o, u) {
      Lt(t, o, u), n = !0;
    },
    p(o, u) {
      var g;
      const f = {};
      u[0] & /*value*/
      1 && (f.src = /*part*/
      (g = o[47].file) == null ? void 0 : g.url), u[0] & /*value*/
      1 && (f.title = /*part*/
      o[47].alt_text), t.$set(f);
    },
    i(o) {
      n || (pe(t.$$.fragment, o), n = !0);
    },
    o(o) {
      ke(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Rt(t, o);
    }
  };
}
function Cd(s) {
  let t, n;
  return t = new Eu({
    props: {
      message: (
        /*part*/
        s[47]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        s[1]
      ),
      sanitize_html: (
        /*sanitize_html*/
        s[9]
      ),
      render_markdown: (
        /*render_markdown*/
        s[11]
      ),
      line_breaks: (
        /*line_breaks*/
        s[12]
      )
    }
  }), t.$on(
    "load",
    /*scroll*/
    s[16]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(i, o) {
      Lt(t, i, o), n = !0;
    },
    p(i, o) {
      const u = {};
      o[0] & /*value*/
      1 && (u.message = /*part*/
      i[47]), o[0] & /*latex_delimiters*/
      2 && (u.latex_delimiters = /*latex_delimiters*/
      i[1]), o[0] & /*sanitize_html*/
      512 && (u.sanitize_html = /*sanitize_html*/
      i[9]), o[0] & /*render_markdown*/
      2048 && (u.render_markdown = /*render_markdown*/
      i[11]), o[0] & /*line_breaks*/
      4096 && (u.line_breaks = /*line_breaks*/
      i[12]), t.$set(u);
    },
    i(i) {
      n || (pe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      ke(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Rt(t, i);
    }
  };
}
function Td(s) {
  let t, n;
  return {
    c() {
      t = Xt("track"), n = tr(), Ae(t, "kind", "captions"), Ae(t, "class", "svelte-10ymup0");
    },
    m(i, o) {
      ut(i, t, o), ut(i, n, o);
    },
    p: Dr,
    d(i) {
      i && (ot(t), ot(n));
    }
  };
}
function Ro(s) {
  let t, n, i, o, u, f, g;
  const v = [
    Cd,
    Fd,
    Ed,
    Sd,
    xd
  ], y = [];
  function D(B, q) {
    var G, K, $, X, M, z, F;
    return q[0] & /*value*/
    1 && (t = null), q[0] & /*value*/
    1 && (n = null), q[0] & /*value*/
    1 && (i = null), typeof /*part*/
    B[47] == "string" ? 0 : (t == null && (t = !!/*part*/
    (B[47] !== null && /*part*/
    ((K = (G = B[47].file) == null ? void 0 : G.mime_type) != null && K.includes("audio")))), t ? 1 : (n == null && (n = !!/*part*/
    (B[47] !== null && /*part*/
    ((X = ($ = B[47].file) == null ? void 0 : $.mime_type) != null && X.includes("video")))), n ? 2 : (i == null && (i = !!/*part*/
    (B[47] !== null && /*part*/
    ((z = (M = B[47].file) == null ? void 0 : M.mime_type) != null && z.includes("image")))), i ? 3 : (
      /*part*/
      B[47] !== null && /*part*/
      ((F = B[47].file) == null ? void 0 : F.url) !== null ? 4 : -1
    ))));
  }
  return ~(o = D(s, [-1, -1])) && (u = y[o] = v[o](s)), {
    c() {
      u && u.c(), f = Zr();
    },
    m(B, q) {
      ~o && y[o].m(B, q), ut(B, f, q), g = !0;
    },
    p(B, q) {
      let G = o;
      o = D(B, q), o === G ? ~o && y[o].p(B, q) : (u && (Mt(), ke(y[G], 1, 1, () => {
        y[G] = null;
      }), Bt()), ~o ? (u = y[o], u ? u.p(B, q) : (u = y[o] = v[o](B), u.c()), pe(u, 1), u.m(f.parentNode, f)) : u = null);
    },
    i(B) {
      g || (pe(u), g = !0);
    },
    o(B) {
      ke(u), g = !1;
    },
    d(B) {
      B && ot(f), ~o && y[o].d(B);
    }
  };
}
function Lo(s) {
  let t, n, i, o, u = (
    /*likeable*/
    s[4] && /*j*/
    s[46] == 1 && Io(s)
  ), f = (
    /*show_copy_button*/
    s[7] && /*message*/
    s[44] && typeof /*message*/
    s[44] == "string" && Oo(s)
  );
  return {
    c() {
      t = Xt("div"), u && u.c(), n = tr(), f && f.c(), Ae(t, "class", i = "message-buttons-" + /*j*/
      (s[46] == 0 ? "user" : "bot") + " message-buttons-" + /*layout*/
      s[14] + " " + /*avatar_images*/
      (s[8][
        /*j*/
        s[46]
      ] !== null && "with-avatar") + " svelte-10ymup0"), rt(
        t,
        "message-buttons-fit",
        /*layout*/
        s[14] === "bubble" && !/*bubble_full_width*/
        s[10]
      ), rt(
        t,
        "bubble-buttons-user",
        /*layout*/
        s[14] === "bubble"
      );
    },
    m(g, v) {
      ut(g, t, v), u && u.m(t, null), w0(t, n), f && f.m(t, null), o = !0;
    },
    p(g, v) {
      /*likeable*/
      g[4] && /*j*/
      g[46] == 1 ? u ? (u.p(g, v), v[0] & /*likeable*/
      16 && pe(u, 1)) : (u = Io(g), u.c(), pe(u, 1), u.m(t, n)) : u && (Mt(), ke(u, 1, 1, () => {
        u = null;
      }), Bt()), /*show_copy_button*/
      g[7] && /*message*/
      g[44] && typeof /*message*/
      g[44] == "string" ? f ? (f.p(g, v), v[0] & /*show_copy_button, value*/
      129 && pe(f, 1)) : (f = Oo(g), f.c(), pe(f, 1), f.m(t, null)) : f && (Mt(), ke(f, 1, 1, () => {
        f = null;
      }), Bt()), (!o || v[0] & /*layout, avatar_images*/
      16640 && i !== (i = "message-buttons-" + /*j*/
      (g[46] == 0 ? "user" : "bot") + " message-buttons-" + /*layout*/
      g[14] + " " + /*avatar_images*/
      (g[8][
        /*j*/
        g[46]
      ] !== null && "with-avatar") + " svelte-10ymup0")) && Ae(t, "class", i), (!o || v[0] & /*layout, avatar_images, layout, bubble_full_width*/
      17664) && rt(
        t,
        "message-buttons-fit",
        /*layout*/
        g[14] === "bubble" && !/*bubble_full_width*/
        g[10]
      ), (!o || v[0] & /*layout, avatar_images, layout*/
      16640) && rt(
        t,
        "bubble-buttons-user",
        /*layout*/
        g[14] === "bubble"
      );
    },
    i(g) {
      o || (pe(u), pe(f), o = !0);
    },
    o(g) {
      ke(u), ke(f), o = !1;
    },
    d(g) {
      g && ot(t), u && u.d(), f && f.d();
    }
  };
}
function Io(s) {
  let t, n;
  function i(...o) {
    return (
      /*func*/
      s[37](
        /*i*/
        s[43],
        /*j*/
        s[46],
        /*message*/
        s[44],
        ...o
      )
    );
  }
  return t = new $m({ props: { handle_action: i } }), {
    c() {
      Nt(t.$$.fragment);
    },
    m(o, u) {
      Lt(t, o, u), n = !0;
    },
    p(o, u) {
      s = o;
      const f = {};
      u[0] & /*value*/
      1 && (f.handle_action = i), t.$set(f);
    },
    i(o) {
      n || (pe(t.$$.fragment, o), n = !0);
    },
    o(o) {
      ke(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Rt(t, o);
    }
  };
}
function Oo(s) {
  let t, n;
  return t = new Wm({ props: { value: (
    /*message*/
    s[44]
  ) } }), {
    c() {
      Nt(t.$$.fragment);
    },
    m(i, o) {
      Lt(t, i, o), n = !0;
    },
    p(i, o) {
      const u = {};
      o[0] & /*value*/
      1 && (u.value = /*message*/
      i[44]), t.$set(u);
    },
    i(i) {
      n || (pe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      ke(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Rt(t, i);
    }
  };
}
function qo(s) {
  let t, n, i = (
    /*message*/
    s[44] !== null && zo(s)
  );
  return {
    c() {
      i && i.c(), t = Zr();
    },
    m(o, u) {
      i && i.m(o, u), ut(o, t, u), n = !0;
    },
    p(o, u) {
      /*message*/
      o[44] !== null ? i ? (i.p(o, u), u[0] & /*value*/
      1 && pe(i, 1)) : (i = zo(o), i.c(), pe(i, 1), i.m(t.parentNode, t)) : i && (Mt(), ke(i, 1, 1, () => {
        i = null;
      }), Bt());
    },
    i(o) {
      n || (pe(i), n = !0);
    },
    o(o) {
      ke(i), n = !1;
    },
    d(o) {
      o && ot(t), i && i.d(o);
    }
  };
}
function Po(s) {
  let t, n, i = kr(
    /*message_pair*/
    s[41]
  ), o = [];
  for (let f = 0; f < i.length; f += 1)
    o[f] = qo(Co(s, i, f));
  const u = (f) => ke(o[f], 1, 1, () => {
    o[f] = null;
  });
  return {
    c() {
      for (let f = 0; f < o.length; f += 1)
        o[f].c();
      t = Zr();
    },
    m(f, g) {
      for (let v = 0; v < o.length; v += 1)
        o[v] && o[v].m(f, g);
      ut(f, t, g), n = !0;
    },
    p(f, g) {
      if (g[0] & /*layout, avatar_images, bubble_full_width, value, show_copy_button, handle_like, likeable, render_markdown, rtl, selectable, handle_select, latex_delimiters, sanitize_html, line_breaks, scroll*/
      483291) {
        i = kr(
          /*message_pair*/
          f[41]
        );
        let v;
        for (v = 0; v < i.length; v += 1) {
          const y = Co(f, i, v);
          o[v] ? (o[v].p(y, g), pe(o[v], 1)) : (o[v] = qo(y), o[v].c(), pe(o[v], 1), o[v].m(t.parentNode, t));
        }
        for (Mt(), v = i.length; v < o.length; v += 1)
          u(v);
        Bt();
      }
    },
    i(f) {
      if (!n) {
        for (let g = 0; g < i.length; g += 1)
          pe(o[g]);
        n = !0;
      }
    },
    o(f) {
      o = o.filter(Boolean);
      for (let g = 0; g < o.length; g += 1)
        ke(o[g]);
      n = !1;
    },
    d(f) {
      f && ot(t), Fi(o, f);
    }
  };
}
function Ho(s) {
  let t, n;
  return t = new od({ props: { layout: (
    /*layout*/
    s[14]
  ) } }), {
    c() {
      Nt(t.$$.fragment);
    },
    m(i, o) {
      Lt(t, i, o), n = !0;
    },
    p(i, o) {
      const u = {};
      o[0] & /*layout*/
      16384 && (u.layout = /*layout*/
      i[14]), t.$set(u);
    },
    i(i) {
      n || (pe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      ke(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Rt(t, i);
    }
  };
}
function Bd(s) {
  let t, n, i, o, u, f, g, v = (
    /*show_share_button*/
    s[5] && /*value*/
    s[0] !== null && /*value*/
    s[0].length > 0 && Bo(s)
  ), y = (
    /*value*/
    s[0] !== null && Mo(s)
  );
  return {
    c() {
      v && v.c(), t = tr(), n = Xt("div"), i = Xt("div"), y && y.c(), Ae(i, "class", "message-wrap svelte-10ymup0"), rt(
        i,
        "bubble-gap",
        /*layout*/
        s[14] === "bubble"
      ), Ae(n, "class", o = Eo(
        /*layout*/
        s[14] === "bubble" ? "bubble-wrap" : "panel-wrap"
      ) + " svelte-10ymup0"), Ae(n, "role", "log"), Ae(n, "aria-label", "chatbot conversation"), Ae(n, "aria-live", "polite");
    },
    m(D, B) {
      v && v.m(D, B), ut(D, t, B), ut(D, n, B), w0(n, i), y && y.m(i, null), s[38](n), u = !0, f || (g = cd(mc.call(null, i)), f = !0);
    },
    p(D, B) {
      /*show_share_button*/
      D[5] && /*value*/
      D[0] !== null && /*value*/
      D[0].length > 0 ? v ? (v.p(D, B), B[0] & /*show_share_button, value*/
      33 && pe(v, 1)) : (v = Bo(D), v.c(), pe(v, 1), v.m(t.parentNode, t)) : v && (Mt(), ke(v, 1, 1, () => {
        v = null;
      }), Bt()), /*value*/
      D[0] !== null ? y ? (y.p(D, B), B[0] & /*value*/
      1 && pe(y, 1)) : (y = Mo(D), y.c(), pe(y, 1), y.m(i, null)) : y && (Mt(), ke(y, 1, 1, () => {
        y = null;
      }), Bt()), (!u || B[0] & /*layout*/
      16384) && rt(
        i,
        "bubble-gap",
        /*layout*/
        D[14] === "bubble"
      ), (!u || B[0] & /*layout*/
      16384 && o !== (o = Eo(
        /*layout*/
        D[14] === "bubble" ? "bubble-wrap" : "panel-wrap"
      ) + " svelte-10ymup0")) && Ae(n, "class", o);
    },
    i(D) {
      u || (pe(v), pe(y), u = !0);
    },
    o(D) {
      ke(v), ke(y), u = !1;
    },
    d(D) {
      D && (ot(t), ot(n)), v && v.d(D), y && y.d(), s[38](null), f = !1, g();
    }
  };
}
function Md(s, t, n) {
  let i, { value: o } = t, u = null, { latex_delimiters: f } = t, { pending_message: g = !1 } = t, { selectable: v = !1 } = t, { likeable: y = !1 } = t, { show_share_button: D = !1 } = t, { rtl: B = !1 } = t, { show_copy_button: q = !1 } = t, { avatar_images: G = [null, null] } = t, { sanitize_html: K = !0 } = t, { bubble_full_width: $ = !0 } = t, { render_markdown: X = !0 } = t, { line_breaks: M = !0 } = t, { i18n: z } = t, { layout: F = "bubble" } = t, N, O;
  const R = vd();
  pd(() => {
    O = N && N.offsetHeight + N.scrollTop > N.scrollHeight - 100;
  });
  const U = () => {
    O && N.scrollTo(0, N.scrollHeight);
  };
  gd(() => {
    O && (U(), N.querySelectorAll("img").forEach((ae) => {
      ae.addEventListener("load", () => {
        U();
      });
    }));
  });
  function J(ae, nt, Re) {
    R("select", { index: [ae, nt], value: Re });
  }
  function V(ae, nt, Re, tt) {
    R("like", {
      index: [ae, nt],
      value: Re,
      liked: tt === "like"
    });
  }
  function ee(ae) {
    Dt.call(this, s, ae);
  }
  function fe(ae) {
    Dt.call(this, s, ae);
  }
  function xe(ae) {
    Dt.call(this, s, ae);
  }
  function ve(ae) {
    Dt.call(this, s, ae);
  }
  function Se(ae) {
    Dt.call(this, s, ae);
  }
  function Je(ae) {
    Dt.call(this, s, ae);
  }
  function ft(ae) {
    Dt.call(this, s, ae);
  }
  function ct(ae) {
    Dt.call(this, s, ae);
  }
  function Ne(ae) {
    Dt.call(this, s, ae);
  }
  function Y(ae) {
    Dt.call(this, s, ae);
  }
  function Me(ae) {
    Dt.call(this, s, ae);
  }
  function re(ae) {
    Dt.call(this, s, ae);
  }
  function Ue(ae) {
    Dt.call(this, s, ae);
  }
  function le(ae) {
    Dt.call(this, s, ae);
  }
  const Ke = (ae, nt, Re) => J(ae, nt, Re), yt = (ae, nt, Re, tt) => {
    tt.key === "Enter" && J(ae, nt, Re);
  }, ht = (ae, nt, Re, tt) => V(ae, nt, Re, tt);
  function It(ae) {
    hd[ae ? "unshift" : "push"](() => {
      N = ae, n(15, N);
    });
  }
  return s.$$set = (ae) => {
    "value" in ae && n(0, o = ae.value), "latex_delimiters" in ae && n(1, f = ae.latex_delimiters), "pending_message" in ae && n(2, g = ae.pending_message), "selectable" in ae && n(3, v = ae.selectable), "likeable" in ae && n(4, y = ae.likeable), "show_share_button" in ae && n(5, D = ae.show_share_button), "rtl" in ae && n(6, B = ae.rtl), "show_copy_button" in ae && n(7, q = ae.show_copy_button), "avatar_images" in ae && n(8, G = ae.avatar_images), "sanitize_html" in ae && n(9, K = ae.sanitize_html), "bubble_full_width" in ae && n(10, $ = ae.bubble_full_width), "render_markdown" in ae && n(11, X = ae.render_markdown), "line_breaks" in ae && n(12, M = ae.line_breaks), "i18n" in ae && n(13, z = ae.i18n), "layout" in ae && n(14, F = ae.layout);
  }, s.$$.update = () => {
    s.$$.dirty[0] & /*adjust_text_size*/
    1048576 && i(), s.$$.dirty[0] & /*value, old_value*/
    524289 && (li(o, u) || (n(19, u = o), R("change")));
  }, n(20, i = () => {
    let nt = getComputedStyle(document.body).getPropertyValue("--body-text-size"), Re;
    switch (nt) {
      case "13px":
        Re = 14;
        break;
      case "14px":
        Re = 16;
        break;
      case "16px":
        Re = 20;
        break;
      default:
        Re = 14;
        break;
    }
    document.body.style.setProperty("--chatbot-body-text-size", Re + "px");
  }), [
    o,
    f,
    g,
    v,
    y,
    D,
    B,
    q,
    G,
    K,
    $,
    X,
    M,
    z,
    F,
    N,
    U,
    J,
    V,
    u,
    i,
    ee,
    fe,
    xe,
    ve,
    Se,
    Je,
    ft,
    ct,
    Ne,
    Y,
    Me,
    re,
    Ue,
    le,
    Ke,
    yt,
    ht,
    It
  ];
}
class zd extends ud {
  constructor(t) {
    super(), fd(
      this,
      t,
      Md,
      Bd,
      dd,
      {
        value: 0,
        latex_delimiters: 1,
        pending_message: 2,
        selectable: 3,
        likeable: 4,
        show_share_button: 5,
        rtl: 6,
        show_copy_button: 7,
        avatar_images: 8,
        sanitize_html: 9,
        bubble_full_width: 10,
        render_markdown: 11,
        line_breaks: 12,
        i18n: 13,
        layout: 14
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: Nd,
  append: Rd,
  assign: Ld,
  attr: Id,
  check_outros: Uo,
  create_component: Yn,
  destroy_component: Zn,
  detach: Go,
  element: Od,
  get_spread_object: qd,
  get_spread_update: Pd,
  group_outros: Vo,
  init: Hd,
  insert: Wo,
  mount_component: Kn,
  safe_not_equal: Ud,
  space: jo,
  transition_in: s0,
  transition_out: H0
} = window.__gradio__svelte__internal;
function Xo(s) {
  let t, n;
  const i = [
    {
      autoscroll: (
        /*gradio*/
        s[19].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      s[19].i18n
    ) },
    /*loading_status*/
    s[21],
    {
      show_progress: (
        /*loading_status*/
        s[21].show_progress === "hidden" ? "hidden" : "minimal"
      )
    }
  ];
  let o = {};
  for (let u = 0; u < i.length; u += 1)
    o = Ld(o, i[u]);
  return t = new Mm({ props: o }), {
    c() {
      Yn(t.$$.fragment);
    },
    m(u, f) {
      Kn(t, u, f), n = !0;
    },
    p(u, f) {
      const g = f[0] & /*gradio, loading_status*/
      2621440 ? Pd(i, [
        f[0] & /*gradio*/
        524288 && {
          autoscroll: (
            /*gradio*/
            u[19].autoscroll
          )
        },
        f[0] & /*gradio*/
        524288 && { i18n: (
          /*gradio*/
          u[19].i18n
        ) },
        f[0] & /*loading_status*/
        2097152 && qd(
          /*loading_status*/
          u[21]
        ),
        f[0] & /*loading_status*/
        2097152 && {
          show_progress: (
            /*loading_status*/
            u[21].show_progress === "hidden" ? "hidden" : "minimal"
          )
        }
      ]) : {};
      t.$set(g);
    },
    i(u) {
      n || (s0(t.$$.fragment, u), n = !0);
    },
    o(u) {
      H0(t.$$.fragment, u), n = !1;
    },
    d(u) {
      Zn(t, u);
    }
  };
}
function Yo(s) {
  let t, n;
  return t = new Xc({
    props: {
      show_label: (
        /*show_label*/
        s[7]
      ),
      Icon: g4,
      float: !1,
      label: (
        /*label*/
        s[6] || "Chatbot"
      )
    }
  }), {
    c() {
      Yn(t.$$.fragment);
    },
    m(i, o) {
      Kn(t, i, o), n = !0;
    },
    p(i, o) {
      const u = {};
      o[0] & /*show_label*/
      128 && (u.show_label = /*show_label*/
      i[7]), o[0] & /*label*/
      64 && (u.label = /*label*/
      i[6] || "Chatbot"), t.$set(u);
    },
    i(i) {
      n || (s0(t.$$.fragment, i), n = !0);
    },
    o(i) {
      H0(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Zn(t, i);
    }
  };
}
function Gd(s) {
  var v;
  let t, n, i, o, u, f = (
    /*loading_status*/
    s[21] && Xo(s)
  ), g = (
    /*show_label*/
    s[7] && Yo(s)
  );
  return o = new zd({
    props: {
      i18n: (
        /*gradio*/
        s[19].i18n
      ),
      selectable: (
        /*_selectable*/
        s[8]
      ),
      likeable: (
        /*likeable*/
        s[9]
      ),
      show_share_button: (
        /*show_share_button*/
        s[10]
      ),
      value: (
        /*_value*/
        s[23]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        s[18]
      ),
      render_markdown: (
        /*render_markdown*/
        s[16]
      ),
      pending_message: (
        /*loading_status*/
        ((v = s[21]) == null ? void 0 : v.status) === "pending"
      ),
      rtl: (
        /*rtl*/
        s[11]
      ),
      show_copy_button: (
        /*show_copy_button*/
        s[12]
      ),
      avatar_images: (
        /*avatar_images*/
        s[20]
      ),
      sanitize_html: (
        /*sanitize_html*/
        s[13]
      ),
      bubble_full_width: (
        /*bubble_full_width*/
        s[14]
      ),
      line_breaks: (
        /*line_breaks*/
        s[17]
      ),
      layout: (
        /*layout*/
        s[15]
      )
    }
  }), o.$on(
    "change",
    /*change_handler*/
    s[25]
  ), o.$on(
    "select",
    /*select_handler*/
    s[26]
  ), o.$on(
    "like",
    /*like_handler*/
    s[27]
  ), o.$on(
    "share",
    /*share_handler*/
    s[28]
  ), o.$on(
    "error",
    /*error_handler*/
    s[29]
  ), {
    c() {
      f && f.c(), t = jo(), n = Od("div"), g && g.c(), i = jo(), Yn(o.$$.fragment), Id(n, "class", "wrapper svelte-r8zcdo");
    },
    m(y, D) {
      f && f.m(y, D), Wo(y, t, D), Wo(y, n, D), g && g.m(n, null), Rd(n, i), Kn(o, n, null), u = !0;
    },
    p(y, D) {
      var q;
      /*loading_status*/
      y[21] ? f ? (f.p(y, D), D[0] & /*loading_status*/
      2097152 && s0(f, 1)) : (f = Xo(y), f.c(), s0(f, 1), f.m(t.parentNode, t)) : f && (Vo(), H0(f, 1, 1, () => {
        f = null;
      }), Uo()), /*show_label*/
      y[7] ? g ? (g.p(y, D), D[0] & /*show_label*/
      128 && s0(g, 1)) : (g = Yo(y), g.c(), s0(g, 1), g.m(n, i)) : g && (Vo(), H0(g, 1, 1, () => {
        g = null;
      }), Uo());
      const B = {};
      D[0] & /*gradio*/
      524288 && (B.i18n = /*gradio*/
      y[19].i18n), D[0] & /*_selectable*/
      256 && (B.selectable = /*_selectable*/
      y[8]), D[0] & /*likeable*/
      512 && (B.likeable = /*likeable*/
      y[9]), D[0] & /*show_share_button*/
      1024 && (B.show_share_button = /*show_share_button*/
      y[10]), D[0] & /*_value*/
      8388608 && (B.value = /*_value*/
      y[23]), D[0] & /*latex_delimiters*/
      262144 && (B.latex_delimiters = /*latex_delimiters*/
      y[18]), D[0] & /*render_markdown*/
      65536 && (B.render_markdown = /*render_markdown*/
      y[16]), D[0] & /*loading_status*/
      2097152 && (B.pending_message = /*loading_status*/
      ((q = y[21]) == null ? void 0 : q.status) === "pending"), D[0] & /*rtl*/
      2048 && (B.rtl = /*rtl*/
      y[11]), D[0] & /*show_copy_button*/
      4096 && (B.show_copy_button = /*show_copy_button*/
      y[12]), D[0] & /*avatar_images*/
      1048576 && (B.avatar_images = /*avatar_images*/
      y[20]), D[0] & /*sanitize_html*/
      8192 && (B.sanitize_html = /*sanitize_html*/
      y[13]), D[0] & /*bubble_full_width*/
      16384 && (B.bubble_full_width = /*bubble_full_width*/
      y[14]), D[0] & /*line_breaks*/
      131072 && (B.line_breaks = /*line_breaks*/
      y[17]), D[0] & /*layout*/
      32768 && (B.layout = /*layout*/
      y[15]), o.$set(B);
    },
    i(y) {
      u || (s0(f), s0(g), s0(o.$$.fragment, y), u = !0);
    },
    o(y) {
      H0(f), H0(g), H0(o.$$.fragment, y), u = !1;
    },
    d(y) {
      y && (Go(t), Go(n)), f && f.d(y), g && g.d(), Zn(o);
    }
  };
}
function Vd(s) {
  let t, n;
  return t = new Bc({
    props: {
      elem_id: (
        /*elem_id*/
        s[0]
      ),
      elem_classes: (
        /*elem_classes*/
        s[1]
      ),
      visible: (
        /*visible*/
        s[2]
      ),
      padding: !1,
      scale: (
        /*scale*/
        s[4]
      ),
      min_width: (
        /*min_width*/
        s[5]
      ),
      height: (
        /*height*/
        s[22]
      ),
      allow_overflow: !1,
      $$slots: { default: [Gd] },
      $$scope: { ctx: s }
    }
  }), {
    c() {
      Yn(t.$$.fragment);
    },
    m(i, o) {
      Kn(t, i, o), n = !0;
    },
    p(i, o) {
      const u = {};
      o[0] & /*elem_id*/
      1 && (u.elem_id = /*elem_id*/
      i[0]), o[0] & /*elem_classes*/
      2 && (u.elem_classes = /*elem_classes*/
      i[1]), o[0] & /*visible*/
      4 && (u.visible = /*visible*/
      i[2]), o[0] & /*scale*/
      16 && (u.scale = /*scale*/
      i[4]), o[0] & /*min_width*/
      32 && (u.min_width = /*min_width*/
      i[5]), o[0] & /*height*/
      4194304 && (u.height = /*height*/
      i[22]), o[0] & /*gradio, _selectable, likeable, show_share_button, _value, latex_delimiters, render_markdown, loading_status, rtl, show_copy_button, avatar_images, sanitize_html, bubble_full_width, line_breaks, layout, value, show_label, label*/
      12582856 | o[1] & /*$$scope*/
      2 && (u.$$scope = { dirty: o, ctx: i }), t.$set(u);
    },
    i(i) {
      n || (s0(t.$$.fragment, i), n = !0);
    },
    o(i) {
      H0(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Zn(t, i);
    }
  };
}
function In(s) {
  let t, n = s[0], i = 1;
  for (; i < s.length; ) {
    const o = s[i], u = s[i + 1];
    if (i += 2, (o === "optionalAccess" || o === "optionalCall") && n == null)
      return;
    o === "access" || o === "optionalAccess" ? (t = n, n = u(n)) : (o === "call" || o === "optionalCall") && (n = u((...f) => n.call(t, ...f)), t = void 0);
  }
  return n;
}
function Wd(s, t, n) {
  let { elem_id: i = "" } = t, { elem_classes: o = [] } = t, { visible: u = !0 } = t, { value: f = [] } = t, { scale: g = null } = t, { min_width: v = void 0 } = t, { label: y } = t, { show_label: D = !0 } = t, { root: B } = t, { _selectable: q = !1 } = t, { likeable: G = !1 } = t, { show_share_button: K = !1 } = t, { rtl: $ = !1 } = t, { show_copy_button: X = !1 } = t, { sanitize_html: M = !0 } = t, { bubble_full_width: z = !0 } = t, { layout: F = "bubble" } = t, { render_markdown: N = !0 } = t, { line_breaks: O = !0 } = t, { latex_delimiters: R } = t, { gradio: U } = t, { avatar_images: J = [null, null] } = t, V;
  const ee = (Y) => (Y.replace('src="/file', `src="${B}file`), Y);
  function fe(Y) {
    if (Y === null)
      return Y;
    if (Object.prototype.toString.call(Y) === "[object Object]")
      return {
        file: In([Y, "optionalAccess", (Me) => Me.file]),
        alt_text: In([Y, "optionalAccess", (Me) => Me.alt_text])
      };
    {
      let Me = [];
      for (let re of Y)
        Me.push(typeof re == "string" ? ee(re) : {
          file: In([re, "optionalAccess", (Ue) => Ue.file]),
          alt_text: In([re, "optionalAccess", (Ue) => Ue.alt_text])
        });
      return Me;
    }
  }
  let { loading_status: xe = void 0 } = t, { height: ve = 400 } = t;
  const Se = () => U.dispatch("change", f), Je = (Y) => U.dispatch("select", Y.detail), ft = (Y) => U.dispatch("like", Y.detail), ct = (Y) => U.dispatch("share", Y.detail), Ne = (Y) => U.dispatch("error", Y.detail);
  return s.$$set = (Y) => {
    "elem_id" in Y && n(0, i = Y.elem_id), "elem_classes" in Y && n(1, o = Y.elem_classes), "visible" in Y && n(2, u = Y.visible), "value" in Y && n(3, f = Y.value), "scale" in Y && n(4, g = Y.scale), "min_width" in Y && n(5, v = Y.min_width), "label" in Y && n(6, y = Y.label), "show_label" in Y && n(7, D = Y.show_label), "root" in Y && n(24, B = Y.root), "_selectable" in Y && n(8, q = Y._selectable), "likeable" in Y && n(9, G = Y.likeable), "show_share_button" in Y && n(10, K = Y.show_share_button), "rtl" in Y && n(11, $ = Y.rtl), "show_copy_button" in Y && n(12, X = Y.show_copy_button), "sanitize_html" in Y && n(13, M = Y.sanitize_html), "bubble_full_width" in Y && n(14, z = Y.bubble_full_width), "layout" in Y && n(15, F = Y.layout), "render_markdown" in Y && n(16, N = Y.render_markdown), "line_breaks" in Y && n(17, O = Y.line_breaks), "latex_delimiters" in Y && n(18, R = Y.latex_delimiters), "gradio" in Y && n(19, U = Y.gradio), "avatar_images" in Y && n(20, J = Y.avatar_images), "loading_status" in Y && n(21, xe = Y.loading_status), "height" in Y && n(22, ve = Y.height);
  }, s.$$.update = () => {
    s.$$.dirty[0] & /*value*/
    8 && n(23, V = f ? f.map(([Y, Me]) => [
      typeof Y == "string" ? ee(Y) : fe(Y),
      typeof Me == "string" ? ee(Me) : fe(Me)
    ]) : []);
  }, [
    i,
    o,
    u,
    f,
    g,
    v,
    y,
    D,
    q,
    G,
    K,
    $,
    X,
    M,
    z,
    F,
    N,
    O,
    R,
    U,
    J,
    xe,
    ve,
    V,
    B,
    Se,
    Je,
    ft,
    ct,
    Ne
  ];
}
class Zd extends Nd {
  constructor(t) {
    super(), Hd(
      this,
      t,
      Wd,
      Vd,
      Ud,
      {
        elem_id: 0,
        elem_classes: 1,
        visible: 2,
        value: 3,
        scale: 4,
        min_width: 5,
        label: 6,
        show_label: 7,
        root: 24,
        _selectable: 8,
        likeable: 9,
        show_share_button: 10,
        rtl: 11,
        show_copy_button: 12,
        sanitize_html: 13,
        bubble_full_width: 14,
        layout: 15,
        render_markdown: 16,
        line_breaks: 17,
        latex_delimiters: 18,
        gradio: 19,
        avatar_images: 20,
        loading_status: 21,
        height: 22
      },
      null,
      [-1, -1]
    );
  }
}
export {
  zd as BaseChatBot,
  Zd as default
};
