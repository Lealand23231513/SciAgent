
import gradio as gr
from gradio_mchatbot import MultiModalChatbot
# gr.Chatbot

path = '/home/wjclnx/Pictures/bear.jpeg'
user_msg = [
    {
        "type": "text",
        'text': "xxx"
    },
    {
        "type": "file",
        "filepath": path
    },
    "s",
    {
        "type": "file",
        "filepath": path
    }
]
value = [
    [
        user_msg,
        None
    ]
]
value = [["Hello!", None]]
# value = [[path,None]]
with gr.Blocks() as demo:
    with gr.Row():
        MultiModalChatbot(label="Blank")
        MultiModalChatbot(value=value, label="Populated")  # populated component


if __name__ == "__main__":
    demo.launch()
