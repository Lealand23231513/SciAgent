const {
  SvelteComponent: g,
  append: o,
  attr: c,
  detach: v,
  element: u,
  init: b,
  insert: h,
  noop: m,
  safe_not_equal: p,
  set_style: d,
  src_url_equal: y,
  toggle_class: _
} = window.__gradio__svelte__internal;
function w(s) {
  let e, l, n;
  return {
    c() {
      e = u("div"), l = u("embed"), y(l.src, n = /*pdfUrl*/
      s[2]) || c(l, "src", n), c(l, "type", "application/pdf"), c(l, "width", "100%"), c(l, "height", "100%"), d(e, "justify-content", "center"), d(e, "align-items", "center"), d(e, "display", "flex"), d(e, "flex-direction", "column"), c(e, "class", "svelte-1gecy8w"), _(
        e,
        "table",
        /*type*/
        s[0] === "table"
      ), _(
        e,
        "gallery",
        /*type*/
        s[0] === "gallery"
      ), _(
        e,
        "selected",
        /*selected*/
        s[1]
      );
    },
    m(t, a) {
      h(t, e, a), o(e, l);
    },
    p(t, [a]) {
      a & /*pdfUrl*/
      4 && !y(l.src, n = /*pdfUrl*/
      t[2]) && c(l, "src", n), a & /*type*/
      1 && _(
        e,
        "table",
        /*type*/
        t[0] === "table"
      ), a & /*type*/
      1 && _(
        e,
        "gallery",
        /*type*/
        t[0] === "gallery"
      ), a & /*selected*/
      2 && _(
        e,
        "selected",
        /*selected*/
        t[1]
      );
    },
    i: m,
    o: m,
    d(t) {
      t && v(e);
    }
  };
}
function q(s, e, l) {
  let { value: n } = e, { samples_dir: t } = e, { type: a } = e, { selected: r = !1 } = e, f;
  return s.$$set = (i) => {
    "value" in i && l(3, n = i.value), "samples_dir" in i && l(4, t = i.samples_dir), "type" in i && l(0, a = i.type), "selected" in i && l(1, r = i.selected);
  }, s.$$.update = () => {
    s.$$.dirty & /*samples_dir, value*/
    24 && l(2, f = t + n);
  }, [a, r, f, n, t];
}
class E extends g {
  constructor(e) {
    super(), b(this, e, q, w, p, {
      value: 3,
      samples_dir: 4,
      type: 0,
      selected: 1
    });
  }
}
export {
  E as default
};
