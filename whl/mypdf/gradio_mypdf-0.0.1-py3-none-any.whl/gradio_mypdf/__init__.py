
from .mypdf import PDF

__all__ = ['PDF']
