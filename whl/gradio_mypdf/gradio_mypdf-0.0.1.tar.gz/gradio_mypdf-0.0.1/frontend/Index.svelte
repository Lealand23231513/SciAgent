<script lang="ts">
	import { tick } from "svelte";
	import PdfUploadText from "./PdfUploadText.svelte";
	import type { Gradio } from "@gradio/utils";
	import { Block, BlockLabel } from "@gradio/atoms";
	// import { BaseButton } from "@gradio/button";
	import { File } from "@gradio/icons";
	import { StatusTracker } from "@gradio/statustracker";
	import type { LoadingStatus } from "@gradio/statustracker";
	import type { FileData } from "@gradio/client";
	import { Upload, ModifyUpload } from "@gradio/upload";

	export let elem_id = "";
	export let elem_classes: string[] = [];
	export let visible = true;
	export let value: FileData | null = null;
	export let container = true;
	export let scale: number | null = null;
	export let root: string;
	export let height: number | null = 500;
	export let label: string;
	export let min_width: number | undefined = undefined;
	export let loading_status: LoadingStatus;
	export let gradio: Gradio<{
		change: never;
		upload: never;
	}>;

	async function handle_clear() {
		value = null;
		await tick();
		gradio.dispatch("change");
	}

	async function handle_upload({
		detail,
	}: CustomEvent<FileData>): Promise<void> {
		value = detail;
		await tick();
		gradio.dispatch("change");
		gradio.dispatch("upload");
	}

	$: height = height || 500;

</script>

<Block {visible} {elem_id} {elem_classes} {container} {scale} {min_width}>
	{#if loading_status}
		<StatusTracker
			autoscroll={gradio.autoscroll}
			i18n={gradio.i18n}
			{...loading_status}
		/>
	{/if}
	<BlockLabel
		show_label={label !== null}
		Icon={File}
		float={value === null}
		label={label || "File"}
	/>
	{#if value}
		<ModifyUpload i18n={gradio.i18n} on:clear={handle_clear} absolute />
		<embed src={value.url} type="application/pdf" width="100%" height="{height}px" />
	{:else}
		<Upload
			on:load={handle_upload}
			filetype={"pdf"}
			file_count="single"
			{root}
		>
			<PdfUploadText />
		</Upload>
	{/if}
</Block>
