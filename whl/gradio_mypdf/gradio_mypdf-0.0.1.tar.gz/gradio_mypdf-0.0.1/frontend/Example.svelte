<script lang="ts">
	export let value: string;
	export let samples_dir: string;
	export let type: "gallery" | "table";
	export let selected = false;
	
	let pdfUrl;

	
	$: pdfUrl = samples_dir + value
</script>

<div
	class:table={type === "table"}
	class:gallery={type === "gallery"}
	class:selected
	style="justify-content: center; align-items: center; display: flex; flex-direction: column;"
>
	<embed src={pdfUrl} type="application/pdf" width="100%" height="100%" />
</div>

<style>
	.gallery {
		padding: var(--size-1) var(--size-2);
	}
</style>
