
import gradio as gr
# from gradio_mypdf import mypdf
from backend.gradio_mypdf import mypdf

def fn(pdf):
    gr.Info('hi there!')

def get_timestamp():
    return "timestamp"

with gr.Blocks() as demo:
    pdf = mypdf(value=None, label="Static", height=1000)
    timeStampDisp = gr.Textbox(label='时间戳', value=get_timestamp, every=1, visible=False)
    pdf.upload(
        fn,
        pdf
    )

if __name__ == "__main__":
    demo.launch()
