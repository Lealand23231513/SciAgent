const {
  SvelteComponent: Ts,
  append: un,
  attr: ve,
  detach: Bs,
  init: As,
  insert: ks,
  noop: fn,
  safe_not_equal: Hs,
  set_style: Ae,
  svg_element: Lt
} = window.__gradio__svelte__internal;
function Ps(e) {
  let t, n, r, i;
  return {
    c() {
      t = Lt("svg"), n = Lt("g"), r = Lt("path"), i = Lt("path"), ve(r, "d", "M18,6L6.087,17.913"), Ae(r, "fill", "none"), Ae(r, "fill-rule", "nonzero"), Ae(r, "stroke-width", "2px"), ve(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), ve(i, "d", "M4.364,4.364L19.636,19.636"), Ae(i, "fill", "none"), Ae(i, "fill-rule", "nonzero"), Ae(i, "stroke-width", "2px"), ve(t, "width", "100%"), ve(t, "height", "100%"), ve(t, "viewBox", "0 0 24 24"), ve(t, "version", "1.1"), ve(t, "xmlns", "http://www.w3.org/2000/svg"), ve(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), ve(t, "xml:space", "preserve"), ve(t, "stroke", "currentColor"), Ae(t, "fill-rule", "evenodd"), Ae(t, "clip-rule", "evenodd"), Ae(t, "stroke-linecap", "round"), Ae(t, "stroke-linejoin", "round");
    },
    m(s, l) {
      ks(s, t, l), un(t, n), un(n, r), un(t, i);
    },
    p: fn,
    i: fn,
    o: fn,
    d(s) {
      s && Bs(t);
    }
  };
}
class Ns extends Ts {
  constructor(t) {
    super(), As(this, t, null, Ps, Hs, {});
  }
}
const {
  SvelteComponent: Cs,
  append: Is,
  attr: nt,
  detach: Os,
  init: Ls,
  insert: Ms,
  noop: cn,
  safe_not_equal: Rs,
  svg_element: fr
} = window.__gradio__svelte__internal;
function Ds(e) {
  let t, n;
  return {
    c() {
      t = fr("svg"), n = fr("path"), nt(n, "fill", "currentColor"), nt(n, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), nt(t, "xmlns", "http://www.w3.org/2000/svg"), nt(t, "width", "100%"), nt(t, "height", "100%"), nt(t, "viewBox", "0 0 32 32");
    },
    m(r, i) {
      Ms(r, t, i), Is(t, n);
    },
    p: cn,
    i: cn,
    o: cn,
    d(r) {
      r && Os(t);
    }
  };
}
class xs extends Cs {
  constructor(t) {
    super(), Ls(this, t, null, Ds, Rs, {});
  }
}
const {
  SvelteComponent: Us,
  append: Fs,
  attr: we,
  detach: Gs,
  init: js,
  insert: qs,
  noop: hn,
  safe_not_equal: Vs,
  svg_element: cr
} = window.__gradio__svelte__internal;
function zs(e) {
  let t, n;
  return {
    c() {
      t = cr("svg"), n = cr("path"), we(n, "d", "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"), we(t, "xmlns", "http://www.w3.org/2000/svg"), we(t, "width", "100%"), we(t, "height", "100%"), we(t, "viewBox", "0 0 24 24"), we(t, "fill", "none"), we(t, "stroke", "currentColor"), we(t, "stroke-width", "1.5"), we(t, "stroke-linecap", "round"), we(t, "stroke-linejoin", "round"), we(t, "class", "feather feather-edit-2");
    },
    m(r, i) {
      qs(r, t, i), Fs(t, n);
    },
    p: hn,
    i: hn,
    o: hn,
    d(r) {
      r && Gs(t);
    }
  };
}
class Xs extends Us {
  constructor(t) {
    super(), js(this, t, null, zs, Vs, {});
  }
}
const {
  SvelteComponent: Ws,
  append: hr,
  attr: _e,
  detach: Zs,
  init: Js,
  insert: Qs,
  noop: _n,
  safe_not_equal: Ys,
  svg_element: dn
} = window.__gradio__svelte__internal;
function Ks(e) {
  let t, n, r;
  return {
    c() {
      t = dn("svg"), n = dn("path"), r = dn("polyline"), _e(n, "d", "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"), _e(r, "points", "13 2 13 9 20 9"), _e(t, "xmlns", "http://www.w3.org/2000/svg"), _e(t, "width", "100%"), _e(t, "height", "100%"), _e(t, "viewBox", "0 0 24 24"), _e(t, "fill", "none"), _e(t, "stroke", "currentColor"), _e(t, "stroke-width", "1.5"), _e(t, "stroke-linecap", "round"), _e(t, "stroke-linejoin", "round"), _e(t, "class", "feather feather-file");
    },
    m(i, s) {
      Qs(i, t, s), hr(t, n), hr(t, r);
    },
    p: _n,
    i: _n,
    o: _n,
    d(i) {
      i && Zs(t);
    }
  };
}
let $s = class extends Ws {
  constructor(t) {
    super(), Js(this, t, null, Ks, Ys, {});
  }
};
const {
  SvelteComponent: eo,
  append: _r,
  attr: de,
  detach: to,
  init: no,
  insert: ro,
  noop: mn,
  safe_not_equal: io,
  svg_element: pn
} = window.__gradio__svelte__internal;
function so(e) {
  let t, n, r;
  return {
    c() {
      t = pn("svg"), n = pn("polyline"), r = pn("path"), de(n, "points", "1 4 1 10 7 10"), de(r, "d", "M3.51 15a9 9 0 1 0 2.13-9.36L1 10"), de(t, "xmlns", "http://www.w3.org/2000/svg"), de(t, "width", "100%"), de(t, "height", "100%"), de(t, "viewBox", "0 0 24 24"), de(t, "fill", "none"), de(t, "stroke", "currentColor"), de(t, "stroke-width", "2"), de(t, "stroke-linecap", "round"), de(t, "stroke-linejoin", "round"), de(t, "class", "feather feather-rotate-ccw");
    },
    m(i, s) {
      ro(i, t, s), _r(t, n), _r(t, r);
    },
    p: mn,
    i: mn,
    o: mn,
    d(i) {
      i && to(t);
    }
  };
}
class oo extends eo {
  constructor(t) {
    super(), no(this, t, null, so, io, {});
  }
}
const {
  SvelteComponent: lo,
  append: gn,
  attr: J,
  detach: ao,
  init: uo,
  insert: fo,
  noop: bn,
  safe_not_equal: co,
  svg_element: Mt
} = window.__gradio__svelte__internal;
function ho(e) {
  let t, n, r, i;
  return {
    c() {
      t = Mt("svg"), n = Mt("path"), r = Mt("polyline"), i = Mt("line"), J(n, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), J(r, "points", "17 8 12 3 7 8"), J(i, "x1", "12"), J(i, "y1", "3"), J(i, "x2", "12"), J(i, "y2", "15"), J(t, "xmlns", "http://www.w3.org/2000/svg"), J(t, "width", "90%"), J(t, "height", "90%"), J(t, "viewBox", "0 0 24 24"), J(t, "fill", "none"), J(t, "stroke", "currentColor"), J(t, "stroke-width", "2"), J(t, "stroke-linecap", "round"), J(t, "stroke-linejoin", "round"), J(t, "class", "feather feather-upload");
    },
    m(s, l) {
      fo(s, t, l), gn(t, n), gn(t, r), gn(t, i);
    },
    p: bn,
    i: bn,
    o: bn,
    d(s) {
      s && ao(t);
    }
  };
}
let _o = class extends lo {
  constructor(t) {
    super(), uo(this, t, null, ho, co, {});
  }
};
const {
  SvelteComponent: mo,
  append: Rt,
  attr: yn,
  create_component: po,
  destroy_component: go,
  detach: bo,
  element: vn,
  init: yo,
  insert: vo,
  mount_component: wo,
  safe_not_equal: Eo,
  text: dr,
  toggle_class: mr,
  transition_in: So,
  transition_out: To
} = window.__gradio__svelte__internal;
function Bo(e) {
  let t, n, r, i, s, l, a;
  return r = new _o({}), {
    c() {
      t = vn("div"), n = vn("span"), po(r.$$.fragment), i = dr(`
    Drop PDF
    `), s = vn("span"), s.textContent = "- or -", l = dr(`
    Click to Upload`), yn(n, "class", "icon-wrap svelte-kzcjhc"), mr(
        n,
        "hovered",
        /*hovered*/
        e[0]
      ), yn(s, "class", "or svelte-kzcjhc"), yn(t, "class", "wrap svelte-kzcjhc");
    },
    m(o, u) {
      vo(o, t, u), Rt(t, n), wo(r, n, null), Rt(t, i), Rt(t, s), Rt(t, l), a = !0;
    },
    p(o, [u]) {
      (!a || u & /*hovered*/
      1) && mr(
        n,
        "hovered",
        /*hovered*/
        o[0]
      );
    },
    i(o) {
      a || (So(r.$$.fragment, o), a = !0);
    },
    o(o) {
      To(r.$$.fragment, o), a = !1;
    },
    d(o) {
      o && bo(t), go(r);
    }
  };
}
function Ao(e, t, n) {
  let { hovered: r = !1 } = t;
  return e.$$set = (i) => {
    "hovered" in i && n(0, r = i.hovered);
  }, [r];
}
class ko extends mo {
  constructor(t) {
    super(), yo(this, t, Ao, Bo, Eo, { hovered: 0 });
  }
}
const {
  SvelteComponent: Ho,
  assign: Po,
  create_slot: No,
  detach: Co,
  element: Io,
  get_all_dirty_from_scope: Oo,
  get_slot_changes: Lo,
  get_spread_update: Mo,
  init: Ro,
  insert: Do,
  safe_not_equal: xo,
  set_dynamic_element_data: pr,
  set_style: ue,
  toggle_class: Le,
  transition_in: Si,
  transition_out: Ti,
  update_slot_base: Uo
} = window.__gradio__svelte__internal;
function Fo(e) {
  let t, n, r;
  const i = (
    /*#slots*/
    e[18].default
  ), s = No(
    i,
    e,
    /*$$scope*/
    e[17],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      e[7]
    ) },
    { id: (
      /*elem_id*/
      e[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      e[3].join(" ") + " svelte-1t38q2d"
    }
  ], a = {};
  for (let o = 0; o < l.length; o += 1)
    a = Po(a, l[o]);
  return {
    c() {
      t = Io(
        /*tag*/
        e[14]
      ), s && s.c(), pr(
        /*tag*/
        e[14]
      )(t, a), Le(
        t,
        "hidden",
        /*visible*/
        e[10] === !1
      ), Le(
        t,
        "padded",
        /*padding*/
        e[6]
      ), Le(
        t,
        "border_focus",
        /*border_mode*/
        e[5] === "focus"
      ), Le(t, "hide-container", !/*explicit_call*/
      e[8] && !/*container*/
      e[9]), ue(
        t,
        "height",
        /*get_dimension*/
        e[15](
          /*height*/
          e[0]
        )
      ), ue(t, "width", typeof /*width*/
      e[1] == "number" ? `calc(min(${/*width*/
      e[1]}px, 100%))` : (
        /*get_dimension*/
        e[15](
          /*width*/
          e[1]
        )
      )), ue(
        t,
        "border-style",
        /*variant*/
        e[4]
      ), ue(
        t,
        "overflow",
        /*allow_overflow*/
        e[11] ? "visible" : "hidden"
      ), ue(
        t,
        "flex-grow",
        /*scale*/
        e[12]
      ), ue(t, "min-width", `calc(min(${/*min_width*/
      e[13]}px, 100%))`), ue(t, "border-width", "var(--block-border-width)");
    },
    m(o, u) {
      Do(o, t, u), s && s.m(t, null), r = !0;
    },
    p(o, u) {
      s && s.p && (!r || u & /*$$scope*/
      131072) && Uo(
        s,
        i,
        o,
        /*$$scope*/
        o[17],
        r ? Lo(
          i,
          /*$$scope*/
          o[17],
          u,
          null
        ) : Oo(
          /*$$scope*/
          o[17]
        ),
        null
      ), pr(
        /*tag*/
        o[14]
      )(t, a = Mo(l, [
        (!r || u & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          o[7]
        ) },
        (!r || u & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          o[2]
        ) },
        (!r || u & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        o[3].join(" ") + " svelte-1t38q2d")) && { class: n }
      ])), Le(
        t,
        "hidden",
        /*visible*/
        o[10] === !1
      ), Le(
        t,
        "padded",
        /*padding*/
        o[6]
      ), Le(
        t,
        "border_focus",
        /*border_mode*/
        o[5] === "focus"
      ), Le(t, "hide-container", !/*explicit_call*/
      o[8] && !/*container*/
      o[9]), u & /*height*/
      1 && ue(
        t,
        "height",
        /*get_dimension*/
        o[15](
          /*height*/
          o[0]
        )
      ), u & /*width*/
      2 && ue(t, "width", typeof /*width*/
      o[1] == "number" ? `calc(min(${/*width*/
      o[1]}px, 100%))` : (
        /*get_dimension*/
        o[15](
          /*width*/
          o[1]
        )
      )), u & /*variant*/
      16 && ue(
        t,
        "border-style",
        /*variant*/
        o[4]
      ), u & /*allow_overflow*/
      2048 && ue(
        t,
        "overflow",
        /*allow_overflow*/
        o[11] ? "visible" : "hidden"
      ), u & /*scale*/
      4096 && ue(
        t,
        "flex-grow",
        /*scale*/
        o[12]
      ), u & /*min_width*/
      8192 && ue(t, "min-width", `calc(min(${/*min_width*/
      o[13]}px, 100%))`);
    },
    i(o) {
      r || (Si(s, o), r = !0);
    },
    o(o) {
      Ti(s, o), r = !1;
    },
    d(o) {
      o && Co(t), s && s.d(o);
    }
  };
}
function Go(e) {
  let t, n = (
    /*tag*/
    e[14] && Fo(e)
  );
  return {
    c() {
      n && n.c();
    },
    m(r, i) {
      n && n.m(r, i), t = !0;
    },
    p(r, [i]) {
      /*tag*/
      r[14] && n.p(r, i);
    },
    i(r) {
      t || (Si(n, r), t = !0);
    },
    o(r) {
      Ti(n, r), t = !1;
    },
    d(r) {
      n && n.d(r);
    }
  };
}
function jo(e, t, n) {
  let { $$slots: r = {}, $$scope: i } = t, { height: s = void 0 } = t, { width: l = void 0 } = t, { elem_id: a = "" } = t, { elem_classes: o = [] } = t, { variant: u = "solid" } = t, { border_mode: f = "base" } = t, { padding: h = !0 } = t, { type: c = "normal" } = t, { test_id: _ = void 0 } = t, { explicit_call: m = !1 } = t, { container: y = !0 } = t, { visible: w = !0 } = t, { allow_overflow: p = !0 } = t, { scale: S = null } = t, { min_width: g = 0 } = t, E = c === "fieldset" ? "fieldset" : "div";
  const L = (v) => {
    if (v !== void 0) {
      if (typeof v == "number")
        return v + "px";
      if (typeof v == "string")
        return v;
    }
  };
  return e.$$set = (v) => {
    "height" in v && n(0, s = v.height), "width" in v && n(1, l = v.width), "elem_id" in v && n(2, a = v.elem_id), "elem_classes" in v && n(3, o = v.elem_classes), "variant" in v && n(4, u = v.variant), "border_mode" in v && n(5, f = v.border_mode), "padding" in v && n(6, h = v.padding), "type" in v && n(16, c = v.type), "test_id" in v && n(7, _ = v.test_id), "explicit_call" in v && n(8, m = v.explicit_call), "container" in v && n(9, y = v.container), "visible" in v && n(10, w = v.visible), "allow_overflow" in v && n(11, p = v.allow_overflow), "scale" in v && n(12, S = v.scale), "min_width" in v && n(13, g = v.min_width), "$$scope" in v && n(17, i = v.$$scope);
  }, [
    s,
    l,
    a,
    o,
    u,
    f,
    h,
    _,
    m,
    y,
    w,
    p,
    S,
    g,
    E,
    L,
    c,
    i,
    r
  ];
}
class qo extends Ho {
  constructor(t) {
    super(), Ro(this, t, jo, Go, xo, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: Vo,
  append: wn,
  attr: Dt,
  create_component: zo,
  destroy_component: Xo,
  detach: Wo,
  element: gr,
  init: Zo,
  insert: Jo,
  mount_component: Qo,
  safe_not_equal: Yo,
  set_data: Ko,
  space: $o,
  text: el,
  toggle_class: Me,
  transition_in: tl,
  transition_out: nl
} = window.__gradio__svelte__internal;
function rl(e) {
  let t, n, r, i, s, l;
  return r = new /*Icon*/
  e[1]({}), {
    c() {
      t = gr("label"), n = gr("span"), zo(r.$$.fragment), i = $o(), s = el(
        /*label*/
        e[0]
      ), Dt(n, "class", "svelte-9gxdi0"), Dt(t, "for", ""), Dt(t, "data-testid", "block-label"), Dt(t, "class", "svelte-9gxdi0"), Me(t, "hide", !/*show_label*/
      e[2]), Me(t, "sr-only", !/*show_label*/
      e[2]), Me(
        t,
        "float",
        /*float*/
        e[4]
      ), Me(
        t,
        "hide-label",
        /*disable*/
        e[3]
      );
    },
    m(a, o) {
      Jo(a, t, o), wn(t, n), Qo(r, n, null), wn(t, i), wn(t, s), l = !0;
    },
    p(a, [o]) {
      (!l || o & /*label*/
      1) && Ko(
        s,
        /*label*/
        a[0]
      ), (!l || o & /*show_label*/
      4) && Me(t, "hide", !/*show_label*/
      a[2]), (!l || o & /*show_label*/
      4) && Me(t, "sr-only", !/*show_label*/
      a[2]), (!l || o & /*float*/
      16) && Me(
        t,
        "float",
        /*float*/
        a[4]
      ), (!l || o & /*disable*/
      8) && Me(
        t,
        "hide-label",
        /*disable*/
        a[3]
      );
    },
    i(a) {
      l || (tl(r.$$.fragment, a), l = !0);
    },
    o(a) {
      nl(r.$$.fragment, a), l = !1;
    },
    d(a) {
      a && Wo(t), Xo(r);
    }
  };
}
function il(e, t, n) {
  let { label: r = null } = t, { Icon: i } = t, { show_label: s = !0 } = t, { disable: l = !1 } = t, { float: a = !0 } = t;
  return e.$$set = (o) => {
    "label" in o && n(0, r = o.label), "Icon" in o && n(1, i = o.Icon), "show_label" in o && n(2, s = o.show_label), "disable" in o && n(3, l = o.disable), "float" in o && n(4, a = o.float);
  }, [r, i, s, l, a];
}
class sl extends Vo {
  constructor(t) {
    super(), Zo(this, t, il, rl, Yo, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: ol,
  append: Dn,
  attr: Ce,
  bubble: ll,
  create_component: al,
  destroy_component: ul,
  detach: Bi,
  element: xn,
  init: fl,
  insert: Ai,
  listen: cl,
  mount_component: hl,
  safe_not_equal: _l,
  set_data: dl,
  set_style: xt,
  space: ml,
  text: pl,
  toggle_class: me,
  transition_in: gl,
  transition_out: bl
} = window.__gradio__svelte__internal;
function br(e) {
  let t, n;
  return {
    c() {
      t = xn("span"), n = pl(
        /*label*/
        e[1]
      ), Ce(t, "class", "svelte-lpi64a");
    },
    m(r, i) {
      Ai(r, t, i), Dn(t, n);
    },
    p(r, i) {
      i & /*label*/
      2 && dl(
        n,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && Bi(t);
    }
  };
}
function yl(e) {
  let t, n, r, i, s, l, a, o = (
    /*show_label*/
    e[2] && br(e)
  );
  return i = new /*Icon*/
  e[0]({}), {
    c() {
      t = xn("button"), o && o.c(), n = ml(), r = xn("div"), al(i.$$.fragment), Ce(r, "class", "svelte-lpi64a"), me(
        r,
        "small",
        /*size*/
        e[4] === "small"
      ), me(
        r,
        "large",
        /*size*/
        e[4] === "large"
      ), t.disabled = /*disabled*/
      e[7], Ce(
        t,
        "aria-label",
        /*label*/
        e[1]
      ), Ce(
        t,
        "aria-haspopup",
        /*hasPopup*/
        e[8]
      ), Ce(
        t,
        "title",
        /*label*/
        e[1]
      ), Ce(t, "class", "svelte-lpi64a"), me(
        t,
        "pending",
        /*pending*/
        e[3]
      ), me(
        t,
        "padded",
        /*padded*/
        e[5]
      ), me(
        t,
        "highlight",
        /*highlight*/
        e[6]
      ), me(
        t,
        "transparent",
        /*transparent*/
        e[9]
      ), xt(t, "color", !/*disabled*/
      e[7] && /*_color*/
      e[11] ? (
        /*_color*/
        e[11]
      ) : "var(--block-label-text-color)"), xt(t, "--bg-color", /*disabled*/
      e[7] ? "auto" : (
        /*background*/
        e[10]
      ));
    },
    m(u, f) {
      Ai(u, t, f), o && o.m(t, null), Dn(t, n), Dn(t, r), hl(i, r, null), s = !0, l || (a = cl(
        t,
        "click",
        /*click_handler*/
        e[13]
      ), l = !0);
    },
    p(u, [f]) {
      /*show_label*/
      u[2] ? o ? o.p(u, f) : (o = br(u), o.c(), o.m(t, n)) : o && (o.d(1), o = null), (!s || f & /*size*/
      16) && me(
        r,
        "small",
        /*size*/
        u[4] === "small"
      ), (!s || f & /*size*/
      16) && me(
        r,
        "large",
        /*size*/
        u[4] === "large"
      ), (!s || f & /*disabled*/
      128) && (t.disabled = /*disabled*/
      u[7]), (!s || f & /*label*/
      2) && Ce(
        t,
        "aria-label",
        /*label*/
        u[1]
      ), (!s || f & /*hasPopup*/
      256) && Ce(
        t,
        "aria-haspopup",
        /*hasPopup*/
        u[8]
      ), (!s || f & /*label*/
      2) && Ce(
        t,
        "title",
        /*label*/
        u[1]
      ), (!s || f & /*pending*/
      8) && me(
        t,
        "pending",
        /*pending*/
        u[3]
      ), (!s || f & /*padded*/
      32) && me(
        t,
        "padded",
        /*padded*/
        u[5]
      ), (!s || f & /*highlight*/
      64) && me(
        t,
        "highlight",
        /*highlight*/
        u[6]
      ), (!s || f & /*transparent*/
      512) && me(
        t,
        "transparent",
        /*transparent*/
        u[9]
      ), f & /*disabled, _color*/
      2176 && xt(t, "color", !/*disabled*/
      u[7] && /*_color*/
      u[11] ? (
        /*_color*/
        u[11]
      ) : "var(--block-label-text-color)"), f & /*disabled, background*/
      1152 && xt(t, "--bg-color", /*disabled*/
      u[7] ? "auto" : (
        /*background*/
        u[10]
      ));
    },
    i(u) {
      s || (gl(i.$$.fragment, u), s = !0);
    },
    o(u) {
      bl(i.$$.fragment, u), s = !1;
    },
    d(u) {
      u && Bi(t), o && o.d(), ul(i), l = !1, a();
    }
  };
}
function vl(e, t, n) {
  let r, { Icon: i } = t, { label: s = "" } = t, { show_label: l = !1 } = t, { pending: a = !1 } = t, { size: o = "small" } = t, { padded: u = !0 } = t, { highlight: f = !1 } = t, { disabled: h = !1 } = t, { hasPopup: c = !1 } = t, { color: _ = "var(--block-label-text-color)" } = t, { transparent: m = !1 } = t, { background: y = "var(--background-fill-primary)" } = t;
  function w(p) {
    ll.call(this, e, p);
  }
  return e.$$set = (p) => {
    "Icon" in p && n(0, i = p.Icon), "label" in p && n(1, s = p.label), "show_label" in p && n(2, l = p.show_label), "pending" in p && n(3, a = p.pending), "size" in p && n(4, o = p.size), "padded" in p && n(5, u = p.padded), "highlight" in p && n(6, f = p.highlight), "disabled" in p && n(7, h = p.disabled), "hasPopup" in p && n(8, c = p.hasPopup), "color" in p && n(12, _ = p.color), "transparent" in p && n(9, m = p.transparent), "background" in p && n(10, y = p.background);
  }, e.$$.update = () => {
    e.$$.dirty & /*highlight, color*/
    4160 && n(11, r = f ? "var(--color-accent)" : _);
  }, [
    i,
    s,
    l,
    a,
    o,
    u,
    f,
    h,
    c,
    m,
    y,
    r,
    _,
    w
  ];
}
class Qt extends ol {
  constructor(t) {
    super(), fl(this, t, vl, yl, _l, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const wl = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], yr = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
wl.reduce(
  (e, { color: t, primary: n, secondary: r }) => ({
    ...e,
    [t]: {
      primary: yr[t][n],
      secondary: yr[t][r]
    }
  }),
  {}
);
function st(e) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; e > 1e3 && n < t.length - 1; )
    e /= 1e3, n++;
  let r = t[n];
  return (Number.isInteger(e) ? e : e.toFixed(1)) + r;
}
function Je() {
}
function El(e) {
  return e();
}
function Sl(e) {
  e.forEach(El);
}
function Tl(e) {
  return typeof e == "function";
}
function Bl(e, t) {
  return e != e ? t == t : e !== t || e && typeof e == "object" || typeof e == "function";
}
function Al(e, ...t) {
  if (e == null) {
    for (const r of t)
      r(void 0);
    return Je;
  }
  const n = e.subscribe(...t);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
const ki = typeof window < "u";
let vr = ki ? () => window.performance.now() : () => Date.now(), Hi = ki ? (e) => requestAnimationFrame(e) : Je;
const lt = /* @__PURE__ */ new Set();
function Pi(e) {
  lt.forEach((t) => {
    t.c(e) || (lt.delete(t), t.f());
  }), lt.size !== 0 && Hi(Pi);
}
function kl(e) {
  let t;
  return lt.size === 0 && Hi(Pi), {
    promise: new Promise((n) => {
      lt.add(t = { c: e, f: n });
    }),
    abort() {
      lt.delete(t);
    }
  };
}
const rt = [];
function Hl(e, t) {
  return {
    subscribe: kt(e, t).subscribe
  };
}
function kt(e, t = Je) {
  let n;
  const r = /* @__PURE__ */ new Set();
  function i(a) {
    if (Bl(e, a) && (e = a, n)) {
      const o = !rt.length;
      for (const u of r)
        u[1](), rt.push(u, e);
      if (o) {
        for (let u = 0; u < rt.length; u += 2)
          rt[u][0](rt[u + 1]);
        rt.length = 0;
      }
    }
  }
  function s(a) {
    i(a(e));
  }
  function l(a, o = Je) {
    const u = [a, o];
    return r.add(u), r.size === 1 && (n = t(i, s) || Je), a(e), () => {
      r.delete(u), r.size === 0 && n && (n(), n = null);
    };
  }
  return { set: i, update: s, subscribe: l };
}
function dt(e, t, n) {
  const r = !Array.isArray(e), i = r ? [e] : e;
  if (!i.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const s = t.length < 2;
  return Hl(n, (l, a) => {
    let o = !1;
    const u = [];
    let f = 0, h = Je;
    const c = () => {
      if (f)
        return;
      h();
      const m = t(r ? u[0] : u, l, a);
      s ? l(m) : h = Tl(m) ? m : Je;
    }, _ = i.map(
      (m, y) => Al(
        m,
        (w) => {
          u[y] = w, f &= ~(1 << y), o && c();
        },
        () => {
          f |= 1 << y;
        }
      )
    );
    return o = !0, c(), function() {
      Sl(_), h(), o = !1;
    };
  });
}
function wr(e) {
  return Object.prototype.toString.call(e) === "[object Date]";
}
function Un(e, t, n, r) {
  if (typeof n == "number" || wr(n)) {
    const i = r - n, s = (n - t) / (e.dt || 1 / 60), l = e.opts.stiffness * i, a = e.opts.damping * s, o = (l - a) * e.inv_mass, u = (s + o) * e.dt;
    return Math.abs(u) < e.opts.precision && Math.abs(i) < e.opts.precision ? r : (e.settled = !1, wr(n) ? new Date(n.getTime() + u) : n + u);
  } else {
    if (Array.isArray(n))
      return n.map(
        (i, s) => Un(e, t[s], n[s], r[s])
      );
    if (typeof n == "object") {
      const i = {};
      for (const s in n)
        i[s] = Un(e, t[s], n[s], r[s]);
      return i;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function Er(e, t = {}) {
  const n = kt(e), { stiffness: r = 0.15, damping: i = 0.8, precision: s = 0.01 } = t;
  let l, a, o, u = e, f = e, h = 1, c = 0, _ = !1;
  function m(w, p = {}) {
    f = w;
    const S = o = {};
    return e == null || p.hard || y.stiffness >= 1 && y.damping >= 1 ? (_ = !0, l = vr(), u = w, n.set(e = f), Promise.resolve()) : (p.soft && (c = 1 / ((p.soft === !0 ? 0.5 : +p.soft) * 60), h = 0), a || (l = vr(), _ = !1, a = kl((g) => {
      if (_)
        return _ = !1, a = null, !1;
      h = Math.min(h + c, 1);
      const E = {
        inv_mass: h,
        opts: y,
        settled: !0,
        dt: (g - l) * 60 / 1e3
      }, L = Un(E, u, e, f);
      return l = g, u = e, n.set(e = L), E.settled && (a = null), !E.settled;
    })), new Promise((g) => {
      a.promise.then(() => {
        S === o && g();
      });
    }));
  }
  const y = {
    set: m,
    update: (w, p) => m(w(f, e), p),
    subscribe: n.subscribe,
    stiffness: r,
    damping: i,
    precision: s
  };
  return y;
}
const {
  SvelteComponent: Pl,
  append: Ee,
  attr: C,
  component_subscribe: Sr,
  detach: Nl,
  element: Cl,
  init: Il,
  insert: Ol,
  noop: Tr,
  safe_not_equal: Ll,
  set_style: Ut,
  svg_element: Se,
  toggle_class: Br
} = window.__gradio__svelte__internal, { onMount: Ml } = window.__gradio__svelte__internal;
function Rl(e) {
  let t, n, r, i, s, l, a, o, u, f, h, c;
  return {
    c() {
      t = Cl("div"), n = Se("svg"), r = Se("g"), i = Se("path"), s = Se("path"), l = Se("path"), a = Se("path"), o = Se("g"), u = Se("path"), f = Se("path"), h = Se("path"), c = Se("path"), C(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), C(i, "fill", "#FF7C00"), C(i, "fill-opacity", "0.4"), C(i, "class", "svelte-43sxxs"), C(s, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), C(s, "fill", "#FF7C00"), C(s, "class", "svelte-43sxxs"), C(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), C(l, "fill", "#FF7C00"), C(l, "fill-opacity", "0.4"), C(l, "class", "svelte-43sxxs"), C(a, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), C(a, "fill", "#FF7C00"), C(a, "class", "svelte-43sxxs"), Ut(r, "transform", "translate(" + /*$top*/
      e[1][0] + "px, " + /*$top*/
      e[1][1] + "px)"), C(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), C(u, "fill", "#FF7C00"), C(u, "fill-opacity", "0.4"), C(u, "class", "svelte-43sxxs"), C(f, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), C(f, "fill", "#FF7C00"), C(f, "class", "svelte-43sxxs"), C(h, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), C(h, "fill", "#FF7C00"), C(h, "fill-opacity", "0.4"), C(h, "class", "svelte-43sxxs"), C(c, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), C(c, "fill", "#FF7C00"), C(c, "class", "svelte-43sxxs"), Ut(o, "transform", "translate(" + /*$bottom*/
      e[2][0] + "px, " + /*$bottom*/
      e[2][1] + "px)"), C(n, "viewBox", "-1200 -1200 3000 3000"), C(n, "fill", "none"), C(n, "xmlns", "http://www.w3.org/2000/svg"), C(n, "class", "svelte-43sxxs"), C(t, "class", "svelte-43sxxs"), Br(
        t,
        "margin",
        /*margin*/
        e[0]
      );
    },
    m(_, m) {
      Ol(_, t, m), Ee(t, n), Ee(n, r), Ee(r, i), Ee(r, s), Ee(r, l), Ee(r, a), Ee(n, o), Ee(o, u), Ee(o, f), Ee(o, h), Ee(o, c);
    },
    p(_, [m]) {
      m & /*$top*/
      2 && Ut(r, "transform", "translate(" + /*$top*/
      _[1][0] + "px, " + /*$top*/
      _[1][1] + "px)"), m & /*$bottom*/
      4 && Ut(o, "transform", "translate(" + /*$bottom*/
      _[2][0] + "px, " + /*$bottom*/
      _[2][1] + "px)"), m & /*margin*/
      1 && Br(
        t,
        "margin",
        /*margin*/
        _[0]
      );
    },
    i: Tr,
    o: Tr,
    d(_) {
      _ && Nl(t);
    }
  };
}
function Dl(e, t, n) {
  let r, i, { margin: s = !0 } = t;
  const l = Er([0, 0]);
  Sr(e, l, (c) => n(1, r = c));
  const a = Er([0, 0]);
  Sr(e, a, (c) => n(2, i = c));
  let o;
  async function u() {
    await Promise.all([l.set([125, 140]), a.set([-125, -140])]), await Promise.all([l.set([-125, 140]), a.set([125, -140])]), await Promise.all([l.set([-125, 0]), a.set([125, -0])]), await Promise.all([l.set([125, 0]), a.set([-125, 0])]);
  }
  async function f() {
    await u(), o || f();
  }
  async function h() {
    await Promise.all([l.set([125, 0]), a.set([-125, 0])]), f();
  }
  return Ml(() => (h(), () => o = !0)), e.$$set = (c) => {
    "margin" in c && n(0, s = c.margin);
  }, [s, r, i, l, a];
}
class xl extends Pl {
  constructor(t) {
    super(), Il(this, t, Dl, Rl, Ll, { margin: 0 });
  }
}
const {
  SvelteComponent: Ul,
  append: Ze,
  attr: He,
  binding_callbacks: Ar,
  check_outros: Ni,
  create_component: Fl,
  create_slot: Gl,
  destroy_component: jl,
  destroy_each: Ci,
  detach: B,
  element: Ie,
  empty: mt,
  ensure_array_like: Vt,
  get_all_dirty_from_scope: ql,
  get_slot_changes: Vl,
  group_outros: Ii,
  init: zl,
  insert: A,
  mount_component: Xl,
  noop: Fn,
  safe_not_equal: Wl,
  set_data: ge,
  set_style: Re,
  space: Pe,
  text: q,
  toggle_class: pe,
  transition_in: at,
  transition_out: ut,
  update_slot_base: Zl
} = window.__gradio__svelte__internal, { tick: Jl } = window.__gradio__svelte__internal, { onDestroy: Ql } = window.__gradio__svelte__internal, Yl = (e) => ({}), kr = (e) => ({});
function Hr(e, t, n) {
  const r = e.slice();
  return r[38] = t[n], r[40] = n, r;
}
function Pr(e, t, n) {
  const r = e.slice();
  return r[38] = t[n], r;
}
function Kl(e) {
  let t, n = (
    /*i18n*/
    e[1]("common.error") + ""
  ), r, i, s;
  const l = (
    /*#slots*/
    e[29].error
  ), a = Gl(
    l,
    e,
    /*$$scope*/
    e[28],
    kr
  );
  return {
    c() {
      t = Ie("span"), r = q(n), i = Pe(), a && a.c(), He(t, "class", "error svelte-1yserjw");
    },
    m(o, u) {
      A(o, t, u), Ze(t, r), A(o, i, u), a && a.m(o, u), s = !0;
    },
    p(o, u) {
      (!s || u[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      o[1]("common.error") + "") && ge(r, n), a && a.p && (!s || u[0] & /*$$scope*/
      268435456) && Zl(
        a,
        l,
        o,
        /*$$scope*/
        o[28],
        s ? Vl(
          l,
          /*$$scope*/
          o[28],
          u,
          Yl
        ) : ql(
          /*$$scope*/
          o[28]
        ),
        kr
      );
    },
    i(o) {
      s || (at(a, o), s = !0);
    },
    o(o) {
      ut(a, o), s = !1;
    },
    d(o) {
      o && (B(t), B(i)), a && a.d(o);
    }
  };
}
function $l(e) {
  let t, n, r, i, s, l, a, o, u, f = (
    /*variant*/
    e[8] === "default" && /*show_eta_bar*/
    e[18] && /*show_progress*/
    e[6] === "full" && Nr(e)
  );
  function h(g, E) {
    if (
      /*progress*/
      g[7]
    )
      return na;
    if (
      /*queue_position*/
      g[2] !== null && /*queue_size*/
      g[3] !== void 0 && /*queue_position*/
      g[2] >= 0
    )
      return ta;
    if (
      /*queue_position*/
      g[2] === 0
    )
      return ea;
  }
  let c = h(e), _ = c && c(e), m = (
    /*timer*/
    e[5] && Or(e)
  );
  const y = [oa, sa], w = [];
  function p(g, E) {
    return (
      /*last_progress_level*/
      g[15] != null ? 0 : (
        /*show_progress*/
        g[6] === "full" ? 1 : -1
      )
    );
  }
  ~(s = p(e)) && (l = w[s] = y[s](e));
  let S = !/*timer*/
  e[5] && Fr(e);
  return {
    c() {
      f && f.c(), t = Pe(), n = Ie("div"), _ && _.c(), r = Pe(), m && m.c(), i = Pe(), l && l.c(), a = Pe(), S && S.c(), o = mt(), He(n, "class", "progress-text svelte-1yserjw"), pe(
        n,
        "meta-text-center",
        /*variant*/
        e[8] === "center"
      ), pe(
        n,
        "meta-text",
        /*variant*/
        e[8] === "default"
      );
    },
    m(g, E) {
      f && f.m(g, E), A(g, t, E), A(g, n, E), _ && _.m(n, null), Ze(n, r), m && m.m(n, null), A(g, i, E), ~s && w[s].m(g, E), A(g, a, E), S && S.m(g, E), A(g, o, E), u = !0;
    },
    p(g, E) {
      /*variant*/
      g[8] === "default" && /*show_eta_bar*/
      g[18] && /*show_progress*/
      g[6] === "full" ? f ? f.p(g, E) : (f = Nr(g), f.c(), f.m(t.parentNode, t)) : f && (f.d(1), f = null), c === (c = h(g)) && _ ? _.p(g, E) : (_ && _.d(1), _ = c && c(g), _ && (_.c(), _.m(n, r))), /*timer*/
      g[5] ? m ? m.p(g, E) : (m = Or(g), m.c(), m.m(n, null)) : m && (m.d(1), m = null), (!u || E[0] & /*variant*/
      256) && pe(
        n,
        "meta-text-center",
        /*variant*/
        g[8] === "center"
      ), (!u || E[0] & /*variant*/
      256) && pe(
        n,
        "meta-text",
        /*variant*/
        g[8] === "default"
      );
      let L = s;
      s = p(g), s === L ? ~s && w[s].p(g, E) : (l && (Ii(), ut(w[L], 1, 1, () => {
        w[L] = null;
      }), Ni()), ~s ? (l = w[s], l ? l.p(g, E) : (l = w[s] = y[s](g), l.c()), at(l, 1), l.m(a.parentNode, a)) : l = null), /*timer*/
      g[5] ? S && (S.d(1), S = null) : S ? S.p(g, E) : (S = Fr(g), S.c(), S.m(o.parentNode, o));
    },
    i(g) {
      u || (at(l), u = !0);
    },
    o(g) {
      ut(l), u = !1;
    },
    d(g) {
      g && (B(t), B(n), B(i), B(a), B(o)), f && f.d(g), _ && _.d(), m && m.d(), ~s && w[s].d(g), S && S.d(g);
    }
  };
}
function Nr(e) {
  let t, n = `translateX(${/*eta_level*/
  (e[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = Ie("div"), He(t, "class", "eta-bar svelte-1yserjw"), Re(t, "transform", n);
    },
    m(r, i) {
      A(r, t, i);
    },
    p(r, i) {
      i[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && Re(t, "transform", n);
    },
    d(r) {
      r && B(t);
    }
  };
}
function ea(e) {
  let t;
  return {
    c() {
      t = q("processing |");
    },
    m(n, r) {
      A(n, t, r);
    },
    p: Fn,
    d(n) {
      n && B(t);
    }
  };
}
function ta(e) {
  let t, n = (
    /*queue_position*/
    e[2] + 1 + ""
  ), r, i, s, l;
  return {
    c() {
      t = q("queue: "), r = q(n), i = q("/"), s = q(
        /*queue_size*/
        e[3]
      ), l = q(" |");
    },
    m(a, o) {
      A(a, t, o), A(a, r, o), A(a, i, o), A(a, s, o), A(a, l, o);
    },
    p(a, o) {
      o[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      a[2] + 1 + "") && ge(r, n), o[0] & /*queue_size*/
      8 && ge(
        s,
        /*queue_size*/
        a[3]
      );
    },
    d(a) {
      a && (B(t), B(r), B(i), B(s), B(l));
    }
  };
}
function na(e) {
  let t, n = Vt(
    /*progress*/
    e[7]
  ), r = [];
  for (let i = 0; i < n.length; i += 1)
    r[i] = Ir(Pr(e, n, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      t = mt();
    },
    m(i, s) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(i, s);
      A(i, t, s);
    },
    p(i, s) {
      if (s[0] & /*progress*/
      128) {
        n = Vt(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < n.length; l += 1) {
          const a = Pr(i, n, l);
          r[l] ? r[l].p(a, s) : (r[l] = Ir(a), r[l].c(), r[l].m(t.parentNode, t));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = n.length;
      }
    },
    d(i) {
      i && B(t), Ci(r, i);
    }
  };
}
function Cr(e) {
  let t, n = (
    /*p*/
    e[38].unit + ""
  ), r, i, s = " ", l;
  function a(f, h) {
    return (
      /*p*/
      f[38].length != null ? ia : ra
    );
  }
  let o = a(e), u = o(e);
  return {
    c() {
      u.c(), t = Pe(), r = q(n), i = q(" | "), l = q(s);
    },
    m(f, h) {
      u.m(f, h), A(f, t, h), A(f, r, h), A(f, i, h), A(f, l, h);
    },
    p(f, h) {
      o === (o = a(f)) && u ? u.p(f, h) : (u.d(1), u = o(f), u && (u.c(), u.m(t.parentNode, t))), h[0] & /*progress*/
      128 && n !== (n = /*p*/
      f[38].unit + "") && ge(r, n);
    },
    d(f) {
      f && (B(t), B(r), B(i), B(l)), u.d(f);
    }
  };
}
function ra(e) {
  let t = st(
    /*p*/
    e[38].index || 0
  ) + "", n;
  return {
    c() {
      n = q(t);
    },
    m(r, i) {
      A(r, n, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && t !== (t = st(
        /*p*/
        r[38].index || 0
      ) + "") && ge(n, t);
    },
    d(r) {
      r && B(n);
    }
  };
}
function ia(e) {
  let t = st(
    /*p*/
    e[38].index || 0
  ) + "", n, r, i = st(
    /*p*/
    e[38].length
  ) + "", s;
  return {
    c() {
      n = q(t), r = q("/"), s = q(i);
    },
    m(l, a) {
      A(l, n, a), A(l, r, a), A(l, s, a);
    },
    p(l, a) {
      a[0] & /*progress*/
      128 && t !== (t = st(
        /*p*/
        l[38].index || 0
      ) + "") && ge(n, t), a[0] & /*progress*/
      128 && i !== (i = st(
        /*p*/
        l[38].length
      ) + "") && ge(s, i);
    },
    d(l) {
      l && (B(n), B(r), B(s));
    }
  };
}
function Ir(e) {
  let t, n = (
    /*p*/
    e[38].index != null && Cr(e)
  );
  return {
    c() {
      n && n.c(), t = mt();
    },
    m(r, i) {
      n && n.m(r, i), A(r, t, i);
    },
    p(r, i) {
      /*p*/
      r[38].index != null ? n ? n.p(r, i) : (n = Cr(r), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(r) {
      r && B(t), n && n.d(r);
    }
  };
}
function Or(e) {
  let t, n = (
    /*eta*/
    e[0] ? `/${/*formatted_eta*/
    e[19]}` : ""
  ), r, i;
  return {
    c() {
      t = q(
        /*formatted_timer*/
        e[20]
      ), r = q(n), i = q("s");
    },
    m(s, l) {
      A(s, t, l), A(s, r, l), A(s, i, l);
    },
    p(s, l) {
      l[0] & /*formatted_timer*/
      1048576 && ge(
        t,
        /*formatted_timer*/
        s[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      s[0] ? `/${/*formatted_eta*/
      s[19]}` : "") && ge(r, n);
    },
    d(s) {
      s && (B(t), B(r), B(i));
    }
  };
}
function sa(e) {
  let t, n;
  return t = new xl({
    props: { margin: (
      /*variant*/
      e[8] === "default"
    ) }
  }), {
    c() {
      Fl(t.$$.fragment);
    },
    m(r, i) {
      Xl(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i[0] & /*variant*/
      256 && (s.margin = /*variant*/
      r[8] === "default"), t.$set(s);
    },
    i(r) {
      n || (at(t.$$.fragment, r), n = !0);
    },
    o(r) {
      ut(t.$$.fragment, r), n = !1;
    },
    d(r) {
      jl(t, r);
    }
  };
}
function oa(e) {
  let t, n, r, i, s, l = `${/*last_progress_level*/
  e[15] * 100}%`, a = (
    /*progress*/
    e[7] != null && Lr(e)
  );
  return {
    c() {
      t = Ie("div"), n = Ie("div"), a && a.c(), r = Pe(), i = Ie("div"), s = Ie("div"), He(n, "class", "progress-level-inner svelte-1yserjw"), He(s, "class", "progress-bar svelte-1yserjw"), Re(s, "width", l), He(i, "class", "progress-bar-wrap svelte-1yserjw"), He(t, "class", "progress-level svelte-1yserjw");
    },
    m(o, u) {
      A(o, t, u), Ze(t, n), a && a.m(n, null), Ze(t, r), Ze(t, i), Ze(i, s), e[30](s);
    },
    p(o, u) {
      /*progress*/
      o[7] != null ? a ? a.p(o, u) : (a = Lr(o), a.c(), a.m(n, null)) : a && (a.d(1), a = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      o[15] * 100}%`) && Re(s, "width", l);
    },
    i: Fn,
    o: Fn,
    d(o) {
      o && B(t), a && a.d(), e[30](null);
    }
  };
}
function Lr(e) {
  let t, n = Vt(
    /*progress*/
    e[7]
  ), r = [];
  for (let i = 0; i < n.length; i += 1)
    r[i] = Ur(Hr(e, n, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      t = mt();
    },
    m(i, s) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(i, s);
      A(i, t, s);
    },
    p(i, s) {
      if (s[0] & /*progress_level, progress*/
      16512) {
        n = Vt(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < n.length; l += 1) {
          const a = Hr(i, n, l);
          r[l] ? r[l].p(a, s) : (r[l] = Ur(a), r[l].c(), r[l].m(t.parentNode, t));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = n.length;
      }
    },
    d(i) {
      i && B(t), Ci(r, i);
    }
  };
}
function Mr(e) {
  let t, n, r, i, s = (
    /*i*/
    e[40] !== 0 && la()
  ), l = (
    /*p*/
    e[38].desc != null && Rr(e)
  ), a = (
    /*p*/
    e[38].desc != null && /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null && Dr()
  ), o = (
    /*progress_level*/
    e[14] != null && xr(e)
  );
  return {
    c() {
      s && s.c(), t = Pe(), l && l.c(), n = Pe(), a && a.c(), r = Pe(), o && o.c(), i = mt();
    },
    m(u, f) {
      s && s.m(u, f), A(u, t, f), l && l.m(u, f), A(u, n, f), a && a.m(u, f), A(u, r, f), o && o.m(u, f), A(u, i, f);
    },
    p(u, f) {
      /*p*/
      u[38].desc != null ? l ? l.p(u, f) : (l = Rr(u), l.c(), l.m(n.parentNode, n)) : l && (l.d(1), l = null), /*p*/
      u[38].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[40]
      ] != null ? a || (a = Dr(), a.c(), a.m(r.parentNode, r)) : a && (a.d(1), a = null), /*progress_level*/
      u[14] != null ? o ? o.p(u, f) : (o = xr(u), o.c(), o.m(i.parentNode, i)) : o && (o.d(1), o = null);
    },
    d(u) {
      u && (B(t), B(n), B(r), B(i)), s && s.d(u), l && l.d(u), a && a.d(u), o && o.d(u);
    }
  };
}
function la(e) {
  let t;
  return {
    c() {
      t = q(" /");
    },
    m(n, r) {
      A(n, t, r);
    },
    d(n) {
      n && B(t);
    }
  };
}
function Rr(e) {
  let t = (
    /*p*/
    e[38].desc + ""
  ), n;
  return {
    c() {
      n = q(t);
    },
    m(r, i) {
      A(r, n, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && t !== (t = /*p*/
      r[38].desc + "") && ge(n, t);
    },
    d(r) {
      r && B(n);
    }
  };
}
function Dr(e) {
  let t;
  return {
    c() {
      t = q("-");
    },
    m(n, r) {
      A(n, t, r);
    },
    d(n) {
      n && B(t);
    }
  };
}
function xr(e) {
  let t = (100 * /*progress_level*/
  (e[14][
    /*i*/
    e[40]
  ] || 0)).toFixed(1) + "", n, r;
  return {
    c() {
      n = q(t), r = q("%");
    },
    m(i, s) {
      A(i, n, s), A(i, r, s);
    },
    p(i, s) {
      s[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[40]
      ] || 0)).toFixed(1) + "") && ge(n, t);
    },
    d(i) {
      i && (B(n), B(r));
    }
  };
}
function Ur(e) {
  let t, n = (
    /*p*/
    (e[38].desc != null || /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null) && Mr(e)
  );
  return {
    c() {
      n && n.c(), t = mt();
    },
    m(r, i) {
      n && n.m(r, i), A(r, t, i);
    },
    p(r, i) {
      /*p*/
      r[38].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[40]
      ] != null ? n ? n.p(r, i) : (n = Mr(r), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(r) {
      r && B(t), n && n.d(r);
    }
  };
}
function Fr(e) {
  let t, n;
  return {
    c() {
      t = Ie("p"), n = q(
        /*loading_text*/
        e[9]
      ), He(t, "class", "loading svelte-1yserjw");
    },
    m(r, i) {
      A(r, t, i), Ze(t, n);
    },
    p(r, i) {
      i[0] & /*loading_text*/
      512 && ge(
        n,
        /*loading_text*/
        r[9]
      );
    },
    d(r) {
      r && B(t);
    }
  };
}
function aa(e) {
  let t, n, r, i, s;
  const l = [$l, Kl], a = [];
  function o(u, f) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = o(e)) && (r = a[n] = l[n](e)), {
    c() {
      t = Ie("div"), r && r.c(), He(t, "class", i = "wrap " + /*variant*/
      e[8] + " " + /*show_progress*/
      e[6] + " svelte-1yserjw"), pe(t, "hide", !/*status*/
      e[4] || /*status*/
      e[4] === "complete" || /*show_progress*/
      e[6] === "hidden"), pe(
        t,
        "translucent",
        /*variant*/
        e[8] === "center" && /*status*/
        (e[4] === "pending" || /*status*/
        e[4] === "error") || /*translucent*/
        e[11] || /*show_progress*/
        e[6] === "minimal"
      ), pe(
        t,
        "generating",
        /*status*/
        e[4] === "generating"
      ), pe(
        t,
        "border",
        /*border*/
        e[12]
      ), Re(
        t,
        "position",
        /*absolute*/
        e[10] ? "absolute" : "static"
      ), Re(
        t,
        "padding",
        /*absolute*/
        e[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, f) {
      A(u, t, f), ~n && a[n].m(t, null), e[31](t), s = !0;
    },
    p(u, f) {
      let h = n;
      n = o(u), n === h ? ~n && a[n].p(u, f) : (r && (Ii(), ut(a[h], 1, 1, () => {
        a[h] = null;
      }), Ni()), ~n ? (r = a[n], r ? r.p(u, f) : (r = a[n] = l[n](u), r.c()), at(r, 1), r.m(t, null)) : r = null), (!s || f[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-1yserjw")) && He(t, "class", i), (!s || f[0] & /*variant, show_progress, status, show_progress*/
      336) && pe(t, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden"), (!s || f[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && pe(
        t,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!s || f[0] & /*variant, show_progress, status*/
      336) && pe(
        t,
        "generating",
        /*status*/
        u[4] === "generating"
      ), (!s || f[0] & /*variant, show_progress, border*/
      4416) && pe(
        t,
        "border",
        /*border*/
        u[12]
      ), f[0] & /*absolute*/
      1024 && Re(
        t,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), f[0] & /*absolute*/
      1024 && Re(
        t,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      s || (at(r), s = !0);
    },
    o(u) {
      ut(r), s = !1;
    },
    d(u) {
      u && B(t), ~n && a[n].d(), e[31](null);
    }
  };
}
let Ft = [], En = !1;
async function ua(e, t = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
    if (Ft.push(e), !En)
      En = !0;
    else
      return;
    await Jl(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let r = 0; r < Ft.length; r++) {
        const s = Ft[r].getBoundingClientRect();
        (r === 0 || s.top + window.scrollY <= n[0]) && (n[0] = s.top + window.scrollY, n[1] = r);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), En = !1, Ft = [];
    });
  }
}
function fa(e, t, n) {
  let r, { $$slots: i = {}, $$scope: s } = t, { i18n: l } = t, { eta: a = null } = t, { queue_position: o } = t, { queue_size: u } = t, { status: f } = t, { scroll_to_output: h = !1 } = t, { timer: c = !0 } = t, { show_progress: _ = "full" } = t, { message: m = null } = t, { progress: y = null } = t, { variant: w = "default" } = t, { loading_text: p = "Loading..." } = t, { absolute: S = !0 } = t, { translucent: g = !1 } = t, { border: E = !1 } = t, { autoscroll: L } = t, v, K = !1, N = 0, ee = 0, ce = null, be = null, se = 0, ye = null, Ne, oe = null, et = !0;
  const Ue = () => {
    n(0, a = n(26, ce = n(19, T = null))), n(24, N = performance.now()), n(25, ee = 0), K = !0, tt();
  };
  function tt() {
    requestAnimationFrame(() => {
      n(25, ee = (performance.now() - N) / 1e3), K && tt();
    });
  }
  function Fe() {
    n(25, ee = 0), n(0, a = n(26, ce = n(19, T = null))), K && (K = !1);
  }
  Ql(() => {
    K && Fe();
  });
  let T = null;
  function V(d) {
    Ar[d ? "unshift" : "push"](() => {
      oe = d, n(16, oe), n(7, y), n(14, ye), n(15, Ne);
    });
  }
  function X(d) {
    Ar[d ? "unshift" : "push"](() => {
      v = d, n(13, v);
    });
  }
  return e.$$set = (d) => {
    "i18n" in d && n(1, l = d.i18n), "eta" in d && n(0, a = d.eta), "queue_position" in d && n(2, o = d.queue_position), "queue_size" in d && n(3, u = d.queue_size), "status" in d && n(4, f = d.status), "scroll_to_output" in d && n(21, h = d.scroll_to_output), "timer" in d && n(5, c = d.timer), "show_progress" in d && n(6, _ = d.show_progress), "message" in d && n(22, m = d.message), "progress" in d && n(7, y = d.progress), "variant" in d && n(8, w = d.variant), "loading_text" in d && n(9, p = d.loading_text), "absolute" in d && n(10, S = d.absolute), "translucent" in d && n(11, g = d.translucent), "border" in d && n(12, E = d.border), "autoscroll" in d && n(23, L = d.autoscroll), "$$scope" in d && n(28, s = d.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    218103809 && (a === null && n(0, a = ce), a != null && ce !== a && (n(27, be = (performance.now() - N) / 1e3 + a), n(19, T = be.toFixed(1)), n(26, ce = a))), e.$$.dirty[0] & /*eta_from_start, timer_diff*/
    167772160 && n(17, se = be === null || be <= 0 || !ee ? null : Math.min(ee / be, 1)), e.$$.dirty[0] & /*progress*/
    128 && y != null && n(18, et = !1), e.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (y != null ? n(14, ye = y.map((d) => {
      if (d.index != null && d.length != null)
        return d.index / d.length;
      if (d.progress != null)
        return d.progress;
    })) : n(14, ye = null), ye ? (n(15, Ne = ye[ye.length - 1]), oe && (Ne === 0 ? n(16, oe.style.transition = "0", oe) : n(16, oe.style.transition = "150ms", oe))) : n(15, Ne = void 0)), e.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? Ue() : Fe()), e.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    10493968 && v && h && (f === "pending" || f === "complete") && ua(v, L), e.$$.dirty[0] & /*status, message*/
    4194320, e.$$.dirty[0] & /*timer_diff*/
    33554432 && n(20, r = ee.toFixed(1));
  }, [
    a,
    l,
    o,
    u,
    f,
    c,
    _,
    y,
    w,
    p,
    S,
    g,
    E,
    v,
    ye,
    Ne,
    oe,
    se,
    et,
    T,
    r,
    h,
    m,
    L,
    N,
    ee,
    ce,
    be,
    s,
    i,
    V,
    X
  ];
}
class ca extends Ul {
  constructor(t) {
    super(), zl(
      this,
      t,
      fa,
      aa,
      Wl,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 21,
        timer: 5,
        show_progress: 6,
        message: 22,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 23
      },
      null,
      [-1, -1]
    );
  }
}
var Sn = new Intl.Collator(0, { numeric: 1 }).compare;
function Gr(e, t, n) {
  return e = e.split("."), t = t.split("."), Sn(e[0], t[0]) || Sn(e[1], t[1]) || (t[2] = t.slice(2).join("."), n = /[.-]/.test(e[2] = e.slice(2).join(".")), n == /[.-]/.test(t[2]) ? Sn(e[2], t[2]) : n ? -1 : 1);
}
function Oi(e, t, n) {
  return t.startsWith("http://") || t.startsWith("https://") ? n ? e : t : e + t;
}
function Tn(e) {
  if (e.startsWith("http")) {
    const { protocol: t, host: n } = new URL(e);
    return n.endsWith("hf.space") ? {
      ws_protocol: "wss",
      host: n,
      http_protocol: t
    } : {
      ws_protocol: t === "https:" ? "wss" : "ws",
      http_protocol: t,
      host: n
    };
  } else if (e.startsWith("file:"))
    return {
      ws_protocol: "ws",
      http_protocol: "http:",
      host: "lite.local"
      // Special fake hostname only used for this case. This matches the hostname allowed in `is_self_host()` in `js/wasm/network/host.ts`.
    };
  return {
    ws_protocol: "wss",
    http_protocol: "https:",
    host: e
  };
}
const Li = /^[^\/]*\/[^\/]*$/, ha = /.*hf\.space\/{0,1}$/;
async function _a(e, t) {
  const n = {};
  t && (n.Authorization = `Bearer ${t}`);
  const r = e.trim();
  if (Li.test(r))
    try {
      const i = await fetch(
        `https://huggingface.co/api/spaces/${r}/host`,
        { headers: n }
      );
      if (i.status !== 200)
        throw new Error("Space metadata could not be loaded.");
      const s = (await i.json()).host;
      return {
        space_id: e,
        ...Tn(s)
      };
    } catch (i) {
      throw new Error("Space metadata could not be loaded." + i.message);
    }
  if (ha.test(r)) {
    const { ws_protocol: i, http_protocol: s, host: l } = Tn(r);
    return {
      space_id: l.replace(".hf.space", ""),
      ws_protocol: i,
      http_protocol: s,
      host: l
    };
  }
  return {
    space_id: !1,
    ...Tn(r)
  };
}
function da(e) {
  let t = {};
  return e.forEach(({ api_name: n }, r) => {
    n && (t[n] = r);
  }), t;
}
const ma = /^(?=[^]*\b[dD]iscussions{0,1}\b)(?=[^]*\b[dD]isabled\b)[^]*$/;
async function jr(e) {
  try {
    const n = (await fetch(
      `https://huggingface.co/api/spaces/${e}/discussions`,
      {
        method: "HEAD"
      }
    )).headers.get("x-error-message");
    return !(n && ma.test(n));
  } catch {
    return !1;
  }
}
function pa(e, t, n, r) {
  if (t.length === 0) {
    if (n === "replace")
      return r;
    if (n === "append")
      return e + r;
    throw new Error(`Unsupported action: ${n}`);
  }
  let i = e;
  for (let l = 0; l < t.length - 1; l++)
    i = i[t[l]];
  const s = t[t.length - 1];
  switch (n) {
    case "replace":
      i[s] = r;
      break;
    case "append":
      i[s] += r;
      break;
    case "add":
      Array.isArray(i) ? i.splice(Number(s), 0, r) : i[s] = r;
      break;
    case "delete":
      Array.isArray(i) ? i.splice(Number(s), 1) : delete i[s];
      break;
    default:
      throw new Error(`Unknown action: ${n}`);
  }
  return e;
}
function ga(e, t) {
  return t.forEach(([n, r, i]) => {
    e = pa(e, r, n, i);
  }), e;
}
async function ba(e, t, n, r = wa) {
  let i = (Array.isArray(e) ? e : [e]).map(
    (s) => s.blob
  );
  return await Promise.all(
    await r(t, i, void 0, n).then(
      async (s) => {
        if (s.error)
          throw new Error(s.error);
        return s.files ? s.files.map((l, a) => new tr({
          ...e[a],
          path: l,
          url: t + "/file=" + l
        })) : [];
      }
    )
  );
}
async function ya(e, t) {
  return e.map(
    (n, r) => new tr({
      path: n.name,
      orig_name: n.name,
      blob: n,
      size: n.size,
      mime_type: n.type,
      is_stream: t
    })
  );
}
class tr {
  constructor({
    path: t,
    url: n,
    orig_name: r,
    size: i,
    blob: s,
    is_stream: l,
    mime_type: a,
    alt_text: o
  }) {
    this.meta = { _type: "gradio.FileData" }, this.path = t, this.url = n, this.orig_name = r, this.size = i, this.blob = n ? void 0 : s, this.is_stream = l, this.mime_type = a, this.alt_text = o;
  }
}
const Mi = "This application is too busy. Keep trying!", je = "Connection errored out.";
let Ri;
function va(e, t) {
  return { post_data: n, upload_files: r, client: i, handle_blob: s };
  async function n(l, a, o) {
    const u = { "Content-Type": "application/json" };
    o && (u.Authorization = `Bearer ${o}`);
    try {
      var f = await e(l, {
        method: "POST",
        body: JSON.stringify(a),
        headers: u
      });
    } catch {
      return [{ error: je }, 500];
    }
    let h, c;
    try {
      h = await f.json(), c = f.status;
    } catch (_) {
      h = { error: `Could not parse server response: ${_}` }, c = 500;
    }
    return [h, c];
  }
  async function r(l, a, o, u) {
    const f = {};
    o && (f.Authorization = `Bearer ${o}`);
    const h = 1e3, c = [];
    for (let m = 0; m < a.length; m += h) {
      const y = a.slice(m, m + h), w = new FormData();
      y.forEach((S) => {
        w.append("files", S);
      });
      try {
        const S = u ? `${l}/upload?upload_id=${u}` : `${l}/upload`;
        var _ = await e(S, {
          method: "POST",
          body: w,
          headers: f
        });
      } catch {
        return { error: je };
      }
      const p = await _.json();
      c.push(...p);
    }
    return { files: c };
  }
  async function i(l, a = {}) {
    return new Promise(async (o) => {
      const { status_callback: u, hf_token: f } = a, h = {
        predict: Ne,
        submit: oe,
        view_api: Fe,
        component_server: tt
      };
      if ((typeof window > "u" || !("WebSocket" in window)) && !global.Websocket) {
        const T = await import("./wrapper-6f348d45-19fa94bf.js");
        Ri = (await import("./__vite-browser-external-2447137e.js")).Blob, global.WebSocket = T.WebSocket;
      }
      const { ws_protocol: c, http_protocol: _, host: m, space_id: y } = await _a(l, f), w = Math.random().toString(36).substring(2), p = {};
      let S = !1, g = {}, E = {}, L = null;
      const v = {}, K = /* @__PURE__ */ new Set();
      let N, ee = {}, ce = !1;
      f && y && (ce = await Sa(y, f));
      async function be(T) {
        if (N = T, window.location.protocol === "https:" && (N.root = N.root.replace("http://", "https://")), ee = da((T == null ? void 0 : T.dependencies) || []), N.auth_required)
          return {
            config: N,
            ...h
          };
        try {
          se = await Fe(N);
        } catch (V) {
          console.error(`Could not get api details: ${V.message}`);
        }
        return {
          config: N,
          ...h
        };
      }
      let se;
      async function ye(T) {
        if (u && u(T), T.status === "running")
          try {
            N = await Xr(
              e,
              `${_}//${m}`,
              f
            );
            const V = await be(N);
            o(V);
          } catch (V) {
            console.error(V), u && u({
              status: "error",
              message: "Could not load this space.",
              load_status: "error",
              detail: "NOT_FOUND"
            });
          }
      }
      try {
        N = await Xr(
          e,
          `${_}//${m}`,
          f
        );
        const T = await be(N);
        o(T);
      } catch (T) {
        console.error(T), y ? jn(
          y,
          Li.test(y) ? "space_name" : "subdomain",
          ye
        ) : u && u({
          status: "error",
          message: "Could not load this space.",
          load_status: "error",
          detail: "NOT_FOUND"
        });
      }
      function Ne(T, V, X) {
        let d = !1, b = !1, O;
        if (typeof T == "number")
          O = N.dependencies[T];
        else {
          const I = T.replace(/^\//, "");
          O = N.dependencies[ee[I]];
        }
        if (O.types.continuous)
          throw new Error(
            "Cannot call predict on this function as it may run forever. Use submit instead"
          );
        return new Promise((I, te) => {
          const le = oe(T, V, X);
          let k;
          le.on("data", (he) => {
            b && (le.destroy(), I(he)), d = !0, k = he;
          }).on("status", (he) => {
            he.stage === "error" && te(he), he.stage === "complete" && (b = !0, d && (le.destroy(), I(k)));
          });
        });
      }
      function oe(T, V, X, d = null) {
        let b, O;
        if (typeof T == "number")
          b = T, O = se.unnamed_endpoints[b];
        else {
          const F = T.replace(/^\//, "");
          b = ee[F], O = se.named_endpoints[T.trim()];
        }
        if (typeof b != "number")
          throw new Error(
            "There is no endpoint matching that name of fn_index matching that number."
          );
        let I, te, le = N.protocol ?? "ws";
        const k = typeof T == "number" ? "/predict" : T;
        let he, ne = null, ae = !1;
        const vt = {};
        let Oe = "";
        typeof window < "u" && (Oe = new URLSearchParams(window.location.search).toString()), s(`${N.root}`, V, O, f).then(
          (F) => {
            if (he = {
              data: F || [],
              event_data: X,
              fn_index: b,
              trigger_id: d
            }, Ta(b, N))
              M({
                type: "status",
                endpoint: k,
                stage: "pending",
                queue: !1,
                fn_index: b,
                time: /* @__PURE__ */ new Date()
              }), n(
                `${N.root}/run${k.startsWith("/") ? k : `/${k}`}${Oe ? "?" + Oe : ""}`,
                {
                  ...he,
                  session_hash: w
                },
                f
              ).then(([j, U]) => {
                const W = j.data;
                U == 200 ? (M({
                  type: "data",
                  endpoint: k,
                  fn_index: b,
                  data: W,
                  time: /* @__PURE__ */ new Date()
                }), M({
                  type: "status",
                  endpoint: k,
                  fn_index: b,
                  stage: "complete",
                  eta: j.average_duration,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                })) : M({
                  type: "status",
                  stage: "error",
                  endpoint: k,
                  fn_index: b,
                  message: j.error,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                });
              }).catch((j) => {
                M({
                  type: "status",
                  stage: "error",
                  message: j.message,
                  endpoint: k,
                  fn_index: b,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                });
              });
            else if (le == "ws") {
              M({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: k,
                fn_index: b,
                time: /* @__PURE__ */ new Date()
              });
              let j = new URL(`${c}://${Oi(
                m,
                N.path,
                !0
              )}
							/queue/join${Oe ? "?" + Oe : ""}`);
              ce && j.searchParams.set("__sign", ce), I = new WebSocket(j), I.onclose = (U) => {
                U.wasClean || M({
                  type: "status",
                  stage: "error",
                  broken: !0,
                  message: je,
                  queue: !0,
                  endpoint: k,
                  fn_index: b,
                  time: /* @__PURE__ */ new Date()
                });
              }, I.onmessage = function(U) {
                const W = JSON.parse(U.data), { type: z, status: D, data: x } = Bn(
                  W,
                  p[b]
                );
                if (z === "update" && D && !ae)
                  M({
                    type: "status",
                    endpoint: k,
                    fn_index: b,
                    time: /* @__PURE__ */ new Date(),
                    ...D
                  }), D.stage === "error" && I.close();
                else if (z === "hash") {
                  I.send(JSON.stringify({ fn_index: b, session_hash: w }));
                  return;
                } else
                  z === "data" ? I.send(JSON.stringify({ ...he, session_hash: w })) : z === "complete" ? ae = D : z === "log" ? M({
                    type: "log",
                    log: x.log,
                    level: x.level,
                    endpoint: k,
                    fn_index: b
                  }) : z === "generating" && M({
                    type: "status",
                    time: /* @__PURE__ */ new Date(),
                    ...D,
                    stage: D == null ? void 0 : D.stage,
                    queue: !0,
                    endpoint: k,
                    fn_index: b
                  });
                x && (M({
                  type: "data",
                  time: /* @__PURE__ */ new Date(),
                  data: x.data,
                  endpoint: k,
                  fn_index: b
                }), ae && (M({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...ae,
                  stage: D == null ? void 0 : D.stage,
                  queue: !0,
                  endpoint: k,
                  fn_index: b
                }), I.close()));
              }, Gr(N.version || "2.0.0", "3.6") < 0 && addEventListener(
                "open",
                () => I.send(JSON.stringify({ hash: w }))
              );
            } else if (le == "sse") {
              M({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: k,
                fn_index: b,
                time: /* @__PURE__ */ new Date()
              });
              var Z = new URLSearchParams({
                fn_index: b.toString(),
                session_hash: w
              }).toString();
              let j = new URL(
                `${N.root}/queue/join?${Oe ? Oe + "&" : ""}${Z}`
              );
              te = t(j), te.onmessage = async function(U) {
                const W = JSON.parse(U.data), { type: z, status: D, data: x } = Bn(
                  W,
                  p[b]
                );
                if (z === "update" && D && !ae)
                  M({
                    type: "status",
                    endpoint: k,
                    fn_index: b,
                    time: /* @__PURE__ */ new Date(),
                    ...D
                  }), D.stage === "error" && te.close();
                else if (z === "data") {
                  ne = W.event_id;
                  let [Ge, Ss] = await n(
                    `${N.root}/queue/data`,
                    {
                      ...he,
                      session_hash: w,
                      event_id: ne
                    },
                    f
                  );
                  Ss !== 200 && (M({
                    type: "status",
                    stage: "error",
                    message: je,
                    queue: !0,
                    endpoint: k,
                    fn_index: b,
                    time: /* @__PURE__ */ new Date()
                  }), te.close());
                } else
                  z === "complete" ? ae = D : z === "log" ? M({
                    type: "log",
                    log: x.log,
                    level: x.level,
                    endpoint: k,
                    fn_index: b
                  }) : z === "generating" && M({
                    type: "status",
                    time: /* @__PURE__ */ new Date(),
                    ...D,
                    stage: D == null ? void 0 : D.stage,
                    queue: !0,
                    endpoint: k,
                    fn_index: b
                  });
                x && (M({
                  type: "data",
                  time: /* @__PURE__ */ new Date(),
                  data: x.data,
                  endpoint: k,
                  fn_index: b
                }), ae && (M({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...ae,
                  stage: D == null ? void 0 : D.stage,
                  queue: !0,
                  endpoint: k,
                  fn_index: b
                }), te.close()));
              };
            } else
              (le == "sse_v1" || le == "sse_v2" || le == "sse_v2.1") && (M({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: k,
                fn_index: b,
                time: /* @__PURE__ */ new Date()
              }), n(
                `${N.root}/queue/join?${Oe}`,
                {
                  ...he,
                  session_hash: w
                },
                f
              ).then(([j, U]) => {
                if (U === 503)
                  M({
                    type: "status",
                    stage: "error",
                    message: Mi,
                    queue: !0,
                    endpoint: k,
                    fn_index: b,
                    time: /* @__PURE__ */ new Date()
                  });
                else if (U !== 200)
                  M({
                    type: "status",
                    stage: "error",
                    message: je,
                    queue: !0,
                    endpoint: k,
                    fn_index: b,
                    time: /* @__PURE__ */ new Date()
                  });
                else {
                  ne = j.event_id;
                  let W = async function(z) {
                    try {
                      const { type: D, status: x, data: Ge } = Bn(
                        z,
                        p[b]
                      );
                      if (D == "heartbeat")
                        return;
                      if (D === "update" && x && !ae)
                        M({
                          type: "status",
                          endpoint: k,
                          fn_index: b,
                          time: /* @__PURE__ */ new Date(),
                          ...x
                        });
                      else if (D === "complete")
                        ae = x;
                      else if (D == "unexpected_error")
                        console.error("Unexpected error", x == null ? void 0 : x.message), M({
                          type: "status",
                          stage: "error",
                          message: (x == null ? void 0 : x.message) || "An Unexpected Error Occurred!",
                          queue: !0,
                          endpoint: k,
                          fn_index: b,
                          time: /* @__PURE__ */ new Date()
                        });
                      else if (D === "log") {
                        M({
                          type: "log",
                          log: Ge.log,
                          level: Ge.level,
                          endpoint: k,
                          fn_index: b
                        });
                        return;
                      } else
                        D === "generating" && (M({
                          type: "status",
                          time: /* @__PURE__ */ new Date(),
                          ...x,
                          stage: x == null ? void 0 : x.stage,
                          queue: !0,
                          endpoint: k,
                          fn_index: b
                        }), Ge && (le === "sse_v2" || le === "sse_v2.1") && Es(ne, Ge));
                      Ge && (M({
                        type: "data",
                        time: /* @__PURE__ */ new Date(),
                        data: Ge.data,
                        endpoint: k,
                        fn_index: b
                      }), ae && M({
                        type: "status",
                        time: /* @__PURE__ */ new Date(),
                        ...ae,
                        stage: x == null ? void 0 : x.stage,
                        queue: !0,
                        endpoint: k,
                        fn_index: b
                      })), ((x == null ? void 0 : x.stage) === "complete" || (x == null ? void 0 : x.stage) === "error") && (v[ne] && delete v[ne], ne in E && delete E[ne]);
                    } catch (D) {
                      console.error("Unexpected client exception", D), M({
                        type: "status",
                        stage: "error",
                        message: "An Unexpected Error Occurred!",
                        queue: !0,
                        endpoint: k,
                        fn_index: b,
                        time: /* @__PURE__ */ new Date()
                      }), Ue();
                    }
                  };
                  ne in g && (g[ne].forEach(
                    (z) => W(z)
                  ), delete g[ne]), v[ne] = W, K.add(ne), S || et();
                }
              }));
          }
        );
        function Es(F, Z) {
          !E[F] ? (E[F] = [], Z.data.forEach((U, W) => {
            E[F][W] = U;
          })) : Z.data.forEach((U, W) => {
            let z = ga(
              E[F][W],
              U
            );
            E[F][W] = z, Z.data[W] = z;
          });
        }
        function M(F) {
          const j = vt[F.type] || [];
          j == null || j.forEach((U) => U(F));
        }
        function on(F, Z) {
          const j = vt, U = j[F] || [];
          return j[F] = U, U == null || U.push(Z), { on, off: Ot, cancel: ln, destroy: an };
        }
        function Ot(F, Z) {
          const j = vt;
          let U = j[F] || [];
          return U = U == null ? void 0 : U.filter((W) => W !== Z), j[F] = U, { on, off: Ot, cancel: ln, destroy: an };
        }
        async function ln() {
          const F = {
            stage: "complete",
            queue: !1,
            time: /* @__PURE__ */ new Date()
          };
          ae = F, M({
            ...F,
            type: "status",
            endpoint: k,
            fn_index: b
          });
          let Z = {};
          le === "ws" ? (I && I.readyState === 0 ? I.addEventListener("open", () => {
            I.close();
          }) : I.close(), Z = { fn_index: b, session_hash: w }) : (te.close(), Z = { event_id: ne });
          try {
            await e(`${N.root}/reset`, {
              headers: { "Content-Type": "application/json" },
              method: "POST",
              body: JSON.stringify(Z)
            });
          } catch {
            console.warn(
              "The `/reset` endpoint could not be called. Subsequent endpoint results may be unreliable."
            );
          }
        }
        function an() {
          for (const F in vt)
            vt[F].forEach((Z) => {
              Ot(F, Z);
            });
        }
        return {
          on,
          off: Ot,
          cancel: ln,
          destroy: an
        };
      }
      function et() {
        S = !0;
        let T = new URLSearchParams({
          session_hash: w
        }).toString(), V = new URL(`${N.root}/queue/data?${T}`);
        L = t(V), L.onmessage = async function(X) {
          let d = JSON.parse(X.data);
          const b = d.event_id;
          if (!b)
            await Promise.all(
              Object.keys(v).map(
                (O) => v[O](d)
              )
            );
          else if (v[b]) {
            d.msg === "process_completed" && (K.delete(b), K.size === 0 && Ue());
            let O = v[b];
            window.setTimeout(O, 0, d);
          } else
            g[b] || (g[b] = []), g[b].push(d);
        }, L.onerror = async function(X) {
          await Promise.all(
            Object.keys(v).map(
              (d) => v[d]({
                msg: "unexpected_error",
                message: je
              })
            )
          ), Ue();
        };
      }
      function Ue() {
        S = !1, L == null || L.close();
      }
      async function tt(T, V, X) {
        var d;
        const b = { "Content-Type": "application/json" };
        f && (b.Authorization = `Bearer ${f}`);
        let O, I = N.components.find(
          (k) => k.id === T
        );
        (d = I == null ? void 0 : I.props) != null && d.root_url ? O = I.props.root_url : O = N.root;
        const te = await e(
          `${O}/component_server/`,
          {
            method: "POST",
            body: JSON.stringify({
              data: X,
              component_id: T,
              fn_name: V,
              session_hash: w
            }),
            headers: b
          }
        );
        if (!te.ok)
          throw new Error(
            "Could not connect to component server: " + te.statusText
          );
        return await te.json();
      }
      async function Fe(T) {
        if (se)
          return se;
        const V = { "Content-Type": "application/json" };
        f && (V.Authorization = `Bearer ${f}`);
        let X;
        if (Gr(T.version || "2.0.0", "3.30") < 0 ? X = await e(
          "https://gradio-space-api-fetcher-v2.hf.space/api",
          {
            method: "POST",
            body: JSON.stringify({
              serialize: !1,
              config: JSON.stringify(T)
            }),
            headers: V
          }
        ) : X = await e(`${T.root}/info`, {
          headers: V
        }), !X.ok)
          throw new Error(je);
        let d = await X.json();
        return "api" in d && (d = d.api), d.named_endpoints["/predict"] && !d.unnamed_endpoints[0] && (d.unnamed_endpoints[0] = d.named_endpoints["/predict"]), Ea(d, T, ee);
      }
    });
  }
  async function s(l, a, o, u) {
    const f = await Gn(
      a,
      void 0,
      [],
      !0,
      o
    );
    return Promise.all(
      f.map(async ({ path: h, blob: c, type: _ }) => {
        if (c) {
          const m = (await r(l, [c], u)).files[0];
          return { path: h, file_url: m, type: _, name: c == null ? void 0 : c.name };
        }
        return { path: h, type: _ };
      })
    ).then((h) => (h.forEach(({ path: c, file_url: _, type: m, name: y }) => {
      if (m === "Gallery")
        zr(a, _, c);
      else if (_) {
        const w = new tr({ path: _, orig_name: y });
        zr(a, w, c);
      }
    }), a));
  }
}
const { post_data: Oc, upload_files: wa, client: Lc, handle_blob: Mc } = va(
  fetch,
  (...e) => new EventSource(...e)
);
function qr(e, t, n, r) {
  switch (e.type) {
    case "string":
      return "string";
    case "boolean":
      return "boolean";
    case "number":
      return "number";
  }
  if (n === "JSONSerializable" || n === "StringSerializable")
    return "any";
  if (n === "ListStringSerializable")
    return "string[]";
  if (t === "Image")
    return r === "parameter" ? "Blob | File | Buffer" : "string";
  if (n === "FileSerializable")
    return (e == null ? void 0 : e.type) === "array" ? r === "parameter" ? "(Blob | File | Buffer)[]" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}[]" : r === "parameter" ? "Blob | File | Buffer" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}";
  if (n === "GallerySerializable")
    return r === "parameter" ? "[(Blob | File | Buffer), (string | null)][]" : "[{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}, (string | null))][]";
}
function Vr(e, t) {
  return t === "GallerySerializable" ? "array of [file, label] tuples" : t === "ListStringSerializable" ? "array of strings" : t === "FileSerializable" ? "array of files or single file" : e.description;
}
function Ea(e, t, n) {
  const r = {
    named_endpoints: {},
    unnamed_endpoints: {}
  };
  for (const i in e) {
    const s = e[i];
    for (const l in s) {
      const a = t.dependencies[l] ? l : n[l.replace("/", "")], o = s[l];
      r[i][l] = {}, r[i][l].parameters = {}, r[i][l].returns = {}, r[i][l].type = t.dependencies[a].types, r[i][l].parameters = o.parameters.map(
        ({ label: u, component: f, type: h, serializer: c }) => ({
          label: u,
          component: f,
          type: qr(h, f, c, "parameter"),
          description: Vr(h, c)
        })
      ), r[i][l].returns = o.returns.map(
        ({ label: u, component: f, type: h, serializer: c }) => ({
          label: u,
          component: f,
          type: qr(h, f, c, "return"),
          description: Vr(h, c)
        })
      );
    }
  }
  return r;
}
async function Sa(e, t) {
  try {
    return (await (await fetch(`https://huggingface.co/api/spaces/${e}/jwt`, {
      headers: {
        Authorization: `Bearer ${t}`
      }
    })).json()).token || !1;
  } catch (n) {
    return console.error(n), !1;
  }
}
function zr(e, t, n) {
  for (; n.length > 1; )
    e = e[n.shift()];
  e[n.shift()] = t;
}
async function Gn(e, t = void 0, n = [], r = !1, i = void 0) {
  if (Array.isArray(e)) {
    let s = [];
    return await Promise.all(
      e.map(async (l, a) => {
        var o;
        let u = n.slice();
        u.push(a);
        const f = await Gn(
          e[a],
          r ? ((o = i == null ? void 0 : i.parameters[a]) == null ? void 0 : o.component) || void 0 : t,
          u,
          !1,
          i
        );
        s = s.concat(f);
      })
    ), s;
  } else {
    if (globalThis.Buffer && e instanceof globalThis.Buffer)
      return [
        {
          path: n,
          blob: t === "Image" ? !1 : new Ri([e]),
          type: t
        }
      ];
    if (typeof e == "object") {
      let s = [];
      for (let l in e)
        if (e.hasOwnProperty(l)) {
          let a = n.slice();
          a.push(l), s = s.concat(
            await Gn(
              e[l],
              void 0,
              a,
              !1,
              i
            )
          );
        }
      return s;
    }
  }
  return [];
}
function Ta(e, t) {
  var n, r, i, s;
  return !(((r = (n = t == null ? void 0 : t.dependencies) == null ? void 0 : n[e]) == null ? void 0 : r.queue) === null ? t.enable_queue : (s = (i = t == null ? void 0 : t.dependencies) == null ? void 0 : i[e]) != null && s.queue) || !1;
}
async function Xr(e, t, n) {
  const r = {};
  if (n && (r.Authorization = `Bearer ${n}`), typeof window < "u" && window.gradio_config && location.origin !== "http://localhost:9876" && !window.gradio_config.dev_mode) {
    const i = window.gradio_config.root, s = window.gradio_config;
    return s.root = Oi(t, s.root, !1), { ...s, path: i };
  } else if (t) {
    let i = await e(`${t}/config`, {
      headers: r
    });
    if (i.status === 200) {
      const s = await i.json();
      return s.path = s.path ?? "", s.root = t, s;
    }
    throw new Error("Could not get config.");
  }
  throw new Error("No config or app endpoint found");
}
async function jn(e, t, n) {
  let r = t === "subdomain" ? `https://huggingface.co/api/spaces/by-subdomain/${e}` : `https://huggingface.co/api/spaces/${e}`, i, s;
  try {
    if (i = await fetch(r), s = i.status, s !== 200)
      throw new Error();
    i = await i.json();
  } catch {
    n({
      status: "error",
      load_status: "error",
      message: "Could not get space status",
      detail: "NOT_FOUND"
    });
    return;
  }
  if (!i || s !== 200)
    return;
  const {
    runtime: { stage: l },
    id: a
  } = i;
  switch (l) {
    case "STOPPED":
    case "SLEEPING":
      n({
        status: "sleeping",
        load_status: "pending",
        message: "Space is asleep. Waking it up...",
        detail: l
      }), setTimeout(() => {
        jn(e, t, n);
      }, 1e3);
      break;
    case "PAUSED":
      n({
        status: "paused",
        load_status: "error",
        message: "This space has been paused by the author. If you would like to try this demo, consider duplicating the space.",
        detail: l,
        discussions_enabled: await jr(a)
      });
      break;
    case "RUNNING":
    case "RUNNING_BUILDING":
      n({
        status: "running",
        load_status: "complete",
        message: "",
        detail: l
      });
      break;
    case "BUILDING":
      n({
        status: "building",
        load_status: "pending",
        message: "Space is building...",
        detail: l
      }), setTimeout(() => {
        jn(e, t, n);
      }, 1e3);
      break;
    default:
      n({
        status: "space_error",
        load_status: "error",
        message: "This space is experiencing an issue.",
        detail: l,
        discussions_enabled: await jr(a)
      });
      break;
  }
}
function Bn(e, t) {
  switch (e.msg) {
    case "send_data":
      return { type: "data" };
    case "send_hash":
      return { type: "hash" };
    case "queue_full":
      return {
        type: "update",
        status: {
          queue: !0,
          message: Mi,
          stage: "error",
          code: e.code,
          success: e.success
        }
      };
    case "heartbeat":
      return {
        type: "heartbeat"
      };
    case "unexpected_error":
      return {
        type: "unexpected_error",
        status: {
          queue: !0,
          message: e.message,
          stage: "error",
          success: !1
        }
      };
    case "estimation":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: t || "pending",
          code: e.code,
          size: e.queue_size,
          position: e.rank,
          eta: e.rank_eta,
          success: e.success
        }
      };
    case "progress":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: e.code,
          progress_data: e.progress_data,
          success: e.success
        }
      };
    case "log":
      return { type: "log", data: e };
    case "process_generating":
      return {
        type: "generating",
        status: {
          queue: !0,
          message: e.success ? null : e.output.error,
          stage: e.success ? "generating" : "error",
          code: e.code,
          progress_data: e.progress_data,
          eta: e.average_duration
        },
        data: e.success ? e.output : null
      };
    case "process_completed":
      return "error" in e.output ? {
        type: "update",
        status: {
          queue: !0,
          message: e.output.error,
          stage: "error",
          code: e.code,
          success: e.success
        }
      } : {
        type: "complete",
        status: {
          queue: !0,
          message: e.success ? void 0 : e.output.error,
          stage: e.success ? "complete" : "error",
          code: e.code,
          progress_data: e.progress_data
        },
        data: e.success ? e.output : null
      };
    case "process_starts":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: e.code,
          size: e.rank,
          position: 0,
          success: e.success,
          eta: e.eta
        }
      };
  }
  return { type: "none", status: { stage: "error", queue: !0 } };
}
function Ba(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Aa = function(t) {
  return ka(t) && !Ha(t);
};
function ka(e) {
  return !!e && typeof e == "object";
}
function Ha(e) {
  var t = Object.prototype.toString.call(e);
  return t === "[object RegExp]" || t === "[object Date]" || Ca(e);
}
var Pa = typeof Symbol == "function" && Symbol.for, Na = Pa ? Symbol.for("react.element") : 60103;
function Ca(e) {
  return e.$$typeof === Na;
}
function Ia(e) {
  return Array.isArray(e) ? [] : {};
}
function Bt(e, t) {
  return t.clone !== !1 && t.isMergeableObject(e) ? ft(Ia(e), e, t) : e;
}
function Oa(e, t, n) {
  return e.concat(t).map(function(r) {
    return Bt(r, n);
  });
}
function La(e, t) {
  if (!t.customMerge)
    return ft;
  var n = t.customMerge(e);
  return typeof n == "function" ? n : ft;
}
function Ma(e) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e).filter(function(t) {
    return Object.propertyIsEnumerable.call(e, t);
  }) : [];
}
function Wr(e) {
  return Object.keys(e).concat(Ma(e));
}
function Di(e, t) {
  try {
    return t in e;
  } catch {
    return !1;
  }
}
function Ra(e, t) {
  return Di(e, t) && !(Object.hasOwnProperty.call(e, t) && Object.propertyIsEnumerable.call(e, t));
}
function Da(e, t, n) {
  var r = {};
  return n.isMergeableObject(e) && Wr(e).forEach(function(i) {
    r[i] = Bt(e[i], n);
  }), Wr(t).forEach(function(i) {
    Ra(e, i) || (Di(e, i) && n.isMergeableObject(t[i]) ? r[i] = La(i, n)(e[i], t[i], n) : r[i] = Bt(t[i], n));
  }), r;
}
function ft(e, t, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || Oa, n.isMergeableObject = n.isMergeableObject || Aa, n.cloneUnlessOtherwiseSpecified = Bt;
  var r = Array.isArray(t), i = Array.isArray(e), s = r === i;
  return s ? r ? n.arrayMerge(e, t, n) : Da(e, t, n) : Bt(t, n);
}
ft.all = function(t, n) {
  if (!Array.isArray(t))
    throw new Error("first argument should be an array");
  return t.reduce(function(r, i) {
    return ft(r, i, n);
  }, {});
};
var xa = ft, Ua = xa;
const Fa = /* @__PURE__ */ Ba(Ua);
var qn = function(e, t) {
  return qn = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
    n.__proto__ = r;
  } || function(n, r) {
    for (var i in r)
      Object.prototype.hasOwnProperty.call(r, i) && (n[i] = r[i]);
  }, qn(e, t);
};
function Yt(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
  qn(e, t);
  function n() {
    this.constructor = e;
  }
  e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
var R = function() {
  return R = Object.assign || function(t) {
    for (var n, r = 1, i = arguments.length; r < i; r++) {
      n = arguments[r];
      for (var s in n)
        Object.prototype.hasOwnProperty.call(n, s) && (t[s] = n[s]);
    }
    return t;
  }, R.apply(this, arguments);
};
function An(e, t, n) {
  if (n || arguments.length === 2)
    for (var r = 0, i = t.length, s; r < i; r++)
      (s || !(r in t)) && (s || (s = Array.prototype.slice.call(t, 0, r)), s[r] = t[r]);
  return e.concat(s || Array.prototype.slice.call(t));
}
var H;
(function(e) {
  e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(H || (H = {}));
var G;
(function(e) {
  e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag";
})(G || (G = {}));
var ct;
(function(e) {
  e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime";
})(ct || (ct = {}));
function Zr(e) {
  return e.type === G.literal;
}
function Ga(e) {
  return e.type === G.argument;
}
function xi(e) {
  return e.type === G.number;
}
function Ui(e) {
  return e.type === G.date;
}
function Fi(e) {
  return e.type === G.time;
}
function Gi(e) {
  return e.type === G.select;
}
function ji(e) {
  return e.type === G.plural;
}
function ja(e) {
  return e.type === G.pound;
}
function qi(e) {
  return e.type === G.tag;
}
function Vi(e) {
  return !!(e && typeof e == "object" && e.type === ct.number);
}
function Vn(e) {
  return !!(e && typeof e == "object" && e.type === ct.dateTime);
}
var zi = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, qa = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function Va(e) {
  var t = {};
  return e.replace(qa, function(n) {
    var r = n.length;
    switch (n[0]) {
      case "G":
        t.era = r === 4 ? "long" : r === 5 ? "narrow" : "short";
        break;
      case "y":
        t.year = r === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        t.month = ["numeric", "2-digit", "short", "long", "narrow"][r - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        t.day = ["numeric", "2-digit"][r - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        t.weekday = r === 4 ? "short" : r === 5 ? "narrow" : "short";
        break;
      case "e":
        if (r < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      case "c":
        if (r < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      case "a":
        t.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "H":
        t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "K":
        t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "k":
        t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        t.minute = ["numeric", "2-digit"][r - 1];
        break;
      case "s":
        t.second = ["numeric", "2-digit"][r - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        t.timeZoneName = r < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), t;
}
var za = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function Xa(e) {
  if (e.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var t = e.split(za).filter(function(c) {
    return c.length > 0;
  }), n = [], r = 0, i = t; r < i.length; r++) {
    var s = i[r], l = s.split("/");
    if (l.length === 0)
      throw new Error("Invalid number skeleton");
    for (var a = l[0], o = l.slice(1), u = 0, f = o; u < f.length; u++) {
      var h = f[u];
      if (h.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: a, options: o });
  }
  return n;
}
function Wa(e) {
  return e.replace(/^(.*?)-/, "");
}
var Jr = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, Xi = /^(@+)?(\+|#+)?[rs]?$/g, Za = /(\*)(0+)|(#+)(0+)|(0+)/g, Wi = /^(0+)$/;
function Qr(e) {
  var t = {};
  return e[e.length - 1] === "r" ? t.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (t.roundingPriority = "lessPrecision"), e.replace(Xi, function(n, r, i) {
    return typeof i != "string" ? (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length) : i === "+" ? t.minimumSignificantDigits = r.length : r[0] === "#" ? t.maximumSignificantDigits = r.length : (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length + (typeof i == "string" ? i.length : 0)), "";
  }), t;
}
function Zi(e) {
  switch (e) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function Ja(e) {
  var t;
  if (e[0] === "E" && e[1] === "E" ? (t = {
    notation: "engineering"
  }, e = e.slice(2)) : e[0] === "E" && (t = {
    notation: "scientific"
  }, e = e.slice(1)), t) {
    var n = e.slice(0, 2);
    if (n === "+!" ? (t.signDisplay = "always", e = e.slice(2)) : n === "+?" && (t.signDisplay = "exceptZero", e = e.slice(2)), !Wi.test(e))
      throw new Error("Malformed concise eng/scientific notation");
    t.minimumIntegerDigits = e.length;
  }
  return t;
}
function Yr(e) {
  var t = {}, n = Zi(e);
  return n || t;
}
function Qa(e) {
  for (var t = {}, n = 0, r = e; n < r.length; n++) {
    var i = r[n];
    switch (i.stem) {
      case "percent":
      case "%":
        t.style = "percent";
        continue;
      case "%x100":
        t.style = "percent", t.scale = 100;
        continue;
      case "currency":
        t.style = "currency", t.currency = i.options[0];
        continue;
      case "group-off":
      case ",_":
        t.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        t.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        t.style = "unit", t.unit = Wa(i.options[0]);
        continue;
      case "compact-short":
      case "K":
        t.notation = "compact", t.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        t.notation = "compact", t.compactDisplay = "long";
        continue;
      case "scientific":
        t = R(R(R({}, t), { notation: "scientific" }), i.options.reduce(function(o, u) {
          return R(R({}, o), Yr(u));
        }, {}));
        continue;
      case "engineering":
        t = R(R(R({}, t), { notation: "engineering" }), i.options.reduce(function(o, u) {
          return R(R({}, o), Yr(u));
        }, {}));
        continue;
      case "notation-simple":
        t.notation = "standard";
        continue;
      case "unit-width-narrow":
        t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        t.currencyDisplay = "code", t.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        t.currencyDisplay = "name", t.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        t.currencyDisplay = "symbol";
        continue;
      case "scale":
        t.scale = parseFloat(i.options[0]);
        continue;
      case "integer-width":
        if (i.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        i.options[0].replace(Za, function(o, u, f, h, c, _) {
          if (u)
            t.minimumIntegerDigits = f.length;
          else {
            if (h && c)
              throw new Error("We currently do not support maximum integer digits");
            if (_)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (Wi.test(i.stem)) {
      t.minimumIntegerDigits = i.stem.length;
      continue;
    }
    if (Jr.test(i.stem)) {
      if (i.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      i.stem.replace(Jr, function(o, u, f, h, c, _) {
        return f === "*" ? t.minimumFractionDigits = u.length : h && h[0] === "#" ? t.maximumFractionDigits = h.length : c && _ ? (t.minimumFractionDigits = c.length, t.maximumFractionDigits = c.length + _.length) : (t.minimumFractionDigits = u.length, t.maximumFractionDigits = u.length), "";
      });
      var s = i.options[0];
      s === "w" ? t = R(R({}, t), { trailingZeroDisplay: "stripIfInteger" }) : s && (t = R(R({}, t), Qr(s)));
      continue;
    }
    if (Xi.test(i.stem)) {
      t = R(R({}, t), Qr(i.stem));
      continue;
    }
    var l = Zi(i.stem);
    l && (t = R(R({}, t), l));
    var a = Ja(i.stem);
    a && (t = R(R({}, t), a));
  }
  return t;
}
var Gt = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function Ya(e, t) {
  for (var n = "", r = 0; r < e.length; r++) {
    var i = e.charAt(r);
    if (i === "j") {
      for (var s = 0; r + 1 < e.length && e.charAt(r + 1) === i; )
        s++, r++;
      var l = 1 + (s & 1), a = s < 2 ? 1 : 3 + (s >> 1), o = "a", u = Ka(t);
      for ((u == "H" || u == "k") && (a = 0); a-- > 0; )
        n += o;
      for (; l-- > 0; )
        n = u + n;
    } else
      i === "J" ? n += "H" : n += i;
  }
  return n;
}
function Ka(e) {
  var t = e.hourCycle;
  if (t === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  e.hourCycles && // @ts-ignore
  e.hourCycles.length && (t = e.hourCycles[0]), t)
    switch (t) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = e.language, r;
  n !== "root" && (r = e.maximize().region);
  var i = Gt[r || ""] || Gt[n || ""] || Gt["".concat(n, "-001")] || Gt["001"];
  return i[0];
}
var kn, $a = new RegExp("^".concat(zi.source, "*")), eu = new RegExp("".concat(zi.source, "*$"));
function P(e, t) {
  return { start: e, end: t };
}
var tu = !!String.prototype.startsWith, nu = !!String.fromCodePoint, ru = !!Object.fromEntries, iu = !!String.prototype.codePointAt, su = !!String.prototype.trimStart, ou = !!String.prototype.trimEnd, lu = !!Number.isSafeInteger, au = lu ? Number.isSafeInteger : function(e) {
  return typeof e == "number" && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991;
}, zn = !0;
try {
  var uu = Qi("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  zn = ((kn = uu.exec("a")) === null || kn === void 0 ? void 0 : kn[0]) === "a";
} catch {
  zn = !1;
}
var Kr = tu ? (
  // Native
  function(t, n, r) {
    return t.startsWith(n, r);
  }
) : (
  // For IE11
  function(t, n, r) {
    return t.slice(r, r + n.length) === n;
  }
), Xn = nu ? String.fromCodePoint : (
  // IE11
  function() {
    for (var t = [], n = 0; n < arguments.length; n++)
      t[n] = arguments[n];
    for (var r = "", i = t.length, s = 0, l; i > s; ) {
      if (l = t[s++], l > 1114111)
        throw RangeError(l + " is not a valid code point");
      r += l < 65536 ? String.fromCharCode(l) : String.fromCharCode(((l -= 65536) >> 10) + 55296, l % 1024 + 56320);
    }
    return r;
  }
), $r = (
  // native
  ru ? Object.fromEntries : (
    // Ponyfill
    function(t) {
      for (var n = {}, r = 0, i = t; r < i.length; r++) {
        var s = i[r], l = s[0], a = s[1];
        n[l] = a;
      }
      return n;
    }
  )
), Ji = iu ? (
  // Native
  function(t, n) {
    return t.codePointAt(n);
  }
) : (
  // IE 11
  function(t, n) {
    var r = t.length;
    if (!(n < 0 || n >= r)) {
      var i = t.charCodeAt(n), s;
      return i < 55296 || i > 56319 || n + 1 === r || (s = t.charCodeAt(n + 1)) < 56320 || s > 57343 ? i : (i - 55296 << 10) + (s - 56320) + 65536;
    }
  }
), fu = su ? (
  // Native
  function(t) {
    return t.trimStart();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace($a, "");
  }
), cu = ou ? (
  // Native
  function(t) {
    return t.trimEnd();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(eu, "");
  }
);
function Qi(e, t) {
  return new RegExp(e, t);
}
var Wn;
if (zn) {
  var ei = Qi("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Wn = function(t, n) {
    var r;
    ei.lastIndex = n;
    var i = ei.exec(t);
    return (r = i[1]) !== null && r !== void 0 ? r : "";
  };
} else
  Wn = function(t, n) {
    for (var r = []; ; ) {
      var i = Ji(t, n);
      if (i === void 0 || Yi(i) || mu(i))
        break;
      r.push(i), n += i >= 65536 ? 2 : 1;
    }
    return Xn.apply(void 0, r);
  };
var hu = (
  /** @class */
  function() {
    function e(t, n) {
      n === void 0 && (n = {}), this.message = t, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return e.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, e.prototype.parseMessage = function(t, n, r) {
      for (var i = []; !this.isEOF(); ) {
        var s = this.char();
        if (s === 123) {
          var l = this.parseArgument(t, r);
          if (l.err)
            return l;
          i.push(l.val);
        } else {
          if (s === 125 && t > 0)
            break;
          if (s === 35 && (n === "plural" || n === "selectordinal")) {
            var a = this.clonePosition();
            this.bump(), i.push({
              type: G.pound,
              location: P(a, this.clonePosition())
            });
          } else if (s === 60 && !this.ignoreTag && this.peek() === 47) {
            if (r)
              break;
            return this.error(H.UNMATCHED_CLOSING_TAG, P(this.clonePosition(), this.clonePosition()));
          } else if (s === 60 && !this.ignoreTag && Zn(this.peek() || 0)) {
            var l = this.parseTag(t, n);
            if (l.err)
              return l;
            i.push(l.val);
          } else {
            var l = this.parseLiteral(t, n);
            if (l.err)
              return l;
            i.push(l.val);
          }
        }
      }
      return { val: i, err: null };
    }, e.prototype.parseTag = function(t, n) {
      var r = this.clonePosition();
      this.bump();
      var i = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: G.literal,
            value: "<".concat(i, "/>"),
            location: P(r, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var s = this.parseMessage(t + 1, n, !0);
        if (s.err)
          return s;
        var l = s.val, a = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !Zn(this.char()))
            return this.error(H.INVALID_TAG, P(a, this.clonePosition()));
          var o = this.clonePosition(), u = this.parseTagName();
          return i !== u ? this.error(H.UNMATCHED_CLOSING_TAG, P(o, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: G.tag,
              value: i,
              children: l,
              location: P(r, this.clonePosition())
            },
            err: null
          } : this.error(H.INVALID_TAG, P(a, this.clonePosition())));
        } else
          return this.error(H.UNCLOSED_TAG, P(r, this.clonePosition()));
      } else
        return this.error(H.INVALID_TAG, P(r, this.clonePosition()));
    }, e.prototype.parseTagName = function() {
      var t = this.offset();
      for (this.bump(); !this.isEOF() && du(this.char()); )
        this.bump();
      return this.message.slice(t, this.offset());
    }, e.prototype.parseLiteral = function(t, n) {
      for (var r = this.clonePosition(), i = ""; ; ) {
        var s = this.tryParseQuote(n);
        if (s) {
          i += s;
          continue;
        }
        var l = this.tryParseUnquoted(t, n);
        if (l) {
          i += l;
          continue;
        }
        var a = this.tryParseLeftAngleBracket();
        if (a) {
          i += a;
          continue;
        }
        break;
      }
      var o = P(r, this.clonePosition());
      return {
        val: { type: G.literal, value: i, location: o },
        err: null
      };
    }, e.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !_u(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, e.prototype.tryParseQuote = function(t) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (t === "plural" || t === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var r = this.char();
        if (r === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(r);
        this.bump();
      }
      return Xn.apply(void 0, n);
    }, e.prototype.tryParseUnquoted = function(t, n) {
      if (this.isEOF())
        return null;
      var r = this.char();
      return r === 60 || r === 123 || r === 35 && (n === "plural" || n === "selectordinal") || r === 125 && t > 0 ? null : (this.bump(), Xn(r));
    }, e.prototype.parseArgument = function(t, n) {
      var r = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(H.EXPECT_ARGUMENT_CLOSING_BRACE, P(r, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(H.EMPTY_ARGUMENT, P(r, this.clonePosition()));
      var i = this.parseIdentifierIfPossible().value;
      if (!i)
        return this.error(H.MALFORMED_ARGUMENT, P(r, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(H.EXPECT_ARGUMENT_CLOSING_BRACE, P(r, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: G.argument,
              // value does not include the opening and closing braces.
              value: i,
              location: P(r, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(H.EXPECT_ARGUMENT_CLOSING_BRACE, P(r, this.clonePosition())) : this.parseArgumentOptions(t, n, i, r);
        default:
          return this.error(H.MALFORMED_ARGUMENT, P(r, this.clonePosition()));
      }
    }, e.prototype.parseIdentifierIfPossible = function() {
      var t = this.clonePosition(), n = this.offset(), r = Wn(this.message, n), i = n + r.length;
      this.bumpTo(i);
      var s = this.clonePosition(), l = P(t, s);
      return { value: r, location: l };
    }, e.prototype.parseArgumentOptions = function(t, n, r, i) {
      var s, l = this.clonePosition(), a = this.parseIdentifierIfPossible().value, o = this.clonePosition();
      switch (a) {
        case "":
          return this.error(H.EXPECT_ARGUMENT_TYPE, P(l, o));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var u = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var f = this.clonePosition(), h = this.parseSimpleArgStyleIfPossible();
            if (h.err)
              return h;
            var c = cu(h.val);
            if (c.length === 0)
              return this.error(H.EXPECT_ARGUMENT_STYLE, P(this.clonePosition(), this.clonePosition()));
            var _ = P(f, this.clonePosition());
            u = { style: c, styleLocation: _ };
          }
          var m = this.tryParseArgumentClose(i);
          if (m.err)
            return m;
          var y = P(i, this.clonePosition());
          if (u && Kr(u == null ? void 0 : u.style, "::", 0)) {
            var w = fu(u.style.slice(2));
            if (a === "number") {
              var h = this.parseNumberSkeletonFromString(w, u.styleLocation);
              return h.err ? h : {
                val: { type: G.number, value: r, location: y, style: h.val },
                err: null
              };
            } else {
              if (w.length === 0)
                return this.error(H.EXPECT_DATE_TIME_SKELETON, y);
              var p = w;
              this.locale && (p = Ya(w, this.locale));
              var c = {
                type: ct.dateTime,
                pattern: p,
                location: u.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? Va(p) : {}
              }, S = a === "date" ? G.date : G.time;
              return {
                val: { type: S, value: r, location: y, style: c },
                err: null
              };
            }
          }
          return {
            val: {
              type: a === "number" ? G.number : a === "date" ? G.date : G.time,
              value: r,
              location: y,
              style: (s = u == null ? void 0 : u.style) !== null && s !== void 0 ? s : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var g = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(H.EXPECT_SELECT_ARGUMENT_OPTIONS, P(g, R({}, g)));
          this.bumpSpace();
          var E = this.parseIdentifierIfPossible(), L = 0;
          if (a !== "select" && E.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(H.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, P(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var h = this.tryParseDecimalInteger(H.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, H.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (h.err)
              return h;
            this.bumpSpace(), E = this.parseIdentifierIfPossible(), L = h.val;
          }
          var v = this.tryParsePluralOrSelectOptions(t, a, n, E);
          if (v.err)
            return v;
          var m = this.tryParseArgumentClose(i);
          if (m.err)
            return m;
          var K = P(i, this.clonePosition());
          return a === "select" ? {
            val: {
              type: G.select,
              value: r,
              options: $r(v.val),
              location: K
            },
            err: null
          } : {
            val: {
              type: G.plural,
              value: r,
              options: $r(v.val),
              offset: L,
              pluralType: a === "plural" ? "cardinal" : "ordinal",
              location: K
            },
            err: null
          };
        }
        default:
          return this.error(H.INVALID_ARGUMENT_TYPE, P(l, o));
      }
    }, e.prototype.tryParseArgumentClose = function(t) {
      return this.isEOF() || this.char() !== 125 ? this.error(H.EXPECT_ARGUMENT_CLOSING_BRACE, P(t, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, e.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var t = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var r = this.char();
        switch (r) {
          case 39: {
            this.bump();
            var i = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(H.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, P(i, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            t += 1, this.bump();
            break;
          }
          case 125: {
            if (t > 0)
              t -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, e.prototype.parseNumberSkeletonFromString = function(t, n) {
      var r = [];
      try {
        r = Xa(t);
      } catch {
        return this.error(H.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: ct.number,
          tokens: r,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? Qa(r) : {}
        },
        err: null
      };
    }, e.prototype.tryParsePluralOrSelectOptions = function(t, n, r, i) {
      for (var s, l = !1, a = [], o = /* @__PURE__ */ new Set(), u = i.value, f = i.location; ; ) {
        if (u.length === 0) {
          var h = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var c = this.tryParseDecimalInteger(H.EXPECT_PLURAL_ARGUMENT_SELECTOR, H.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (c.err)
              return c;
            f = P(h, this.clonePosition()), u = this.message.slice(h.offset, this.offset());
          } else
            break;
        }
        if (o.has(u))
          return this.error(n === "select" ? H.DUPLICATE_SELECT_ARGUMENT_SELECTOR : H.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, f);
        u === "other" && (l = !0), this.bumpSpace();
        var _ = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? H.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : H.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, P(this.clonePosition(), this.clonePosition()));
        var m = this.parseMessage(t + 1, n, r);
        if (m.err)
          return m;
        var y = this.tryParseArgumentClose(_);
        if (y.err)
          return y;
        a.push([
          u,
          {
            value: m.val,
            location: P(_, this.clonePosition())
          }
        ]), o.add(u), this.bumpSpace(), s = this.parseIdentifierIfPossible(), u = s.value, f = s.location;
      }
      return a.length === 0 ? this.error(n === "select" ? H.EXPECT_SELECT_ARGUMENT_SELECTOR : H.EXPECT_PLURAL_ARGUMENT_SELECTOR, P(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !l ? this.error(H.MISSING_OTHER_CLAUSE, P(this.clonePosition(), this.clonePosition())) : { val: a, err: null };
    }, e.prototype.tryParseDecimalInteger = function(t, n) {
      var r = 1, i = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (r = -1);
      for (var s = !1, l = 0; !this.isEOF(); ) {
        var a = this.char();
        if (a >= 48 && a <= 57)
          s = !0, l = l * 10 + (a - 48), this.bump();
        else
          break;
      }
      var o = P(i, this.clonePosition());
      return s ? (l *= r, au(l) ? { val: l, err: null } : this.error(n, o)) : this.error(t, o);
    }, e.prototype.offset = function() {
      return this.position.offset;
    }, e.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, e.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, e.prototype.char = function() {
      var t = this.position.offset;
      if (t >= this.message.length)
        throw Error("out of bound");
      var n = Ji(this.message, t);
      if (n === void 0)
        throw Error("Offset ".concat(t, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, e.prototype.error = function(t, n) {
      return {
        val: null,
        err: {
          kind: t,
          message: this.message,
          location: n
        }
      };
    }, e.prototype.bump = function() {
      if (!this.isEOF()) {
        var t = this.char();
        t === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += t < 65536 ? 1 : 2);
      }
    }, e.prototype.bumpIf = function(t) {
      if (Kr(this.message, t, this.offset())) {
        for (var n = 0; n < t.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, e.prototype.bumpUntil = function(t) {
      var n = this.offset(), r = this.message.indexOf(t, n);
      return r >= 0 ? (this.bumpTo(r), !0) : (this.bumpTo(this.message.length), !1);
    }, e.prototype.bumpTo = function(t) {
      if (this.offset() > t)
        throw Error("targetOffset ".concat(t, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (t = Math.min(t, this.message.length); ; ) {
        var n = this.offset();
        if (n === t)
          break;
        if (n > t)
          throw Error("targetOffset ".concat(t, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, e.prototype.bumpSpace = function() {
      for (; !this.isEOF() && Yi(this.char()); )
        this.bump();
    }, e.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var t = this.char(), n = this.offset(), r = this.message.charCodeAt(n + (t >= 65536 ? 2 : 1));
      return r ?? null;
    }, e;
  }()
);
function Zn(e) {
  return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function _u(e) {
  return Zn(e) || e === 47;
}
function du(e) {
  return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function Yi(e) {
  return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function mu(e) {
  return e >= 33 && e <= 35 || e === 36 || e >= 37 && e <= 39 || e === 40 || e === 41 || e === 42 || e === 43 || e === 44 || e === 45 || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || e === 91 || e === 92 || e === 93 || e === 94 || e === 96 || e === 123 || e === 124 || e === 125 || e === 126 || e === 161 || e >= 162 && e <= 165 || e === 166 || e === 167 || e === 169 || e === 171 || e === 172 || e === 174 || e === 176 || e === 177 || e === 182 || e === 187 || e === 191 || e === 215 || e === 247 || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || e === 8216 || e === 8217 || e === 8218 || e >= 8219 && e <= 8220 || e === 8221 || e === 8222 || e === 8223 || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || e === 8249 || e === 8250 || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || e === 8260 || e === 8261 || e === 8262 || e >= 8263 && e <= 8273 || e === 8274 || e === 8275 || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || e === 8608 || e >= 8609 && e <= 8610 || e === 8611 || e >= 8612 && e <= 8613 || e === 8614 || e >= 8615 && e <= 8621 || e === 8622 || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || e === 8658 || e === 8659 || e === 8660 || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || e === 8968 || e === 8969 || e === 8970 || e === 8971 || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || e === 9001 || e === 9002 || e >= 9003 && e <= 9083 || e === 9084 || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || e === 9655 || e >= 9656 && e <= 9664 || e === 9665 || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || e === 9839 || e >= 9840 && e <= 10087 || e === 10088 || e === 10089 || e === 10090 || e === 10091 || e === 10092 || e === 10093 || e === 10094 || e === 10095 || e === 10096 || e === 10097 || e === 10098 || e === 10099 || e === 10100 || e === 10101 || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || e === 10181 || e === 10182 || e >= 10183 && e <= 10213 || e === 10214 || e === 10215 || e === 10216 || e === 10217 || e === 10218 || e === 10219 || e === 10220 || e === 10221 || e === 10222 || e === 10223 || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || e === 10627 || e === 10628 || e === 10629 || e === 10630 || e === 10631 || e === 10632 || e === 10633 || e === 10634 || e === 10635 || e === 10636 || e === 10637 || e === 10638 || e === 10639 || e === 10640 || e === 10641 || e === 10642 || e === 10643 || e === 10644 || e === 10645 || e === 10646 || e === 10647 || e === 10648 || e >= 10649 && e <= 10711 || e === 10712 || e === 10713 || e === 10714 || e === 10715 || e >= 10716 && e <= 10747 || e === 10748 || e === 10749 || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || e === 11158 || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || e === 11778 || e === 11779 || e === 11780 || e === 11781 || e >= 11782 && e <= 11784 || e === 11785 || e === 11786 || e === 11787 || e === 11788 || e === 11789 || e >= 11790 && e <= 11798 || e === 11799 || e >= 11800 && e <= 11801 || e === 11802 || e === 11803 || e === 11804 || e === 11805 || e >= 11806 && e <= 11807 || e === 11808 || e === 11809 || e === 11810 || e === 11811 || e === 11812 || e === 11813 || e === 11814 || e === 11815 || e === 11816 || e === 11817 || e >= 11818 && e <= 11822 || e === 11823 || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || e === 11840 || e === 11841 || e === 11842 || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || e === 11858 || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || e === 12296 || e === 12297 || e === 12298 || e === 12299 || e === 12300 || e === 12301 || e === 12302 || e === 12303 || e === 12304 || e === 12305 || e >= 12306 && e <= 12307 || e === 12308 || e === 12309 || e === 12310 || e === 12311 || e === 12312 || e === 12313 || e === 12314 || e === 12315 || e === 12316 || e === 12317 || e >= 12318 && e <= 12319 || e === 12320 || e === 12336 || e === 64830 || e === 64831 || e >= 65093 && e <= 65094;
}
function Jn(e) {
  e.forEach(function(t) {
    if (delete t.location, Gi(t) || ji(t))
      for (var n in t.options)
        delete t.options[n].location, Jn(t.options[n].value);
    else
      xi(t) && Vi(t.style) || (Ui(t) || Fi(t)) && Vn(t.style) ? delete t.style.location : qi(t) && Jn(t.children);
  });
}
function pu(e, t) {
  t === void 0 && (t = {}), t = R({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, t);
  var n = new hu(e, t).parse();
  if (n.err) {
    var r = SyntaxError(H[n.err.kind]);
    throw r.location = n.err.location, r.originalMessage = n.err.message, r;
  }
  return t != null && t.captureLocation || Jn(n.val), n.val;
}
function Hn(e, t) {
  var n = t && t.cache ? t.cache : Eu, r = t && t.serializer ? t.serializer : wu, i = t && t.strategy ? t.strategy : bu;
  return i(e, {
    cache: n,
    serializer: r
  });
}
function gu(e) {
  return e == null || typeof e == "number" || typeof e == "boolean";
}
function Ki(e, t, n, r) {
  var i = gu(r) ? r : n(r), s = t.get(i);
  return typeof s > "u" && (s = e.call(this, r), t.set(i, s)), s;
}
function $i(e, t, n) {
  var r = Array.prototype.slice.call(arguments, 3), i = n(r), s = t.get(i);
  return typeof s > "u" && (s = e.apply(this, r), t.set(i, s)), s;
}
function nr(e, t, n, r, i) {
  return n.bind(t, e, r, i);
}
function bu(e, t) {
  var n = e.length === 1 ? Ki : $i;
  return nr(e, this, n, t.cache.create(), t.serializer);
}
function yu(e, t) {
  return nr(e, this, $i, t.cache.create(), t.serializer);
}
function vu(e, t) {
  return nr(e, this, Ki, t.cache.create(), t.serializer);
}
var wu = function() {
  return JSON.stringify(arguments);
};
function rr() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
rr.prototype.get = function(e) {
  return this.cache[e];
};
rr.prototype.set = function(e, t) {
  this.cache[e] = t;
};
var Eu = {
  create: function() {
    return new rr();
  }
}, Pn = {
  variadic: yu,
  monadic: vu
}, ht;
(function(e) {
  e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API";
})(ht || (ht = {}));
var Kt = (
  /** @class */
  function(e) {
    Yt(t, e);
    function t(n, r, i) {
      var s = e.call(this, n) || this;
      return s.code = r, s.originalMessage = i, s;
    }
    return t.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, t;
  }(Error)
), ti = (
  /** @class */
  function(e) {
    Yt(t, e);
    function t(n, r, i, s) {
      return e.call(this, 'Invalid values for "'.concat(n, '": "').concat(r, '". Options are "').concat(Object.keys(i).join('", "'), '"'), ht.INVALID_VALUE, s) || this;
    }
    return t;
  }(Kt)
), Su = (
  /** @class */
  function(e) {
    Yt(t, e);
    function t(n, r, i) {
      return e.call(this, 'Value for "'.concat(n, '" must be of type ').concat(r), ht.INVALID_VALUE, i) || this;
    }
    return t;
  }(Kt)
), Tu = (
  /** @class */
  function(e) {
    Yt(t, e);
    function t(n, r) {
      return e.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(r, '"'), ht.MISSING_VALUE, r) || this;
    }
    return t;
  }(Kt)
), $;
(function(e) {
  e[e.literal = 0] = "literal", e[e.object = 1] = "object";
})($ || ($ = {}));
function Bu(e) {
  return e.length < 2 ? e : e.reduce(function(t, n) {
    var r = t[t.length - 1];
    return !r || r.type !== $.literal || n.type !== $.literal ? t.push(n) : r.value += n.value, t;
  }, []);
}
function Au(e) {
  return typeof e == "function";
}
function jt(e, t, n, r, i, s, l) {
  if (e.length === 1 && Zr(e[0]))
    return [
      {
        type: $.literal,
        value: e[0].value
      }
    ];
  for (var a = [], o = 0, u = e; o < u.length; o++) {
    var f = u[o];
    if (Zr(f)) {
      a.push({
        type: $.literal,
        value: f.value
      });
      continue;
    }
    if (ja(f)) {
      typeof s == "number" && a.push({
        type: $.literal,
        value: n.getNumberFormat(t).format(s)
      });
      continue;
    }
    var h = f.value;
    if (!(i && h in i))
      throw new Tu(h, l);
    var c = i[h];
    if (Ga(f)) {
      (!c || typeof c == "string" || typeof c == "number") && (c = typeof c == "string" || typeof c == "number" ? String(c) : ""), a.push({
        type: typeof c == "string" ? $.literal : $.object,
        value: c
      });
      continue;
    }
    if (Ui(f)) {
      var _ = typeof f.style == "string" ? r.date[f.style] : Vn(f.style) ? f.style.parsedOptions : void 0;
      a.push({
        type: $.literal,
        value: n.getDateTimeFormat(t, _).format(c)
      });
      continue;
    }
    if (Fi(f)) {
      var _ = typeof f.style == "string" ? r.time[f.style] : Vn(f.style) ? f.style.parsedOptions : r.time.medium;
      a.push({
        type: $.literal,
        value: n.getDateTimeFormat(t, _).format(c)
      });
      continue;
    }
    if (xi(f)) {
      var _ = typeof f.style == "string" ? r.number[f.style] : Vi(f.style) ? f.style.parsedOptions : void 0;
      _ && _.scale && (c = c * (_.scale || 1)), a.push({
        type: $.literal,
        value: n.getNumberFormat(t, _).format(c)
      });
      continue;
    }
    if (qi(f)) {
      var m = f.children, y = f.value, w = i[y];
      if (!Au(w))
        throw new Su(y, "function", l);
      var p = jt(m, t, n, r, i, s), S = w(p.map(function(L) {
        return L.value;
      }));
      Array.isArray(S) || (S = [S]), a.push.apply(a, S.map(function(L) {
        return {
          type: typeof L == "string" ? $.literal : $.object,
          value: L
        };
      }));
    }
    if (Gi(f)) {
      var g = f.options[c] || f.options.other;
      if (!g)
        throw new ti(f.value, c, Object.keys(f.options), l);
      a.push.apply(a, jt(g.value, t, n, r, i));
      continue;
    }
    if (ji(f)) {
      var g = f.options["=".concat(c)];
      if (!g) {
        if (!Intl.PluralRules)
          throw new Kt(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, ht.MISSING_INTL_API, l);
        var E = n.getPluralRules(t, { type: f.pluralType }).select(c - (f.offset || 0));
        g = f.options[E] || f.options.other;
      }
      if (!g)
        throw new ti(f.value, c, Object.keys(f.options), l);
      a.push.apply(a, jt(g.value, t, n, r, i, c - (f.offset || 0)));
      continue;
    }
  }
  return Bu(a);
}
function ku(e, t) {
  return t ? R(R(R({}, e || {}), t || {}), Object.keys(e).reduce(function(n, r) {
    return n[r] = R(R({}, e[r]), t[r] || {}), n;
  }, {})) : e;
}
function Hu(e, t) {
  return t ? Object.keys(e).reduce(function(n, r) {
    return n[r] = ku(e[r], t[r]), n;
  }, R({}, e)) : e;
}
function Nn(e) {
  return {
    create: function() {
      return {
        get: function(t) {
          return e[t];
        },
        set: function(t, n) {
          e[t] = n;
        }
      };
    }
  };
}
function Pu(e) {
  return e === void 0 && (e = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: Hn(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.NumberFormat).bind.apply(t, An([void 0], n, !1)))();
    }, {
      cache: Nn(e.number),
      strategy: Pn.variadic
    }),
    getDateTimeFormat: Hn(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.DateTimeFormat).bind.apply(t, An([void 0], n, !1)))();
    }, {
      cache: Nn(e.dateTime),
      strategy: Pn.variadic
    }),
    getPluralRules: Hn(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.PluralRules).bind.apply(t, An([void 0], n, !1)))();
    }, {
      cache: Nn(e.pluralRules),
      strategy: Pn.variadic
    })
  };
}
var Nu = (
  /** @class */
  function() {
    function e(t, n, r, i) {
      var s = this;
      if (n === void 0 && (n = e.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(l) {
        var a = s.formatToParts(l);
        if (a.length === 1)
          return a[0].value;
        var o = a.reduce(function(u, f) {
          return !u.length || f.type !== $.literal || typeof u[u.length - 1] != "string" ? u.push(f.value) : u[u.length - 1] += f.value, u;
        }, []);
        return o.length <= 1 ? o[0] || "" : o;
      }, this.formatToParts = function(l) {
        return jt(s.ast, s.locales, s.formatters, s.formats, l, void 0, s.message);
      }, this.resolvedOptions = function() {
        return {
          locale: s.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return s.ast;
      }, this.locales = n, this.resolvedLocale = e.resolveLocale(n), typeof t == "string") {
        if (this.message = t, !e.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = e.__parse(t, {
          ignoreTag: i == null ? void 0 : i.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = t;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = Hu(e.formats, r), this.formatters = i && i.formatters || Pu(this.formatterCache);
    }
    return Object.defineProperty(e, "defaultLocale", {
      get: function() {
        return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), e.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), e.memoizedDefaultLocale = null, e.resolveLocale = function(t) {
      var n = Intl.NumberFormat.supportedLocalesOf(t);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof t == "string" ? t : t[0]);
    }, e.__parse = pu, e.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, e;
  }()
);
function Cu(e, t) {
  if (t == null)
    return;
  if (t in e)
    return e[t];
  const n = t.split(".");
  let r = e;
  for (let i = 0; i < n.length; i++)
    if (typeof r == "object") {
      if (i > 0) {
        const s = n.slice(i, n.length).join(".");
        if (s in r) {
          r = r[s];
          break;
        }
      }
      r = r[n[i]];
    } else
      r = void 0;
  return r;
}
const De = {}, Iu = (e, t, n) => n && (t in De || (De[t] = {}), e in De[t] || (De[t][e] = n), n), es = (e, t) => {
  if (t == null)
    return;
  if (t in De && e in De[t])
    return De[t][e];
  const n = $t(t);
  for (let r = 0; r < n.length; r++) {
    const i = n[r], s = Lu(i, e);
    if (s)
      return Iu(e, t, s);
  }
};
let ir;
const Ht = kt({});
function Ou(e) {
  return ir[e] || null;
}
function ts(e) {
  return e in ir;
}
function Lu(e, t) {
  if (!ts(e))
    return null;
  const n = Ou(e);
  return Cu(n, t);
}
function Mu(e) {
  if (e == null)
    return;
  const t = $t(e);
  for (let n = 0; n < t.length; n++) {
    const r = t[n];
    if (ts(r))
      return r;
  }
}
function Ru(e, ...t) {
  delete De[e], Ht.update((n) => (n[e] = Fa.all([n[e] || {}, ...t]), n));
}
dt(
  [Ht],
  ([e]) => Object.keys(e)
);
Ht.subscribe((e) => ir = e);
const qt = {};
function Du(e, t) {
  qt[e].delete(t), qt[e].size === 0 && delete qt[e];
}
function ns(e) {
  return qt[e];
}
function xu(e) {
  return $t(e).map((t) => {
    const n = ns(t);
    return [t, n ? [...n] : []];
  }).filter(([, t]) => t.length > 0);
}
function Qn(e) {
  return e == null ? !1 : $t(e).some(
    (t) => {
      var n;
      return (n = ns(t)) == null ? void 0 : n.size;
    }
  );
}
function Uu(e, t) {
  return Promise.all(
    t.map((r) => (Du(e, r), r().then((i) => i.default || i)))
  ).then((r) => Ru(e, ...r));
}
const wt = {};
function rs(e) {
  if (!Qn(e))
    return e in wt ? wt[e] : Promise.resolve();
  const t = xu(e);
  return wt[e] = Promise.all(
    t.map(
      ([n, r]) => Uu(n, r)
    )
  ).then(() => {
    if (Qn(e))
      return rs(e);
    delete wt[e];
  }), wt[e];
}
const Fu = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, Gu = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: Fu,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, ju = Gu;
function _t() {
  return ju;
}
const Cn = kt(!1);
var qu = Object.defineProperty, Vu = Object.defineProperties, zu = Object.getOwnPropertyDescriptors, ni = Object.getOwnPropertySymbols, Xu = Object.prototype.hasOwnProperty, Wu = Object.prototype.propertyIsEnumerable, ri = (e, t, n) => t in e ? qu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, Zu = (e, t) => {
  for (var n in t || (t = {}))
    Xu.call(t, n) && ri(e, n, t[n]);
  if (ni)
    for (var n of ni(t))
      Wu.call(t, n) && ri(e, n, t[n]);
  return e;
}, Ju = (e, t) => Vu(e, zu(t));
let Yn;
const zt = kt(null);
function ii(e) {
  return e.split("-").map((t, n, r) => r.slice(0, n + 1).join("-")).reverse();
}
function $t(e, t = _t().fallbackLocale) {
  const n = ii(e);
  return t ? [.../* @__PURE__ */ new Set([...n, ...ii(t)])] : n;
}
function $e() {
  return Yn ?? void 0;
}
zt.subscribe((e) => {
  Yn = e ?? void 0, typeof window < "u" && e != null && document.documentElement.setAttribute("lang", e);
});
const Qu = (e) => {
  if (e && Mu(e) && Qn(e)) {
    const { loadingDelay: t } = _t();
    let n;
    return typeof window < "u" && $e() != null && t ? n = window.setTimeout(
      () => Cn.set(!0),
      t
    ) : Cn.set(!0), rs(e).then(() => {
      zt.set(e);
    }).finally(() => {
      clearTimeout(n), Cn.set(!1);
    });
  }
  return zt.set(e);
}, Pt = Ju(Zu({}, zt), {
  set: Qu
}), en = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (r) => {
    const i = JSON.stringify(r);
    return i in t ? t[i] : t[i] = e(r);
  };
};
var Yu = Object.defineProperty, Xt = Object.getOwnPropertySymbols, is = Object.prototype.hasOwnProperty, ss = Object.prototype.propertyIsEnumerable, si = (e, t, n) => t in e ? Yu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, sr = (e, t) => {
  for (var n in t || (t = {}))
    is.call(t, n) && si(e, n, t[n]);
  if (Xt)
    for (var n of Xt(t))
      ss.call(t, n) && si(e, n, t[n]);
  return e;
}, pt = (e, t) => {
  var n = {};
  for (var r in e)
    is.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && Xt)
    for (var r of Xt(e))
      t.indexOf(r) < 0 && ss.call(e, r) && (n[r] = e[r]);
  return n;
};
const At = (e, t) => {
  const { formats: n } = _t();
  if (e in n && t in n[e])
    return n[e][t];
  throw new Error(`[svelte-i18n] Unknown "${t}" ${e} format.`);
}, Ku = en(
  (e) => {
    var t = e, { locale: n, format: r } = t, i = pt(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return r && (i = At("number", r)), new Intl.NumberFormat(n, i);
  }
), $u = en(
  (e) => {
    var t = e, { locale: n, format: r } = t, i = pt(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return r ? i = At("date", r) : Object.keys(i).length === 0 && (i = At("date", "short")), new Intl.DateTimeFormat(n, i);
  }
), ef = en(
  (e) => {
    var t = e, { locale: n, format: r } = t, i = pt(t, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return r ? i = At("time", r) : Object.keys(i).length === 0 && (i = At("time", "short")), new Intl.DateTimeFormat(n, i);
  }
), tf = (e = {}) => {
  var t = e, {
    locale: n = $e()
  } = t, r = pt(t, [
    "locale"
  ]);
  return Ku(sr({ locale: n }, r));
}, nf = (e = {}) => {
  var t = e, {
    locale: n = $e()
  } = t, r = pt(t, [
    "locale"
  ]);
  return $u(sr({ locale: n }, r));
}, rf = (e = {}) => {
  var t = e, {
    locale: n = $e()
  } = t, r = pt(t, [
    "locale"
  ]);
  return ef(sr({ locale: n }, r));
}, sf = en(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (e, t = $e()) => new Nu(e, t, _t().formats, {
    ignoreTag: _t().ignoreTag
  })
), of = (e, t = {}) => {
  var n, r, i, s;
  let l = t;
  typeof e == "object" && (l = e, e = l.id);
  const {
    values: a,
    locale: o = $e(),
    default: u
  } = l;
  if (o == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let f = es(e, o);
  if (!f)
    f = (s = (i = (r = (n = _t()).handleMissingMessage) == null ? void 0 : r.call(n, { locale: o, id: e, defaultValue: u })) != null ? i : u) != null ? s : e;
  else if (typeof f != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${e}" must be of type "string", found: "${typeof f}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), f;
  if (!a)
    return f;
  let h = f;
  try {
    h = sf(f, o).format(a);
  } catch (c) {
    c instanceof Error && console.warn(
      `[svelte-i18n] Message "${e}" has syntax error:`,
      c.message
    );
  }
  return h;
}, lf = (e, t) => rf(t).format(e), af = (e, t) => nf(t).format(e), uf = (e, t) => tf(t).format(e), ff = (e, t = $e()) => es(e, t);
dt([Pt, Ht], () => of);
dt([Pt], () => lf);
dt([Pt], () => af);
dt([Pt], () => uf);
dt([Pt, Ht], () => ff);
const {
  SvelteComponent: cf,
  append: ie,
  attr: Xe,
  detach: os,
  element: We,
  init: hf,
  insert: ls,
  noop: oi,
  safe_not_equal: _f,
  set_data: Wt,
  set_style: In,
  space: Kn,
  text: ot,
  toggle_class: li
} = window.__gradio__svelte__internal, { onMount: df, createEventDispatcher: mf, getContext: pf } = window.__gradio__svelte__internal;
function ai(e) {
  let t, n, r, i, s = Et(
    /*file_to_display*/
    e[2]
  ) + "", l, a, o, u, f = (
    /*file_to_display*/
    e[2].orig_name + ""
  ), h;
  return {
    c() {
      t = We("div"), n = We("span"), r = We("div"), i = We("progress"), l = ot(s), o = Kn(), u = We("span"), h = ot(f), In(i, "visibility", "hidden"), In(i, "height", "0"), In(i, "width", "0"), i.value = a = Et(
        /*file_to_display*/
        e[2]
      ), Xe(i, "max", "100"), Xe(i, "class", "svelte-cr2edf"), Xe(r, "class", "progress-bar svelte-cr2edf"), Xe(u, "class", "file-name svelte-cr2edf"), Xe(t, "class", "file svelte-cr2edf");
    },
    m(c, _) {
      ls(c, t, _), ie(t, n), ie(n, r), ie(r, i), ie(i, l), ie(t, o), ie(t, u), ie(u, h);
    },
    p(c, _) {
      _ & /*file_to_display*/
      4 && s !== (s = Et(
        /*file_to_display*/
        c[2]
      ) + "") && Wt(l, s), _ & /*file_to_display*/
      4 && a !== (a = Et(
        /*file_to_display*/
        c[2]
      )) && (i.value = a), _ & /*file_to_display*/
      4 && f !== (f = /*file_to_display*/
      c[2].orig_name + "") && Wt(h, f);
    },
    d(c) {
      c && os(t);
    }
  };
}
function gf(e) {
  let t, n, r, i = (
    /*files_with_progress*/
    e[0].length + ""
  ), s, l, a = (
    /*files_with_progress*/
    e[0].length > 1 ? "files" : "file"
  ), o, u, f, h = (
    /*file_to_display*/
    e[2] && ai(e)
  );
  return {
    c() {
      t = We("div"), n = We("span"), r = ot("Uploading "), s = ot(i), l = Kn(), o = ot(a), u = ot("..."), f = Kn(), h && h.c(), Xe(n, "class", "uploading svelte-cr2edf"), Xe(t, "class", "wrap svelte-cr2edf"), li(
        t,
        "progress",
        /*progress*/
        e[1]
      );
    },
    m(c, _) {
      ls(c, t, _), ie(t, n), ie(n, r), ie(n, s), ie(n, l), ie(n, o), ie(n, u), ie(t, f), h && h.m(t, null);
    },
    p(c, [_]) {
      _ & /*files_with_progress*/
      1 && i !== (i = /*files_with_progress*/
      c[0].length + "") && Wt(s, i), _ & /*files_with_progress*/
      1 && a !== (a = /*files_with_progress*/
      c[0].length > 1 ? "files" : "file") && Wt(o, a), /*file_to_display*/
      c[2] ? h ? h.p(c, _) : (h = ai(c), h.c(), h.m(t, null)) : h && (h.d(1), h = null), _ & /*progress*/
      2 && li(
        t,
        "progress",
        /*progress*/
        c[1]
      );
    },
    i: oi,
    o: oi,
    d(c) {
      c && os(t), h && h.d();
    }
  };
}
function Et(e) {
  return e.progress * 100 / (e.size || 0) || 0;
}
function bf(e) {
  let t = 0;
  return e.forEach((n) => {
    t += Et(n);
  }), document.documentElement.style.setProperty("--upload-progress-width", (t / e.length).toFixed(2) + "%"), t / e.length;
}
function yf(e, t, n) {
  let { upload_id: r } = t, { root: i } = t, { files: s } = t, l, a = !1, o, u, f = s.map((m) => ({ ...m, progress: 0 }));
  const h = mf();
  function c(m, y) {
    n(0, f = f.map((w) => (w.orig_name === m && (w.progress += y), w)));
  }
  const _ = pf("EventSource_factory");
  return df(() => {
    l = _(new URL(`${i}/upload_progress?upload_id=${r}`)), l.onmessage = async function(m) {
      const y = JSON.parse(m.data);
      a || n(1, a = !0), y.msg === "done" ? (l.close(), h("done")) : (n(6, o = y), c(y.orig_name, y.chunk_size));
    };
  }), e.$$set = (m) => {
    "upload_id" in m && n(3, r = m.upload_id), "root" in m && n(4, i = m.root), "files" in m && n(5, s = m.files);
  }, e.$$.update = () => {
    e.$$.dirty & /*files_with_progress*/
    1 && bf(f), e.$$.dirty & /*current_file_upload, files_with_progress*/
    65 && n(2, u = o || f[0]);
  }, [
    f,
    a,
    u,
    r,
    i,
    s,
    o
  ];
}
class vf extends cf {
  constructor(t) {
    super(), hf(this, t, yf, gf, _f, { upload_id: 3, root: 4, files: 5 });
  }
}
const {
  SvelteComponent: wf,
  append: ui,
  attr: Q,
  binding_callbacks: Ef,
  bubble: qe,
  check_outros: as,
  create_component: Sf,
  create_slot: us,
  destroy_component: Tf,
  detach: tn,
  element: $n,
  empty: fs,
  get_all_dirty_from_scope: cs,
  get_slot_changes: hs,
  group_outros: _s,
  init: Bf,
  insert: nn,
  listen: fe,
  mount_component: Af,
  prevent_default: Ve,
  run_all: kf,
  safe_not_equal: Hf,
  set_style: ds,
  space: Pf,
  stop_propagation: ze,
  toggle_class: Y,
  transition_in: xe,
  transition_out: Qe,
  update_slot_base: ms
} = window.__gradio__svelte__internal, { createEventDispatcher: Nf, tick: Cf, getContext: If } = window.__gradio__svelte__internal;
function Of(e) {
  let t, n, r, i, s, l, a, o, u, f;
  const h = (
    /*#slots*/
    e[22].default
  ), c = us(
    h,
    e,
    /*$$scope*/
    e[21],
    null
  );
  return {
    c() {
      t = $n("button"), c && c.c(), n = Pf(), r = $n("input"), Q(r, "aria-label", "file upload"), Q(r, "data-testid", "file-upload"), Q(r, "type", "file"), Q(
        r,
        "accept",
        /*accept_file_types*/
        e[12]
      ), r.multiple = i = /*file_count*/
      e[5] === "multiple" || void 0, Q(r, "webkitdirectory", s = /*file_count*/
      e[5] === "directory" || void 0), Q(r, "mozdirectory", l = /*file_count*/
      e[5] === "directory" || void 0), Q(r, "class", "svelte-1aq8tno"), Q(t, "tabindex", a = /*hidden*/
      e[7] ? -1 : 0), Q(t, "class", "svelte-1aq8tno"), Y(
        t,
        "hidden",
        /*hidden*/
        e[7]
      ), Y(
        t,
        "center",
        /*center*/
        e[3]
      ), Y(
        t,
        "boundedheight",
        /*boundedheight*/
        e[2]
      ), Y(
        t,
        "flex",
        /*flex*/
        e[4]
      ), ds(t, "height", "100%");
    },
    m(_, m) {
      nn(_, t, m), c && c.m(t, null), ui(t, n), ui(t, r), e[30](r), o = !0, u || (f = [
        fe(
          r,
          "change",
          /*load_files_from_upload*/
          e[15]
        ),
        fe(t, "drag", ze(Ve(
          /*drag_handler*/
          e[23]
        ))),
        fe(t, "dragstart", ze(Ve(
          /*dragstart_handler*/
          e[24]
        ))),
        fe(t, "dragend", ze(Ve(
          /*dragend_handler*/
          e[25]
        ))),
        fe(t, "dragover", ze(Ve(
          /*dragover_handler*/
          e[26]
        ))),
        fe(t, "dragenter", ze(Ve(
          /*dragenter_handler*/
          e[27]
        ))),
        fe(t, "dragleave", ze(Ve(
          /*dragleave_handler*/
          e[28]
        ))),
        fe(t, "drop", ze(Ve(
          /*drop_handler*/
          e[29]
        ))),
        fe(
          t,
          "click",
          /*open_file_upload*/
          e[9]
        ),
        fe(
          t,
          "drop",
          /*loadFilesFromDrop*/
          e[16]
        ),
        fe(
          t,
          "dragenter",
          /*updateDragging*/
          e[14]
        ),
        fe(
          t,
          "dragleave",
          /*updateDragging*/
          e[14]
        )
      ], u = !0);
    },
    p(_, m) {
      c && c.p && (!o || m[0] & /*$$scope*/
      2097152) && ms(
        c,
        h,
        _,
        /*$$scope*/
        _[21],
        o ? hs(
          h,
          /*$$scope*/
          _[21],
          m,
          null
        ) : cs(
          /*$$scope*/
          _[21]
        ),
        null
      ), (!o || m[0] & /*accept_file_types*/
      4096) && Q(
        r,
        "accept",
        /*accept_file_types*/
        _[12]
      ), (!o || m[0] & /*file_count*/
      32 && i !== (i = /*file_count*/
      _[5] === "multiple" || void 0)) && (r.multiple = i), (!o || m[0] & /*file_count*/
      32 && s !== (s = /*file_count*/
      _[5] === "directory" || void 0)) && Q(r, "webkitdirectory", s), (!o || m[0] & /*file_count*/
      32 && l !== (l = /*file_count*/
      _[5] === "directory" || void 0)) && Q(r, "mozdirectory", l), (!o || m[0] & /*hidden*/
      128 && a !== (a = /*hidden*/
      _[7] ? -1 : 0)) && Q(t, "tabindex", a), (!o || m[0] & /*hidden*/
      128) && Y(
        t,
        "hidden",
        /*hidden*/
        _[7]
      ), (!o || m[0] & /*center*/
      8) && Y(
        t,
        "center",
        /*center*/
        _[3]
      ), (!o || m[0] & /*boundedheight*/
      4) && Y(
        t,
        "boundedheight",
        /*boundedheight*/
        _[2]
      ), (!o || m[0] & /*flex*/
      16) && Y(
        t,
        "flex",
        /*flex*/
        _[4]
      );
    },
    i(_) {
      o || (xe(c, _), o = !0);
    },
    o(_) {
      Qe(c, _), o = !1;
    },
    d(_) {
      _ && tn(t), c && c.d(_), e[30](null), u = !1, kf(f);
    }
  };
}
function Lf(e) {
  let t, n, r = !/*hidden*/
  e[7] && fi(e);
  return {
    c() {
      r && r.c(), t = fs();
    },
    m(i, s) {
      r && r.m(i, s), nn(i, t, s), n = !0;
    },
    p(i, s) {
      /*hidden*/
      i[7] ? r && (_s(), Qe(r, 1, 1, () => {
        r = null;
      }), as()) : r ? (r.p(i, s), s[0] & /*hidden*/
      128 && xe(r, 1)) : (r = fi(i), r.c(), xe(r, 1), r.m(t.parentNode, t));
    },
    i(i) {
      n || (xe(r), n = !0);
    },
    o(i) {
      Qe(r), n = !1;
    },
    d(i) {
      i && tn(t), r && r.d(i);
    }
  };
}
function Mf(e) {
  let t, n, r, i, s;
  const l = (
    /*#slots*/
    e[22].default
  ), a = us(
    l,
    e,
    /*$$scope*/
    e[21],
    null
  );
  return {
    c() {
      t = $n("button"), a && a.c(), Q(t, "tabindex", n = /*hidden*/
      e[7] ? -1 : 0), Q(t, "class", "svelte-1aq8tno"), Y(
        t,
        "hidden",
        /*hidden*/
        e[7]
      ), Y(
        t,
        "center",
        /*center*/
        e[3]
      ), Y(
        t,
        "boundedheight",
        /*boundedheight*/
        e[2]
      ), Y(
        t,
        "flex",
        /*flex*/
        e[4]
      ), ds(t, "height", "100%");
    },
    m(o, u) {
      nn(o, t, u), a && a.m(t, null), r = !0, i || (s = fe(
        t,
        "click",
        /*paste_clipboard*/
        e[8]
      ), i = !0);
    },
    p(o, u) {
      a && a.p && (!r || u[0] & /*$$scope*/
      2097152) && ms(
        a,
        l,
        o,
        /*$$scope*/
        o[21],
        r ? hs(
          l,
          /*$$scope*/
          o[21],
          u,
          null
        ) : cs(
          /*$$scope*/
          o[21]
        ),
        null
      ), (!r || u[0] & /*hidden*/
      128 && n !== (n = /*hidden*/
      o[7] ? -1 : 0)) && Q(t, "tabindex", n), (!r || u[0] & /*hidden*/
      128) && Y(
        t,
        "hidden",
        /*hidden*/
        o[7]
      ), (!r || u[0] & /*center*/
      8) && Y(
        t,
        "center",
        /*center*/
        o[3]
      ), (!r || u[0] & /*boundedheight*/
      4) && Y(
        t,
        "boundedheight",
        /*boundedheight*/
        o[2]
      ), (!r || u[0] & /*flex*/
      16) && Y(
        t,
        "flex",
        /*flex*/
        o[4]
      );
    },
    i(o) {
      r || (xe(a, o), r = !0);
    },
    o(o) {
      Qe(a, o), r = !1;
    },
    d(o) {
      o && tn(t), a && a.d(o), i = !1, s();
    }
  };
}
function fi(e) {
  let t, n;
  return t = new vf({
    props: {
      root: (
        /*root*/
        e[6]
      ),
      upload_id: (
        /*upload_id*/
        e[10]
      ),
      files: (
        /*file_data*/
        e[11]
      )
    }
  }), {
    c() {
      Sf(t.$$.fragment);
    },
    m(r, i) {
      Af(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i[0] & /*root*/
      64 && (s.root = /*root*/
      r[6]), i[0] & /*upload_id*/
      1024 && (s.upload_id = /*upload_id*/
      r[10]), i[0] & /*file_data*/
      2048 && (s.files = /*file_data*/
      r[11]), t.$set(s);
    },
    i(r) {
      n || (xe(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Qe(t.$$.fragment, r), n = !1;
    },
    d(r) {
      Tf(t, r);
    }
  };
}
function Rf(e) {
  let t, n, r, i;
  const s = [Mf, Lf, Of], l = [];
  function a(o, u) {
    return (
      /*filetype*/
      o[0] === "clipboard" ? 0 : (
        /*uploading*/
        o[1] ? 1 : 2
      )
    );
  }
  return t = a(e), n = l[t] = s[t](e), {
    c() {
      n.c(), r = fs();
    },
    m(o, u) {
      l[t].m(o, u), nn(o, r, u), i = !0;
    },
    p(o, u) {
      let f = t;
      t = a(o), t === f ? l[t].p(o, u) : (_s(), Qe(l[f], 1, 1, () => {
        l[f] = null;
      }), as(), n = l[t], n ? n.p(o, u) : (n = l[t] = s[t](o), n.c()), xe(n, 1), n.m(r.parentNode, r));
    },
    i(o) {
      i || (xe(n), i = !0);
    },
    o(o) {
      Qe(n), i = !1;
    },
    d(o) {
      o && tn(r), l[t].d(o);
    }
  };
}
function ci(e) {
  let t, n = e[0], r = 1;
  for (; r < e.length; ) {
    const i = e[r], s = e[r + 1];
    if (r += 2, (i === "optionalAccess" || i === "optionalCall") && n == null)
      return;
    i === "access" || i === "optionalAccess" ? (t = n, n = s(n)) : (i === "call" || i === "optionalCall") && (n = s((...l) => n.call(t, ...l)), t = void 0);
  }
  return n;
}
function Df(e, t, n) {
  if (!e || e === "*" || e === "file/*" || Array.isArray(e) && e.some((i) => i === "*" || i === "file/*"))
    return !0;
  let r;
  if (typeof e == "string")
    r = e.split(",").map((i) => i.trim());
  else if (Array.isArray(e))
    r = e;
  else
    return !1;
  return r.includes(t) || r.some((i) => {
    const [s] = i.split("/").map((l) => l.trim());
    return i.endsWith("/*") && n.startsWith(s + "/");
  });
}
function xf(e, t, n) {
  let { $$slots: r = {}, $$scope: i } = t, { filetype: s = null } = t, { dragging: l = !1 } = t, { boundedheight: a = !0 } = t, { center: o = !0 } = t, { flex: u = !0 } = t, { file_count: f = "single" } = t, { disable_click: h = !1 } = t, { root: c } = t, { hidden: _ = !1 } = t, { format: m = "file" } = t, { uploading: y = !1 } = t, w, p, S;
  const g = If("upload_files");
  let E;
  const L = Nf(), v = ["image", "video", "audio", "text", "file"], K = (d) => d.startsWith(".") || d.endsWith("/*") ? d : v.includes(d) ? d + "/*" : "." + d;
  function N() {
    n(17, l = !l);
  }
  function ee() {
    navigator.clipboard.read().then(async (d) => {
      for (let b = 0; b < d.length; b++) {
        const O = d[b].types.find((I) => I.startsWith("image/"));
        if (O) {
          d[b].getType(O).then(async (I) => {
            const te = new File([I], `clipboard.${O.replace("image/", "")}`);
            await se([te]);
          });
          break;
        }
      }
    });
  }
  function ce() {
    h || (n(13, E.value = "", E), E.click());
  }
  async function be(d) {
    await Cf(), n(10, w = Math.random().toString(36).substring(2, 15)), n(1, y = !0);
    const b = await ba(d, c, w, g);
    return L("load", f === "single" ? ci([b, "optionalAccess", (O) => O[0]]) : b), n(1, y = !1), b || [];
  }
  async function se(d) {
    if (!d.length)
      return;
    let b = d.map((O) => new File([O], O.name));
    return n(11, p = await ya(b)), await be(p);
  }
  async function ye(d) {
    const b = d.target;
    if (b.files)
      if (m != "blob")
        await se(Array.from(b.files));
      else {
        if (f === "single") {
          L("load", b.files[0]);
          return;
        }
        L("load", b.files);
      }
  }
  async function Ne(d) {
    if (n(17, l = !1), !ci([d, "access", (O) => O.dataTransfer, "optionalAccess", (O) => O.files]))
      return;
    const b = Array.from(d.dataTransfer.files).filter((O) => {
      const I = "." + O.name.split(".").pop();
      return I && Df(S, I, O.type) || (I && Array.isArray(s) ? s.includes(I) : I === s) ? !0 : (L("error", `Invalid file type only ${s} allowed.`), !1);
    });
    await se(b);
  }
  function oe(d) {
    qe.call(this, e, d);
  }
  function et(d) {
    qe.call(this, e, d);
  }
  function Ue(d) {
    qe.call(this, e, d);
  }
  function tt(d) {
    qe.call(this, e, d);
  }
  function Fe(d) {
    qe.call(this, e, d);
  }
  function T(d) {
    qe.call(this, e, d);
  }
  function V(d) {
    qe.call(this, e, d);
  }
  function X(d) {
    Ef[d ? "unshift" : "push"](() => {
      E = d, n(13, E);
    });
  }
  return e.$$set = (d) => {
    "filetype" in d && n(0, s = d.filetype), "dragging" in d && n(17, l = d.dragging), "boundedheight" in d && n(2, a = d.boundedheight), "center" in d && n(3, o = d.center), "flex" in d && n(4, u = d.flex), "file_count" in d && n(5, f = d.file_count), "disable_click" in d && n(18, h = d.disable_click), "root" in d && n(6, c = d.root), "hidden" in d && n(7, _ = d.hidden), "format" in d && n(19, m = d.format), "uploading" in d && n(1, y = d.uploading), "$$scope" in d && n(21, i = d.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*filetype*/
    1 && (s == null ? n(12, S = null) : typeof s == "string" ? n(12, S = K(s)) : (n(0, s = s.map(K)), n(12, S = s.join(", "))));
  }, [
    s,
    y,
    a,
    o,
    u,
    f,
    c,
    _,
    ee,
    ce,
    w,
    p,
    S,
    E,
    N,
    ye,
    Ne,
    l,
    h,
    m,
    se,
    i,
    r,
    oe,
    et,
    Ue,
    tt,
    Fe,
    T,
    V,
    X
  ];
}
class Uf extends wf {
  constructor(t) {
    super(), Bf(
      this,
      t,
      xf,
      Rf,
      Hf,
      {
        filetype: 0,
        dragging: 17,
        boundedheight: 2,
        center: 3,
        flex: 4,
        file_count: 5,
        disable_click: 18,
        root: 6,
        hidden: 7,
        format: 19,
        uploading: 1,
        paste_clipboard: 8,
        open_file_upload: 9,
        load_files: 20
      },
      null,
      [-1, -1]
    );
  }
  get paste_clipboard() {
    return this.$$.ctx[8];
  }
  get open_file_upload() {
    return this.$$.ctx[9];
  }
  get load_files() {
    return this.$$.ctx[20];
  }
}
const { setContext: Rc, getContext: Ff } = window.__gradio__svelte__internal, Gf = "WORKER_PROXY_CONTEXT_KEY";
function jf() {
  return Ff(Gf);
}
function qf(e) {
  return e.host === window.location.host || e.host === "localhost:7860" || e.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  e.host === "lite.local";
}
function Vf(e, t) {
  const n = t.toLowerCase();
  for (const [r, i] of Object.entries(e))
    if (r.toLowerCase() === n)
      return i;
}
function zf(e) {
  if (e == null)
    return !1;
  const t = new URL(e, window.location.href);
  return !(!qf(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
const {
  SvelteComponent: Xf,
  assign: Zt,
  check_outros: ps,
  compute_rest_props: hi,
  create_slot: or,
  detach: rn,
  element: gs,
  empty: bs,
  exclude_internal_props: Wf,
  get_all_dirty_from_scope: lr,
  get_slot_changes: ar,
  get_spread_update: ys,
  group_outros: vs,
  init: Zf,
  insert: sn,
  listen: ws,
  prevent_default: Jf,
  safe_not_equal: Qf,
  set_attributes: Jt,
  transition_in: Ye,
  transition_out: Ke,
  update_slot_base: ur
} = window.__gradio__svelte__internal, { createEventDispatcher: Yf } = window.__gradio__svelte__internal;
function Kf(e) {
  let t, n, r, i, s;
  const l = (
    /*#slots*/
    e[8].default
  ), a = or(
    l,
    e,
    /*$$scope*/
    e[7],
    null
  );
  let o = [
    { href: (
      /*href*/
      e[0]
    ) },
    {
      target: n = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      e[1]
    ) },
    /*$$restProps*/
    e[6]
  ], u = {};
  for (let f = 0; f < o.length; f += 1)
    u = Zt(u, o[f]);
  return {
    c() {
      t = gs("a"), a && a.c(), Jt(t, u);
    },
    m(f, h) {
      sn(f, t, h), a && a.m(t, null), r = !0, i || (s = ws(
        t,
        "click",
        /*dispatch*/
        e[3].bind(null, "click")
      ), i = !0);
    },
    p(f, h) {
      a && a.p && (!r || h & /*$$scope*/
      128) && ur(
        a,
        l,
        f,
        /*$$scope*/
        f[7],
        r ? ar(
          l,
          /*$$scope*/
          f[7],
          h,
          null
        ) : lr(
          /*$$scope*/
          f[7]
        ),
        null
      ), Jt(t, u = ys(o, [
        (!r || h & /*href*/
        1) && { href: (
          /*href*/
          f[0]
        ) },
        { target: n },
        { rel: "noopener noreferrer" },
        (!r || h & /*download*/
        2) && { download: (
          /*download*/
          f[1]
        ) },
        h & /*$$restProps*/
        64 && /*$$restProps*/
        f[6]
      ]));
    },
    i(f) {
      r || (Ye(a, f), r = !0);
    },
    o(f) {
      Ke(a, f), r = !1;
    },
    d(f) {
      f && rn(t), a && a.d(f), i = !1, s();
    }
  };
}
function $f(e) {
  let t, n, r, i;
  const s = [tc, ec], l = [];
  function a(o, u) {
    return (
      /*is_downloading*/
      o[2] ? 0 : 1
    );
  }
  return t = a(e), n = l[t] = s[t](e), {
    c() {
      n.c(), r = bs();
    },
    m(o, u) {
      l[t].m(o, u), sn(o, r, u), i = !0;
    },
    p(o, u) {
      let f = t;
      t = a(o), t === f ? l[t].p(o, u) : (vs(), Ke(l[f], 1, 1, () => {
        l[f] = null;
      }), ps(), n = l[t], n ? n.p(o, u) : (n = l[t] = s[t](o), n.c()), Ye(n, 1), n.m(r.parentNode, r));
    },
    i(o) {
      i || (Ye(n), i = !0);
    },
    o(o) {
      Ke(n), i = !1;
    },
    d(o) {
      o && rn(r), l[t].d(o);
    }
  };
}
function ec(e) {
  let t, n, r, i;
  const s = (
    /*#slots*/
    e[8].default
  ), l = or(
    s,
    e,
    /*$$scope*/
    e[7],
    null
  );
  let a = [
    /*$$restProps*/
    e[6],
    { href: (
      /*href*/
      e[0]
    ) }
  ], o = {};
  for (let u = 0; u < a.length; u += 1)
    o = Zt(o, a[u]);
  return {
    c() {
      t = gs("a"), l && l.c(), Jt(t, o);
    },
    m(u, f) {
      sn(u, t, f), l && l.m(t, null), n = !0, r || (i = ws(t, "click", Jf(
        /*wasm_click_handler*/
        e[5]
      )), r = !0);
    },
    p(u, f) {
      l && l.p && (!n || f & /*$$scope*/
      128) && ur(
        l,
        s,
        u,
        /*$$scope*/
        u[7],
        n ? ar(
          s,
          /*$$scope*/
          u[7],
          f,
          null
        ) : lr(
          /*$$scope*/
          u[7]
        ),
        null
      ), Jt(t, o = ys(a, [
        f & /*$$restProps*/
        64 && /*$$restProps*/
        u[6],
        (!n || f & /*href*/
        1) && { href: (
          /*href*/
          u[0]
        ) }
      ]));
    },
    i(u) {
      n || (Ye(l, u), n = !0);
    },
    o(u) {
      Ke(l, u), n = !1;
    },
    d(u) {
      u && rn(t), l && l.d(u), r = !1, i();
    }
  };
}
function tc(e) {
  let t;
  const n = (
    /*#slots*/
    e[8].default
  ), r = or(
    n,
    e,
    /*$$scope*/
    e[7],
    null
  );
  return {
    c() {
      r && r.c();
    },
    m(i, s) {
      r && r.m(i, s), t = !0;
    },
    p(i, s) {
      r && r.p && (!t || s & /*$$scope*/
      128) && ur(
        r,
        n,
        i,
        /*$$scope*/
        i[7],
        t ? ar(
          n,
          /*$$scope*/
          i[7],
          s,
          null
        ) : lr(
          /*$$scope*/
          i[7]
        ),
        null
      );
    },
    i(i) {
      t || (Ye(r, i), t = !0);
    },
    o(i) {
      Ke(r, i), t = !1;
    },
    d(i) {
      r && r.d(i);
    }
  };
}
function nc(e) {
  let t, n, r, i, s;
  const l = [$f, Kf], a = [];
  function o(u, f) {
    return f & /*href*/
    1 && (t = null), t == null && (t = !!/*worker_proxy*/
    (u[4] && zf(
      /*href*/
      u[0]
    ))), t ? 0 : 1;
  }
  return n = o(e, -1), r = a[n] = l[n](e), {
    c() {
      r.c(), i = bs();
    },
    m(u, f) {
      a[n].m(u, f), sn(u, i, f), s = !0;
    },
    p(u, [f]) {
      let h = n;
      n = o(u, f), n === h ? a[n].p(u, f) : (vs(), Ke(a[h], 1, 1, () => {
        a[h] = null;
      }), ps(), r = a[n], r ? r.p(u, f) : (r = a[n] = l[n](u), r.c()), Ye(r, 1), r.m(i.parentNode, i));
    },
    i(u) {
      s || (Ye(r), s = !0);
    },
    o(u) {
      Ke(r), s = !1;
    },
    d(u) {
      u && rn(i), a[n].d(u);
    }
  };
}
function rc(e, t, n) {
  const r = ["href", "download"];
  let i = hi(t, r), { $$slots: s = {}, $$scope: l } = t, { href: a = void 0 } = t, { download: o } = t;
  const u = Yf();
  let f = !1;
  const h = jf();
  async function c() {
    if (f)
      return;
    if (u("click"), a == null)
      throw new Error("href is not defined.");
    if (h == null)
      throw new Error("Wasm worker proxy is not available.");
    const m = new URL(a, window.location.href).pathname;
    n(2, f = !0), h.httpRequest({
      method: "GET",
      path: m,
      headers: {},
      query_string: ""
    }).then((y) => {
      if (y.status !== 200)
        throw new Error(`Failed to get file ${m} from the Wasm worker.`);
      const w = new Blob(
        [y.body],
        {
          type: Vf(y.headers, "content-type")
        }
      ), p = URL.createObjectURL(w), S = document.createElement("a");
      S.href = p, S.download = o, S.click(), URL.revokeObjectURL(p);
    }).finally(() => {
      n(2, f = !1);
    });
  }
  return e.$$set = (_) => {
    t = Zt(Zt({}, t), Wf(_)), n(6, i = hi(t, r)), "href" in _ && n(0, a = _.href), "download" in _ && n(1, o = _.download), "$$scope" in _ && n(7, l = _.$$scope);
  }, [
    a,
    o,
    f,
    u,
    h,
    c,
    i,
    l,
    s
  ];
}
class ic extends Xf {
  constructor(t) {
    super(), Zf(this, t, rc, nc, Qf, { href: 0, download: 1 });
  }
}
const {
  SvelteComponent: sc,
  append: On,
  attr: oc,
  check_outros: Ln,
  create_component: Nt,
  destroy_component: Ct,
  detach: lc,
  element: ac,
  group_outros: Mn,
  init: uc,
  insert: fc,
  mount_component: It,
  safe_not_equal: cc,
  set_style: _i,
  space: Rn,
  toggle_class: di,
  transition_in: re,
  transition_out: Te
} = window.__gradio__svelte__internal, { createEventDispatcher: hc } = window.__gradio__svelte__internal;
function mi(e) {
  let t, n;
  return t = new Qt({
    props: {
      Icon: Xs,
      label: (
        /*i18n*/
        e[4]("common.edit")
      )
    }
  }), t.$on(
    "click",
    /*click_handler*/
    e[6]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(r, i) {
      It(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*i18n*/
      16 && (s.label = /*i18n*/
      r[4]("common.edit")), t.$set(s);
    },
    i(r) {
      n || (re(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Te(t.$$.fragment, r), n = !1;
    },
    d(r) {
      Ct(t, r);
    }
  };
}
function pi(e) {
  let t, n;
  return t = new Qt({
    props: {
      Icon: oo,
      label: (
        /*i18n*/
        e[4]("common.undo")
      )
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    e[7]
  ), {
    c() {
      Nt(t.$$.fragment);
    },
    m(r, i) {
      It(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*i18n*/
      16 && (s.label = /*i18n*/
      r[4]("common.undo")), t.$set(s);
    },
    i(r) {
      n || (re(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Te(t.$$.fragment, r), n = !1;
    },
    d(r) {
      Ct(t, r);
    }
  };
}
function gi(e) {
  let t, n;
  return t = new ic({
    props: {
      href: (
        /*download*/
        e[2]
      ),
      download: !0,
      $$slots: { default: [_c] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      Nt(t.$$.fragment);
    },
    m(r, i) {
      It(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*download*/
      4 && (s.href = /*download*/
      r[2]), i & /*$$scope, i18n*/
      528 && (s.$$scope = { dirty: i, ctx: r }), t.$set(s);
    },
    i(r) {
      n || (re(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Te(t.$$.fragment, r), n = !1;
    },
    d(r) {
      Ct(t, r);
    }
  };
}
function _c(e) {
  let t, n;
  return t = new Qt({
    props: {
      Icon: xs,
      label: (
        /*i18n*/
        e[4]("common.download")
      )
    }
  }), {
    c() {
      Nt(t.$$.fragment);
    },
    m(r, i) {
      It(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*i18n*/
      16 && (s.label = /*i18n*/
      r[4]("common.download")), t.$set(s);
    },
    i(r) {
      n || (re(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Te(t.$$.fragment, r), n = !1;
    },
    d(r) {
      Ct(t, r);
    }
  };
}
function dc(e) {
  let t, n, r, i, s, l, a = (
    /*editable*/
    e[0] && mi(e)
  ), o = (
    /*undoable*/
    e[1] && pi(e)
  ), u = (
    /*download*/
    e[2] && gi(e)
  );
  return s = new Qt({
    props: {
      Icon: Ns,
      label: (
        /*i18n*/
        e[4]("common.clear")
      )
    }
  }), s.$on(
    "click",
    /*click_handler_2*/
    e[8]
  ), {
    c() {
      t = ac("div"), a && a.c(), n = Rn(), o && o.c(), r = Rn(), u && u.c(), i = Rn(), Nt(s.$$.fragment), oc(t, "class", "svelte-1wj0ocy"), di(t, "not-absolute", !/*absolute*/
      e[3]), _i(
        t,
        "position",
        /*absolute*/
        e[3] ? "absolute" : "static"
      );
    },
    m(f, h) {
      fc(f, t, h), a && a.m(t, null), On(t, n), o && o.m(t, null), On(t, r), u && u.m(t, null), On(t, i), It(s, t, null), l = !0;
    },
    p(f, [h]) {
      /*editable*/
      f[0] ? a ? (a.p(f, h), h & /*editable*/
      1 && re(a, 1)) : (a = mi(f), a.c(), re(a, 1), a.m(t, n)) : a && (Mn(), Te(a, 1, 1, () => {
        a = null;
      }), Ln()), /*undoable*/
      f[1] ? o ? (o.p(f, h), h & /*undoable*/
      2 && re(o, 1)) : (o = pi(f), o.c(), re(o, 1), o.m(t, r)) : o && (Mn(), Te(o, 1, 1, () => {
        o = null;
      }), Ln()), /*download*/
      f[2] ? u ? (u.p(f, h), h & /*download*/
      4 && re(u, 1)) : (u = gi(f), u.c(), re(u, 1), u.m(t, i)) : u && (Mn(), Te(u, 1, 1, () => {
        u = null;
      }), Ln());
      const c = {};
      h & /*i18n*/
      16 && (c.label = /*i18n*/
      f[4]("common.clear")), s.$set(c), (!l || h & /*absolute*/
      8) && di(t, "not-absolute", !/*absolute*/
      f[3]), h & /*absolute*/
      8 && _i(
        t,
        "position",
        /*absolute*/
        f[3] ? "absolute" : "static"
      );
    },
    i(f) {
      l || (re(a), re(o), re(u), re(s.$$.fragment, f), l = !0);
    },
    o(f) {
      Te(a), Te(o), Te(u), Te(s.$$.fragment, f), l = !1;
    },
    d(f) {
      f && lc(t), a && a.d(), o && o.d(), u && u.d(), Ct(s);
    }
  };
}
function mc(e, t, n) {
  let { editable: r = !1 } = t, { undoable: i = !1 } = t, { download: s = null } = t, { absolute: l = !0 } = t, { i18n: a } = t;
  const o = hc(), u = () => o("edit"), f = () => o("undo"), h = (c) => {
    o("clear"), c.stopPropagation();
  };
  return e.$$set = (c) => {
    "editable" in c && n(0, r = c.editable), "undoable" in c && n(1, i = c.undoable), "download" in c && n(2, s = c.download), "absolute" in c && n(3, l = c.absolute), "i18n" in c && n(4, a = c.i18n);
  }, [
    r,
    i,
    s,
    l,
    a,
    o,
    u,
    f,
    h
  ];
}
class pc extends sc {
  constructor(t) {
    super(), uc(this, t, mc, dc, cc, {
      editable: 0,
      undoable: 1,
      download: 2,
      absolute: 3,
      i18n: 4
    });
  }
}
const {
  SvelteComponent: gc,
  assign: bc,
  attr: it,
  check_outros: bi,
  create_component: gt,
  destroy_component: bt,
  detach: St,
  element: yc,
  empty: vc,
  get_spread_object: wc,
  get_spread_update: Ec,
  group_outros: yi,
  init: Sc,
  insert: Tt,
  mount_component: yt,
  safe_not_equal: Tc,
  space: er,
  src_url_equal: vi,
  transition_in: Be,
  transition_out: ke
} = window.__gradio__svelte__internal, { tick: wi } = window.__gradio__svelte__internal;
function Ei(e) {
  let t, n;
  const r = [
    {
      autoscroll: (
        /*gradio*/
        e[11].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      e[11].i18n
    ) },
    /*loading_status*/
    e[10]
  ];
  let i = {};
  for (let s = 0; s < r.length; s += 1)
    i = bc(i, r[s]);
  return t = new ca({ props: i }), {
    c() {
      gt(t.$$.fragment);
    },
    m(s, l) {
      yt(t, s, l), n = !0;
    },
    p(s, l) {
      const a = l & /*gradio, loading_status*/
      3072 ? Ec(r, [
        l & /*gradio*/
        2048 && {
          autoscroll: (
            /*gradio*/
            s[11].autoscroll
          )
        },
        l & /*gradio*/
        2048 && { i18n: (
          /*gradio*/
          s[11].i18n
        ) },
        l & /*loading_status*/
        1024 && wc(
          /*loading_status*/
          s[10]
        )
      ]) : {};
      t.$set(a);
    },
    i(s) {
      n || (Be(t.$$.fragment, s), n = !0);
    },
    o(s) {
      ke(t.$$.fragment, s), n = !1;
    },
    d(s) {
      bt(t, s);
    }
  };
}
function Bc(e) {
  let t, n;
  return t = new Uf({
    props: {
      filetype: "pdf",
      file_count: "single",
      root: (
        /*root*/
        e[7]
      ),
      $$slots: { default: [kc] },
      $$scope: { ctx: e }
    }
  }), t.$on(
    "load",
    /*handle_upload*/
    e[13]
  ), {
    c() {
      gt(t.$$.fragment);
    },
    m(r, i) {
      yt(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*root*/
      128 && (s.root = /*root*/
      r[7]), i & /*$$scope*/
      16384 && (s.$$scope = { dirty: i, ctx: r }), t.$set(s);
    },
    i(r) {
      n || (Be(t.$$.fragment, r), n = !0);
    },
    o(r) {
      ke(t.$$.fragment, r), n = !1;
    },
    d(r) {
      bt(t, r);
    }
  };
}
function Ac(e) {
  let t, n, r, i, s, l;
  return t = new pc({
    props: {
      i18n: (
        /*gradio*/
        e[11].i18n
      ),
      absolute: !0
    }
  }), t.$on(
    "clear",
    /*handle_clear*/
    e[12]
  ), {
    c() {
      gt(t.$$.fragment), n = er(), r = yc("embed"), vi(r.src, i = /*value*/
      e[1].url) || it(r, "src", i), it(r, "type", "application/pdf"), it(r, "width", "100%"), it(r, "height", s = /*height*/
      e[0] + "px");
    },
    m(a, o) {
      yt(t, a, o), Tt(a, n, o), Tt(a, r, o), l = !0;
    },
    p(a, o) {
      const u = {};
      o & /*gradio*/
      2048 && (u.i18n = /*gradio*/
      a[11].i18n), t.$set(u), (!l || o & /*value*/
      2 && !vi(r.src, i = /*value*/
      a[1].url)) && it(r, "src", i), (!l || o & /*height*/
      1 && s !== (s = /*height*/
      a[0] + "px")) && it(r, "height", s);
    },
    i(a) {
      l || (Be(t.$$.fragment, a), l = !0);
    },
    o(a) {
      ke(t.$$.fragment, a), l = !1;
    },
    d(a) {
      a && (St(n), St(r)), bt(t, a);
    }
  };
}
function kc(e) {
  let t, n;
  return t = new ko({}), {
    c() {
      gt(t.$$.fragment);
    },
    m(r, i) {
      yt(t, r, i), n = !0;
    },
    i(r) {
      n || (Be(t.$$.fragment, r), n = !0);
    },
    o(r) {
      ke(t.$$.fragment, r), n = !1;
    },
    d(r) {
      bt(t, r);
    }
  };
}
function Hc(e) {
  let t, n, r, i, s, l, a, o = (
    /*loading_status*/
    e[10] && Ei(e)
  );
  n = new sl({
    props: {
      show_label: (
        /*label*/
        e[8] !== null
      ),
      Icon: $s,
      float: (
        /*value*/
        e[1] === null
      ),
      label: (
        /*label*/
        e[8] || "File"
      )
    }
  });
  const u = [Ac, Bc], f = [];
  function h(c, _) {
    return (
      /*value*/
      c[1] ? 0 : 1
    );
  }
  return i = h(e), s = f[i] = u[i](e), {
    c() {
      o && o.c(), t = er(), gt(n.$$.fragment), r = er(), s.c(), l = vc();
    },
    m(c, _) {
      o && o.m(c, _), Tt(c, t, _), yt(n, c, _), Tt(c, r, _), f[i].m(c, _), Tt(c, l, _), a = !0;
    },
    p(c, _) {
      /*loading_status*/
      c[10] ? o ? (o.p(c, _), _ & /*loading_status*/
      1024 && Be(o, 1)) : (o = Ei(c), o.c(), Be(o, 1), o.m(t.parentNode, t)) : o && (yi(), ke(o, 1, 1, () => {
        o = null;
      }), bi());
      const m = {};
      _ & /*label*/
      256 && (m.show_label = /*label*/
      c[8] !== null), _ & /*value*/
      2 && (m.float = /*value*/
      c[1] === null), _ & /*label*/
      256 && (m.label = /*label*/
      c[8] || "File"), n.$set(m);
      let y = i;
      i = h(c), i === y ? f[i].p(c, _) : (yi(), ke(f[y], 1, 1, () => {
        f[y] = null;
      }), bi(), s = f[i], s ? s.p(c, _) : (s = f[i] = u[i](c), s.c()), Be(s, 1), s.m(l.parentNode, l));
    },
    i(c) {
      a || (Be(o), Be(n.$$.fragment, c), Be(s), a = !0);
    },
    o(c) {
      ke(o), ke(n.$$.fragment, c), ke(s), a = !1;
    },
    d(c) {
      c && (St(t), St(r), St(l)), o && o.d(c), bt(n, c), f[i].d(c);
    }
  };
}
function Pc(e) {
  let t, n;
  return t = new qo({
    props: {
      visible: (
        /*visible*/
        e[4]
      ),
      elem_id: (
        /*elem_id*/
        e[2]
      ),
      elem_classes: (
        /*elem_classes*/
        e[3]
      ),
      container: (
        /*container*/
        e[5]
      ),
      scale: (
        /*scale*/
        e[6]
      ),
      min_width: (
        /*min_width*/
        e[9]
      ),
      $$slots: { default: [Hc] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      gt(t.$$.fragment);
    },
    m(r, i) {
      yt(t, r, i), n = !0;
    },
    p(r, [i]) {
      const s = {};
      i & /*visible*/
      16 && (s.visible = /*visible*/
      r[4]), i & /*elem_id*/
      4 && (s.elem_id = /*elem_id*/
      r[2]), i & /*elem_classes*/
      8 && (s.elem_classes = /*elem_classes*/
      r[3]), i & /*container*/
      32 && (s.container = /*container*/
      r[5]), i & /*scale*/
      64 && (s.scale = /*scale*/
      r[6]), i & /*min_width*/
      512 && (s.min_width = /*min_width*/
      r[9]), i & /*$$scope, value, height, gradio, root, label, loading_status*/
      19843 && (s.$$scope = { dirty: i, ctx: r }), t.$set(s);
    },
    i(r) {
      n || (Be(t.$$.fragment, r), n = !0);
    },
    o(r) {
      ke(t.$$.fragment, r), n = !1;
    },
    d(r) {
      bt(t, r);
    }
  };
}
function Nc(e, t, n) {
  let { elem_id: r = "" } = t, { elem_classes: i = [] } = t, { visible: s = !0 } = t, { value: l = null } = t, { container: a = !0 } = t, { scale: o = null } = t, { root: u } = t, { height: f = 500 } = t, { label: h } = t, { min_width: c = void 0 } = t, { loading_status: _ } = t, { gradio: m } = t;
  async function y() {
    n(1, l = null), await wi(), m.dispatch("change");
  }
  async function w({ detail: p }) {
    n(1, l = p), await wi(), m.dispatch("change"), m.dispatch("upload");
  }
  return e.$$set = (p) => {
    "elem_id" in p && n(2, r = p.elem_id), "elem_classes" in p && n(3, i = p.elem_classes), "visible" in p && n(4, s = p.visible), "value" in p && n(1, l = p.value), "container" in p && n(5, a = p.container), "scale" in p && n(6, o = p.scale), "root" in p && n(7, u = p.root), "height" in p && n(0, f = p.height), "label" in p && n(8, h = p.label), "min_width" in p && n(9, c = p.min_width), "loading_status" in p && n(10, _ = p.loading_status), "gradio" in p && n(11, m = p.gradio);
  }, e.$$.update = () => {
    e.$$.dirty & /*height*/
    1 && n(0, f = f || 500);
  }, [
    f,
    l,
    r,
    i,
    s,
    a,
    o,
    u,
    h,
    c,
    _,
    m,
    y,
    w
  ];
}
class Dc extends gc {
  constructor(t) {
    super(), Sc(this, t, Nc, Pc, Tc, {
      elem_id: 2,
      elem_classes: 3,
      visible: 4,
      value: 1,
      container: 5,
      scale: 6,
      root: 7,
      height: 0,
      label: 8,
      min_width: 9,
      loading_status: 10,
      gradio: 11
    });
  }
}
export {
  Dc as default
};
