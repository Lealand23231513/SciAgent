
import gradio as gr
from gradio_mypdf import PDF

def fn(pdf):
    gr.Info('hi there!')

def get_timestamp():
    return "timestamp"

with gr.Blocks() as demo:
    pdf = PDF(label="Static", height=1000)
    timeStampDisp = gr.Textbox(label='time stamp', value=get_timestamp, every=1, visible=False)
    pdf.upload(
        fn,
        pdf
    )

if __name__ == "__main__":
    demo.launch()
